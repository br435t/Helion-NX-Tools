#!/usr/bin/env python3
"""Example: call the NXOpen RAG from a program in a DIFFERENT folder.

This file lives in  C:\\Code\\NX Open\\example_client\\  and imports the library
from  C:\\Code\\NX Open\\nxopen_python_ref\\ .

Run:  py use_nxopen.py
"""
import os, sys

# --- make the library importable (Option A: add its folder to sys.path) -----
RAG_DIR = r"C:\Code\NX Open\nxopen_python_ref"
sys.path.insert(0, RAG_DIR)

from nxopen_rag import NXOpenRAG

rag = NXOpenRAG()   # finds bm25_index.pkl next to the module, regardless of cwd

# 1) Pure retrieval — offline, no API key. Great for tooling / autocomplete.
print("== retrieval only ==")
for h in rag.search("create a block feature", k=5):
    print(f"  {h['score']:6.2f}  {h['name']}  [{h['section']}]")

# 2) Full RAG answer from Claude (needs ANTHROPIC_API_KEY / ant login).
if os.environ.get("ANTHROPIC_API_KEY"):
    print("\n== claude answer ==")
    result = rag.ask("How do I create a block feature?", k=8)
    print(result["answer"])
    print("\nsources:")
    for s in result["sources"][:5]:
        print("  ", s["name"], s["url"])
else:
    print("\n(set ANTHROPIC_API_KEY to see the Claude-generated answer)")
