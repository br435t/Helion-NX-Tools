# NXOpen Python — project guide for Claude

This workspace contains a **local, offline knowledge base for the NXOpen Python API
(Siemens NX 2506)** plus a small RAG toolkit around it. Use it whenever the task
involves NXOpen: answering API questions, writing NX automation scripts, or
looking up exact signatures.

## Golden rule: retrieve before you answer

NXOpen is niche and version-specific — do **not** answer NXOpen questions from
training memory. Retrieve the real signatures/docs from the local index first,
then write a grounded answer or script and **cite the source** (a
`docs.sw.siemens.com` URL or a `.pyi` file path).

## The one command you need

Retrieval is fully local — **no API key, no network, no nested Claude call.** Run:

```sh
py "C:\Code\NX Open\nxopen_python_ref\ask.py" --retrieve-only --text -k 8 "your query"
```

This prints the top matching chunks *with full text* — exact Python signatures
(from the `.pyi` stubs) and prose descriptions (from the Doxygen reference).
Read them, then write your answer/code from what they say.

- Drop `--text` to see just a ranked list (name / section / source / URL).
- Raise `-k` (e.g. `-k 15`) when you need broader coverage or many overloads.
- Query with the words that appear in the API: class names, method names, and
  concepts (`CreateExtrudeBuilder`, `extrude sketch section`, `Session work part`).
  The tokenizer splits camelCase, so natural language matches too.

### From Python (when you want structured hits in a script)

```python
import sys; sys.path.insert(0, r"C:\Code\NX Open\nxopen_python_ref")
from nxopen_rag import NXOpenRAG
rag = NXOpenRAG()
for h in rag.search("create a block feature", k=8):
    print(h["name"], h["section"], h["source"], h["url"])
    print(h["text"])
```

## Recommended workflow

1. **Search** with `--retrieve-only --text` for the classes/methods involved.
2. Prefer the **`[stub]`** hit for the exact signature (arg + return types) and the
   **`[doc]`** hit for behavior, "Created in NX…", and license requirements.
3. Write the script/answer grounded in those excerpts; cite the source per claim.
4. If the excerpts don't cover it, say so and widen the query — don't invent API.

## What's here

| Path | What it is |
|------|-----------|
| `nxopen_python_ref/ask.py` | CLI: `--retrieve-only [--text]` (offline) or full Claude answer |
| `nxopen_python_ref/chat.py` | Interactive REPL (needs `ANTHROPIC_API_KEY`) |
| `nxopen_python_ref/nxopen_rag.py` | Importable library: `NXOpenRAG().search()` / `.ask()` / `.stream()` |
| `nxopen_python_ref/nxopen_mcp.py` | MCP server exposing `search_nxopen` (retrieval-only, no key) |
| `nxopen_python_ref/bm25_index.pkl` | Prebuilt BM25 index (219,490 chunks) — already built |
| `nxopen_python_ref/corpus.jsonl` + `md/` | Doxygen reference (7,116 pages) |
| `nxopen_python_ref/stub_chunks.jsonl` | Parsed `.pyi` stub signatures (143,528 chunks) |
| `nxopen_python_ref/README.md` | Full pipeline docs (how it was built / how to rebuild) |

The index is prebuilt and ready — you normally do **not** need to rebuild it.
If the NX version changes, rebuild with:
`py parse_stubs.py && py chunk_corpus.py && py build_index.py` (see the README).

## Environment notes (important)

- **Python launcher is `py`**, not `python`. (`py "C:\...\ask.py" ...`)
- **Console encoding is cp1252.** Don't print Unicode box-drawing/emoji in scripts
  you run here — it raises `UnicodeEncodeError`. Use ASCII (`====`, `--`).
- **Corporate TLS interception (Helion):** only affects the *optional* paths that
  call the network — the Anthropic API (`ask.py` without `--retrieve-only`,
  `chat.py`) needs `ANTHROPIC_API_KEY` and `set SSL_CERT_FILE=<corp-root-ca.pem>`;
  `pip` needs `--trusted-host pypi.org --trusted-host files.pythonhosted.org`.
  **Retrieval (`--retrieve-only`) needs none of this.**

## Using it as an MCP tool (alternative to the CLI)

Instead of shelling out to `ask.py`, this KB can be wired in as an MCP server so
you call it as a native tool. If a tool named **`search_nxopen`** is available in
this session, prefer it over the CLI — same data, same retrieval. Register it with:

```sh
claude mcp add nxopen -- py "C:\Code\NX Open\nxopen_python_ref\nxopen_mcp.py"
```

(Full setup, Claude Desktop config, and troubleshooting: `HowToUseMCP.md`.)

## When to use the Claude-calling paths vs. retrieval-only

You (Claude in this session) should almost always use **`--retrieve-only --text`**
and reason yourself — it's free, offline, and puts the real API surface in your
context. The `ask.py`/`chat.py` paths that call the Anthropic API are for the
*user* running the tool standalone (outside a Claude session), not for you.
