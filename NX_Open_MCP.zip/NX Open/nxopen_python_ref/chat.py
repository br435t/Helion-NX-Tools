#!/usr/bin/env python3
"""Interactive NXOpen API chat — BM25 retrieval + Claude, with memory & streaming.

Thin CLI over nxopen_rag.NXOpenRAG.

Usage:
    py chat.py
    py chat.py -k 10

Commands: /sources  /k N  /reset  /quit   (also Ctrl-D / Ctrl-C)

Auth: set ANTHROPIC_API_KEY, or `ant auth login`. Behind a TLS-inspecting proxy,
set SSL_CERT_FILE to your corporate root CA.
"""
import os, sys, argparse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from nxopen_rag import NXOpenRAG

MAX_TURNS = 6   # keep the last N exchanges as context

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-k", type=int, default=8)
    args = ap.parse_args()
    k = args.k

    print("Loading index…", flush=True)
    rag = NXOpenRAG()
    try:
        _ = rag.client            # trigger client init early to fail fast on auth
    except Exception as e:
        print(f"\nCould not init Anthropic client: {e}\n"
              "Set ANTHROPIC_API_KEY or run `ant auth login`.", file=sys.stderr)
        sys.exit(1)

    print(f"NXOpen chat ready (NX 2506, k={k}). Ask a question, or /quit.\n")
    history, last_hits = [], []

    while True:
        try:
            q = input("you › ").strip()
        except (EOFError, KeyboardInterrupt):
            print(); break
        if not q:
            continue
        if q in ("/quit", "/exit"):
            break
        if q == "/reset":
            history.clear(); print("(history cleared)\n"); continue
        if q.startswith("/k"):
            p = q.split()
            if len(p) == 2 and p[1].isdigit():
                k = int(p[1]); print(f"(k = {k})\n")
            else:
                print("usage: /k N\n")
            continue
        if q == "/sources":
            if not last_hits:
                print("(no question asked yet)\n"); continue
            for h in last_hits:
                print(f"  {h['score']:6.2f}  {h['name']}  [{h['section']}]  {h['url']}")
            print(); continue

        print("\nclaude › ", end="", flush=True)
        try:
            gen = rag.stream(q, k=k, history=history)   # appends to history in place
            last_hits = gen.hits
            for text in gen:
                print(text, end="", flush=True)
        except Exception as e:
            print(f"\n[error: {e}]\n", file=sys.stderr)
            if history and history[-1]["role"] == "user":
                history.pop()
            continue
        print("\n")

        if len(history) > MAX_TURNS * 2:
            history[:] = history[-MAX_TURNS * 2:]

if __name__ == "__main__":
    main()
