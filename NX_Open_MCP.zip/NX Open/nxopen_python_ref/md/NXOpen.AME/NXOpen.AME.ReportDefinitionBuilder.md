# NXOpen.AME.ReportDefinitionBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00090.html>

## Classes

class — Types

the creation type of query 

Enumerator — Comment

NewReportDefinition

FromLibrary

More...

Copyright 2025 Siemens
