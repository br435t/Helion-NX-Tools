# NXOpen.AME.FilterObjectsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00050.html>

## Classes

class — SelectionMethod

choices for selection method 

Enumerator — Comment

Type

List

More...

Copyright 2025 Siemens
