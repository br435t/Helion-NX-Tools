# NXOpen.AME.DB Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00040.html>

Classes, Enums and Structs under NXOpen.AME.DB namespace. 
More...

## Namespaces

namespace — DocumentStructure

## Classes

class — DocumentStructure

Class to define Document Structure object 

This object does not need a creator. More...

## Detailed Description

Classes, Enums and Structs under NXOpen.AME.DB namespace. 

Copyright 2025 Siemens
