# NXOpen.AME.EditEngineeringObjectBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00044.html>

## Classes

class — SourceType

Assign EOs or POUs 

Enumerator — Comment

AssignEos

AssignPous

More...

Copyright 2025 Siemens
