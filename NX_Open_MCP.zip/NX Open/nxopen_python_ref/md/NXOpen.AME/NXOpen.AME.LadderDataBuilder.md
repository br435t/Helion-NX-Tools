# NXOpen.AME.LadderDataBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00058.html>

## Classes

class — Ladders

Represents the type of ladder 

Enumerator — Comment

One

Two

More...

Copyright 2025 Siemens
