# NXOpen.AME.DrawingStandardSettingsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00042.html>

## Classes

class — DrawingStandardType

represents the Drawing Standard type 

Enumerator — Comment

IEC

ANSI

NonStandard

More...

Copyright 2025 Siemens
