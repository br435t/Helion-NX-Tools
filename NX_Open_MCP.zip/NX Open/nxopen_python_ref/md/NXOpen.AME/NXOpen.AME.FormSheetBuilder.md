# NXOpen.AME.FormSheetBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00052.html>

## Classes

class — AnsiStandardMetricSize

Represents standard metric sizes for ANSI form sheet 

Enumerator — Comment

A

B

C

D

E

More...

class — SizeOption

Represents form sheet size option 

Enumerator — Comment

Standard

Custom

More...

class — StandardMetricSize

Represents standard metric sizes for form sheet 

Enumerator — Comment

A4landscape

A3landscape

A2landscape

A1landscape

A0landscape

A4portrait

More...

class — StandardTypes

The types of managing the standard. More...

Copyright 2025 Siemens
