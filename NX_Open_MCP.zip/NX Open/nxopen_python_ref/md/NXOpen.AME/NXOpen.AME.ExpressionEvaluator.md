# NXOpen.AME.ExpressionEvaluator Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00047.html>

## Classes

class — RenderOptions

the render options for evaluators 

Enumerator — Comment

All

Cached

Evaluated

Failed

Unsupported

More...

Copyright 2025 Siemens
