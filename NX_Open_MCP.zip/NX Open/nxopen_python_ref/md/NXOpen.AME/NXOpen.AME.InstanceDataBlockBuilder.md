# NXOpen.AME.InstanceDataBlockBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00055.html>

## Classes

class — ActionType

the idb scope 

Enumerator — Comment

Global

Local

More...

class — CreateMode

the idb create mode 

Enumerator — Comment

Aspect

Library

More...

Copyright 2025 Siemens
