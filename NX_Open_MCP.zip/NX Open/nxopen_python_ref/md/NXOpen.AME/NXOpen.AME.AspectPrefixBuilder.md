# NXOpen.AME.AspectPrefixBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00026.html>

## Classes

class — DelimiterType

represents delimiter type 

Enumerator — Comment

Dot — A dot (.) is used as the delimiter

AspectPrefix — Aspect Prefix is used as the delimiter

NoDelimiter — No delimiter will be used

More...

Copyright 2025 Siemens
