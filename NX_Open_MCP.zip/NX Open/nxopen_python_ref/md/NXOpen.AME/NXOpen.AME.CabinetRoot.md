# NXOpen.AME.CabinetRoot Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00031.html>

## Classes

class — CabinetState

Represents cabinet state 

Enumerator — Comment

Active

Inactive

More...

Copyright 2025 Siemens
