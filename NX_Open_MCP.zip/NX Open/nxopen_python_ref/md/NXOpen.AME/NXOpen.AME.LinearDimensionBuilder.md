# NXOpen.AME.LinearDimensionBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00059.html>

## Classes

class — Dimensionset

Represents the Dimension Set type 

Enumerator — Comment

Single

Chain

Baseline

More...

class — MeasurementDirection

Represents the Direction of Measurement for Dimension. More...

Copyright 2025 Siemens
