# NXOpen.AME.PlcSymbolsEvaluatorBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00082.html>

## Classes

class — FilterType

choices for type filter, can either be tags, instance dbs, function blocks, functions, eplan macros, local variable or all 

Enumerator — Comment

Tags

Idbs

FunctionBlocks

Functions

PageMacros

WindowMacros

CallerInstance

All

LocalVariable

Methods

LocalModules

PlcDataTypes

More...

class — SearchCriteriaByHierarchy

choices for depth criteria 

Enumerator — Comment

All

Levels

More...

Copyright 2025 Siemens
