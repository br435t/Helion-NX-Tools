# NXOpen.AME.SelectAndHighlightBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00092.html>

## Classes

class — SelType

possible choices for selecting of navigator objects in a set 

Enumerator — Comment

TemplateMembers

PagePlacedObjects

ObjectChildren

AspectChildren

GroupMembers

MappedAncestors

SymbolItems

NotSet

More...

Copyright 2025 Siemens
