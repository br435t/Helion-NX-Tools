# NXOpen.AME.PlcRule Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00078.html>

## Classes

class — RefObjectType

type which discribed the context object 

Enumerator — Comment

Statement

Compileunit

Operand

StatementUnit

NotSet

More...

class — ReplacementType

type which defined wich object has to be replaced 

Enumerator — Comment

Replace

Insert

NotSet

More...

class — Type

replace or insert rule Type. More...

Copyright 2025 Siemens
