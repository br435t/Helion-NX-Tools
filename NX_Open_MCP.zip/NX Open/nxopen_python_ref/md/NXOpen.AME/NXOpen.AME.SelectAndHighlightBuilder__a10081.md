# NXOpen.AME.SelectAndHighlightBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10081.html>

Represents a SelectAndHighlightBuilder for select and highlight in the Navigators 

To create a new instance of this class, use NXOpen::AME::AMEManager::SelectAndHighlightBuilder 

More...

Inheritance diagram for NXOpen.AME.SelectAndHighlightBuilder:

## Public Member Functions

SelectHighlightMode (self)

Getter for property: (NXOpen.AME.SelectAndHighlightBuilder.SelType) SelectHighlightMode Returns. 

SelectHighlightMode (self, sel)

Setter for property: (NXOpen.AME.SelectAndHighlightBuilder.SelType) SelectHighlightMode. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

SelectAndHighlightBuilderSelType = SelectAndHighlightBuilder.SelType

NXOpen.AME.SelectAndHighlightBuilderSelType is an alias for NXOpen.AME.SelectAndHighlightBuilder.SelType 

## Detailed Description

Represents a SelectAndHighlightBuilder for select and highlight in the Navigators 

To create a new instance of this class, use NXOpen::AME::AMEManager::SelectAndHighlightBuilder 

Created in NX11.0.0 

## Member Function Documentation

## ◆ SelectHighlightMode() [1/2]

NXOpen.AME.SelectAndHighlightBuilder.SelectHighlightMode
(
self — )

Getter for property: (NXOpen.AME.SelectAndHighlightBuilder.SelType) SelectHighlightMode Returns. 

Getter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Returns
SelectAndHighlightBuilder.SelType 

## ◆ SelectHighlightMode() [2/2]

NXOpen.AME.SelectAndHighlightBuilder.SelectHighlightMode
(
self,

sel )

Setter for property: (NXOpen.AME.SelectAndHighlightBuilder.SelType) SelectHighlightMode. 

Sets

Setter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

## Member Data Documentation

## ◆ SelectAndHighlightBuilderSelType

NXOpen.AME.SelectAndHighlightBuilder.SelectAndHighlightBuilderSelType = SelectAndHighlightBuilder.SelType

NXOpen.AME.SelectAndHighlightBuilderSelType is an alias for NXOpen.AME.SelectAndHighlightBuilder.SelType 

Copyright 2025 Siemens
