# NXOpen.AME.AspectBoxBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00025.html>

## Classes

class — Variant

Represents Aspect Box Variant type 

Enumerator — Comment

Vertical

Horizontal

More...

Copyright 2025 Siemens
