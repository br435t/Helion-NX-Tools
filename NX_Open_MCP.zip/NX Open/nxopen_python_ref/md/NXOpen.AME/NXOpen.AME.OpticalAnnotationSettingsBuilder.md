# NXOpen.AME.OpticalAnnotationSettingsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00073.html>

## Classes

class — AnnotationAttrType

Represents the type of annotations 

Enumerator — Comment

SourceTarget

FiberType

CoreDiameter

CladdingDiameter

ObjectName

CutLength

More...

Copyright 2025 Siemens
