# NXOpen.AME.OrderAspectsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00074.html>

## Classes

class — OrderType

possible choices for order of navigator objects 

Enumerator — Comment

EngineeringObjects

Tag

Channel

UpstreamObjects

Page

Fragment

DocumentStructureNode

ProductComponentCore

ProductComponentBundle

ProductComponent

ConnectorNode

ProductMemoryArea

ProductTag

Product2dsymbolMultilineNode

Product2dsymbolSinglelineNode

Product2dsymbolBusTopologyNode

Product2dsymbolPowerTopologyNode

Product2dsymbolGenericNode

Product3dmodelNode

ProductTemplateLinkNode

EngineeringObjectsWithNoProduct

SymbolVariantNode

InterruptionPoint

TagTable

More...

class — SortType

possible choices for sorting of navigator objects in a set 

Enumerator — Comment

SortbyCreation

SortbyName

More...

Copyright 2025 Siemens
