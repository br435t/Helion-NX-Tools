# NXOpen.AME.PlcStateChartActionBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00079.html>

## Classes

class — ActionType

action type for action dialog. More...

class — MoveAction

the move action enum type 

Enumerator — Comment

Up

Down

More...

class — OperatorType

operator type for state action operators. More...

class — QualifierType

qualifier type for action table editor. More...

Copyright 2025 Siemens
