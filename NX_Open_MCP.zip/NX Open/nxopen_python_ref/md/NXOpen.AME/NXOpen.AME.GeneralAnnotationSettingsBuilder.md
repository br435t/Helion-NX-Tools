# NXOpen.AME.GeneralAnnotationSettingsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00054.html>

## Classes

class — AnnotationSeparator

the separator for annotation set 

Enumerator — Comment

SemiColon

Comma

Multiline

More...

class — HorizontalTextPosition

horizontal text postion type 

Enumerator — Comment

Above

Below

More...

class — SourceAndTargetSeparator

the separator between Source and Target 

Enumerator — Comment

LessthanGreaterthan

SemiColon

More...

class — VerticalTextPosition

verical text postion type 

Enumerator — Comment

Left

Right

More...

Copyright 2025 Siemens
