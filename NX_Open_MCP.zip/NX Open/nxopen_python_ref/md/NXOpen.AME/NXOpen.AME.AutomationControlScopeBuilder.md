# NXOpen.AME.AutomationControlScopeBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00027.html>

## Classes

class — Aspect

Aspect Type for search in descendants 

Enumerator — Comment

Function

Location

Product

Automation

NotSet

More...

Copyright 2025 Siemens
