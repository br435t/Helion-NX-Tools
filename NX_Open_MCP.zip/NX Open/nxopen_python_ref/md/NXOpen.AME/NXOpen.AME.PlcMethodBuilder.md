# NXOpen.AME.PlcMethodBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00077.html>

## Classes

class — ParameterLevelType

the parameter level enum type 

Enumerator — Comment

All

First

Second

Third

More...

Copyright 2025 Siemens
