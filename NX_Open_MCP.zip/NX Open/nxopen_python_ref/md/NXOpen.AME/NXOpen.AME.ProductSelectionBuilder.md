# NXOpen.AME.ProductSelectionBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00087.html>

## Classes

class — Type

the product type for product selection 

Enumerator — Comment

SameEngineeringObjectDefinition

SameClassificationAndMoreDetailedClassification

AllCommonProducts

More...

Copyright 2025 Siemens
