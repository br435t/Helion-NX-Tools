# NXOpen.AME.SortingBlockBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00094.html>

## Classes

class — Order

possible choices for order selection 

Enumerator — Comment

Ascending

Descending

More...

Copyright 2025 Siemens
