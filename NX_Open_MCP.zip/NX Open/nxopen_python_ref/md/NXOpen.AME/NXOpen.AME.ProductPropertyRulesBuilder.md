# NXOpen.AME.ProductPropertyRulesBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00086.html>

## Classes

class — PropertyMergeOption

Represents product properties merging actions on assignment or removal of product 

Enumerator — Comment

Invalid

Yes

No

OnlyIfEmpty

More...

Copyright 2025 Siemens
