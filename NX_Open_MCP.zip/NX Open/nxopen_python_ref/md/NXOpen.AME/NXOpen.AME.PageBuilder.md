# NXOpen.AME.PageBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00075.html>

## Classes

class — Types

Represents the type of page 

Enumerator — Comment

AspectStructureOverview

CableDiagram

CableList

OrderList

PartListBom

PlugList

TableOfContent

TerminalDiagram

TerminalStripList

TitlePage

WireTubeConnectionLists

WireList

MultiLineSchematics

SingleLineSchematics

NetworkTopology

PowerSupplyTopology

ViewPage

FluidicDiagram

CabinetLayout

SummarizeBom

More...

Copyright 2025 Siemens
