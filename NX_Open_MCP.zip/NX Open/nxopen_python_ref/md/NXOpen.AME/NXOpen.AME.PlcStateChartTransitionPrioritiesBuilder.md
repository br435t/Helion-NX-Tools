# NXOpen.AME.PlcStateChartTransitionPrioritiesBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00081.html>

## Classes

class — Moving

Enum of priority direction 

Enumerator — Comment

Up

Down

More...

Copyright 2025 Siemens
