# NXOpen.AME.MountingInterfaceBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00067.html>

## Classes

class — FixingPolicy

Represents component fixing type 

Enumerator — Comment

Point

Face

More...

class — InterfaceType

Represents mounting interface type 

Enumerator — Comment

Fixing

ComponentReceptacle

More...

class — ReceptaclePolicy

Represents component receptacle type 

Enumerator — Comment

Fixed

AxisMovement

PlaneMovement

More...

Copyright 2025 Siemens
