# NXOpen.AME.UpdateObjectsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00099.html>

## Classes

class — ObjectType

Represents the type of input objects 

Enumerator — Comment

Engobject

Product

Symbol

More...

class — Types

Represents the type of input 

Enumerator — Comment

Definition

Query

More...

Copyright 2025 Siemens
