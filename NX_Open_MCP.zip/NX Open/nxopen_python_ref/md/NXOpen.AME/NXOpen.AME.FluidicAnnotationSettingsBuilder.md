# NXOpen.AME.FluidicAnnotationSettingsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00051.html>

## Classes

class — AnnotationAttrType

Represents the type of annotations 

Enumerator — Comment

SourceTarget

ObjectName

Size

ColorCode

CutLength

More...

Copyright 2025 Siemens
