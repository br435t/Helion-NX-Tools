# NXOpen.AME.EditClauseBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00043.html>

## Classes

class — CableAssigmentOperator

the cable assignment operator applied to 

Enumerator — Comment

Equal

More...

class — CableAssigmentValue

the cable assignment value applied to 

Enumerator — Comment

TrueValue

FalseValue

More...

class — MathOperatorsType

the math operators 

Enumerator — Comment

IsEqual

IsNotEqual

IsGreaterThanOrEqual

IsGreaterThan

IsLessThanOrEqual

IsLessThan

More...

class — Operator

the query operator 

Enumerator — Comment

As

Under

OfType

More...

class — ParentPropertyAspect

the selected aspect for parent property 

Enumerator — Comment

FunctionAspect

LocationAspect

ProductAspect

AutomationAspect

More...

class — ProductAssignmentOperator

the product assignment operator applied to 

Enumerator — Comment

Equal

NotEqual

More...

class — ProductAssignmentValue

the product assignment value applied to 

Enumerator — Comment

TrueValue

FalseValue

More...

class — QueryClauseOperatorType

the clause operator 

Enumerator — Comment

And

Or

NotSet

More...

class — QueryConnectedValue

the value true/false 

Enumerator — Comment

TrueValue

FalseValue

More...

class — QueryPortCondition

the property applied to 

Enumerator — Comment

Exists

IsConnected

More...

class — QueryPropertyAppliedTo

the property applied to 

Enumerator — Comment

Classification

LibraryObject

Aspect

General

Tag

More...

class — QueryPropertyOfCategory

the property of aspect 

Enumerator — Comment

FunctionAspect

LocationAspect

ProductAspect

More...

class — QueryPropertyOfClassLibCategory

the property of classification or library item 

Enumerator — Comment

Type

Product

More...

class — Types

the type of object to be used for edit clause 

Enumerator — Comment

Classification

LibraryObject

Aspect

Property

Port

ProductAssignment

ParentProperty

CableAssignment

More...

Copyright 2025 Siemens
