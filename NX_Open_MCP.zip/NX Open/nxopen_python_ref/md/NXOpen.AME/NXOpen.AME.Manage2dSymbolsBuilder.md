# NXOpen.AME.Manage2dSymbolsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00062.html>

## Classes

class — SymbolDrawingStandard

Symbol drawing standard 

Enumerator — Comment

Iec

Ansi

NonStandard

More...

class — SymbolRepresentationTypes

Representation type of symbol 

Enumerator — Comment

MultiLineSchematic

SingleLineSchematic

BusTopologyDiagram

PowerSupplyTopologyDiagram

FluidicDiagram

Cabinet2d

GenericSchematic

More...

Copyright 2025 Siemens
