# NXOpen.AME.SymbolVariantBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00097.html>

## Classes

class — Variant

represents the type of Symbol Variant 

Enumerator — Comment

A

B

C

D

E

F

G

H

ContactBlockInPath

ContactBlockOnComponent

More...

Copyright 2025 Siemens
