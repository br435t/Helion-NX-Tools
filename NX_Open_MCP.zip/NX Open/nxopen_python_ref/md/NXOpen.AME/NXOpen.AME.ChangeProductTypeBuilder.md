# NXOpen.AME.ChangeProductTypeBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00032.html>

## Classes

class — Types

Select Type 

Enumerator — Comment

Product

DeviceFunction

More...

Copyright 2025 Siemens
