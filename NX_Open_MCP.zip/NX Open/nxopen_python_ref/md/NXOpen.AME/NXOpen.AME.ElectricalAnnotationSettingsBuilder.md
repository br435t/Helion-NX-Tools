# NXOpen.AME.ElectricalAnnotationSettingsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00045.html>

## Classes

class — AnnotationAttrType

Represents the type of annotations 

Enumerator — Comment

SourceTarget

CrossSection

Color

WireType

ObjectName

CutLength

PotentialType

More...

Copyright 2025 Siemens
