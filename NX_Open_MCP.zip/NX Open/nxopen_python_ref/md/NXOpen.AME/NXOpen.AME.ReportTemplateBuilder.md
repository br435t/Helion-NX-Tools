# NXOpen.AME.ReportTemplateBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00091.html>

## Classes

class — ReportType

Represents Report type for report Template 

Enumerator — Comment

ListReport

ReportsWithTargets

ConnectionReports

TitlePage

More...

Copyright 2025 Siemens
