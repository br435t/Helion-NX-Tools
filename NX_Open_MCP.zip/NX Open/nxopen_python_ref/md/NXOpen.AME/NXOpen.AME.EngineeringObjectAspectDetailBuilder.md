# NXOpen.AME.EngineeringObjectAspectDetailBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00046.html>

## Classes

class — Columns

Aspect Detail columns 

Enumerator — Comment

Type

Parent

Name

More...

class — NameSource

Aspect name from 

Enumerator — Comment

Default

NamingRule

UserInput

Mapping

More...

Copyright 2025 Siemens
