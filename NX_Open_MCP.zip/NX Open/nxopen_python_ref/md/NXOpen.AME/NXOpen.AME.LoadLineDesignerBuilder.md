# NXOpen.AME.LoadLineDesignerBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00061.html>

## Classes

class — RevisionRuleType

enum for the revision rule 

Enumerator — Comment

Working

NoWorking

More...

Copyright 2025 Siemens
