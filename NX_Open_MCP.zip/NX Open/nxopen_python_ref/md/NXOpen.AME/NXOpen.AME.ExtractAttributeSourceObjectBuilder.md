# NXOpen.AME.ExtractAttributeSourceObjectBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00049.html>

## Classes

class — SourceType

source object Type 

Enumerator — Comment

SelectObject

MemoryArea

UserPorts

TypedPorts

More...

Copyright 2025 Siemens
