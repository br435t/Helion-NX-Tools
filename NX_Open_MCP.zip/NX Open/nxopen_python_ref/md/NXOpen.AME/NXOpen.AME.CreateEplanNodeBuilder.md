# NXOpen.AME.CreateEplanNodeBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00037.html>

## Classes

class — DataTypeOptions

Represents the Data type options 

Enumerator — Comment

Bool — Boolean, the value will be true or false

Integer — Integer, the value is a whole number

Number — Number, the value is a floating point number and may contain units

String — String, the value will be a textual string

StringTranslatable — String, the value will be a textual string which is translatable

Date — Date, the value will be date and time

More...

class — Mode

Represents the mode 

Enumerator — Comment

Create

Edit

More...

class — Types

Represents the type of Eplan node 

Enumerator — Comment

Property

PropertyValue

Product

FunctionTemplate

More...

Copyright 2025 Siemens
