# NXOpen.AME.ManageInterruptionPointsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00064.html>

## Classes

class — ActionTypes

The types of managing interruption points actions. More...

Copyright 2025 Siemens
