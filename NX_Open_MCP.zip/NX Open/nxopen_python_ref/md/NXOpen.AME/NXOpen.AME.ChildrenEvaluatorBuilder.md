# NXOpen.AME.ChildrenEvaluatorBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00033.html>

## Classes

class — FilterType

choices for object type filter, can either be local modules, program blocks, plc data types, or tags 

Enumerator — Comment

LocalModules

ProgramBlocks

PlcDatatypes

Tags

All

More...

Copyright 2025 Siemens
