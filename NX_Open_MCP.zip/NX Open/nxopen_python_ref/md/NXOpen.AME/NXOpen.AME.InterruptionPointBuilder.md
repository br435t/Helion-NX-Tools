# NXOpen.AME.InterruptionPointBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00057.html>

## Classes

class — Variant

Represents Interruption Point Variant type 

Enumerator — Comment

A

B

C

D

E

F

G

H

More...

Copyright 2025 Siemens
