# NXOpen.AME.CreateBOMBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00036.html>

## Classes

class — BomScopes

Represents the scope for BOM 

Enumerator — Comment

EntireProject

Partial

More...

class — Types

Represents the type of BOM 

Enumerator — Comment

CreateNew

Update

More...

Copyright 2025 Siemens
