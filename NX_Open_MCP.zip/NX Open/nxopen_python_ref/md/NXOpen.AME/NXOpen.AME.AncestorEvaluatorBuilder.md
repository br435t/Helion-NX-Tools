# NXOpen.AME.AncestorEvaluatorBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00024.html>

## Classes

class — JaAspectEvaluatorBuilderNavCriteria

Choices for navigation criteria - Could be By Levels or By Property 

Enumerator — Comment

ByLevels

ByProperty

More...

class — JaAspectEvaluatorBuilderNavDirection

Choices for direction of navigation - Could be from starting object upwards, or from root node downwards 

Enumerator — Comment

Up

Down

More...

Copyright 2025 Siemens
