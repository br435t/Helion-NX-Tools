# NXOpen.AME.ManageTypeMappingBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00065.html>

## Classes

class — DomainRelevancy

enum for the domain relevancy status filter 

Enumerator — Comment

Relevant

Undefined

Irrelevant

More...

Copyright 2025 Siemens
