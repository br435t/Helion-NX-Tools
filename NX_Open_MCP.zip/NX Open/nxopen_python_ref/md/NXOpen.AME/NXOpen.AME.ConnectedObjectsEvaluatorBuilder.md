# NXOpen.AME.ConnectedObjectsEvaluatorBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00035.html>

## Classes

class — Type

enum for feature type being extracted 

Enumerator — Comment

EngineeringObject — Engineer Object

Port — Port

More...

Copyright 2025 Siemens
