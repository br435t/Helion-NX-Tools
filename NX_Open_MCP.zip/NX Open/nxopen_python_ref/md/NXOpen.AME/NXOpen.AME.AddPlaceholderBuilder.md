# NXOpen.AME.AddPlaceholderBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00020.html>

## Classes

class — Category

the category 

Enumerator — Comment

Objects

ObjectPortsA

ObjectPortsB

ObjectParents

Connections

ConnectionParents

ConnectionsA

ConnectionParentsA

ConnectionsB

ConnectionParentsB

Sources

SourcePorts

SourceParents

Targets

TargetPorts

TargetParents

TargetsA

TargetPortsA

TargetParentsA

TargetsB

TargetPortsB

TargetParentsB

Placeholder

MatrixConnectionsA

MatrixConnectionsB

MatrixConnectionParentsA

MatrixConnectionParentsB

MatrixPlaceholder

More...

class — ContentPropertyType

content property type 

Enumerator — Comment

Value

Sum

More...

class — Flp

the flp 

Enumerator — Comment

Function

Location

Product

Automation

More...

class — Property

the properties 

Enumerator — Comment

Type

Product

ProductOrType

General

Aspect

Page

Tag

More...

Copyright 2025 Siemens
