# NXOpen.AME.AddPropertyColumnBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00021.html>

## Classes

class — ParentObjectTypes

Represents the parent object property 

Enumerator — Comment

Function

Location

Product

Automation

More...

class — Types

Represents the property of 

Enumerator — Comment

Objects

Targets

Sources

Connections

ObjectPorts

TargetPorts

SourcePorts

ObjectParents

TargetParents

SourceParents

ConnectionParents

More...

Copyright 2025 Siemens
