# NXOpen.AME.PrimitiveSheetElementBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00084.html>

## Classes

class — PrimitiveType

represents the type of primitive sheet element 

Enumerator — Comment

Line

Circle

Rectangle

Image

Note

More...

Copyright 2025 Siemens
