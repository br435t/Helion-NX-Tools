# NXOpen.AME.ProductMatchingRulesBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00085.html>

## Classes

class — Condition

Represents matching rule condition 

Enumerator — Comment

ValueIsEqual — used if conditon is "Value is equal"

Match — used if conditon is "Match"

More...

Copyright 2025 Siemens
