# NXOpen.AME.PlcFlowChartOperatorBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00076.html>

## Classes

class — Input

Represents Plc Flow Chart Operator Input type 

Enumerator — Comment

Calculate

Compare

Logical

More...

Copyright 2025 Siemens
