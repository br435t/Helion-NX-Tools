# NXOpen.AME.OrderAspectsBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a09577.html>

Represents a OrderAspectsBuilder for changing the order of Navigator 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateOrderAspectsBuilder 

More...

Inheritance diagram for NXOpen.AME.OrderAspectsBuilder:

## Public Member Functions

GetOrder (self)

The order for the aspects. 

SetOrder (self, index, order)

The order for the aspects. 

SortFunctionMode (self)

Getter for property: (NXOpen.AME.OrderAspectsBuilder.SortType) SortFunctionMode Returns. 

SortFunctionMode (self, sort)

Setter for property: (NXOpen.AME.OrderAspectsBuilder.SortType) SortFunctionMode. 

SortLocationMode (self)

Getter for property: (NXOpen.AME.OrderAspectsBuilder.SortType) SortLocationMode Returns. 

SortLocationMode (self, sort)

Setter for property: (NXOpen.AME.OrderAspectsBuilder.SortType) SortLocationMode. 

SortProductMode (self)

Getter for property: (NXOpen.AME.OrderAspectsBuilder.SortType) SortProductMode Returns. 

SortProductMode (self, sort)

Setter for property: (NXOpen.AME.OrderAspectsBuilder.SortType) SortProductMode. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

OrderAspectsBuilderOrderType = OrderAspectsBuilder.OrderType

NXOpen.AME.OrderAspectsBuilderOrderType is an alias for NXOpen.AME.OrderAspectsBuilder.OrderType 

OrderAspectsBuilderSortType = OrderAspectsBuilder.SortType

NXOpen.AME.OrderAspectsBuilderSortType is an alias for NXOpen.AME.OrderAspectsBuilder.SortType 

## Detailed Description

Represents a OrderAspectsBuilder for changing the order of Navigator 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateOrderAspectsBuilder 

Created in NX11.0.0 

## Member Function Documentation

## ◆ GetOrder()

NXOpen.AME.OrderAspectsBuilder.GetOrder
(
self — )

The order for the aspects. 

Returns
order (List[NXOpen.AME.OrderAspectsBuilder.OrderType]): .

Created in NX11.0.0 

License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER") 

## ◆ SetOrder()

NXOpen.AME.OrderAspectsBuilder.SetOrder
(
self,

index,

order )

The order for the aspects. 

Created in NX1926.0.0 

License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Parameters

index — (int)

order — (NXOpen.AME.OrderAspectsBuilder.OrderType)

## ◆ SortFunctionMode() [1/2]

NXOpen.AME.OrderAspectsBuilder.SortFunctionMode
(
self — )

Getter for property: (NXOpen.AME.OrderAspectsBuilder.SortType) SortFunctionMode Returns. 

Getter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Deprecated
Deprecated in NX1872.0.0. Use AME.SortingManager class instead. 

Returns
OrderAspectsBuilder.SortType 

## ◆ SortFunctionMode() [2/2]

NXOpen.AME.OrderAspectsBuilder.SortFunctionMode
(
self,

sort )

Setter for property: (NXOpen.AME.OrderAspectsBuilder.SortType) SortFunctionMode. 

Sets

Setter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Deprecated
Deprecated in NX1872.0.0. Use AME.SortingManager class instead. 

## ◆ SortLocationMode() [1/2]

NXOpen.AME.OrderAspectsBuilder.SortLocationMode
(
self — )

Getter for property: (NXOpen.AME.OrderAspectsBuilder.SortType) SortLocationMode Returns. 

Getter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Deprecated
Deprecated in NX1872.0.0. Use AME.SortingManager class instead. 

Returns
OrderAspectsBuilder.SortType 

## ◆ SortLocationMode() [2/2]

NXOpen.AME.OrderAspectsBuilder.SortLocationMode
(
self,

sort )

Setter for property: (NXOpen.AME.OrderAspectsBuilder.SortType) SortLocationMode. 

Sets

Setter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Deprecated
Deprecated in NX1872.0.0. Use AME.SortingManager class instead. 

## ◆ SortProductMode() [1/2]

NXOpen.AME.OrderAspectsBuilder.SortProductMode
(
self — )

Getter for property: (NXOpen.AME.OrderAspectsBuilder.SortType) SortProductMode Returns. 

Getter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Deprecated
Deprecated in NX1872.0.0. Use AME.SortingManager class instead. 

Returns
OrderAspectsBuilder.SortType 

## ◆ SortProductMode() [2/2]

NXOpen.AME.OrderAspectsBuilder.SortProductMode
(
self,

sort )

Setter for property: (NXOpen.AME.OrderAspectsBuilder.SortType) SortProductMode. 

Sets

Setter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Deprecated
Deprecated in NX1872.0.0. Use AME.SortingManager class instead. 

## Member Data Documentation

## ◆ OrderAspectsBuilderOrderType

NXOpen.AME.OrderAspectsBuilder.OrderAspectsBuilderOrderType = OrderAspectsBuilder.OrderType

NXOpen.AME.OrderAspectsBuilderOrderType is an alias for NXOpen.AME.OrderAspectsBuilder.OrderType 

## ◆ OrderAspectsBuilderSortType

NXOpen.AME.OrderAspectsBuilder.OrderAspectsBuilderSortType = OrderAspectsBuilder.SortType

NXOpen.AME.OrderAspectsBuilderSortType is an alias for NXOpen.AME.OrderAspectsBuilder.SortType 

Copyright 2025 Siemens
