# NXOpen.AME.MappingSourceBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00066.html>

## Classes

class — MappingMode

possible choices for type mapping mode 

Enumerator — Comment

MechanicalObject

AutomationIdAsProperty

MechanicalTypeAsProperty

More...

Copyright 2025 Siemens
