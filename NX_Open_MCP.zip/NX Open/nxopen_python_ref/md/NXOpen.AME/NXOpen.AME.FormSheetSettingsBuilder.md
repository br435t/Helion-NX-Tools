# NXOpen.AME.FormSheetSettingsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00053.html>

## Classes

class — SymbolDrawingStandard

Symbol drawing standard 

Enumerator — Comment

Iec

Ansi

NonStandard

More...

Copyright 2025 Siemens
