# NXOpen.AME.EplanSettingsBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a08965.html>

EplanSettingsBuilder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEplanSettingsBuilder 

More...

Inheritance diagram for NXOpen.AME.EplanSettingsBuilder:

## Public Member Functions

Commission (self)

Getter for property: (str) Commission Returns the commission. 

Commission (self, commission)

Setter for property: (str) Commission. 

ControlVoltage (self)

Getter for property: (str) ControlVoltage Returns the control voltage. 

ControlVoltage (self, controlVoltage)

Setter for property: (str) ControlVoltage. 

Customer (self)

Getter for property: (str) Customer Returns the customer. 

Customer (self, customer)

Setter for property: (str) Customer. 

Description (self)

Getter for property: (str) Description Returns the description. 

Description (self, description)

Setter for property: (str) Description. 

GetDetails (self)

Returns the details. 

Id (self)

Getter for property: (str) Id Returns the id. 

Id (self, id)

Setter for property: (str) Id. 

Location (self)

Getter for property: (str) Location Returns the location. 

Location (self, location)

Setter for property: (str) Location. 

ManufacturingYear (self)

Getter for property: (str) ManufacturingYear Returns the manufacturing year. 

ManufacturingYear (self, manufacturingYear)

Setter for property: (str) ManufacturingYear. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

PowerInput (self)

Getter for property: (str) PowerInput Returns the power input. 

PowerInput (self, powerInput)

Setter for property: (str) PowerInput. 

ProjectTargetPath (self)

Getter for property: (str) ProjectTargetPath Returns the generation path. 

ProjectTargetPath (self, projectTargetPath)

Setter for property: (str) ProjectTargetPath. 

ProjectTemplateFile (self)

Getter for property: (str) ProjectTemplateFile Returns the project template file. 

ProjectTemplateFile (self, filename)

Setter for property: (str) ProjectTemplateFile. 

ResetProjectTemplate (self)

Reset the eplan project template information. 

SetDetails (self, details)

Sets the details. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

EplanSettingsBuilder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEplanSettingsBuilder 

Created in NX11.0.0 

## Member Function Documentation

## ◆ Commission() [1/2]

NXOpen.AME.EplanSettingsBuilder.Commission
(
self — )

Getter for property: (str) Commission Returns the commission. 

Getter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Returns
str 

## ◆ Commission() [2/2]

NXOpen.AME.EplanSettingsBuilder.Commission
(
self,

commission )

Setter for property: (str) Commission. 

Sets the commission

Setter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

## ◆ ControlVoltage() [1/2]

NXOpen.AME.EplanSettingsBuilder.ControlVoltage
(
self — )

Getter for property: (str) ControlVoltage Returns the control voltage. 

Getter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Returns
str 

## ◆ ControlVoltage() [2/2]

NXOpen.AME.EplanSettingsBuilder.ControlVoltage
(
self,

controlVoltage )

Setter for property: (str) ControlVoltage. 

Sets the control voltage

Setter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

## ◆ Customer() [1/2]

NXOpen.AME.EplanSettingsBuilder.Customer
(
self — )

Getter for property: (str) Customer Returns the customer. 

Getter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Returns
str 

## ◆ Customer() [2/2]

NXOpen.AME.EplanSettingsBuilder.Customer
(
self,

customer )

Setter for property: (str) Customer. 

Sets the customer

Setter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

## ◆ Description() [1/2]

NXOpen.AME.EplanSettingsBuilder.Description
(
self — )

Getter for property: (str) Description Returns the description. 

Getter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Returns
str 

## ◆ Description() [2/2]

NXOpen.AME.EplanSettingsBuilder.Description
(
self,

description )

Setter for property: (str) Description. 

Sets the description

Setter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

## ◆ GetDetails()

NXOpen.AME.EplanSettingsBuilder.GetDetails
(
self — )

Returns the details. 

Returns
details (List[str]): .

Created in NX11.0.0 

License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER") 

## ◆ Id() [1/2]

NXOpen.AME.EplanSettingsBuilder.Id
(
self — )

Getter for property: (str) Id Returns the id. 

Getter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Returns
str 

## ◆ Id() [2/2]

NXOpen.AME.EplanSettingsBuilder.Id
(
self,

id )

Setter for property: (str) Id. 

Sets the id

Setter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

## ◆ Location() [1/2]

NXOpen.AME.EplanSettingsBuilder.Location
(
self — )

Getter for property: (str) Location Returns the location. 

Getter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Returns
str 

## ◆ Location() [2/2]

NXOpen.AME.EplanSettingsBuilder.Location
(
self,

location )

Setter for property: (str) Location. 

Sets the location

Setter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

## ◆ ManufacturingYear() [1/2]

NXOpen.AME.EplanSettingsBuilder.ManufacturingYear
(
self — )

Getter for property: (str) ManufacturingYear Returns the manufacturing year. 

Getter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Returns
str 

## ◆ ManufacturingYear() [2/2]

NXOpen.AME.EplanSettingsBuilder.ManufacturingYear
(
self,

manufacturingYear )

Setter for property: (str) ManufacturingYear. 

Sets the manufacturing year

Setter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

## ◆ Name() [1/2]

NXOpen.AME.EplanSettingsBuilder.Name
(
self — )

Getter for property: (str) Name Returns the name. 

Getter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Returns
str 

## ◆ Name() [2/2]

NXOpen.AME.EplanSettingsBuilder.Name
(
self,

name )

Setter for property: (str) Name. 

Sets the name

Setter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

## ◆ PowerInput() [1/2]

NXOpen.AME.EplanSettingsBuilder.PowerInput
(
self — )

Getter for property: (str) PowerInput Returns the power input. 

Getter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Returns
str 

## ◆ PowerInput() [2/2]

NXOpen.AME.EplanSettingsBuilder.PowerInput
(
self,

powerInput )

Setter for property: (str) PowerInput. 

Sets the power input

Setter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

## ◆ ProjectTargetPath() [1/2]

NXOpen.AME.EplanSettingsBuilder.ProjectTargetPath
(
self — )

Getter for property: (str) ProjectTargetPath Returns the generation path. 

Getter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Returns
str 

## ◆ ProjectTargetPath() [2/2]

NXOpen.AME.EplanSettingsBuilder.ProjectTargetPath
(
self,

projectTargetPath )

Setter for property: (str) ProjectTargetPath. 

Sets the generation path

Setter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

## ◆ ProjectTemplateFile() [1/2]

NXOpen.AME.EplanSettingsBuilder.ProjectTemplateFile
(
self — )

Getter for property: (str) ProjectTemplateFile Returns the project template file. 

Getter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

Returns
str 

## ◆ ProjectTemplateFile() [2/2]

NXOpen.AME.EplanSettingsBuilder.ProjectTemplateFile
(
self,

filename )

Setter for property: (str) ProjectTemplateFile. 

Sets the project template file

Setter License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Created in NX11.0.0 

## ◆ ResetProjectTemplate()

NXOpen.AME.EplanSettingsBuilder.ResetProjectTemplate
(
self — )

Reset the eplan project template information. 

Created in NX11.0.0 

License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER") 

## ◆ SetDetails()

NXOpen.AME.EplanSettingsBuilder.SetDetails
(
self,

details )

Sets the details. 

Created in NX11.0.0 

License requirements: ad_automation_design ("FULL AUTOMATION DESIGNER")

Parameters

details — (List[str])

Copyright 2025 Siemens
