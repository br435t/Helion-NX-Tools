# NXOpen.AME.QueryBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00088.html>

## Classes

class — Types

the creation type of query 

Enumerator — Comment

NewQuery

FromLibrary

More...

Copyright 2025 Siemens
