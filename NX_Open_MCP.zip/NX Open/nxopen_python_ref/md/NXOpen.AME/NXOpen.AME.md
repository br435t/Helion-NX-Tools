# NXOpen.AME Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00018.html>

Classes, Enums and Structs under NXOpen.AME namespace. 
More...

## Namespaces

namespace — AccessorEvaluatorBuilder

namespace — AddPlaceholderBuilder

namespace — AddPropertyColumnBuilder

namespace — AMEBaseNode

namespace — AMEManager

namespace — AncestorEvaluatorBuilder

namespace — AspectBoxBuilder

namespace — AspectPrefixBuilder

namespace — AutomationControlScopeBuilder

namespace — BaseEvaluatorBuilder

namespace — Bulk3DPlacementBuilder

namespace — BulkEngineeringObjectBuilder

namespace — CabinetRoot

namespace — ChangeProductTypeBuilder

namespace — ChildrenEvaluatorBuilder

namespace — CollaborationProjectSettingsBuilder

namespace — ConnectedObjectsEvaluatorBuilder

namespace — CreateBOMBuilder

namespace — CreateEplanNodeBuilder

namespace — CreateReportBuilder

namespace — CreateRuleSetBuilder

namespace — DB

Classes, Enums and Structs under NXOpen.AME.DB namespace. 

namespace — DrawingStandardSettingsBuilder

namespace — EditClauseBuilder

namespace — EditEngineeringObjectBuilder

namespace — ElectricalAnnotationSettingsBuilder

namespace — EngineeringObjectAspectDetailBuilder

namespace — ExpressionEvaluator

namespace — ExtractAttributeBuilder

namespace — ExtractAttributeSourceObjectBuilder

namespace — FilterObjectsBuilder

namespace — FluidicAnnotationSettingsBuilder

namespace — FormSheetBuilder

namespace — FormSheetSettingsBuilder

namespace — GeneralAnnotationSettingsBuilder

namespace — InstanceDataBlockBuilder

namespace — InstantiateTemplateBulkBuilder

namespace — InterruptionPointBuilder

namespace — LadderDataBuilder

namespace — LinearDimensionBuilder

namespace — LineDesignerMappingBuilder

namespace — LoadLineDesignerBuilder

namespace — Manage2dSymbolsBuilder

namespace — ManageDimensionPointsBuilder

namespace — ManageInterruptionPointsBuilder

namespace — ManageTypeMappingBuilder

namespace — MappingSourceBuilder

namespace — MountingInterfaceBuilder

namespace — MultiValueObjectsPort

namespace — NamingRuleSettingsBuilder

namespace — NamingSchemeGeneralBuilder

namespace — ObjectConnectionBuilder

namespace — OperatorRuleBuilder

namespace — OpticalAnnotationSettingsBuilder

namespace — OrderAspectsBuilder

namespace — PageBuilder

namespace — PlcFlowChartOperatorBuilder

namespace — PlcMethodBuilder

namespace — PlcRule

namespace — PlcStateChartActionBuilder

namespace — PlcStateChartTransitionBuilder

namespace — PlcStateChartTransitionPrioritiesBuilder

namespace — PlcSymbolsEvaluatorBuilder

namespace — PortBuilder

namespace — PrimitiveSheetElementBuilder

namespace — ProductMatchingRulesBuilder

namespace — ProductPropertyRulesBuilder

namespace — ProductSelectionBuilder

namespace — QueryBuilder

namespace — ReferenceObjectBuilder

namespace — ReportDefinitionBuilder

namespace — ReportTemplateBuilder

namespace — SelectAndHighlightBuilder

namespace — ShieldBuilder

namespace — SortingBlockBuilder

namespace — SymbolAnnotationBuilder

namespace — SymbolAuthoringBuilder

namespace — SymbolVariantBuilder

namespace — TiaPortalProjectSettingsBuilder

namespace — UpdateObjectsBuilder

## Classes

class — AccessorEvaluatorBuilder

Evaluates an object based on a property value or an index 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateAccessorEvaluatorBuilder 

More...

class — AddEplanPropertyBuilder

Class to add new Eplan property to Eplan product/function template node. More...

class — AddEplanValueSetBuilder

Represents a value set creation class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateAddEplanValueSetBuilder 

More...

class — AddPlaceholderBuilder

the builder for adding placeholder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateAddPlaceholderBuilder 

More...

class — AddPlcOperatorBuilder

Represents builder for the Add Plc Operator Object 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateAddPlcOperatorBuilder 

More...

class — AddPropertyColumnBuilder

Represents configure result table class builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateAddPropertyColumnBuilder 

More...

class — AddressObjectIotype

Definition of the Address Object I/O types See Xml node IoType. More...

class — AddressRuleSettingsBuilder

Assign default plc address rule set 

To create a new instance of this class, use NXOpen::AME::AMEManager::AddressRuleSettingsBuilder 

More...

class — ADPropertyData

AD Property Data class 

This object does not need a creator. More...

class — AMEBaseBuilder

JA class for builder which creates one journal able object 

This is an abstract class, and cannot be instantiated. More...

class — AMEBaseNode

Represents Base Node 

Use the static method in this class to obtain an instance. More...

class — AMEConnection

Represents Connection 

To obtain an instance of this class use NXOpen::AME::AMEEngObject::GetAllPhysicalConnections or NXOpen::AME::AMEEngObject::GetCableConnections . More...

class — AmeElectricalConnectionPotentialType

Represents electrical connection Pontential Types. More...

class — AMEEngineeringObjectLabel

Represents Engineering Object Label Object 

This object does not need a creator. More...

class — AMEEngObject

Represents Engineering Object 

This object does not need a creator. More...

class — AMEExtendedObject

Represents Extended Object 

Use the static method in this class to obtain an instance. More...

class — AmeFluidicConnectionOccupancyType

Represents fluidic connection occupancy type. More...

class — AMEGroup

Group Journaling class 

This object does not need a creator. More...

class — AMEGroupFolder

Group Folder Journaling class 

This object does not need a creator. More...

class — AmeJunctionRepresentationStyleType

Representation style for Tee Junction. More...

class — AMEManager

Represents a manager of automation designer objects 

To obtain an instance of this class, refer to NXOpen::Session 

More...

class — AMENamingRule

Represents Naming Rule Object 

This object does not need a creator. More...

class — AmeOpticalConnectionFiberType

Represents optical connection fiber types. More...

class — AMEPlcHwItem

Represents Plc Hw Item 

Use the static method in this class to obtain an instance. More...

class — AmePlcStatechartConditionOperatortype

Represents Operator Types for Conditions in a Transition. More...

class — AMEPort

Represents Port 

Use the static method in this class to obtain an instance. More...

class — AMEQuery

The Query Object 

This is an abstract class, and cannot be instantiated. More...

class — AMEQueryGroup

The Query Group 

This is an abstract class, and cannot be instantiated. More...

class — AMEReportRule

Represents Report Rule Object 

This object does not need a creator. More...

class — AmeSymbolAnnotationAnchor

Represents anchor of annotation 

Enumerator — Comment

TopLeft

TopCenter

TopRight

MiddleLeft

MiddleCenter

MiddleRight

BottomLeft

BottomCenter

BottomRight

More...

class — AmeSymbolAnnotationAttributesource

Represents AttributeSource 

Enumerator — Comment

Unknown — Should not be used

Type

Product

General

AspectFunction

AspectLocation

AspectProduct

CrossReference

More...

class — AmeSymbolAnnotationContactblock

Represents type of contact block 

Enumerator — Comment

InPath

OnComponent

More...

class — AmeSymbolAnnotationJustification

Represents justification of annotation 

Enumerator — Comment

Left

Center

Right

More...

class — AmeSymbolAnnotationLetteringangle

Represents lettering angle of annotation 

Enumerator — Comment

Degree0

Degree45

Degree90

Degree135

Degree180

Degree270

Degree315

More...

class — AmeSymbolAnnotationPropertytype

Represents type of reference property 

Enumerator — Comment

ObjectProperties

CrossReferences

AspectProperties

More...

class — AmeSymbolAnnotationTextOverflowMethod

Represents text overflow method 

Enumerator — Comment

Default

Wrap

Truncate

Overflowborder

Suffix

More...

class — AmeSymbolAnnotationType

Represents type of annotation 

Enumerator — Comment

Properties

ContactBlock

More...

class — AmeTeeJunctionType

Represents the type of TeeJunction 

Enumerator — Comment

HorizontalDown

HorizontalUp

VerticalLeft

VerticalRight

Invalid

More...

class — AmeTeeJunctionVariant

Represents Tee Junction variant index 

Enumerator — Comment

One

Two

Three

More...

class — AncestorEvaluatorBuilder

Evaluates an ancestor for a given aspect and a starting point 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateAncestorEvaluatorBuilder 

More...

class — ApplicationBuilder

Create the AD application builder see AMEApplicationBuilder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateApplicationBuilder 

More...

class — AspectBox

Represents the AspectBox class. More...

class — AspectBoxBuilder

Represents builder for creating aspect box 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateAspectBoxBuilder 

More...

class — AspectDetailsBuilder

JA Class for the Aspect Details UI Block 

This object does not need a creator. More...

class — AspectNavigatorPreferencesBuilder

JA class for aspect navigator builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateAspectNavigatorPreferencesBuilder 

More...

class — AspectNode

Aspect Node Journaling class 

This object does not need a creator. More...

class — AspectPrefixBuilder

represents the builder class which is used to define Aspect Prefixes and Delimiter for NXOpen::AME::Project 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateAspectPrefixBuilder 

More...

class — AspectRoot

AspectRoot Node Journaling class 

This object does not need a creator. More...

class — AssignAspectBuilder

Reassign a single aspect of an Engineering Object 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateAssignAspectBuilder 

More...

class — AssignmentPort

Represents AssignmentPort 

Use the static method in this class to obtain an instance. More...

class — AssignPlcAddressRuleSetBuilder

Reassign plc address rule set to station 

To create a new instance of this class, use NXOpen::AME::AMEManager::AssignPlcAddressRuleSetBuilder 

More...

class — AssignSubnetBuilder

Reassign a single aspect of an Engineering Object 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateAssignSubnetBuilder 

More...

class — AssignTemplateToProductBuilder

Builder class to assign a template object to NXOpen::AME::ProductDefinition 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateAssignTemplateToProductBuilder 

More...

class — AssignTypeBuilder

Builder for selecting an engineering object definition 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateAssignTypeBuilder 

More...

class — AttributeHolder

JA class for the AttributeHolder object 

This is an abstract class, and cannot be instantiated. More...

class — AutomationControlScopeBuilder

Assign/Unassing the automation elevant objects of a Plc 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateAutomationControlScopeBuilder 

More...

class — AutomationFolder

Software Sub Folder Journaling class 

This object does not need a creator. More...

class — BaseDefinition

JA class for the Base Definition object 

This is an abstract class, and cannot be instantiated. More...

class — BaseDefinitionAttributeHolder

JA class for the BaseDefinitionAttributeHolder object 

This does not need a creator. More...

class — BaseEvaluatorBuilder

Represents the builder for all the evaluators. More...

class — BasicPropertiesBuilder

Represents a re-usable component for basic properties such as name and description 

This object does not need a creator. More...

class — BasicTemplateData

JA class for the Basic Template Data object 

This is an abstract class, and cannot be instantiated. More...

class — BMECatVersionNode

BMECat Version Node class 

This object does not need a creator. More...

class — BreakTemplateBuilder

JA class for the insert Eng object dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateBreakTemplateBuilder 

More...

class — Bulk3DPlacementBuilder

Represents a Bulk3DPlacementBuilder class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateBulk3dplacementBuilder 

Default values. More...

class — BulkConnectionBuilder

builder for the bulk connection dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateBulkConnectionBuilder 

More...

class — BulkEditAnnotationBuilder

Represents builder to edit annotations 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateBulkEditAnnotationBuilder 

More...

class — BulkEngineeringObjectBuilder

BulkEngineeringObjectBuilder class will be used for bulk Engineering Object Operation. More...

class — BusInterfaceType

Bus Interface type. More...

class — CabinetComponentNode

Cabinet Component Node class 

This object does not need a creator. More...

class — CabinetDesignBuilder

the builder for creating cabinet design 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateCabinetDesignBuilder 

More...

class — CabinetNode

Cabinet Node class 

This object does not need a creator. More...

class — CabinetObject

Cabinet Object class 

This object does not need a creator. More...

class — CabinetObjectLabelBuilder

JA class for the cabinet object label dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateCabinetObjectLabelBuilder 

More...

class — CabinetRoot

Cabinet Root Node class 

This object does not need a creator. More...

class — CallMethodRuleBuilder

JA class for the call method rule dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateCallMethodRuleBuilder 

More...

class — ChangeProductTypeBuilder

JA class for Change Type of product dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateChangeProductTypeBuilder 

Default values. More...

class — ChangeSymbolVariantBuilder

JA class for the change symbol variant dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateChangeSymbolVariantBuilder 

More...

class — ChildrenEvaluatorBuilder

Evaluates the children objects for a given aspect and a starting point 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateChildrenEvaluatorBuilder 

More...

class — CollaborationProjectSettingsBuilder

This builder class is used for setting type mapping configurations for external mechanical and excel data. More...

class — ConditionBlockBuilder

Represents an object that is used to specify conditions based on the property name, value and comparison operator 

This object does not need a creator. More...

class — ConditionsBuilder

JA class for the conditions dialog. More...

class — ConfigureResultTableBuilder

Represents configure result table class builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateConfigureResultTableBuilder 

More...

class — ConnectedObjectsEvaluatorBuilder

Evaluates the connected objects for the given port and a starting point 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateConnectedObjectsEvaluatorBuilder 

More...

class — ConnectionProductComponent

Connection Product Component class 

This object does not need a creator. More...

class — ConnectionProductComponentInstance

Connection Product Component Instance class 

This object does not need a creator. More...

class — ConnectToLibraryItemBuilder

JA class for the connect to library item dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::ConnectToLibraryItemBuilder 

More...

class — ConstantType

The Plc Constant types. More...

class — CreateBOMBuilder

Represents a BOM Creation class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateBomBuilder 

Default values. More...

class — CreateDefinitionBuilder

Create and classify definition 

This object does not need a creator. More...

class — CreateEngObjectDefinitionBuilder

Create and classify engineering object definition 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEngObjectDefinitionBuilder 

More...

class — CreateEplanNodeBuilder

Class to add new Eplan property/product/function node and new propery value depending of the type. More...

class — CreateFCIBuilder

JA class for the reuse rule dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateCreateFciBuilder 

More...

class — CreateIDBBuilder

JA class for the reuse rule dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateCreateIdbBuilder 

More...

class — CreateMethodBuilder

Represents a method used in the software blocks 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateMethodBuilder 

Default values. More...

class — CreateNamingSchemeBuilder

JA class for dialog for naming rule settings 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateCreateNamingSchemeBuilder 

More...

class — CreatePmiNoteBuilder

Create PMINote dialog JA class 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePmiNoteBuilder 

More...

class — CreateProductBuilder

Create and classify product 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateProductBuilder 

More...

class — CreateReportBuilder

Represents a Report Creation class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateReportBuilder 

More...

class — CreateRuleSetBuilder

JA class for crete rule set 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateCreateRuleSetBuilder 

More...

class — CreateSystemIDBBuilder

JA class for the reuse rule dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateCreateSystemIdbBuilder 

More...

class — CreateTemplateBuilder

Create Template dialog JA class 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateTemplateBuilder 

More...

class — CreateTemplateDefinitionBuilder

Create and classify template definition 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateTemplateDefinitionBuilder 

More...

class — CreateValueSetBuilder

Creates the value set data give name and description 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateCreateValueSetBuilder 

More...

class — DataTypeBuilder

JA class for the data type dialog 

This object does not need a creator. More...

class — DefineAspectBuilder

Define Aspects for Engineering Object Definition 

To create a new instance of this class, use NXOpen::AME::AMEManager::DefineAspectBuilder 

More...

class — DiagramManager

Represents an object that manages sheet elements. More...

class — DiagramNodeBuilder

Represents builder for Diagramming.Node 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateDiagramNodeBuilder 

More...

class — DocumentRoot

Document Root Node class 

This object does not need a creator. More...

class — DocumentStructureBuilder

Class to define Document Structure 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateDocumentStructureBuilder 

More...

class — DocumentType

Represents the type of document 

Enumerator — Comment

AspectStructureOverview

CableDiagram

CableList

OrderList

PartListBom

PlugList

TableOfContent

TerminalDiagram

TerminalStripList

TitlePage

WireTubeConnectionLists

WireList

MultiLineDiagram

SingleLineDiagram

BusTopologyDiagram

PowerSupplyDiagram

ViewPage

FluidicDiagram

CabinetLayout

SummarizeBom

More...

class — DrawingStandardSettingsBuilder

DrawingStandardSettingsBuilder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateDrawingStandardSettingsBuilder 

More...

class — DxfdwgExportBuilder

Represents builder for AME.DxfdwgExportBuilder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateDxfdwgExportBuilder 

Default values. More...

class — EClassClassNode

EClassData Tree Node class 

This object does not need a creator. More...

class — EClassDataRoot

EClassData Root Node class 

This object does not need a creator. More...

class — EClassFolderNode

EClass Folder Node class 

This object does not need a creator. More...

class — EClassGlobalObjectNode

EClassGlobalObject Tree Node class 

This object does not need a creator. More...

class — EClassNode

EClassData Tree Node class 

This object does not need a creator. More...

class — EClassObjectNode

EClassData Tree Node class 

This object does not need a creator. More...

class — EClassPropertyNode

EClassProperty Tree Node class 

This object does not need a creator. More...

class — EClassSegmentNode

EClass Segment Node class 

This object does not need a creator. More...

class — EClassValueListNode

EClassValueList Tree Node class 

This object does not need a creator. More...

class — EClassVersionNode

EClass Version Node class 

This object does not need a creator. More...

class — EditAnnotationBuilder

the builder for creating edit annotation 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEditAnnotationBuilder 

More...

class — EditClauseBuilder

Naming Rule Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEditClauseBuilder 

Default values. More...

class — EditDisplaySettingsBuilder

Display settings builder for primitive geometry on page 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEditDisplaySettingsBuilder 

More...

class — EditEngineeringObjectBuilder

JA class for the Eng object dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEditEngineeringObjectBuilder 

More...

class — EditInEplanBuilder

Represents a Edit in Eplan creation class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEditInEplanBuilder 

More...

class — EditOrderBuilder

JA class for the Edit Order dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEditOrderBuilder 

More...

class — ElectricalAnnotationSettingsBuilder

JA class for the Electrical Annotation Settings dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateElectricalAnnotationSettingsBuilder 

More...

class — ElectricalConnectionSettingsBuilder

Builder object for changing electrical connection settings on diagramming pages associated with the NXOpen::AME::Project . More...

class — EngineeringObjectAspectDetailBuilder

JA class for the Engineering Object Aspect Detail UI block. More...

class — EngineeringObjectBaseBuilder

JA class for the insert Eng object dialog 

This is an abstract class, and cannot be instantiated. More...

class — EngineeringObjectBuilder

JA class for the insert Eng object dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEngineeringObjectBuilder 

More...

class — EngineeringObjectDefinitionLabelBuilder

JA class for the insert Engineering object definition label dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEngineeringObjectDefinitionLabelBuilder 

More...

class — EngineeringObjectNameBuilder

JA class for the Engineering Object and Engineering Object def name and description superclass UI block. More...

class — EngObjectDefinition

JA class for the Engineering Object Definition object 

This is an abstract class, and cannot be instantiated. More...

class — EOAttributeHolder

EOAttributeHolder Atributes Holder Object 

This does not need a creator. More...

class — EODataItemAttributeHolder

EODef Atributes Holder Object 

This does not need a creator. More...

class — EODefAttributeHolder

EODef Atributes Holder Object 

This does not need a creator. More...

class — EplanDataRoot

EplanData Root Node class 

This object does not need a creator. More...

class — EplanFolderNode

Eplan Folder Node class 

This object does not need a creator. More...

class — EplanFunctionTemplateNode

Eplan Value List Node class 

This object does not need a creator. More...

class — EplanImportProjectTemplateBuilder

EplanImportProjectTemplateBuilder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEplanImportProjectTemplateBuilder 

More...

class — EplanImportType

Definition of the Eplan mapping behaviour types. More...

class — EPLANPlug

Represents EPLANPlug 

Use the static method in this class to obtain an instance. More...

class — EplanProductNode

Eplan Product Node class 

This object does not need a creator. More...

class — EplanProjectGenerationBuilder

the eplan project generation dialog builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEplanProjectGenerationBuilder 

Default values. More...

class — EPLANProjectSettings

Eplan project settings Node Journaling class 

To create or edit an instance of this class, use NXOpen::AME::EplanSettingsBuilder 

More...

class — EplanProjectTemplateAndStructureBuilder

JA class for the Eplan project template dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEplanProjectTemplateAndStructureBuilder 

More...

class — EplanPropertyNode

Eplan Property Node class 

This object does not need a creator. More...

class — EplanPropertyType

Represents the EPlan Properties 

Enumerator — Comment

FunctionalAssignment

HigherLevelFunction

InstallationSite

MountingLocation

DocumentType

UserDefinedStructure

Max

More...

class — EplanSettingsBuilder

EplanSettingsBuilder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEplanSettingsBuilder 

More...

class — EPLANSocket

Represents EPLANSocket 

Use the static method in this class to obtain an instance. More...

class — EplanStructureIdentifierOrderBuilder

Represents a Eplan Structure identifier order Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEplanStructureIdentifierOrderBuilder 

More...

class — EplanStructureSettings

Eplan structure settings Journaling class 

Will be added once available 

More...

class — EplanValueListNode

Eplan Value List Node class 

This object does not need a creator. More...

class — EplanValueSetBuilder

Represents a value set creation class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEplanValueSetBuilder 

More...

class — EplanVersionNode

Eplan Version Node class 

This object does not need a creator. More...

class — EvaluatorCopyToBuilder

Copies evaluator and its dependents from one engineering object to another 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEvaluatorCopyToBuilder 

More...

class — ExportCMCTopoProjectBuilder

Export CMC topology into file 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateExportCmctopoProjectBuilder 

More...

class — ExportEClassMappingBuilder

Export eclass mapping into file 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateExportEclassMappingBuilder 

More...

class — ExportEplanMappingBuilder

Export Eplan mapping into file 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateExportEplanMappingBuilder 

More...

class — ExpressionEvaluator

Represents an Expression Evaluator 

This object does not need a creator. More...

class — ExternalObjectsTypeMappingBuilder

This builder class is used to update domain relevancy information on the external objects. More...

class — ExtractAttribute

Extract Attribute Journaling class 

This object does not need a creator. More...

class — ExtractAttributeAbsoluteBuilder

Create a extract attribute 

This object does not need a creator. More...

class — ExtractAttributeBaseBuilder

Create a extract attribute 

This is an abstract class, and cannot be instantiated. More...

class — ExtractAttributeBuilder

Create a extract attribute 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateExtractAttributeBuilder 

More...

class — ExtractAttributeCurrentObjectBuilder

Create a extract attribute 

This object does not need a creator. More...

class — ExtractAttributeExternalObjectBuilder

Creates a NXOpen::AME::ExtractAttribute object between an automation designer object and an external application object. More...

class — ExtractAttributePortBuilder

Create a extract port attribute builder 

This object does not need a creator. More...

class — ExtractAttributeSourceObjectBuilder

Create a extract attribute 

This object does not need a creator. More...

class — FilterObjectsBuilder

Represents a FilterObjectsBuilder class Builder 

This object does not need a creator. More...

class — FindByConditionEvaluatorBuilder

Evaluates an object based on a property 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateFindByConditionEvaluatorBuilder 

More...

class — FluidicAnnotationSettingsBuilder

JA class for the Fluidic Annotation Settings dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateFluidicAnnotationSettingsBuilder 

More...

class — FluidicConnectionSettingsBuilder

Builder object for changing fluidic connection settings on diagramming pages associated with the NXOpen::AME::Project . More...

class — FormSheetBuilder

JA class for the Form Sheet dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateFormSheetBuilder 

Default values. More...

class — FormSheetObject

JA class for the FormSheetObject 

This is an abstract class, and cannot be instantiated. More...

class — FormSheetSettingsBuilder

JA class for the Form Sheet Settings dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateFormSheetSettingsBuilder 

Default values. More...

class — FragmentAttributeHolder

Fragment Object Atributes Holder 

This does not need a creator. More...

class — FragmentBuilder

Represents a Fragment creation class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateFragmentBuilder 

More...

class — FragmentObject

Represents a Fragment Object 

This object does not need a creator. More...

class — GeneralAnnotationSettingsBuilder

builder for the general annotation settings dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateGeneralAnnotationSettingsBuilder 

More...

class — GeneralConnectionSettingsBuilder

Builder for the General Connection Settings dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateGeneralConnectionSettingsBuilder 

More...

class — GeneralNamingRuleBuilder

Assign general naming rule set 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateGeneralNamingRuleBuilder 

More...

class — GenerateReportsBuilder

Comment 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateGenerateReportsBuilder 

More...

class — GlobalSelectionBuilder

GlobalSelectionBuilder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateGlobalSelectionBuilder 

More...

class — GroupBuilder

JA class for groups 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateGroupBuilder 

More...

class — GroupRoot

Group Root Node Journaling class 

This object does not need a creator. More...

class — Height

Represents height of symbol annotation 

Enumerator — Comment

Two — Height = 2

Twopointfive — Height = 2.5

Threepointfive — Height = 3.5

Five — Height = 5

Seven — Height = 7

Ten — Height = 10

Forteen — Height = 14

Twenty — Height = 20

Seventy — Height = 70

Hundred — Height = 100

Onehundredforty — Height = 140

Twohundred — Height = 200

Twohundredfifty — Height = 250

More...

class — IEngObject

Represents Engineering Object. More...

class — ImportBMECatSchemaBuilder

Imports a eclass schema xml file 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateImportBmecatSchemaBuilder 

More...

class — ImportEClassMappingBuilder

Import eClass mapping 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateImportEclassMappingBuilder 

More...

class — ImportEclassMappingMode

enum for import eClass mapping mode. More...

class — ImportEClassProductBuilder

Imports a eclass product xml file 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateImportEclassProductBuilder 

More...

class — ImportEClassProductListBuilder

Represents the Import eclass product list class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateImportEclassProductListBuilder 

More...

class — ImportEClassSchemaBuilder

Imports a eclass schema xml file 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateImportEclassSchemaBuilder 

More...

class — ImportEplanMappingBuilder

Import eplan mapping 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateImportEplanMappingBuilder 

More...

class — ImportEplanMappingMode

enum for import eplan mapping mode. More...

class — ImportEplanPageMacroBuilder

ImportEplanPageMacroBuilder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateImportEplanPageMacroBuilder 

More...

class — ImportEplanProductBuilder

Imports a eplan product xml file 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateImportEplanProductBuilder 

More...

class — ImportEplanProductListBuilder

Represents the Import eplan product list class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateImportEplanProductListBuilder 

More...

class — ImportGlobalMappingBuilder

Imports a global mapping xml file 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateImportGlobalMappingBuilder 

More...

class — ImportHWXmlBuilder

the Import HW Xml builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateImportHwxmlBuilder 

More...

class — ImportMappingType

enum for import mapping file. More...

class — ImportNode

Import Object Journaling class 

This object does not need a creator. More...

class — ImportObject

Import Object Journaling class 

This object does not need a creator. More...

class — ImportType

Definition of the EClass mapping behaviour types. More...

class — INodeObject

Represents INode Object. More...

class — InsertObjectBuilder

JA class for Insert Object dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateInsertObjectBuilder 

Default values. More...

class — InsertSettingsBuilder

Re-usable UI for Settings properties in Insert EO and Insert Template dialog. More...

class — InspectSnapshotBuilder

Inspects snapshot for AD project 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateInspectSnapshotBuilder 

More...

class — InstanceDataBlockBuilder

JA class for the reuse rule dialog 

This is an abstract class, and cannot be instantiated. More...

class — InstantiateBaseDefinitionReuseSelectionBuilder

Builder for selecting base definition 

this is a block 

More...

class — InstantiateTemplateBulkBuilder

JA class for the insert Eng object dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateInstantiateTemplateBulkBuilder 

Default values. More...

class — InterfaceAccessType

The Plc Interface Access types. More...

class — InterfaceMemberBuilder

InterfaceMemberBuilder class will be used for interface member object creation and editing 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateInterfaceMemberBuilder 

More...

class — InterfaceMemberPort

InterfaceMemberPort Journaling class 

This object does not need a creator. More...

class — InterruptionPointBuilder

Represents builder for AME.DB.InterruptionPoint 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateInterruptionPointBuilder 

More...

class — IPlcEditableParameter

Represents an IPlcEditableParameter 

This is an abstract class, and cannot be instantiated. More...

class — IPlcEditableParameterInterface

Represents an IPlcEditableParameterInterface 

This is an abstract class, and cannot be instantiated. More...

class — IPlcParameter

Represents an IPlcParameter 

This is an abstract class, and cannot be instantiated. More...

class — IPort

Represents an IPort 

This is an abstract class, and cannot be instantiated. More...

class — IPortsContainer

Represents Ports Container. More...

class — LadderData

JA class for the LadderData object 

This is an abstract class, and cannot be instantiated. More...

class — LadderDataBuilder

Represents a method used in the ladder data 

To create a new instance of this class, use NXOpen::AME::AMEManager::LadderDataBuilder 

More...

class — LayoutDefinitionBuilder

interface for the LayoutDefinitionBuilder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateLayoutDefinitionBuilder 

More...

class — LDCachedAttribute

JA class for the Line Design cache Attribute object 

This is an abstract class, and cannot be instantiated. More...

class — LinearDimensionBuilder

Represents a Linear Dimension class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateLinearDimensionBuilder 

Default values. More...

class — LineDesignerMappingBuilder

Line Designer mapping dialog JA interface 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateLineDesignerMappingBuilder 

Default values. More...

class — LoadLineDesignerBuilder

JA class for the insert LoadLineDesigner dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateLoadLineDesignerBuilder 

More...

class — Manage2dSymbolsBuilder

Represents a Manage2dSymbolsBuilder class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateManage2dSymbolsBuilder 

Default values. More...

class — Manage3DModelsBuilder

Represents the builder that is used to assign 3D models to a NXOpen::AME::ProductDefinition 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateManage3dmodelsBuilder 

More...

class — ManageDimensionPointsBuilder

Represents a Manage Dimension Points class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateManageDimensionPointsBuilder 

Default values. More...

class — ManageEclassMappingBuilder

Represents a ManageEclassMappingBuilder class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateManageEclassmappingBuilder 

More...

class — ManageEplanGlobalMappingBuilder

Represents a ManageEplanGlobalMappingBuilder class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateManageEplanGlobalMappingBuilder 

More...

class — ManageEplanMappingBuilder

Represents a ManageEplanMappingBuilder class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateManageEplanmappingBuilder 

More...

class — ManageGlobalMappingBuilder

Represents a ManageGlobalMappingBuilder class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateManageGlobalMappingBuilder 

More...

class — ManageInterruptionPointsBuilder

JA class for the Manage Interruption Points builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateManageInterruptionPointsBuilder 

Default values. More...

class — ManageObjectTypeBuilder

Builder class for assigning AD type to NXOpen::Part and name to NXOpen::Assemblies::Component 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateManageObjectTypeBuilder 

More...

class — ManageTypeMappingBuilder

This builder class is used to update relevancy information on the external objects. More...

class — ManageVariantBuilder

Builder class for creating/deleting/editing of variant and variant selection objects. More...

class — MappingSourceBuilder

This builder class is a re-usable component used to filter external objects by discipline. More...

class — MapToExistingObjectBuilder

Line Designer map to existing (EO) dialog JA interface 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateMapToExistingObjectBuilder 

More...

class — MemoryAreaBulkAddressingBuilder

JA class for MemoryAreaBulkAddressing dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateMemoryAreaBulkAddressingBuilder 

More...

class — MemorySectionType

Definition of the memory section types. More...

class — MountingInterface

Represents a Mounting Interface 

This object does not need a creator. More...

class — MountingInterfaceBuilder

Builder class for creating mounting interface object in NXOpen::Part 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateMountingInterfaceBuilder 

Default values. More...

class — MultipleObjectsBuilder

JA class for for builder which creates more than one journal able objects 

This is an abstract class, and cannot be instantiated. More...

class — MultiValueObjectsPort

MultiValueObjectsPort Journaling class 

This object does not need a creator. More...

class — NamingRuleBuilder

Naming Rule Builder 

To create a new instance of this class, use NXOpen::AME::NamingRuleListBuilder::CreateRule 

More...

class — NamingRuleBuilderList

Represents a list of objects. More...

class — NamingRuleListBuilder

Classification to Engineering Object Name Map Builder 

this is a block 

More...

class — NamingRuleSettingsBuilder

JA class for dialog for naming rule settings 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateNamingRuleSettingsBuilder 

More...

class — NamingSchemeAspectNamingBuilder

JA class for Naming Scheme Aspect Naming Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateNamingSchemeAspectNamingBuilder 

More...

class — NamingSchemeGeneralBuilder

JA class for Naming Scheme General Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateNamingSchemeGeneralBuilder 

More...

class — ObjectConnectionBuilder

JA class for the reuse object connection block. More...

class — ObjectConnectionDetailBuilder

JA class for the reuse object connection detail block. More...

class — ObjectEvaluatorBuilder

Evaluates the object given a starting point 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateObjectEvaluatorBuilder 

More...

class — ObjectNameBuilder

Object Name JA class. More...

class — ObjectNameIndexBuilder

Object Name Index JA class. More...

class — OperandRuleBuilder

JA class for the parameter rule dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateOperandRuleBuilder 

More...

class — OperatorRuleBuilder

OperatorRule Dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateOperatorRuleBuilder 

More...

class — OpticalAnnotationSettingsBuilder

JA class for the Optical Annotation Settings dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateOpticalAnnotationSettingsBuilder 

More...

class — OpticalConnectionSettingsBuilder

Builder object for changing optical connection settings on diagramming pages associated with the NXOpen::AME::Project 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateOpticalConnectionSettingsBuilder 

More...

class — OrderAspectsBuilder

Represents a OrderAspectsBuilder for changing the order of Navigator 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateOrderAspectsBuilder 

More...

class — PageAttributeHolder

Page Object Atributes Holder 

This does not need a creator. More...

class — PageBuilder

Represents a Page creation class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePageBuilder 

Default values. More...

class — PageNamingBuilder

Class to define Page naming schema 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePageNamingBuilder 

Default values. More...

class — PageNode

Represents a Page Node 

This object can not be created directly. More...

class — PageObject

Represents a Page Object 

This object does not need a creator. More...

class — PageTypes

Represents the type of page 

Enumerator — Comment

AspectStructureOverview

CableDiagram

CableList

OrderList

PartListBom

PlugList

TableOfContent

TerminalDiagram

TerminalStripList

TitlePage

WireTubeConnectionLists

WireList

MultiLineSchematics

SingleLineSchematics

NetworkTopology

PowerSupplyTopology

ViewPage

FluidicDiagram

CabinetLayout

SummarizeBom

More...

class — ParameterRuleBuilder

JA class for the parameter rule dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateParameterRuleBuilder 

More...

class — ParentEvaluatorBuilder

Evaluates the parent object for a given aspect and a starting point 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateParentEvaluatorBuilder 

More...

class — PhysicalConnectionBuilder

JA class for creating Connection 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePhysicalConnectionBuilder 

More...

class — PlaceAutomationBuilder

Reassign a single aspect of an Engineering Object 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlaceAutomationBuilder 

More...

class — PlcAddressRuleSet

Plc Address Rule Set Journaling class 

This object does not need a creator. More...

class — PlcAddressRuleSetupBuilder

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcAddressRuleSetupBuilder 

More...

class — PlcBlock

Plc Block Node Journaling class 

This is an abstract class. More...

class — PlcChangeInstanceBlockMasterBuilder

This class provides a journalling interface for editing an Instance Data Block source revision. More...

class — PlcChartManager

Represents an object that manages sheet elements. More...

class — PlcCodePosition

Represents Plc Code Position Object 

This object does not need a creator. More...

class — PlcDataType

Definition of the PLC data types. More...

class — PlcDataTypeSource

Definition of the data type sources. More...

class — PlcEditStateNoteBuilder

Represents builder for AME.DB.PlcStateChartBaseElement 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcEditStateNoteBuilder 

More...

class — PlcFlowChartConstantTextBuilder

JA class for the constant text rule 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcStateChartItemValueBuilder 

More...

class — PlcFlowChartNodeType

Definition of PLC Flow Chart Node type. More...

class — PlcFlowChartOperatorBuilder

Represents builder for the Plc FlowChart Operator Object 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcFlowChartOperatorBuilder 

More...

class — PlcFunctionBlockBuilder

PlcFunctionBlockBuilder class to create builder object. More...

class — PlcFunctionBlockType

Type for PlcFunctionBlock Language. More...

class — PlcInterfaceSection

Represents PlcInterfaceSection 

Use the static method in this class to obtain an instance. More...

class — PlcInterfaceSectionType

Definition of type of Interface Section. More...

class — PlcInterfaceVariable

Represents PlcInterfaceVariable 

Use the static method in this class to obtain an instance. More...

class — PlcInterfaceVariableBuilder

PlcInterfaceVariableBuilder class will be used for (bulk) variable object creation and editing 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcInterfaceVariableBuilder 

Default values. More...

class — PlcLogicBlock

Represents a PlcLogicBlock 

This class cannot be instantiated directly. More...

class — PlcLogicBlockNodeType

Definition of PLC Logic Block Node type. More...

class — PlcLogicBlockOperand

Represents a PlcLogicBlockOperand 

This class cannot be instantiated directly. More...

class — PlcLogicBlockParameter

Represents an PlcLogicBlockParameter 

This class cannot be instantiated directly. More...

class — PlcMemoryArea

Plc Memory Area journaling class 

This object does not need a creator. More...

class — PlcMemoryAreaBuilder

Represents a Subnet creation class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcMemoryAreaBuilder 

More...

class — PlcMethod

Plc Method Node Journaling class 

This is an abstract class. More...

class — PlcMethodBuilder

The Journalling class for PlcMethodBuilder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcMethodBuilder 

More...

class — PlcRule

PlcRule Journaling class 

This object does not need a creator. More...

class — PlcSoftwareGenPort

PlcSoftwareGenPort Journaling class 

This object does not need a creator. More...

class — PlcStateChartActionBuilder

Represents builder for AME.UI.PlcStateChartAction 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcStateChartActionBuilder 

More...

class — PlcStateChartCreateElementBuilder

Represents builder for the plc state chart element creation from the PlcBlockContent toolbar 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcStateChartCreateElementBuilder 

More...

class — PlcStateChartDefineCallBuilder

Represents builder for AME.UI.PlcStateChartDefineCall 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcStateChartDefineCallBuilder 

More...

class — PlcStateChartFunctionBlockBuilder

PlcStateChartFunctionBlockBuilder class to create builder object. More...

class — PlcStateChartItemValueBuilder

JA class for the global variable rule 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcStateChartItemValueBuilder 

More...

class — PlcStateChartStateBuilder

Represents builder for AME.DB.PlcStateChartState 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcStateChartStateBuilder 

More...

class — PlcStateChartTransitionBuilder

Represents builder for AME.DB.PlcStateChartTransition 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcStateChartTransitionBuilder 

More...

class — PlcStateChartTransitionPrioritiesBuilder

Represents builder for AME.PlcStateChartTransitionPrioritiesBuilder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcStateChartTransitionPrioritiesBuilder 

More...

class — PlcSubFolder

Software Sub Folder Journaling class 

This object does not need a creator. More...

class — PlcSymbolBuilder

Class to create Functional Tags and assign them to PLC Channels 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcSymbolBuilder 

More...

class — PlcSymbolsEvaluatorBuilder

Evaluates the PLC tags for a given aspect and a starting point 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcSymbolsEvaluatorBuilder 

More...

class — PlcTelegramBuilder

something 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcTelegramBuilder 

More...

class — PlcTelegramDefinition

JA class for the PlcTelegram Definition object 

This is an abstract class, and cannot be instantiated. More...

class — PlcVendorSymbolBuilder

Represents a Subnet creation class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePlcVendorSymbolBuilder 

More...

class — PortBuilder

builder for the software block properties dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePortBuilder 

More...

class — PortConnectionBuilder

builder for the port connector dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePortConnectionBuilder 

More...

class — PortEvaluatorBuilder

Evaluates the port objects for the given port and a starting point 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePortEvaluatorBuilder 

More...

class — PortsManagerBuilder

Provides journal methods for the ports manager dialog. More...

class — PrimitiveSheetElementBuilder

Represents builder for Primitive Sheet Element 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePrimitiveSheetElementBuilder 

More...

class — PrimitiveSheetElementBuilderOfNoteAnchor

Represents anchor of annotation 

Enumerator — Comment

Invalid

NoValue

TopLeft

TopCenter

TopRight

MiddleLeft

MiddleCenter

MiddleRight

BottomLeft

BottomCenter

BottomRight

More...

class — PrimitiveSheetElementBuilderOfNoteLetteringangle

Represents lettering angle of annotation 

Enumerator — Comment

Invalid

NoValue

Degree0

Degree45

Degree90

Degree135

Degree180

Degree225

Degree270

Degree315

More...

class — PrintPagesBuilder

JA class for the PrintPages dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePrintPagesBuilder 

More...

class — ProductComponent

Product Component class 

This object does not need a creator. More...

class — ProductDefAttributeHolder

ProductDefinition Atributes Holder Object 

This does not need a creator. More...

class — ProductDefinition

JA class for the Product Definition object 

This is an abstract class, and cannot be instantiated. More...

class — ProductMatchingRulesBuilder

Represents Product Matching Rules class builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateProductMatchingRulesBuilder 

More...

class — ProductPropertyRulesBuilder

Represents builder for creating product property merging rules 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateProductPropertyRulesBuilder 

More...

class — ProductSelectionBuilder

JA class for Product Selection dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateProductSelectionBuilder 

Default values. More...

class — ProgrammingLanguage

The Plc Programming Languages. More...

class — Project

Project Journaling class 

Created by Application_AME_ApplicationBuilder when we enter the application 

More...

class — ProjectEngineeringObjectBuilder

JA class for the insert Project Eng object dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateProjectEngineeringObjectBuilder 

More...

class — ProjectSymbolAnnotationBuilder

JA class for the Project Symbol Annotation dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateProjectSymbolAnnotationBuilder 

More...

class — PropertyEvaluatorBuilder

Evaluates the property of an object given a category and property 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreatePropertyEvaluatorBuilder 

More...

class — QueryBuilder

Represents query class builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateQueryBuilder 

More...

class — QueryClause

JA class for the QueryClause object 

This is an abstract class, and cannot be instantiated. More...

class — QueryFolder

Query Folder Journaling class 

This object does not need a creator. More...

class — QueryNode

The Query Node 

This is an abstract class, and cannot be instantiated. More...

class — QueryResult

The Query Result 

This is an abstract class, and cannot be instantiated. More...

class — ReferenceDesignationSetNode

Reference Designation Set Node Journaling class 

This object does not need a creator. More...

class — ReferenceObjectBuilder

Re-usable UI consist of a context and source selection. More...

class — RenamePlugsAndStripsBuilder

JA class for the Rename Plugs And Strips dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateRenamePlugsAndStripsBuilder 

Default values. More...

class — ReportDefinition

The Report Definition 

This object does not need a creator. More...

class — ReportDefinitionBuilder

Represents ReportDefinitionBuilder class builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateReportDefinitionBuilder 

More...

class — ReportDefinitionFolder

Report Definition Journaling class 

This object does not need a creator. More...

class — ReportDefinitionNode

The Report Definition Node 

This is an abstract class, and cannot be instantiated. More...

class — ReportHeaderPlaceHolderDataNode

JA class for the ReportHeaderPlaceHolderDataNode object 

This is an abstract class, and cannot be instantiated. More...

class — ReportPageAttributeHolder

JA class for the ReportPageAttributeHolder object 

This object does not need a creator. More...

class — ReportPlaceHolderData

JA class for the ReportPlaceHolderData object 

This is an abstract class, and cannot be instantiated. More...

class — ReportSettingsBuilder

Implements the report settings dialog. More...

class — ReportsSettingsBuilder

interface for the ReportsSettingsBuilder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateReportsSettingsBuilder 

More...

class — ReportTemplate

JA class for the ReportTemplate object 

This is an abstract class, and cannot be instantiated. More...

class — ReportTemplateBuilder

Class to create Report Template and assign the ReportQuery and Report Layout to them 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateReportTemplateBuilder 

More...

class — SaveToLibraryBuilder

Create Software Block JA class 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateSaveToLibraryBuilder 

More...

class — SchematicSymbol

Represents a Schematic Symbol object 

This object does not need a creator. More...

class — SchematicSymbolConfigurationBuilder

JA class for SchematicSymbolConfigurationBuilder dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateSchematicSymbolConfigurationBuilder 

More...

class — SelectADReuseLibraryItemBuilder

Builder for selecting automation designer reuse lirary item 

this is a block 

More...

class — SelectADTypeBuilder

Journalling Interface class for Builder which allows selection of Type, Product or Template. More...

class — SelectAMEBaseNode

Represents a single object selection. More...

class — SelectAMEBaseNodeList

Represents a list of objects on a selection list. More...

class — SelectAMEPort

Represents a single object selection. More...

class — SelectAndHighlightBuilder

Represents a SelectAndHighlightBuilder for select and highlight in the Navigators 

To create a new instance of this class, use NXOpen::AME::AMEManager::SelectAndHighlightBuilder 

More...

class — SelectAspectNode

Represents a single object selection. More...

class — SelectAttrPropSourceBuilder

Journalling Interface class for Builder which allows selection of an object which has attribute properties set on it. More...

class — SelectBaseDefinitionNodeBuilder

Builder for selecting base definition node from navigators 

This object does not need a creator 

More...

class — SelectClassificationBuilder

Select a part from the reuse library. More...

class — SelectClassificationFromTreeBuilder

Select Type from the Classification Library 

This object does not need a creator. More...

class — SelectComponentBuilder

Builder for selection of external component 

this is a block 

More...

class — SelectConditionBuilder

Defines conditions by using expressions for engineering objects 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateAssignAspectBuilder 

More...

class — SelectExternalObjectBuilder

Journalling Interface class for Builder which allows selection of external objects. More...

class — SelectExternalReuseLibraryItemBuilder

Builder for selecting external reuse lirary item 

this is a block 

More...

class — SelectINodeObject

Represents a single object selection. More...

class — SelectINodeObjectList

Represents a list of objects on a selection list. More...

class — SelectionBaseDefinitionBuilder

Journalling Interface class for Builder which allows selection of BaseDefinition. More...

class — SelectionEngineeringObjectDefinitionBuilder

JA class for the Engineering Object Definition Block 

This object does not need a creator. More...

class — SelectIPort

Represents a single object selection. More...

class — SelectMountingInterfaceLocationBuilder

Builder for selecting mounting interface location from graphics window 

This object does not need a creator 

More...

class — SelectProductDefinitionBuilder

JA class for the Product Definition Selection 

This object does not need a creator. More...

class — SelectReuseLibraryItemBuilder

Builder for selecting base definition 

this is a block 

More...

class — SelectSolutionTemplateBuilder

Represents a re-usable component for Select Solution Template 

This object does not need a creator. More...

class — SendReceiveType

Definition of type of Telegrams. More...

class — ShieldBuilder

Represents builder for AME.DB.Shield 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateShieldBuilder 

More...

class — ShowHideObjectsBuilder

JA class for ShowHideObjectsBuilder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateShowHideObjectsBuilder 

More...

class — SinCatMappingBuilder

Class is used to Map to SINAMICS Component Catalog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateSinCatMappingBuilder 

More...

class — SmartPDFPrintPagesBuilder

JA class for the Smart PDF PrintPages 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateSmartPdfPrintPagesBuilder 

More...

class — Snap3DModelsBuilder

Represents a Snap3DModelsBuilder class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateSnap3dmodelsBuilder 

More...

class — SoftwareBlockDataTypePort

SoftwareBlockDataTypePort Journaling class 

This object does not need a creator. More...

class — SolutionTemplateData

JA class for the Solution Template Data object 

This is the singleton Solution Template data class. More...

class — SortingBlockBuilder

Sorts the list expression output according to the property. More...

class — SubnetBuilder

Represents a Subnet creation class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateSubnetBuilder 

More...

class — SumEvaluatorBuilder

Evaluates sum of given property for list of objects 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateSumEvaluatorBuilder 

More...

class — SWStatusItem

Represents SW Status Item 

More...

class — SymbolAnnotationBuilder

Represents a Symbol Annotation creation class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateSymbolAnnotationBuilder 

More...

class — SymbolAnnotationStyleBuilder

Represents a re-usable component for Symbol annotation styles 

This object does not need a creator. More...

class — SymbolAuthoringBuilder

Represents a Symbol Authoring class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateSymbolAuthoringBuilder 

Default values. More...

class — SymbolLocationBuilder

JA class for the symbol location reusable component 

This object does not need a creator. More...

class — SymbolNoteBuilder

Represents a Symbol Note creation class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateSymbolNoteBuilder 

Default values. More...

class — SymbolPlacementBuilder

JA class for the symbol placement reusable component 

This object does not need a creator. More...

class — SymbolRoot

Symbol Root Node class 

This object does not need a creator. More...

class — SymbolVariantBuilder

Represents a Symbol Variant creation class Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateSymbolVariantBuilder 

More...

class — TCSavedQueriesBuilder

Represents a TC Saved Queries builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateEditQueryScopeBuilder 

More...

class — TeeJunctionBuilder

JA class for creating Tee Junction 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateTeeJunctionBuilder 

More...

class — TelegramType

Definition of type of Telegrams. More...

class — TemplateData

JA class for the Template Data object 

This is the singleton Template Data class. More...

class — TemplateVariant

JA class for the Template Variant object 

This is journaling interface file for Template Variant. More...

class — TemplateVariantSelection

JA class for the Template Variant Selection object 

This is journaling interface file for Template Variant Selection. More...

class — TerminalReportSettings

JA class for the TerminalReportSettings object 

This is an abstract class, and cannot be instantiated. More...

class — TiaPortalProjectSettings

Tia Portal project settings node journaling class 

This object does not need a creator. More...

class — TiaPortalProjectSettingsBuilder

TiaPortalProjectSettingsBuilder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateTiaPortalProjectSettingsBuilder 

More...

class — TransferFileDataBuilder

Imports a new one or updates the existing configuration in AD Upstream Data Navigator from the external file. More...

class — TypedProductComponent

Typed Product Component class 

This object does not need a creator. More...

class — TypedProductComponentInstance

Product Component Instance class 

This object does not need a creator. More...

class — TypeMappingBuilder

JA class for the type mapping dialog 

this is a block 

More...

class — TypeMappingBuilderList

Represents a list of objects. More...

class — TypeMappingListBuilder

Type Mapping List Builder 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateTypeMappingListBuilder 

More...

class — TypeRoot

Type Root Node class 

This object does not need a creator. More...

class — UnloadLineDesignerBuilder

JA class for the insert UnloadLineDesigner dialog 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateUnloadLineDesignerBuilder 

More...

class — UpdateLibraryObjectsBuilder

Class to define Update Library Objects 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateUpdateLibraryObjectsBuilder 

More...

class — UpdateObjectsBuilder

Class to define Update Objects 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateUpdateObjectsBuilder 

More...

class — UpstreamDataRoot

UpstreamData Root Node class 

This object does not need a creator. More...

class — ValueSetBuilder

Manages the value set by allowing them to be created and add new values 

To create a new instance of this class, use NXOpen::AME::AMEManager::CreateValueSetBuilder 

More...

class — VariableInterfaceMemberPort

VariableInterfaceMemberPort Journaling class 

This object does not need a creator. More...

## Detailed Description

Classes, Enums and Structs under NXOpen.AME namespace. 

Copyright 2025 Siemens
