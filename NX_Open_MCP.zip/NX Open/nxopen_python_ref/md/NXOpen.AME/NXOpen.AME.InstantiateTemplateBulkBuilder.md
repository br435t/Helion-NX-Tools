# NXOpen.AME.InstantiateTemplateBulkBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00056.html>

## Classes

class — PlacementType

Choices for placement type, can be Place in Navigator or Place on Page 

Enumerator — Comment

Navigator

Page

More...

Copyright 2025 Siemens
