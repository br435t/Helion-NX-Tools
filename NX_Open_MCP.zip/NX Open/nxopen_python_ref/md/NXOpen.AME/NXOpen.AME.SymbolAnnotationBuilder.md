# NXOpen.AME.SymbolAnnotationBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00095.html>

## Classes

class — Anchor

Represents anchor of annotation 

Enumerator — Comment

TopLeft

TopCenter

TopRight

MiddleLeft

MiddleCenter

MiddleRight

BottomLeft

BottomCenter

BottomRight

More...

class — Orientation

Represents orientation of annotation 

Enumerator — Comment

Horizontal

Vertical

More...

Copyright 2025 Siemens
