# NXOpen.AME.CollaborationProjectSettingsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00034.html>

## Classes

class — FilterMode

possible choices for filter type 

Enumerator — Comment

FilterOnClassificationClass

FilterOnProperty

More...

class — ResultsSetting

possible choices for show objects setting 

Enumerator — Comment

DefineFilterValues

ShowObjectsIfNotEmpty

More...

Copyright 2025 Siemens
