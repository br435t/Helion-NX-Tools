# NXOpen.AME.LineDesignerMappingBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00060.html>

## Classes

class — FilterType

enum for the filter 

Enumerator — Comment

Unhidden

Hidden

Unmapped

Mapped

Deleted

TypeMapped

All

More...

Copyright 2025 Siemens
