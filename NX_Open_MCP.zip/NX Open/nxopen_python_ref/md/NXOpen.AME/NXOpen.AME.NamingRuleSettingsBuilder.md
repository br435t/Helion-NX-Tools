# NXOpen.AME.NamingRuleSettingsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00069.html>

## Classes

class — Sources

different types of Delimiter sources 

Enumerator — Comment

Period

AspectPrefix

Nothing

More...

Copyright 2025 Siemens
