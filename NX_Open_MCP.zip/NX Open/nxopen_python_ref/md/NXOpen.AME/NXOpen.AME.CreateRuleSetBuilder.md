# NXOpen.AME.CreateRuleSetBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00039.html>

## Classes

class — RulesType

Definition of the rule set types. More...

Copyright 2025 Siemens
