# NXOpen.AME.ObjectConnectionBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00071.html>

## Classes

class — Type

the selection type 

Enumerator — Comment

Object

Port

Expression

More...

Copyright 2025 Siemens
