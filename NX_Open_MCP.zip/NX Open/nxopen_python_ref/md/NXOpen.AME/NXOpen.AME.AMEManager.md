# NXOpen.AME.AMEManager Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00023.html>

## Classes

class — CreateStationType

Type of PLC Station 

Enumerator — Comment

Central

Dio

More...

class — DeleteType

the deletion type 

Enumerator — Comment

DeleteObject

DeleteTemplate

RemoveLastAspect

DeleteSymbolicRepresentation

More...

class — JaNativeLibType

Represents the type of a native library 

Enumerator — Comment

All — enables a lookup call to iterate through every known library type

Type — type objects from type library

Product — product objects from product library

Symbol — symbol objects from symbol library

Template — template objects from template library

Setting — setting objects from settings library

Connection — connection objects from connection library

Port — port objects from port library

FormSheet — form sheet objects from form sheet library

System — system objects from system library

ReportTemplate — report template objects from report templates library

ReportDefinition — report definition objects from report templates definition

More...

class — JaNavigatorSortedState

Represents the sorted state of navigator 

Enumerator — Comment

Ascending

Descending

Unsorted

More...

class — JaOrderType

Represents the type of an order 

Enumerator — Comment

Chronological — System defined chronological order

Alphanumeric — System defined alphanumeric order

Alphabetic — System defined alphabetic order

Manual — User defined order

More...

class — MoveNavigatorNodesType

Type for Drag-Drop 

Enumerator — Comment

Movebefore

Moveafter

More...

class — PasteStatus

the status of paste operation 

Enumerator — Comment

Successful

NoValidObjectToPaste

NameUnderParentExists

AdditionalObjectsInvolved

More...

Copyright 2025 Siemens
