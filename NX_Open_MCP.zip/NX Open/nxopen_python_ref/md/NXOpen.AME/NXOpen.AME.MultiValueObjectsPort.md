# NXOpen.AME.MultiValueObjectsPort Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00068.html>

## Classes

class — JaAmeValueObjectUsageType

type which usagetype has to be used 

Enumerator — Comment

PreDefinition

DefaultValue

DataType

More...

Copyright 2025 Siemens
