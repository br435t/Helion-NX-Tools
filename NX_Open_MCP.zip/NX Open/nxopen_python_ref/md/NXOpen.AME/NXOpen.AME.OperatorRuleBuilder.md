# NXOpen.AME.OperatorRuleBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00072.html>

## Classes

class — NegationValue

Enum of negation value 

Enumerator — Comment

FalseValue

TrueValue

More...

class — ParameterType

Enum of parameter type 

Enumerator — Comment

Input

Output

More...

Copyright 2025 Siemens
