# NXOpen.AME.AccessorEvaluatorBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00019.html>

## Classes

class — AccessType

Choices for access type either by an index or property 

Enumerator — Comment

Property

Index

More...

class — PositionTypeValue

Choices for position to be either begin, end or defined by index 

Enumerator — Comment

Begin

End

Index

More...

Copyright 2025 Siemens
