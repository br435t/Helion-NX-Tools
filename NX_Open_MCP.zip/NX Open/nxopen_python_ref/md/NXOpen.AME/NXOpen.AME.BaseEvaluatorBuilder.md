# NXOpen.AME.BaseEvaluatorBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00028.html>

## Classes

class — ConditionType

choices for condition type filter for navigations that return a list of filtered objects 

Enumerator — Comment

Contains

Equals

NotEquals

LessThan

GreaterThan

LessThanEquals

GreaterThanEquals

More...

class — ContextType

choices for aspect context type, can either be function, location, product, or automation 

Enumerator — Comment

Function

Location

Product

Automation

More...

Copyright 2025 Siemens
