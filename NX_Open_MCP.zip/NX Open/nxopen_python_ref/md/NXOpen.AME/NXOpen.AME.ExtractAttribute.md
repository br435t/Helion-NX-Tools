# NXOpen.AME.ExtractAttribute Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a09057.html>

Extract Attribute Journaling class 

This object does not need a creator. 
More...

Inheritance diagram for NXOpen.AME.ExtractAttribute:

## Additional Inherited Members

Public Member Functions inherited from NXOpen.NXObject

CreateAttributeIterator (self)

Create an attribute iterator. 

DeleteAllAttributesByType (self, type)

Deletes all attributes of a specific type. 

DeleteAllAttributesByType (self, type, option)

Deletes all attributes of a specific type with the option to update or not. 

DeleteAttributeByTypeAndTitle (self, type, title)

Deletes an attribute by type and title. 

DeleteAttributeByTypeAndTitle (self, type, title, option)

Deletes an attribute by type and title with the option to update or not. 

DeleteUserAttribute (self, type, title, delete_entire_array, option)

Deletes the first attribute encountered with the given Type, Title. 

DeleteUserAttributes (self, iterator, option)

Deletes the attributes on the object, if any, that satisfy the given iterator. 

DeleteUserAttributes (self, type, option)

Deletes the attributes encountered with the given Type with option to update or not. 

GetAttributeTitlesByType (self, type)

Gets all the attribute titles of a specific type. 

GetBooleanUserAttribute (self, title, index)

Gets a boolean attribute by Title and array Index. 

GetComputationalTimeUserAttribute (self, title, index)

Gets a time attribute by Title and array Index. 

GetIntegerAttribute (self, title)

Gets an integer attribute by title. 

GetIntegerUserAttribute (self, title, index)

Gets an integer attribute by Title and array Index. 

GetNextUserAttribute (self, iterator)

Gets the next attribute encountered on the object, if any, that satisfies the given iterator. 

GetPdmReferenceAttributeValue (self, attributeTitle)

Gets the value of PDM Reference attribute for given object. 

GetRealAttribute (self, title)

Gets a real attribute by title. 

GetRealUserAttribute (self, title, index)

Gets a real attribute by Title and array Index. 

GetReferenceAttribute (self, title)

Gets the reference string (not the calculated value) of a string attribute that uses a reference string. 

GetStringAttribute (self, title)

Gets a string attribute value by title. 

GetStringUserAttribute (self, title, index)

Gets a string attribute by Title and array Index. 

GetTimeAttribute (self, format, title)

Gets a time attribute by title. 

GetTimeUserAttribute (self, title, index)

Gets a time attribute by Title and array Index. 

GetUserAttribute (self, title, includeUnset, addStringValues, type)

Gets the first attribute (or attribute array) encountered on the object, if any, with a given Title and Type. 

GetUserAttribute (self, title, type, index)

Gets the first attribute encountered on the object, if any, with a given Title, Type and array Index. 

GetUserAttributeAsString (self, title, type, index)

Gets the first attribute encountered on the object, if any, with a given title, type and array index. 

GetUserAttributeCount (self, iterator)

Gets the count of set attributes on the object, if any, that satisfy the given iterator. 

GetUserAttributeCount (self, iterator, countArrayAsOneAttribute)

Gets the count of set attributes on the object, if any, that satisfy the given iterator. 

GetUserAttributeCount (self, type)

Gets the count of set attributes on the object, if any, of the given type. 

GetUserAttributeCount (self, type, includeUnset, countArrayAsOneAttribute)

Gets the count of attributes on the object, if any, of the given type. 

GetUserAttributeLock (self, title, type)

Determine the lock of the given attribute. 

GetUserAttributes (self)

Gets all the attributes that have been set on the given object. 

GetUserAttributes (self, includeUnset)

Gets all the attributes of the given object. 

GetUserAttributes (self, includeUnset, addStringValues)

Gets all the attributes of the given object. 

GetUserAttributes (self, iterator)

Gets all the attributes that have been set on the given object, if any, that satisfy the given iterator. 

GetUserAttributesAsStrings (self)

Gets all the attributes that have been set on the given object. 

GetUserAttributeSize (self, title, type)

Gets the size of the first attribute encountered on the object, if any, with a given Title and Type. 

GetUserAttributeSourceObjects (self)

Returns an array of objects from which this object presents attributes. 

HasUserAttribute (self, iterator)

Determines if an attribute exists on the object, that satisfies the given iterator. 

HasUserAttribute (self, title, type, index)

Determines if an attribute with the given Title, Type and array Index is present on the object Unset attributes will not be detected by this function, as its purpose is to test for the actual presence of the attribute on the object. 

IsOccurrence (self)

Getter for property: (bool) IsOccurrence Returns whether this object is an occurrence or not. 

JournalIdentifier (self)

Getter for property: (str) JournalIdentifier Returns the identifier that would be recorded in a journal for this object. 

Name (self)

Getter for property: (str) Name Returns the custom name of the object. 

OwningComponent (self)

Getter for property: (NXOpen.Assemblies.Component) OwningComponent Returns the owning component, if this object is an occurrence. 

OwningPart (self)

Getter for property: (NXOpen.BasePart) OwningPart Returns the owning part of this object. 

Prototype (self)

Getter for property: (NXOpen.INXObject) Prototype Returns the prototype of this object if it is an occurrence. 

SetAttribute (self, title)

Creates or modifies a null attribute which is an attribute with a title and no value. 

SetAttribute (self, title, option)

Creates or modifies a null attribute with the option to update or not. 

SetAttribute (self, title, value)

Creates or modifies an integer attribute. 

SetAttribute (self, title, value)

Creates or modifies a real attribute. 

SetAttribute (self, title, value)

Creates or modifies a string attribute. 

SetAttribute (self, title, value, option)

Creates or modifies an integer attribute with the option to update or not. 

SetAttribute (self, title, value, option)

Creates or modifies a real attribute with the option to update or not. 

SetAttribute (self, title, value, option)

Creates or modifies a string attribute with the option to update or not. 

SetBooleanUserAttribute (self, title, index, value, option)

Creates or modifies a boolean attribute with the option to update or not. 

SetPdmReferenceAttribute (self, attributeTitle, attributeValue)

Sets the value of PDM Reference attribute on the object. 

SetReferenceAttribute (self, title, value)

Creates or modifies a string attribute which uses a reference string. 

SetReferenceAttribute (self, title, value, option)

Creates or modifies a string attribute which uses a reference string, with the option to update or not. 

SetTimeAttribute (self, title, value)

Creates or modifies a time attribute. 

SetTimeAttribute (self, title, value, option)

Creates or modifies a time attribute with the option to update or not. 

SetTimeUserAttribute (self, title, index, value, option)

Creates or modifies a time attribute with the option to update or not. 

SetTimeUserAttribute (self, title, index, value, option)

Creates or modifies a time attribute with the option to update or not. 

SetUserAttribute (self, info, option)

Creates or modifies an attribute with the option to update or not. 

SetUserAttribute (self, title, index, option)

Creates or modifies a null attribute with the option to update or not. 

SetUserAttribute (self, title, index, value, option)

Creates or modifies an integer attribute with the option to update or not. 

SetUserAttribute (self, title, index, value, option)

Creates or modifies a real attribute with the option to update or not. 

SetUserAttribute (self, title, index, value, option)

Creates or modifies a string attribute with the option to update or not. 

SetUserAttributeLock (self, title, type, lock)

Lock or unlock the given attribute. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

Public Attributes inherited from NXOpen.NXObject

NXObjectAttributeInformation_Struct = NXObject.AttributeInformation

NXOpen.NXObjectAttributeInformation_Struct is an alias for NXOpen.NXObject.AttributeInformation. 

NXObjectAttributeType = NXObject.AttributeType

NXOpen.NXObjectAttributeType is an alias for NXOpen.NXObject.AttributeType 

NXObjectComputationalTime_Struct = NXObject.ComputationalTime

NXOpen.NXObjectComputationalTime_Struct is an alias for NXOpen.NXObject.ComputationalTime. 

NXObjectDateAndTimeFormat = NXObject.DateAndTimeFormat

NXOpen.NXObjectDateAndTimeFormat is an alias for NXOpen.NXObject.DateAndTimeFormat 

## Detailed Description

Extract Attribute Journaling class 

This object does not need a creator. 

Created in NX11.0.0 

Copyright 2025 Siemens
