# NXOpen.AME.DB.DocumentStructure Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00041.html>

## Classes

class — Attribute

Represents the attribute for Document Structure 

Enumerator — Comment

NotSet

Function

Location

Product

Dcc

More...

Copyright 2025 Siemens
