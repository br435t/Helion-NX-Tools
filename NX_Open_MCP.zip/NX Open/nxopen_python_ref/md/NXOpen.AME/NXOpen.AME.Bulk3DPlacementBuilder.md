# NXOpen.AME.Bulk3DPlacementBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00029.html>

## Classes

class — PlacementAnglePolicy

Represents placement angle 

Enumerator — Comment

ZeroDegree

NinetyDegree

OneEightyDegree

TwoSeventyDegree

More...

class — PlacementTypePolicy

Represents placement type 

Enumerator — Comment

LefttoRight

RighttoLeft

ToptoBottom

BottomtoTop

More...

Copyright 2025 Siemens
