# NXOpen.AME.TiaPortalProjectSettingsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00098.html>

## Classes

class — TiaPortalVersionType

represents the TIA Portal Version type 

Enumerator — Comment

V14Sp1

V15

V151

V16

V17

V18

V19

More...

Copyright 2025 Siemens
