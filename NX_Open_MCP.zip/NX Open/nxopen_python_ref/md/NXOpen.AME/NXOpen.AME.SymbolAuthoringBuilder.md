# NXOpen.AME.SymbolAuthoringBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00096.html>

## Classes

class — Types

Represents the type of symbol 

Enumerator — Comment

StandardSymbol

CableDefinitionLine

More...

Copyright 2025 Siemens
