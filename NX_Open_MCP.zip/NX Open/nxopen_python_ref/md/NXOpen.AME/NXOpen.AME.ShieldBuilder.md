# NXOpen.AME.ShieldBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00093.html>

## Classes

class — Variant

Represents Shield Cable Variant type 

Enumerator — Comment

H

V

More...

Copyright 2025 Siemens
