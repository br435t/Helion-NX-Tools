# NXOpen.AME.CreateReportBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00038.html>

## Classes

class — Types

Represents the type of report 

Enumerator — Comment

AspectListFunction

AspectListLocation

BillOfMaterial

BillOfMaterialCrossref

CableDiagram

CableList

ConnectionListBomElectrical

ConnectionListElectrical

ConnectionListHose

ConnectionListTube

TableOfContents

ProjectTitlePage

TerminalDiagram

TerminalDiagramCrossref

TerminalMatrixDiagram

TerminalMatrixDiagramCrossref

ConnectionBomHose

ConnectionBomTube

DevicePurchaseList

CablePurchaseList

More...

Copyright 2025 Siemens
