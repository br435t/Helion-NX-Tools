# NXOpen.AME.PortBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00083.html>

## Classes

class — ConnectableAttrProxyObjectType

Represents the type of connectable attribute proxy object for typed port 

Enumerator — Comment

All

Library

Tag

More...

class — CreationModeType

Represents the type of creation mode 

Enumerator — Comment

New

Library

More...

class — Type

the type of a port 

Enumerator — Comment

All

Caller

Operand

Method

Block

More...

Copyright 2025 Siemens
