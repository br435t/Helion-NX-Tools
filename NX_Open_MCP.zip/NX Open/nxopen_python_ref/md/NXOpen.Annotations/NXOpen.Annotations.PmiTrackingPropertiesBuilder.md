# NXOpen.Annotations.PmiTrackingPropertiesBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13889.html>

Represents a NXOpen::Annotations::PmiTrackingPropertiesBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreatePmiTrackingPropertiesBuilder 

More...

Inheritance diagram for NXOpen.Annotations.PmiTrackingPropertiesBuilder:

## Public Member Functions

GetPmiTrackingPropertyStatus (self, propertyName)

Get the modified tracking status of Inherit PMI properties. 

LoadDefaultSettings (self)

It load default settings for all properties as defined in inherit.xml file. 

SetPmiTrackingPropertyStatus (self, propertyName, propertyStatus)

Set the modified tracking status of Inherit PMI properties. 

UpdateTrackingProperties (self)

Updates the Inherit PMI properties tracking list. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::PmiTrackingPropertiesBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreatePmiTrackingPropertiesBuilder 

Created in NX10.0.0 

## Member Function Documentation

## ◆ GetPmiTrackingPropertyStatus()

NXOpen.Annotations.PmiTrackingPropertiesBuilder.GetPmiTrackingPropertyStatus
(
self,

propertyName )

Get the modified tracking status of Inherit PMI properties. 

Returns
propertyStatus (bool): .

Created in NX10.0.0 

License requirements: None.

Parameters

propertyName — (str)

## ◆ LoadDefaultSettings()

NXOpen.Annotations.PmiTrackingPropertiesBuilder.LoadDefaultSettings
(
self — )

It load default settings for all properties as defined in inherit.xml file. 

Created in NX10.0.0 

License requirements: drafting ("DRAFTING") 

## ◆ SetPmiTrackingPropertyStatus()

NXOpen.Annotations.PmiTrackingPropertiesBuilder.SetPmiTrackingPropertyStatus
(
self,

propertyName,

propertyStatus )

Set the modified tracking status of Inherit PMI properties. 

Created in NX10.0.0 

License requirements: drafting ("DRAFTING")

Parameters

propertyName — (str)

propertyStatus — (bool)

## ◆ UpdateTrackingProperties()

NXOpen.Annotations.PmiTrackingPropertiesBuilder.UpdateTrackingProperties
(
self — )

Updates the Inherit PMI properties tracking list. 

Created in NX10.0.0 

License requirements: drafting ("DRAFTING") 

Copyright 2025 Siemens
