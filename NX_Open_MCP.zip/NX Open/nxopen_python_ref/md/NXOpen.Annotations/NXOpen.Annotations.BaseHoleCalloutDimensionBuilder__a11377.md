# NXOpen.Annotations.BaseHoleCalloutDimensionBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11377.html>

Represents a NXOpen::Annotations::BaseHoleCalloutDimensionBuilder builder 

This is an abstract class and cannot be instantiated. 
More...

Inheritance diagram for NXOpen.Annotations.BaseHoleCalloutDimensionBuilder:

## Public Member Functions

AppendedText (self)

Getter for property: (NXOpen.Annotations.AppendedTextBuilder) AppendedText Returns the appended text. 

CanReverseFeatureDirection (self)

Determines whether the direction of the current feature can be reversed. 

FirstAssociativity (self)

Getter for property: (NXOpen.SelectNXObject) FirstAssociativity Returns the first associativity. 

GetNthSecondaryArrowheadOrientation (self, nth)

The arrowhead orientation for nth secondary dimensions. 

GetNthSecondaryOrigin (self, nth)

The origin for nth secondary dimensions. 

GetSecondaryCallouts (self)

The secondary callouts. 

Inherit (self)

Getter for property: (NXOpen.SelectDisplayableObject) Inherit Returns the hole dimension from which the properties are inherited. 

IsAutoplaced (self)

Getter for property: (bool) IsAutoplaced Returns the flag to indicate if auto placement turned on. 

IsAutoplaced (self, isAutoplaced)

Setter for property: (bool) IsAutoplaced. 

IsHoleStyle (self)

Getter for property: (bool) IsHoleStyle Returns the flag to indicate if dimension is of hole style. 

IsHoleStyle (self, isArrowsOutDia)

Setter for property: (bool) IsHoleStyle. 

Measurement (self)

Getter for property: (NXOpen.Annotations.DimensionMeasurementBuilder) Measurement Returns the measurement parameters. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

ReverseFeatureDirection (self)

Reverses the direction of the current feature. 

SecondAssociativity (self)

Getter for property: (NXOpen.SelectNXObject) SecondAssociativity Returns the second associativity. 

SetNthSecondaryArrowheadOrientation (self, nth, secondaryArrowheadOrientation)

The arrowhead orientation for nth secondary dimensions. 

SetNthSecondaryOrigin (self, nth, secondaryOrigin)

The origin for nth secondary dimensions. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

Type (self)

Getter for property: (NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.HolecalloutType) Type Returns the hole callout type. 

Type (self, type)

Setter for property: (NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.HolecalloutType) Type. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

BaseHoleCalloutDimensionBuilderHolecalloutType = BaseHoleCalloutDimensionBuilder.HolecalloutType

NXOpen.Annotations.BaseHoleCalloutDimensionBuilderHolecalloutType is an alias for NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.HolecalloutType 

## Detailed Description

Represents a NXOpen::Annotations::BaseHoleCalloutDimensionBuilder builder 

This is an abstract class and cannot be instantiated. 

Created in NX2206.0.0 

## Member Function Documentation

## ◆ AppendedText()

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.AppendedText
(
self — )

Getter for property: (NXOpen.Annotations.AppendedTextBuilder) AppendedText Returns the appended text. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
AppendedTextBuilder 

## ◆ CanReverseFeatureDirection()

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.CanReverseFeatureDirection
(
self — )

Determines whether the direction of the current feature can be reversed. 

Returns
canReverse (bool): .

Created in NX2212.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") 

## ◆ FirstAssociativity()

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.FirstAssociativity
(
self — )

Getter for property: (NXOpen.SelectNXObject) FirstAssociativity Returns the first associativity. 

Supported object types include Feature and DisplayableObject.

Getter License requirements: None.

Created in NX2206.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ GetNthSecondaryArrowheadOrientation()

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.GetNthSecondaryArrowheadOrientation
(
self,

nth )

The arrowhead orientation for nth secondary dimensions. 

Returns
secondaryArrowheadOrientation (NXOpen.Annotations.TextPlacement): .

Created in NX2206.0.0 

License requirements: None.

Parameters

nth — (int) The index of secondary dimension in the range of 0..N-1

## ◆ GetNthSecondaryOrigin()

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.GetNthSecondaryOrigin
(
self,

nth )

The origin for nth secondary dimensions. 

Returns
secondaryOrigin (NXOpen.Point3d): .

Created in NX2206.0.0 

License requirements: None.

Parameters

nth — (int) The index of secondary dimension in the range of 0..N-1

## ◆ GetSecondaryCallouts()

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.GetSecondaryCallouts
(
self — )

The secondary callouts. 

Returns
secondaryCallouts (List[NXOpen.Annotations.Dimension]): .

Created in NX2206.0.0 

License requirements: None. 

## ◆ Inherit()

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.Inherit
(
self — )

Getter for property: (NXOpen.SelectDisplayableObject) Inherit Returns the hole dimension from which the properties are inherited. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
NXOpen.SelectDisplayableObject 

## ◆ IsAutoplaced() [1/2]

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.IsAutoplaced
(
self — )

Getter for property: (bool) IsAutoplaced Returns the flag to indicate if auto placement turned on. 

This is used to compute origins for secondary dimensions.

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IsAutoplaced() [2/2]

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.IsAutoplaced
(
self,

isAutoplaced )

Setter for property: (bool) IsAutoplaced. 

Sets the flag to indicate if auto placement turned on. This is used to compute origins for secondary dimensions.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2206.0.0 

## ◆ IsHoleStyle() [1/2]

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.IsHoleStyle
(
self — )

Getter for property: (bool) IsHoleStyle Returns the flag to indicate if dimension is of hole style. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IsHoleStyle() [2/2]

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.IsHoleStyle
(
self,

isArrowsOutDia )

Setter for property: (bool) IsHoleStyle. 

Sets the flag to indicate if dimension is of hole style.

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX2206.0.0 

## ◆ Measurement()

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.Measurement
(
self — )

Getter for property: (NXOpen.Annotations.DimensionMeasurementBuilder) Measurement Returns the measurement parameters. 

Note that only the folowing properties apply:

## . NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.MeasurementMethod.PartOccurrence.

Getter License requirements: None.

Created in NX2206.0.0 

Returns
DimensionMeasurementBuilder 

## ◆ Origin()

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.Origin
(
self — )

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
OriginBuilder 

## ◆ ReverseFeatureDirection()

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.ReverseFeatureDirection
(
self — )

Reverses the direction of the current feature. 

Created in NX2212.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") 

## ◆ SecondAssociativity()

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.SecondAssociativity
(
self — )

Getter for property: (NXOpen.SelectNXObject) SecondAssociativity Returns the second associativity. 

Supported object types include Feature and DisplayableObject.

Getter License requirements: None.

Created in NX2206.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ SetNthSecondaryArrowheadOrientation()

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.SetNthSecondaryArrowheadOrientation
(
self,

nth,

secondaryArrowheadOrientation )

The arrowhead orientation for nth secondary dimensions. 

Created in NX2206.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

nth — (int) The index of secondary dimension in the range of 0..N-1

secondaryArrowheadOrientation — (NXOpen.Annotations.TextPlacement)

## ◆ SetNthSecondaryOrigin()

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.SetNthSecondaryOrigin
(
self,

nth,

secondaryOrigin )

The origin for nth secondary dimensions. 

Created in NX2206.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

nth — (int) The index of secondary dimension in the range of 0..N-1

secondaryOrigin — (NXOpen.Point3d)

## ◆ Style()

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.Style
(
self — )

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
StyleBuilder 

## ◆ Type() [1/2]

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.Type
(
self — )

Getter for property: (NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.HolecalloutType) Type Returns the hole callout type. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
BaseHoleCalloutDimensionBuilder.HolecalloutType 

## ◆ Type() [2/2]

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.Type
(
self,

type )

Setter for property: (NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.HolecalloutType) Type. 

Sets the hole callout type.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2206.0.0 

## Member Data Documentation

## ◆ BaseHoleCalloutDimensionBuilderHolecalloutType

NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.BaseHoleCalloutDimensionBuilderHolecalloutType = BaseHoleCalloutDimensionBuilder.HolecalloutType

NXOpen.Annotations.BaseHoleCalloutDimensionBuilderHolecalloutType is an alias for NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.HolecalloutType 

Copyright 2025 Siemens
