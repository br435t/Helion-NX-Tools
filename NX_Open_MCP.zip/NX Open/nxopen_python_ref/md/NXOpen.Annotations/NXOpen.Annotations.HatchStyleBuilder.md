# NXOpen.Annotations.HatchStyleBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12493.html>

Represents a NXOpen::Annotations::HatchStyleBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.HatchStyleBuilder:

## Public Member Functions

AreaFillAngle (self)

Getter for property: (float) AreaFillAngle Returns the area fill angle. 

AreaFillAngle (self, areaFillAngle)

Setter for property: (float) AreaFillAngle. 

AreaFillMaterial (self)

Getter for property: (NXOpen.Annotations.AreaFillMaterial) AreaFillMaterial Returns the area fill material. 

AreaFillMaterial (self, areaFillMaterial)

Setter for property: (NXOpen.Annotations.AreaFillMaterial) AreaFillMaterial. 

AreaFillScale (self)

Getter for property: (float) AreaFillScale Returns the area fill scale. 

AreaFillScale (self, areaFillScale)

Setter for property: (float) AreaFillScale. 

AutoTextIsland (self)

Getter for property: (bool) AutoTextIsland Returns the automatic text island creation flag. 

AutoTextIsland (self, autoTextIsland)

Setter for property: (bool) AutoTextIsland. 

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color of crosshatch or area fill lines or area fill solid fill color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

FindApparentIntersections (self)

Getter for property: (bool) FindApparentIntersections Returns the Find Apparent Intersections creation flag. 

FindApparentIntersections (self, findApparentIntersections)

Setter for property: (bool) FindApparentIntersections. 

HatchAngle (self)

Getter for property: (float) HatchAngle Returns the angle of the crosshatching lines. 

HatchAngle (self, angle)

Setter for property: (float) HatchAngle. 

HatchDistance (self)

Getter for property: (float) HatchDistance Returns the distance between crosshatch lines. 

HatchDistance (self, distance)

Setter for property: (float) HatchDistance. 

HatchFile (self)

Getter for property: (str) HatchFile Returns the crosshatch definition file. 

HatchFile (self, file)

Setter for property: (str) HatchFile. 

HatchMaterial (self)

Getter for property: (str) HatchMaterial Returns the crosshatch material. 

HatchMaterial (self, material)

Setter for property: (str) HatchMaterial. 

IslandMargin (self)

Getter for property: (float) IslandMargin Returns the Island margin. 

IslandMargin (self, islandMargin)

Setter for property: (float) IslandMargin. 

LineWidth (self)

Getter for property: (NXOpen.Annotations.LineWidth) LineWidth Returns the line width for crosshatch lines. 

LineWidth (self, lineWidth)

Setter for property: (NXOpen.Annotations.LineWidth) LineWidth. 

Tolerance (self)

Getter for property: (float) Tolerance Returns the crosshatch and area fill tolerance. 

Tolerance (self, tolerance)

Setter for property: (float) Tolerance. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::HatchStyleBuilder . 

This class queries and sets crosshatching and area fill preferences when creating and editing crosshatching and area fill drafting annotations.

Created in NX6.0.0 

## Member Function Documentation

## ◆ AreaFillAngle() [1/2]

NXOpen.Annotations.HatchStyleBuilder.AreaFillAngle
(
self — )

Getter for property: (float) AreaFillAngle Returns the area fill angle. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ AreaFillAngle() [2/2]

NXOpen.Annotations.HatchStyleBuilder.AreaFillAngle
(
self,

areaFillAngle )

Setter for property: (float) AreaFillAngle. 

Sets the area fill angle

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ AreaFillMaterial() [1/2]

NXOpen.Annotations.HatchStyleBuilder.AreaFillMaterial
(
self — )

Getter for property: (NXOpen.Annotations.AreaFillMaterial) AreaFillMaterial Returns the area fill material. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
AreaFillMaterial 

## ◆ AreaFillMaterial() [2/2]

NXOpen.Annotations.HatchStyleBuilder.AreaFillMaterial
(
self,

areaFillMaterial )

Setter for property: (NXOpen.Annotations.AreaFillMaterial) AreaFillMaterial. 

Sets the area fill material

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ AreaFillScale() [1/2]

NXOpen.Annotations.HatchStyleBuilder.AreaFillScale
(
self — )

Getter for property: (float) AreaFillScale Returns the area fill scale. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ AreaFillScale() [2/2]

NXOpen.Annotations.HatchStyleBuilder.AreaFillScale
(
self,

areaFillScale )

Setter for property: (float) AreaFillScale. 

Sets the area fill scale

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ AutoTextIsland() [1/2]

NXOpen.Annotations.HatchStyleBuilder.AutoTextIsland
(
self — )

Getter for property: (bool) AutoTextIsland Returns the automatic text island creation flag. 

A value of True means a text island will be created when the crosshatch or area fill is created

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ AutoTextIsland() [2/2]

NXOpen.Annotations.HatchStyleBuilder.AutoTextIsland
(
self,

autoTextIsland )

Setter for property: (bool) AutoTextIsland. 

Sets the automatic text island creation flag.

A value of True means a text island will be created when the crosshatch or area fill is created

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ Color() [1/2]

NXOpen.Annotations.HatchStyleBuilder.Color
(
self — )

Getter for property: (NXOpen.NXColor) Color Returns the color of crosshatch or area fill lines or area fill solid fill color. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.NXColor 

## ◆ Color() [2/2]

NXOpen.Annotations.HatchStyleBuilder.Color
(
self,

color )

Setter for property: (NXOpen.NXColor) Color. 

Sets the color of crosshatch or area fill lines or area fill solid fill color

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ FindApparentIntersections() [1/2]

NXOpen.Annotations.HatchStyleBuilder.FindApparentIntersections
(
self — )

Getter for property: (bool) FindApparentIntersections Returns the Find Apparent Intersections creation flag. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ FindApparentIntersections() [2/2]

NXOpen.Annotations.HatchStyleBuilder.FindApparentIntersections
(
self,

findApparentIntersections )

Setter for property: (bool) FindApparentIntersections. 

Sets the Find Apparent Intersections creation flag.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ HatchAngle() [1/2]

NXOpen.Annotations.HatchStyleBuilder.HatchAngle
(
self — )

Getter for property: (float) HatchAngle Returns the angle of the crosshatching lines. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ HatchAngle() [2/2]

NXOpen.Annotations.HatchStyleBuilder.HatchAngle
(
self,

angle )

Setter for property: (float) HatchAngle. 

Sets the angle of the crosshatching lines

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ HatchDistance() [1/2]

NXOpen.Annotations.HatchStyleBuilder.HatchDistance
(
self — )

Getter for property: (float) HatchDistance Returns the distance between crosshatch lines. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ HatchDistance() [2/2]

NXOpen.Annotations.HatchStyleBuilder.HatchDistance
(
self,

distance )

Setter for property: (float) HatchDistance. 

Sets the distance between crosshatch lines

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ HatchFile() [1/2]

NXOpen.Annotations.HatchStyleBuilder.HatchFile
(
self — )

Getter for property: (str) HatchFile Returns the crosshatch definition file. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ HatchFile() [2/2]

NXOpen.Annotations.HatchStyleBuilder.HatchFile
(
self,

file )

Setter for property: (str) HatchFile. 

Sets the crosshatch definition file

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ HatchMaterial() [1/2]

NXOpen.Annotations.HatchStyleBuilder.HatchMaterial
(
self — )

Getter for property: (str) HatchMaterial Returns the crosshatch material. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ HatchMaterial() [2/2]

NXOpen.Annotations.HatchStyleBuilder.HatchMaterial
(
self,

material )

Setter for property: (str) HatchMaterial. 

Sets the crosshatch material

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ IslandMargin() [1/2]

NXOpen.Annotations.HatchStyleBuilder.IslandMargin
(
self — )

Getter for property: (float) IslandMargin Returns the Island margin. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
float 

## ◆ IslandMargin() [2/2]

NXOpen.Annotations.HatchStyleBuilder.IslandMargin
(
self,

islandMargin )

Setter for property: (float) IslandMargin. 

Sets the Island margin

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ LineWidth() [1/2]

NXOpen.Annotations.HatchStyleBuilder.LineWidth
(
self — )

Getter for property: (NXOpen.Annotations.LineWidth) LineWidth Returns the line width for crosshatch lines. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWidth 

## ◆ LineWidth() [2/2]

NXOpen.Annotations.HatchStyleBuilder.LineWidth
(
self,

lineWidth )

Setter for property: (NXOpen.Annotations.LineWidth) LineWidth. 

Sets the line width for crosshatch lines

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ Tolerance() [1/2]

NXOpen.Annotations.HatchStyleBuilder.Tolerance
(
self — )

Getter for property: (float) Tolerance Returns the crosshatch and area fill tolerance. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ Tolerance() [2/2]

NXOpen.Annotations.HatchStyleBuilder.Tolerance
(
self,

tolerance )

Setter for property: (float) Tolerance. 

Sets the crosshatch and area fill tolerance

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

Copyright 2025 Siemens
