# NXOpen.Annotations.PmiWaveLinkBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13921.html>

Represents a NXOpen::Annotations::Pmi builder 

To create a new instance of this class, use NXOpen::Annotations::PmiWaveCollection::CreatePmiWaveLinkBuilder 

More...

Inheritance diagram for NXOpen.Annotations.PmiWaveLinkBuilder:

## Public Member Functions

GeometryTypeToWAVELink (self)

Getter for property: (int) GeometryTypeToWAVELink Returns the associated geometry type to WAVE link. 

GeometryTypeToWAVELink (self, geometryType)

Setter for property: (int) GeometryTypeToWAVELink. 

SelectedPMI (self)

Getter for property: (NXOpen.Annotations.SelectAnnotationList) SelectedPMI Returns the list of selected PMI to be WAVE linked. 

SourcePart (self)

Getter for property: (NXOpen.TaggedObject) SourcePart Returns the source part for the WAVE link. 

SourcePart (self, sourcePart1)

Setter for property: (NXOpen.TaggedObject) SourcePart. 

TargetPart (self)

Getter for property: (NXOpen.TaggedObject) TargetPart Returns the target part for the WAVE link. 

TargetPart (self, targetPart)

Setter for property: (NXOpen.TaggedObject) TargetPart. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::Pmi builder 

To create a new instance of this class, use NXOpen::Annotations::PmiWaveCollection::CreatePmiWaveLinkBuilder 

Created in NX8.0.0 

## Member Function Documentation

## ◆ GeometryTypeToWAVELink() [1/2]

NXOpen.Annotations.PmiWaveLinkBuilder.GeometryTypeToWAVELink
(
self — )

Getter for property: (int) GeometryTypeToWAVELink Returns the associated geometry type to WAVE link. 

Getter License requirements: solid_modeling ("SOLIDS MODELING")

Created in NX8.0.0 

Returns
int 

## ◆ GeometryTypeToWAVELink() [2/2]

NXOpen.Annotations.PmiWaveLinkBuilder.GeometryTypeToWAVELink
(
self,

geometryType )

Setter for property: (int) GeometryTypeToWAVELink. 

Sets the associated geometry type to WAVE link

Setter License requirements: solid_modeling ("SOLIDS MODELING")

Created in NX8.0.0 

## ◆ SelectedPMI()

NXOpen.Annotations.PmiWaveLinkBuilder.SelectedPMI
(
self — )

Getter for property: (NXOpen.Annotations.SelectAnnotationList) SelectedPMI Returns the list of selected PMI to be WAVE linked. 

Getter License requirements: solid_modeling ("SOLIDS MODELING")

Created in NX8.0.0 

Returns
SelectAnnotationList 

## ◆ SourcePart() [1/2]

NXOpen.Annotations.PmiWaveLinkBuilder.SourcePart
(
self — )

Getter for property: (NXOpen.TaggedObject) SourcePart Returns the source part for the WAVE link. 

Getter License requirements: solid_modeling ("SOLIDS MODELING")

Created in NX8.0.0 

Returns
NXOpen.TaggedObject 

## ◆ SourcePart() [2/2]

NXOpen.Annotations.PmiWaveLinkBuilder.SourcePart
(
self,

sourcePart1 )

Setter for property: (NXOpen.TaggedObject) SourcePart. 

Sets the source part for the WAVE link

Setter License requirements: solid_modeling ("SOLIDS MODELING")

Created in NX8.0.0 

## ◆ TargetPart() [1/2]

NXOpen.Annotations.PmiWaveLinkBuilder.TargetPart
(
self — )

Getter for property: (NXOpen.TaggedObject) TargetPart Returns the target part for the WAVE link. 

Getter License requirements: solid_modeling ("SOLIDS MODELING")

Created in NX8.0.0 

Returns
NXOpen.TaggedObject 

## ◆ TargetPart() [2/2]

NXOpen.Annotations.PmiWaveLinkBuilder.TargetPart
(
self,

targetPart )

Setter for property: (NXOpen.TaggedObject) TargetPart. 

Sets the target part for the WAVE link

Setter License requirements: solid_modeling ("SOLIDS MODELING")

Created in NX8.0.0 

Copyright 2025 Siemens
