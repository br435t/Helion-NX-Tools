# NXOpen.Annotations.SingleSidedDisplayBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a14397.html>

Represents a NXOpen::Annotations::SingleSidedDisplayBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.SingleSidedDisplayBuilder:

## Public Member Functions

DisableAutoSingleSided (self)

Getter for property: (bool) DisableAutoSingleSided Returns the disable automatically display as single sided. 

DisableAutoSingleSided (self, disableAutoSingleSided)

Setter for property: (bool) DisableAutoSingleSided. 

DisplayAsSingleSided (self)

Getter for property: (bool) DisplayAsSingleSided Returns the display as single sided. 

DisplayAsSingleSided (self, displayAsSingleSided)

Setter for property: (bool) DisplayAsSingleSided. 

Flip (self)

Flips the side of single sided dimension. 

SingleSidedArrowLineLength (self)

Getter for property: (float) SingleSidedArrowLineLength Returns the arrow line length on the open side of single sided dimension. 

SingleSidedArrowLineLength (self, singleSidedArrowLineLength)

Setter for property: (float) SingleSidedArrowLineLength. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::SingleSidedDisplayBuilder . 

This is a sub-builder class and cannot be directly instantiated 

Created in NX10.0.0 

## Member Function Documentation

## ◆ DisableAutoSingleSided() [1/2]

NXOpen.Annotations.SingleSidedDisplayBuilder.DisableAutoSingleSided
(
self — )

Getter for property: (bool) DisableAutoSingleSided Returns the disable automatically display as single sided. 

Getter License requirements: None.

Created in NX1926.0.0 

Returns
bool 

## ◆ DisableAutoSingleSided() [2/2]

NXOpen.Annotations.SingleSidedDisplayBuilder.DisableAutoSingleSided
(
self,

disableAutoSingleSided )

Setter for property: (bool) DisableAutoSingleSided. 

Sets the disable automatically display as single sided

Setter License requirements: drafting ("DRAFTING")

Created in NX1926.0.0 

## ◆ DisplayAsSingleSided() [1/2]

NXOpen.Annotations.SingleSidedDisplayBuilder.DisplayAsSingleSided
(
self — )

Getter for property: (bool) DisplayAsSingleSided Returns the display as single sided. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
bool 

## ◆ DisplayAsSingleSided() [2/2]

NXOpen.Annotations.SingleSidedDisplayBuilder.DisplayAsSingleSided
(
self,

displayAsSingleSided )

Setter for property: (bool) DisplayAsSingleSided. 

Sets the display as single sided

Setter License requirements: drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ Flip()

NXOpen.Annotations.SingleSidedDisplayBuilder.Flip
(
self — )

Flips the side of single sided dimension. 

Created in NX10.0.0 

License requirements: drafting ("DRAFTING") 

## ◆ SingleSidedArrowLineLength() [1/2]

NXOpen.Annotations.SingleSidedDisplayBuilder.SingleSidedArrowLineLength
(
self — )

Getter for property: (float) SingleSidedArrowLineLength Returns the arrow line length on the open side of single sided dimension. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
float 

## ◆ SingleSidedArrowLineLength() [2/2]

NXOpen.Annotations.SingleSidedDisplayBuilder.SingleSidedArrowLineLength
(
self,

singleSidedArrowLineLength )

Setter for property: (float) SingleSidedArrowLineLength. 

Sets the arrow line length on the open side of single sided dimension

Setter License requirements: drafting ("DRAFTING")

Created in NX10.0.0 

Copyright 2025 Siemens
