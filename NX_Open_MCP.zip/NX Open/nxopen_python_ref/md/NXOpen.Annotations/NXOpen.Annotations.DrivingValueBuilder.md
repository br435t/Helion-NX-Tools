# NXOpen.Annotations.DrivingValueBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00155.html>

## Classes

class — DrivingExpressionMode

the driving expression mode 

Enumerator — Comment

MeasureGeometry

KeepExpression

More...

class — DrivingValueMethod

the driving value method 

Enumerator — Comment

Inferred

Driving

Reference

Constant

More...

Copyright 2025 Siemens
