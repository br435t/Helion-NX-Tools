# NXOpen.Annotations.PmiLineWeldData Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00198.html>

## Classes

class — AlongContourTypes

Specifies the PMI Line Weld along-contour type 

Enumerator — Comment

NotSet — No Weld Along Contour

Closed — Weld Along Contour Closed

Unclosed — Weld Along Contour Unclosed

Trilateral — Weld Along Contour Trilateral

AllAround — Weld Along Contour All Around

More...

class — FinishSymbolTypes

Specifies the PMI Line Weld finish symbol type 

Enumerator — Comment

NotSet — No finish symbol type specified

Chipping — Chipping finish

Grinding — Grinding finish

Machining — Machining finish

Hammering — Hammering finish

Peening — Peening finish

Rolling — Rolling finish

Finishing — Finishing finish

More...

class — StandardTypes

Specifies the PMI Line Weld standard 

Enumerator — Comment

NotSet — None

Ansi — ANSI standard

Iso — ISO standard

Din — DIN standard

Jis — JIS standard

Eskd — ESKD standard

Gb — GB standard

More...

class — SupplementalSymbolTypes

Specifies the PMI Line Weld supplemental symbol type 

Enumerator — Comment

NotSet — No supplemental weld symbol

Flush — Flush supplemental weld symbol

Convex — Convex supplemental weld symbol

Concave — Concave supplemental weld symbol

ToesBlended — Blended Toes supplemental weld symbol

PermanentBackingStripSupplemental — Backing strip permanent weld symbol

RemovableBackingStripSupplemental — Backing strip removable weld symbol

MeltThrough — Melt through supplemental weld symbol

More...

class — SymbolTypes

Specifies the PMI Line Weld symbol type 

Enumerator — Comment

NotSet

EdgeFlange

DoubleFlange

FlareSingleVGroove

Square

SquareGroove

SingleV

SingleVGroove

SingleBevel

SingleBevelGroove

SingleFlange

FlareSingleBevelGroove

SingleVBroadRootFace

SingleBevelBroadRootFace

SingleU

SingleUGroove

SingleJ

SingleJGroove

Backing

Bead

KGroove

Fillet

JisFillet

Stake

Plug

PlugAndSlot

Seam

Seam2

JisSeam

SteepFlankedSingleV

SteepFlankedSingleBevel

Edge

Edge2

Surface

Overlay

SurfaceJoint

SolderedJoint

InclinedJoint

FoldJoint

Spot

Spot2

Stud

SpotProjected

PermanentBackingStrip

RemovableBackingStrip

JisStaggeredFillet1

JisStaggeredFillet2

Intermittent

BackingPlate

More...

Copyright 2025 Siemens
