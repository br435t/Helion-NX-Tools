# NXOpen.Annotations.NoteCollection Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13009.html>

Represents a collection of notes 

To obtain an instance of this class, refer to NXOpen::Part 

More...

Inheritance diagram for NXOpen.Annotations.NoteCollection:

## Public Member Functions

CreatePmiNote (self, note_data, pmi_data, annotation_plane, origin)

Creates a PMI note. 

NewNoteData (self)

Creates a new NoteData object. 

## Detailed Description

Represents a collection of notes 

To obtain an instance of this class, refer to NXOpen::Part 

Created in NX3.0.0 

## Member Function Documentation

## ◆ CreatePmiNote()

NXOpen.Annotations.NoteCollection.CreatePmiNote
(
self,

note_data,

pmi_data,

annotation_plane,

origin )

Creates a PMI note. 

Returns
note (NXOpen.Annotations.PmiNote): New PMI note .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

note_data — (NXOpen.Annotations.NoteData) Note data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the note lies

origin — (NXOpen.Point3d) Origin for the note

## ◆ NewNoteData()

NXOpen.Annotations.NoteCollection.NewNoteData
(
self — )

Creates a new NoteData object. 

Returns
note_data (NXOpen.Annotations.NoteData): New NoteData .

Created in NX4.0.0 

License requirements: None. 

Copyright 2025 Siemens
