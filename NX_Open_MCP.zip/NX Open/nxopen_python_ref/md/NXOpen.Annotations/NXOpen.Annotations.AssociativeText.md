# NXOpen.Annotations.AssociativeText Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00128.html>

## Classes

class — PropertyType

the associative text property type to be used with the object 

Enumerator — Comment

DrawingNumberOfSheets — Drawing sheet number of sheets

DrawingNumberOfPrimarySheets — Drawing sheet number of primary sheets

DrawingSheetName — Drawing sheet name

DrawingSheetNumber — Drawing sheet number

DrawingSheetRevision — Drawing sheet revision

DrawingSheetScaleNumerator — Drawing sheet scale numerator

DrawingSheetScaleDenominator — Drawing sheet scale denominator

DrawingSheetSize — Drawing sheet size

DrawingSheetUnits — Drawing sheet units

DrawingSheetZone — Drawing sheet zone

DrawingSheetProjectionAngle — Drawing sheet projection angle

DrawingMasterPartName — Drawing master part name

DrawingPartName — Drawing part name

DrawingViewPrefix — Drawing view prefix

DrawingViewRotationAngle — View rotation angle

More...

Copyright 2025 Siemens
