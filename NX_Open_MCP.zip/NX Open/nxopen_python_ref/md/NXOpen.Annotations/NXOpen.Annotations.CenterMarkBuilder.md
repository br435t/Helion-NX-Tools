# NXOpen.Annotations.CenterMarkBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11645.html>

Builder for creating Center Mark. 
More...

Inheritance diagram for NXOpen.Annotations.CenterMarkBuilder:

## Public Member Functions

Inherit (self)

Getter for property: (NXOpen.SelectNXObject) Inherit Returns the inherit object. 

Public Member Functions inherited from NXOpen.Annotations.BaseCenterMarkBuilder

Locations (self)

Getter for property: (NXOpen.SelectNXObjectList) Locations Returns the location object. 

MultipleCenterMarks (self)

Getter for property: (bool) MultipleCenterMarks Returns the multiple center marks option, applicable only for creation. 

MultipleCenterMarks (self, multipleCenterlines)

Setter for property: (bool) MultipleCenterMarks. 

RemoveLocation (self, index)

Removes location object for a given index from the Select Object List. 

Settings (self)

Getter for property: (NXOpen.Annotations.CenterMarkSettingsBuilder) Settings Returns the center mark settings builder. 

Public Member Functions inherited from NXOpen.Annotations.CenterlineBuilder

AddEndExtensions (self, start, end)

Adds extensions only at ends. 

AddExtension (self, index, defaultValue)

Adds extension based on select object index. 

GetAllExtensions (self)

Returns all extensions. 

GetAllIndividualExtensions (self)

Returns individual extensions. 

GetEndExtensions (self)

Returns end extensions only. 

RemoveEndExtensions (self)

Removes extensions only at ends. 

RemoveExtension (self, index)

Removes extension based on select object index. 

ResetAllExtensions (self, defaultValue)

Reset all extensions by the supplied defaultValue. 

SetAllIndividualExtensions (self, extensionValues)

Sets all individual extensions. 

SetEndExtensions (self, start, end)

Modifies end extensions only. 

SetIndividualExtensions (self, index, value1, value2)

Modifies extensions based on select object index. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Builder for creating Center Mark. 

It creates or edits Center Marks 

To create a new instance of this class, use NXOpen::Annotations::CenterlineCollection::CreateCenterMarkBuilder 

Default values. 

Property — Value

MultipleCenterMarks 

false 

Created in NX6.0.0 

## Member Function Documentation

## ◆ Inherit()

NXOpen.Annotations.CenterMarkBuilder.Inherit
(
self — )

Getter for property: (NXOpen.SelectNXObject) Inherit Returns the inherit object. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectNXObject 

Copyright 2025 Siemens
