# NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12565.html>

Represents a NXOpen::Annotations::HoleTableSettingsHoleFiltersBuilder. 
More...

Inheritance diagram for NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder:

## Public Member Functions

BlindHoles (self)

Getter for property: (bool) BlindHoles Returns the blind holes. 

BlindHoles (self, blindHoles)

Setter for property: (bool) BlindHoles. 

CombinationHoles (self)

Getter for property: (bool) CombinationHoles Returns the combination holes. 

CombinationHoles (self, combinationHoles)

Setter for property: (bool) CombinationHoles. 

CounterboredHoles (self)

Getter for property: (bool) CounterboredHoles Returns the counterbored holes. 

CounterboredHoles (self, counterboredHoles)

Setter for property: (bool) CounterboredHoles. 

CountersinkAngle (self)

Getter for property: (float) CountersinkAngle Returns the countersink angle. 

CountersinkAngle (self, countersinkAngle)

Setter for property: (float) CountersinkAngle. 

CountersunkHoles (self)

Getter for property: (bool) CountersunkHoles Returns the countersunk holes. 

CountersunkHoles (self, countersunkHoles)

Setter for property: (bool) CountersunkHoles. 

DraftingSketchCircles (self)

Getter for property: (bool) DraftingSketchCircles Returns the drafting sketch circles. 

DraftingSketchCircles (self, draftingSketchCircles)

Setter for property: (bool) DraftingSketchCircles. 

IncludePartialHoles (self)

Getter for property: (bool) IncludePartialHoles Returns the include partial holes. 

IncludePartialHoles (self, includePartialHoles)

Setter for property: (bool) IncludePartialHoles. 

ModelingSketchCircles (self)

Getter for property: (bool) ModelingSketchCircles Returns the modeling sketch circles. 

ModelingSketchCircles (self, modelingSketchCircles)

Setter for property: (bool) ModelingSketchCircles. 

NoseAngle (self)

Getter for property: (float) NoseAngle Returns the nose angle. 

NoseAngle (self, noseAngle)

Setter for property: (float) NoseAngle. 

PartialHoleAngle (self)

Getter for property: (float) PartialHoleAngle Returns the partial hole angle. 

PartialHoleAngle (self, partialHoleAngle)

Setter for property: (float) PartialHoleAngle. 

Scope (self)

Getter for property: (NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.ScopeType) Scope Returns the scope. 

Scope (self, scope)

Setter for property: (NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.ScopeType) Scope. 

ThreadedHoles (self)

Getter for property: (bool) ThreadedHoles Returns the threaded holes. 

ThreadedHoles (self, threadedHoles)

Setter for property: (bool) ThreadedHoles. 

ThroughHoles (self)

Getter for property: (bool) ThroughHoles Returns the through holes. 

ThroughHoles (self, throughHoles)

Setter for property: (bool) ThroughHoles. 

WireEDMStartHoles (self)

Getter for property: (bool) WireEDMStartHoles Returns the wire EDM start holes. 

WireEDMStartHoles (self, wireEDMStartHoles)

Setter for property: (bool) WireEDMStartHoles. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

HoleTableSettingsHoleFiltersBuilderScopeType = HoleTableSettingsHoleFiltersBuilder.ScopeType

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilderScopeType is an alias for NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.ScopeType 

## Detailed Description

Represents a NXOpen::Annotations::HoleTableSettingsHoleFiltersBuilder. 

Created in NX9.0.0 

## Member Function Documentation

## ◆ BlindHoles() [1/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.BlindHoles
(
self — )

Getter for property: (bool) BlindHoles Returns the blind holes. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ BlindHoles() [2/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.BlindHoles
(
self,

blindHoles )

Setter for property: (bool) BlindHoles. 

Sets the blind holes

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ CombinationHoles() [1/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.CombinationHoles
(
self — )

Getter for property: (bool) CombinationHoles Returns the combination holes. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ CombinationHoles() [2/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.CombinationHoles
(
self,

combinationHoles )

Setter for property: (bool) CombinationHoles. 

Sets the combination holes

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ CounterboredHoles() [1/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.CounterboredHoles
(
self — )

Getter for property: (bool) CounterboredHoles Returns the counterbored holes. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ CounterboredHoles() [2/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.CounterboredHoles
(
self,

counterboredHoles )

Setter for property: (bool) CounterboredHoles. 

Sets the counterbored holes

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ CountersinkAngle() [1/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.CountersinkAngle
(
self — )

Getter for property: (float) CountersinkAngle Returns the countersink angle. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
float 

## ◆ CountersinkAngle() [2/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.CountersinkAngle
(
self,

countersinkAngle )

Setter for property: (float) CountersinkAngle. 

Sets the countersink angle

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ CountersunkHoles() [1/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.CountersunkHoles
(
self — )

Getter for property: (bool) CountersunkHoles Returns the countersunk holes. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ CountersunkHoles() [2/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.CountersunkHoles
(
self,

countersunkHoles )

Setter for property: (bool) CountersunkHoles. 

Sets the countersunk holes

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ DraftingSketchCircles() [1/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.DraftingSketchCircles
(
self — )

Getter for property: (bool) DraftingSketchCircles Returns the drafting sketch circles. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ DraftingSketchCircles() [2/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.DraftingSketchCircles
(
self,

draftingSketchCircles )

Setter for property: (bool) DraftingSketchCircles. 

Sets the drafting sketch circles

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ IncludePartialHoles() [1/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.IncludePartialHoles
(
self — )

Getter for property: (bool) IncludePartialHoles Returns the include partial holes. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ IncludePartialHoles() [2/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.IncludePartialHoles
(
self,

includePartialHoles )

Setter for property: (bool) IncludePartialHoles. 

Sets the include partial holes

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ ModelingSketchCircles() [1/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.ModelingSketchCircles
(
self — )

Getter for property: (bool) ModelingSketchCircles Returns the modeling sketch circles. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ ModelingSketchCircles() [2/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.ModelingSketchCircles
(
self,

modelingSketchCircles )

Setter for property: (bool) ModelingSketchCircles. 

Sets the modeling sketch circles

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ NoseAngle() [1/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.NoseAngle
(
self — )

Getter for property: (float) NoseAngle Returns the nose angle. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
float 

## ◆ NoseAngle() [2/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.NoseAngle
(
self,

noseAngle )

Setter for property: (float) NoseAngle. 

Sets the nose angle

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ PartialHoleAngle() [1/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.PartialHoleAngle
(
self — )

Getter for property: (float) PartialHoleAngle Returns the partial hole angle. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
float 

## ◆ PartialHoleAngle() [2/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.PartialHoleAngle
(
self,

partialHoleAngle )

Setter for property: (float) PartialHoleAngle. 

Sets the partial hole angle

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ Scope() [1/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.Scope
(
self — )

Getter for property: (NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.ScopeType) Scope Returns the scope. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
HoleTableSettingsHoleFiltersBuilder.ScopeType 

## ◆ Scope() [2/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.Scope
(
self,

scope )

Setter for property: (NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.ScopeType) Scope. 

Sets the scope

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ ThreadedHoles() [1/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.ThreadedHoles
(
self — )

Getter for property: (bool) ThreadedHoles Returns the threaded holes. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ ThreadedHoles() [2/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.ThreadedHoles
(
self,

threadedHoles )

Setter for property: (bool) ThreadedHoles. 

Sets the threaded holes

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ ThroughHoles() [1/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.ThroughHoles
(
self — )

Getter for property: (bool) ThroughHoles Returns the through holes. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ ThroughHoles() [2/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.ThroughHoles
(
self,

throughHoles )

Setter for property: (bool) ThroughHoles. 

Sets the through holes

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ WireEDMStartHoles() [1/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.WireEDMStartHoles
(
self — )

Getter for property: (bool) WireEDMStartHoles Returns the wire EDM start holes. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ WireEDMStartHoles() [2/2]

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.WireEDMStartHoles
(
self,

wireEDMStartHoles )

Setter for property: (bool) WireEDMStartHoles. 

Sets the wire EDM start holes

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## Member Data Documentation

## ◆ HoleTableSettingsHoleFiltersBuilderScopeType

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.HoleTableSettingsHoleFiltersBuilderScopeType = HoleTableSettingsHoleFiltersBuilder.ScopeType

NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilderScopeType is an alias for NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder.ScopeType 

Copyright 2025 Siemens
