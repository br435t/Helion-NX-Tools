# NXOpen.Annotations.LineWeldDataBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12877.html>

Represents a NXOpen::Annotations::LineWeldDataBuilder. 
More...

Inheritance diagram for NXOpen.Annotations.LineWeldDataBuilder:

## Public Member Functions

CompoundWeldSize (self)

Getter for property: (str) CompoundWeldSize Returns the compound weld size. 

CompoundWeldSize (self, compoundWeldSize)

Setter for property: (str) CompoundWeldSize. 

CompoundWeldSizeCode (self)

Getter for property: (NXOpen.Annotations.LineWeldDataBuilder.WeldSizeCodeType) CompoundWeldSizeCode Returns the compound weld size letter code. 

CompoundWeldSizeCode (self, compoundWeldSizeCode)

Setter for property: (NXOpen.Annotations.LineWeldDataBuilder.WeldSizeCodeType) CompoundWeldSizeCode. 

ContourSymbol (self)

Getter for property: (NXOpen.Annotations.LineWeldDataBuilder.ContourSymbolType) ContourSymbol Returns the supplementary contour weld symbols that identify the shape of the weld surface or execution of a weld for both top and bottom of the reference line. 

ContourSymbol (self, contourSymbol)

Setter for property: (NXOpen.Annotations.LineWeldDataBuilder.ContourSymbolType) ContourSymbol. 

FinishSymbol (self)

Getter for property: (NXOpen.Annotations.LineWeldDataBuilder.FinishSymbolType) FinishSymbol Returns the finishing method for the weld symbol. 

FinishSymbol (self, finishSymbol)

Setter for property: (NXOpen.Annotations.LineWeldDataBuilder.FinishSymbolType) FinishSymbol. 

GrooveCountersinkAngle (self)

Getter for property: (str) GrooveCountersinkAngle Returns the groove or coutersink angle. 

GrooveCountersinkAngle (self, grooveCountersinkAngle)

Setter for property: (str) GrooveCountersinkAngle. 

IsCompound (self)

Getter for property: (bool) IsCompound Returns the compound weld. 

IsCompound (self, isCompound)

Setter for property: (bool) IsCompound. 

LengthPitch (self)

Getter for property: (str) LengthPitch Returns the length or pitch. 

LengthPitch (self, lengthPitch)

Setter for property: (str) LengthPitch. 

NumberRootDepth (self)

Getter for property: (str) NumberRootDepth Returns the number of welds or root opening or depth of weld. 

NumberRootDepth (self, numberRootDepth)

Setter for property: (str) NumberRootDepth. 

WeldSize (self)

Getter for property: (str) WeldSize Returns the weld size. 

WeldSize (self, weldSize)

Setter for property: (str) WeldSize. 

WeldSizeCode (self)

Getter for property: (NXOpen.Annotations.LineWeldDataBuilder.WeldSizeCodeType) WeldSizeCode Returns the weld size letter code. 

WeldSizeCode (self, weldSizeCode)

Setter for property: (NXOpen.Annotations.LineWeldDataBuilder.WeldSizeCodeType) WeldSizeCode. 

WeldSymbol (self)

Getter for property: (NXOpen.Annotations.LineWeldDataBuilder.WeldSymbolType) WeldSymbol Returns the weld symbol. 

WeldSymbol (self, weldSymbol)

Setter for property: (NXOpen.Annotations.LineWeldDataBuilder.WeldSymbolType) WeldSymbol. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

LineWeldDataBuilderContourSymbolType = LineWeldDataBuilder.ContourSymbolType

NXOpen.Annotations.LineWeldDataBuilderContourSymbolType is an alias for NXOpen.Annotations.LineWeldDataBuilder.ContourSymbolType 

LineWeldDataBuilderFinishSymbolType = LineWeldDataBuilder.FinishSymbolType

NXOpen.Annotations.LineWeldDataBuilderFinishSymbolType is an alias for NXOpen.Annotations.LineWeldDataBuilder.FinishSymbolType 

LineWeldDataBuilderWeldSizeCodeType = LineWeldDataBuilder.WeldSizeCodeType

NXOpen.Annotations.LineWeldDataBuilderWeldSizeCodeType is an alias for NXOpen.Annotations.LineWeldDataBuilder.WeldSizeCodeType 

LineWeldDataBuilderWeldSymbolType = LineWeldDataBuilder.WeldSymbolType

NXOpen.Annotations.LineWeldDataBuilderWeldSymbolType is an alias for NXOpen.Annotations.LineWeldDataBuilder.WeldSymbolType 

## Detailed Description

Represents a NXOpen::Annotations::LineWeldDataBuilder. 

Created in NX6.0.0 

## Member Function Documentation

## ◆ CompoundWeldSize() [1/2]

NXOpen.Annotations.LineWeldDataBuilder.CompoundWeldSize
(
self — )

Getter for property: (str) CompoundWeldSize Returns the compound weld size. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
str 

## ◆ CompoundWeldSize() [2/2]

NXOpen.Annotations.LineWeldDataBuilder.CompoundWeldSize
(
self,

compoundWeldSize )

Setter for property: (str) CompoundWeldSize. 

Sets the compound weld size

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX7.5.0 

## ◆ CompoundWeldSizeCode() [1/2]

NXOpen.Annotations.LineWeldDataBuilder.CompoundWeldSizeCode
(
self — )

Getter for property: (NXOpen.Annotations.LineWeldDataBuilder.WeldSizeCodeType) CompoundWeldSizeCode Returns the compound weld size letter code. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
LineWeldDataBuilder.WeldSizeCodeType 

## ◆ CompoundWeldSizeCode() [2/2]

NXOpen.Annotations.LineWeldDataBuilder.CompoundWeldSizeCode
(
self,

compoundWeldSizeCode )

Setter for property: (NXOpen.Annotations.LineWeldDataBuilder.WeldSizeCodeType) CompoundWeldSizeCode. 

Sets the compound weld size letter code

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX7.5.0 

## ◆ ContourSymbol() [1/2]

NXOpen.Annotations.LineWeldDataBuilder.ContourSymbol
(
self — )

Getter for property: (NXOpen.Annotations.LineWeldDataBuilder.ContourSymbolType) ContourSymbol Returns the supplementary contour weld symbols that identify the shape of the weld surface or execution of a weld for both top and bottom of the reference line. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWeldDataBuilder.ContourSymbolType 

## ◆ ContourSymbol() [2/2]

NXOpen.Annotations.LineWeldDataBuilder.ContourSymbol
(
self,

contourSymbol )

Setter for property: (NXOpen.Annotations.LineWeldDataBuilder.ContourSymbolType) ContourSymbol. 

Sets the supplementary contour weld symbols that identify the shape of the weld surface or execution of a weld for both top and bottom of the reference line

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ FinishSymbol() [1/2]

NXOpen.Annotations.LineWeldDataBuilder.FinishSymbol
(
self — )

Getter for property: (NXOpen.Annotations.LineWeldDataBuilder.FinishSymbolType) FinishSymbol Returns the finishing method for the weld symbol. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWeldDataBuilder.FinishSymbolType 

## ◆ FinishSymbol() [2/2]

NXOpen.Annotations.LineWeldDataBuilder.FinishSymbol
(
self,

finishSymbol )

Setter for property: (NXOpen.Annotations.LineWeldDataBuilder.FinishSymbolType) FinishSymbol. 

Sets the finishing method for the weld symbol

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ GrooveCountersinkAngle() [1/2]

NXOpen.Annotations.LineWeldDataBuilder.GrooveCountersinkAngle
(
self — )

Getter for property: (str) GrooveCountersinkAngle Returns the groove or coutersink angle. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ GrooveCountersinkAngle() [2/2]

NXOpen.Annotations.LineWeldDataBuilder.GrooveCountersinkAngle
(
self,

grooveCountersinkAngle )

Setter for property: (str) GrooveCountersinkAngle. 

Sets the groove or coutersink angle

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ IsCompound() [1/2]

NXOpen.Annotations.LineWeldDataBuilder.IsCompound
(
self — )

Getter for property: (bool) IsCompound Returns the compound weld. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
bool 

## ◆ IsCompound() [2/2]

NXOpen.Annotations.LineWeldDataBuilder.IsCompound
(
self,

isCompound )

Setter for property: (bool) IsCompound. 

Sets the compound weld

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX7.5.0 

## ◆ LengthPitch() [1/2]

NXOpen.Annotations.LineWeldDataBuilder.LengthPitch
(
self — )

Getter for property: (str) LengthPitch Returns the length or pitch. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ LengthPitch() [2/2]

NXOpen.Annotations.LineWeldDataBuilder.LengthPitch
(
self,

lengthPitch )

Setter for property: (str) LengthPitch. 

Sets the length or pitch

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ NumberRootDepth() [1/2]

NXOpen.Annotations.LineWeldDataBuilder.NumberRootDepth
(
self — )

Getter for property: (str) NumberRootDepth Returns the number of welds or root opening or depth of weld. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ NumberRootDepth() [2/2]

NXOpen.Annotations.LineWeldDataBuilder.NumberRootDepth
(
self,

numberRootDepth )

Setter for property: (str) NumberRootDepth. 

Sets the number of welds or root opening or depth of weld

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ WeldSize() [1/2]

NXOpen.Annotations.LineWeldDataBuilder.WeldSize
(
self — )

Getter for property: (str) WeldSize Returns the weld size. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ WeldSize() [2/2]

NXOpen.Annotations.LineWeldDataBuilder.WeldSize
(
self,

weldSize )

Setter for property: (str) WeldSize. 

Sets the weld size

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ WeldSizeCode() [1/2]

NXOpen.Annotations.LineWeldDataBuilder.WeldSizeCode
(
self — )

Getter for property: (NXOpen.Annotations.LineWeldDataBuilder.WeldSizeCodeType) WeldSizeCode Returns the weld size letter code. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWeldDataBuilder.WeldSizeCodeType 

## ◆ WeldSizeCode() [2/2]

NXOpen.Annotations.LineWeldDataBuilder.WeldSizeCode
(
self,

weldSizeCode )

Setter for property: (NXOpen.Annotations.LineWeldDataBuilder.WeldSizeCodeType) WeldSizeCode. 

Sets the weld size letter code

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ WeldSymbol() [1/2]

NXOpen.Annotations.LineWeldDataBuilder.WeldSymbol
(
self — )

Getter for property: (NXOpen.Annotations.LineWeldDataBuilder.WeldSymbolType) WeldSymbol Returns the weld symbol. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWeldDataBuilder.WeldSymbolType 

## ◆ WeldSymbol() [2/2]

NXOpen.Annotations.LineWeldDataBuilder.WeldSymbol
(
self,

weldSymbol )

Setter for property: (NXOpen.Annotations.LineWeldDataBuilder.WeldSymbolType) WeldSymbol. 

Sets the weld symbol

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## Member Data Documentation

## ◆ LineWeldDataBuilderContourSymbolType

NXOpen.Annotations.LineWeldDataBuilder.LineWeldDataBuilderContourSymbolType = LineWeldDataBuilder.ContourSymbolType

NXOpen.Annotations.LineWeldDataBuilderContourSymbolType is an alias for NXOpen.Annotations.LineWeldDataBuilder.ContourSymbolType 

## ◆ LineWeldDataBuilderFinishSymbolType

NXOpen.Annotations.LineWeldDataBuilder.LineWeldDataBuilderFinishSymbolType = LineWeldDataBuilder.FinishSymbolType

NXOpen.Annotations.LineWeldDataBuilderFinishSymbolType is an alias for NXOpen.Annotations.LineWeldDataBuilder.FinishSymbolType 

## ◆ LineWeldDataBuilderWeldSizeCodeType

NXOpen.Annotations.LineWeldDataBuilder.LineWeldDataBuilderWeldSizeCodeType = LineWeldDataBuilder.WeldSizeCodeType

NXOpen.Annotations.LineWeldDataBuilderWeldSizeCodeType is an alias for NXOpen.Annotations.LineWeldDataBuilder.WeldSizeCodeType 

## ◆ LineWeldDataBuilderWeldSymbolType

NXOpen.Annotations.LineWeldDataBuilder.LineWeldDataBuilderWeldSymbolType = LineWeldDataBuilder.WeldSymbolType

NXOpen.Annotations.LineWeldDataBuilderWeldSymbolType is an alias for NXOpen.Annotations.LineWeldDataBuilder.WeldSymbolType 

Copyright 2025 Siemens
