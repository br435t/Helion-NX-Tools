# NXOpen.Annotations.DraftingImage Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00151.html>

## Classes

class — FileType

The export image file types 

Enumerator — Comment

Png — PNG file type

Jpg — JPG file type

Tif — TIF file type

More...

Copyright 2025 Siemens
