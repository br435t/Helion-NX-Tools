# NXOpen.Annotations.BaseEdgeConditionSymbolBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00131.html>

## Classes

class — MethodType

method types for edge condition symbol 

Enumerator — Comment

Basic

UndefinedDirectionandSize

UndefinedDirectionDefinedSize

UndefinedDirectionEqualBilateralSize

DefinedDirection

More...

class — SymbolElementEnum

symbol element types for for undefined direction and size 

Enumerator — Comment

Plus

Minus

More...

class — TerminatorType

represents the edge condition symbol terminator type 

Enumerator — Comment

Arrow — terminated with Arrow only

ExternalIndicator — terminated with External Indicator

InternalIndicator — terminated with Internal Indicator

More...

Copyright 2025 Siemens
