# NXOpen.Annotations.PmiAttributeBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13241.html>

Represents a NXOpen::Annotations::PmiAttribute builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiAttributeBuilder 

More...

Inheritance diagram for NXOpen.Annotations.PmiAttributeBuilder:

## Public Member Functions

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the NXOpen::Annotations::AssociatedObjectsBuilder for the annotation. 

Attribute (self)

Getter for property: (NXOpen.Annotations.Pmi) Attribute Returns the NXOpen::Annotations::Pmi for this annotation. 

Attribute (self, attribute)

Setter for property: (NXOpen.Annotations.Pmi) Attribute. 

BusinessModifier (self)

Getter for property: (NXOpen.NXObject) BusinessModifier Returns the business modifier. 

BusinessModifier (self, businessModifier)

Setter for property: (NXOpen.NXObject) BusinessModifier. 

GetAttributeValues (self)

Returns the attribute values. 

KnowledgeFusionClassName (self)

Getter for property: (str) KnowledgeFusionClassName Returns the knowledge fusion class name file, the default class is UG provided pmi KF class. 

KnowledgeFusionClassName (self, knowledgeFusionClassName)

Setter for property: (str) KnowledgeFusionClassName. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the NXOpen::Annotations::OriginBuilder for the annotation. 

SetAttributeValues (self, attributeValues)

Sets the attribute values. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the NXOpen::Annotations::StyleBuilder for the annotation. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::PmiAttribute builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiAttributeBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ AssociatedObjects()

NXOpen.Annotations.PmiAttributeBuilder.AssociatedObjects
(
self — )

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the NXOpen::Annotations::AssociatedObjectsBuilder for the annotation. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
AssociatedObjectsBuilder 

## ◆ Attribute() [1/2]

NXOpen.Annotations.PmiAttributeBuilder.Attribute
(
self — )

Getter for property: (NXOpen.Annotations.Pmi) Attribute Returns the NXOpen::Annotations::Pmi for this annotation. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
Pmi 

## ◆ Attribute() [2/2]

NXOpen.Annotations.PmiAttributeBuilder.Attribute
(
self,

attribute )

Setter for property: (NXOpen.Annotations.Pmi) Attribute. 

Sets the NXOpen::Annotations::Pmi for this annotation

Setter License requirements: None.

Created in NX6.0.0 

## ◆ BusinessModifier() [1/2]

NXOpen.Annotations.PmiAttributeBuilder.BusinessModifier
(
self — )

Getter for property: (NXOpen.NXObject) BusinessModifier Returns the business modifier. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.NXObject 

## ◆ BusinessModifier() [2/2]

NXOpen.Annotations.PmiAttributeBuilder.BusinessModifier
(
self,

businessModifier )

Setter for property: (NXOpen.NXObject) BusinessModifier. 

Sets the business modifier

Setter License requirements: None.

Created in NX6.0.0 

## ◆ GetAttributeValues()

NXOpen.Annotations.PmiAttributeBuilder.GetAttributeValues
(
self — )

Returns the attribute values. 

Returns
attributeValues (List[NXOpen.NXObject]): .

Created in NX6.0.0 

License requirements: None. 

## ◆ KnowledgeFusionClassName() [1/2]

NXOpen.Annotations.PmiAttributeBuilder.KnowledgeFusionClassName
(
self — )

Getter for property: (str) KnowledgeFusionClassName Returns the knowledge fusion class name file, the default class is UG provided pmi KF class. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ KnowledgeFusionClassName() [2/2]

NXOpen.Annotations.PmiAttributeBuilder.KnowledgeFusionClassName
(
self,

knowledgeFusionClassName )

Setter for property: (str) KnowledgeFusionClassName. 

Sets the knowledge fusion class name file, the default class is UG provided pmi KF class

Setter License requirements: None.

Created in NX6.0.0 

## ◆ Leader()

NXOpen.Annotations.PmiAttributeBuilder.Leader
(
self — )

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LeaderBuilder 

## ◆ Origin()

NXOpen.Annotations.PmiAttributeBuilder.Origin
(
self — )

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the NXOpen::Annotations::OriginBuilder for the annotation. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
OriginBuilder 

## ◆ SetAttributeValues()

NXOpen.Annotations.PmiAttributeBuilder.SetAttributeValues
(
self,

attributeValues )

Sets the attribute values. 

Created in NX6.0.0 

License requirements: None.

Parameters

attributeValues — (List[NXOpen.NXObject]) attribute values

## ◆ Style()

NXOpen.Annotations.PmiAttributeBuilder.Style
(
self — )

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the NXOpen::Annotations::StyleBuilder for the annotation. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
StyleBuilder 

Copyright 2025 Siemens
