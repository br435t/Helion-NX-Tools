# NXOpen.Annotations.BaseProductGridBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11429.html>

Represents a NXOpen::Annotations::BaseProductGridBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.BaseProductGridBuilder:

## Public Member Functions

CoordinateSystem (self)

Getter for property: (NXOpen.CoordinateSystem) CoordinateSystem Returns the coordinate system. 

CoordinateSystem (self, coordinateSystem)

Setter for property: (NXOpen.CoordinateSystem) CoordinateSystem. 

GridSpacing (self)

Getter for property: (float) GridSpacing Returns the grid spacing. 

GridSpacing (self, gridSpacing)

Setter for property: (float) GridSpacing. 

HorizontalMaximumValue (self)

Getter for property: (float) HorizontalMaximumValue Returns the horizontal maximum value. 

HorizontalMaximumValue (self, horizontalMaximumValue)

Setter for property: (float) HorizontalMaximumValue. 

HorizontalMinimumValue (self)

Getter for property: (float) HorizontalMinimumValue Returns the horizontal minimum value. 

HorizontalMinimumValue (self, horizontalMinimumValue)

Setter for property: (float) HorizontalMinimumValue. 

ShowHorizontalLines (self)

Getter for property: (bool) ShowHorizontalLines Returns the horizontal line display. 

ShowHorizontalLines (self, showHorizontalLines)

Setter for property: (bool) ShowHorizontalLines. 

ShowVerticalLines (self)

Getter for property: (bool) ShowVerticalLines Returns the vertical line display. 

ShowVerticalLines (self, showVerticalLines)

Setter for property: (bool) ShowVerticalLines. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

VerticalMaximumValue (self)

Getter for property: (float) VerticalMaximumValue Returns the vertical maximum value. 

VerticalMaximumValue (self, verticalMaximumValue)

Setter for property: (float) VerticalMaximumValue. 

VerticalMinimumValue (self)

Getter for property: (float) VerticalMinimumValue Returns the vertical minimum value. 

VerticalMinimumValue (self, verticalMinimumValue)

Setter for property: (float) VerticalMinimumValue. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::BaseProductGridBuilder . 

This class allows to creation of a product grid annotation 

This is an abstract class, and cannot be instantiated. 

Created in NX1980.0.0 

## Member Function Documentation

## ◆ CoordinateSystem() [1/2]

NXOpen.Annotations.BaseProductGridBuilder.CoordinateSystem
(
self — )

Getter for property: (NXOpen.CoordinateSystem) CoordinateSystem Returns the coordinate system. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
NXOpen.CoordinateSystem 

## ◆ CoordinateSystem() [2/2]

NXOpen.Annotations.BaseProductGridBuilder.CoordinateSystem
(
self,

coordinateSystem )

Setter for property: (NXOpen.CoordinateSystem) CoordinateSystem. 

Sets the coordinate system

Setter License requirements: drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ GridSpacing() [1/2]

NXOpen.Annotations.BaseProductGridBuilder.GridSpacing
(
self — )

Getter for property: (float) GridSpacing Returns the grid spacing. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
float 

## ◆ GridSpacing() [2/2]

NXOpen.Annotations.BaseProductGridBuilder.GridSpacing
(
self,

gridSpacing )

Setter for property: (float) GridSpacing. 

Sets the grid spacing

Setter License requirements: drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ HorizontalMaximumValue() [1/2]

NXOpen.Annotations.BaseProductGridBuilder.HorizontalMaximumValue
(
self — )

Getter for property: (float) HorizontalMaximumValue Returns the horizontal maximum value. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
float 

## ◆ HorizontalMaximumValue() [2/2]

NXOpen.Annotations.BaseProductGridBuilder.HorizontalMaximumValue
(
self,

horizontalMaximumValue )

Setter for property: (float) HorizontalMaximumValue. 

Sets the horizontal maximum value

Setter License requirements: drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ HorizontalMinimumValue() [1/2]

NXOpen.Annotations.BaseProductGridBuilder.HorizontalMinimumValue
(
self — )

Getter for property: (float) HorizontalMinimumValue Returns the horizontal minimum value. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
float 

## ◆ HorizontalMinimumValue() [2/2]

NXOpen.Annotations.BaseProductGridBuilder.HorizontalMinimumValue
(
self,

horizontalMinimumValue )

Setter for property: (float) HorizontalMinimumValue. 

Sets the horizontal minimum value

Setter License requirements: drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ ShowHorizontalLines() [1/2]

NXOpen.Annotations.BaseProductGridBuilder.ShowHorizontalLines
(
self — )

Getter for property: (bool) ShowHorizontalLines Returns the horizontal line display. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
bool 

## ◆ ShowHorizontalLines() [2/2]

NXOpen.Annotations.BaseProductGridBuilder.ShowHorizontalLines
(
self,

showHorizontalLines )

Setter for property: (bool) ShowHorizontalLines. 

Sets the horizontal line display

Setter License requirements: drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ ShowVerticalLines() [1/2]

NXOpen.Annotations.BaseProductGridBuilder.ShowVerticalLines
(
self — )

Getter for property: (bool) ShowVerticalLines Returns the vertical line display. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
bool 

## ◆ ShowVerticalLines() [2/2]

NXOpen.Annotations.BaseProductGridBuilder.ShowVerticalLines
(
self,

showVerticalLines )

Setter for property: (bool) ShowVerticalLines. 

Sets the vertical line display

Setter License requirements: drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ Style()

NXOpen.Annotations.BaseProductGridBuilder.Style
(
self — )

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
StyleBuilder 

## ◆ VerticalMaximumValue() [1/2]

NXOpen.Annotations.BaseProductGridBuilder.VerticalMaximumValue
(
self — )

Getter for property: (float) VerticalMaximumValue Returns the vertical maximum value. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
float 

## ◆ VerticalMaximumValue() [2/2]

NXOpen.Annotations.BaseProductGridBuilder.VerticalMaximumValue
(
self,

verticalMaximumValue )

Setter for property: (float) VerticalMaximumValue. 

Sets the vertical maximum value

Setter License requirements: drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ VerticalMinimumValue() [1/2]

NXOpen.Annotations.BaseProductGridBuilder.VerticalMinimumValue
(
self — )

Getter for property: (float) VerticalMinimumValue Returns the vertical minimum value. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
float 

## ◆ VerticalMinimumValue() [2/2]

NXOpen.Annotations.BaseProductGridBuilder.VerticalMinimumValue
(
self,

verticalMinimumValue )

Setter for property: (float) VerticalMinimumValue. 

Sets the vertical minimum value

Setter License requirements: drafting ("DRAFTING")

Created in NX1980.0.0 

Copyright 2025 Siemens
