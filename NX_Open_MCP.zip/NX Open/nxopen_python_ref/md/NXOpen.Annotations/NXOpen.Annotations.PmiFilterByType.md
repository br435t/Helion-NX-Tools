# NXOpen.Annotations.PmiFilterByType Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00195.html>

## Classes

class — Type

Represents a PMI type that is assigned to the PMI filter. More...

Copyright 2025 Siemens
