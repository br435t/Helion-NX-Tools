# NXOpen.Annotations.ConvertPmiBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11765.html>

Represents a NXOpen::Annotations::ConvertPmiBuilder builder. 
More...

Inheritance diagram for NXOpen.Annotations.ConvertPmiBuilder:

## Public Member Functions

Selection (self)

Getter for property: (NXOpen.Annotations.SelectPmiCadNeutralAnnotationList) Selection Returns the imported PMI to convert. 

ShowReport (self)

Getter for property: (bool) ShowReport Returns the show report toggle. 

ShowReport (self, showReport)

Setter for property: (bool) ShowReport. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::ConvertPmiBuilder builder. 

This builder is responsible for promoting imported PMI to full fledged NX PMI. 

To create a new instance of this class, use NXOpen::Annotations::PmiManager::CreateConvertPmiBuilder 

Created in NX2007.0.0 

## Member Function Documentation

## ◆ Selection()

NXOpen.Annotations.ConvertPmiBuilder.Selection
(
self — )

Getter for property: (NXOpen.Annotations.SelectPmiCadNeutralAnnotationList) Selection Returns the imported PMI to convert. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
SelectPmiCadNeutralAnnotationList 

## ◆ ShowReport() [1/2]

NXOpen.Annotations.ConvertPmiBuilder.ShowReport
(
self — )

Getter for property: (bool) ShowReport Returns the show report toggle. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
bool 

## ◆ ShowReport() [2/2]

NXOpen.Annotations.ConvertPmiBuilder.ShowReport
(
self,

showReport )

Setter for property: (bool) ShowReport. 

Sets the show report toggle.

Setter License requirements: None.

Created in NX2007.0.0 

Copyright 2025 Siemens
