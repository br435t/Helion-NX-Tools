# NXOpen.Annotations.HoleCalloutSettingsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00165.html>

## Classes

class — Displaytype

This reprensent the option that specifies if the thread size parameter is displayed as a vertical fraction, as a single line or the same as the callout parameter on the feature. More...

class — Featuretype

This reprensent the option that indicates a type of hole features. More...

class — LeaderAttachment

This reprensent the option that indicates the position for the leader to attach to. More...

class — Parametertype

This reprensent the option that indicates a type of hole feature parameters. More...

Copyright 2025 Siemens
