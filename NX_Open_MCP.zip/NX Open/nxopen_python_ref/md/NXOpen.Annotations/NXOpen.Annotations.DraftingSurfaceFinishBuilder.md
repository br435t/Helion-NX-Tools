# NXOpen.Annotations.DraftingSurfaceFinishBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00153.html>

## Classes

class — FinishType

the valid types of finish type 

Enumerator — Comment

Basic — Basic

Modifier — Modifier

ModifierAllAround — Modifier, All Around

MaterialRemovalRequired — Material Removal Required

ModifierMaterialRemovalRequired — Modifier, Material Removal Required

ModifierMaterialRemovalRequiredAllAround — Modifier, Material Removal Required, All Around

MaterialRemovalProhibited — Material Removal Prohibited

ModifierMaterialRemovalProhibited — Modifier, Material Removal Prohibited

ModifierMaterialRemovalProhibitedAllAround — Modifier, Material Removal Prohibited, All Around

More...

Copyright 2025 Siemens
