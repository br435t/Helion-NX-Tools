# NXOpen.Annotations.LineComponent Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00175.html>

## Classes

class — LineType

the line type 

Enumerator — Comment

Extension — extension line

Leader — leader line

NarrowLeader — narrow leader line

Stub — stub line

DualBracket — dual bracket

Annotation — annotation line

Inspection — inspection line

SecondaryExtension — secondary extension

Tolerance — tolerance line

Jog — jog line

Grid — grid line

More...

Copyright 2025 Siemens
