# NXOpen.Annotations.BreakSettingsBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11561.html>

Represents a NXOpen::Annotations::BreakSettingsBuilder builder. 
More...

Inheritance diagram for NXOpen.Annotations.BreakSettingsBuilder:

## Public Member Functions

BreakSize (self)

Getter for property: (float) BreakSize Returns the break size. 

BreakSize (self, breakSize)

Setter for property: (float) BreakSize. 

CreateBreaks (self)

Getter for property: (bool) CreateBreaks Returns the create breaks option. 

CreateBreaks (self, creatsBreak)

Setter for property: (bool) CreateBreaks. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::BreakSettingsBuilder builder. 

Created in NX10.0.0 

## Member Function Documentation

## ◆ BreakSize() [1/2]

NXOpen.Annotations.BreakSettingsBuilder.BreakSize
(
self — )

Getter for property: (float) BreakSize Returns the break size. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
float 

## ◆ BreakSize() [2/2]

NXOpen.Annotations.BreakSettingsBuilder.BreakSize
(
self,

breakSize )

Setter for property: (float) BreakSize. 

Sets the break size

Setter License requirements: drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ CreateBreaks() [1/2]

NXOpen.Annotations.BreakSettingsBuilder.CreateBreaks
(
self — )

Getter for property: (bool) CreateBreaks Returns the create breaks option. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
bool 

## ◆ CreateBreaks() [2/2]

NXOpen.Annotations.BreakSettingsBuilder.CreateBreaks
(
self,

creatsBreak )

Setter for property: (bool) CreateBreaks. 

Sets the create breaks option

Setter License requirements: drafting ("DRAFTING")

Created in NX10.0.0 

Copyright 2025 Siemens
