# NXOpen.Annotations.DimensionSetBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00150.html>

## Classes

class — DimensionSetMethod

dimension set method 

Enumerator — Comment

NotSet — Not part of a set

Chain — Part of a chain

Baseline — Part of a baseline

More...

Copyright 2025 Siemens
