# NXOpen.Annotations.MasterSymbolBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12945.html>

Represents a Builder for MasterSymbol functionality 

To create a new instance of this class, use NXOpen::Annotations::CustomSymbolCollection::CreateMasterSymbolBuilder 

Default values. 
More...

Inheritance diagram for NXOpen.Annotations.MasterSymbolBuilder:

## Public Member Functions

AnchorPoint (self)

Getter for property: (NXOpen.Point) AnchorPoint Returns the anchor point. 

AnchorPoint (self, anchorPoint)

Setter for property: (NXOpen.Point) AnchorPoint. 

Contents (self)

Getter for property: (NXOpen.SelectNXObjectList) Contents Returns the select object. 

CreateNewListItem (self, noteTag, notes)

Create Master Symbol list item builder. 

EditImage (self, currentSymbolTag, newImageName)

Changes symbol image. 

GenerateItemNumber (self)

Item number assign button. 

GenerateRevision (self)

Revision assign button, This will generate the revision number, valid in team center. 

GetLeaderAttachmentPoint (self, attachmentType)

Getting Leader attachment point from builder side. 

GetMultilineString (self)

Returns the multiple notes for a given Text Type. 

GetPartOperationCreateBuilder (self)

Gets NXOpen::PDM::PartOperationBuilder. 

ImageCapture (self)

Getter for property: (NXOpen.Gateway.ImageCaptureBuilder) ImageCapture Returns the image capture builder. 

ImageName (self)

Getter for property: (str) ImageName Returns the symbol image name. 

ImageName (self, imageName)

Setter for property: (str) ImageName. 

ItemName (self)

Getter for property: (str) ItemName Returns the Item Name, valid in team center. 

ItemName (self, itemName)

Setter for property: (str) ItemName. 

ItemNumber (self)

Getter for property: (str) ItemNumber Returns the item number, valid in team center. 

ItemNumber (self, itemNumber)

Setter for property: (str) ItemNumber. 

NoteList (self)

Getter for property: (NXOpen.NXObjectList) NoteList Returns the note list. 

PartFileName (self)

Getter for property: (str) PartFileName Returns the part file name. 

PartFileName (self, partFileName)

Setter for property: (str) PartFileName. 

Rename (self, currentSymbolTag, newSymbolName)

Renames symbol. 

Revision (self)

Getter for property: (str) Revision Returns the revision, valid in team center. 

Revision (self, revision)

Setter for property: (str) Revision. 

SetIsPartSymbol (self, isPartSymbol)

Sets if it is part symbol. 

SetLeaderAttachmentPoint (self, attachmentType, leaderAttachmentPoint)

Setting Leader attachment point on builder side. 

SetPartOperationCreateBuilder (self, partOperationBuilder)

Sets NXOpen::PDM::PartOperationBuilder. 

SetPath (self, path)

Setting Path retrieved from Global method at builder side. 

SymbolName (self)

Getter for property: (str) SymbolName Returns the JA method support for accessing and setting Symbol Name value. 

SymbolName (self, symbolName)

Setter for property: (str) SymbolName. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

MasterSymbolBuilderLeaderAttachmentType = MasterSymbolBuilder.LeaderAttachmentType

NXOpen.Annotations.MasterSymbolBuilderLeaderAttachmentType is an alias for NXOpen.Annotations.MasterSymbolBuilder.LeaderAttachmentType 

## Detailed Description

Represents a Builder for MasterSymbol functionality 

To create a new instance of this class, use NXOpen::Annotations::CustomSymbolCollection::CreateMasterSymbolBuilder 

Default values. 

Property — Value

ImageCapture.CaptureMethod 

GraphicsArea 

ImageCapture.Format 

Bmp 

ImageCapture.Size 

Pixels64 

Created in NX7.5.0 

## Member Function Documentation

## ◆ AnchorPoint() [1/2]

NXOpen.Annotations.MasterSymbolBuilder.AnchorPoint
(
self — )

Getter for property: (NXOpen.Point) AnchorPoint Returns the anchor point. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
NXOpen.Point 

## ◆ AnchorPoint() [2/2]

NXOpen.Annotations.MasterSymbolBuilder.AnchorPoint
(
self,

anchorPoint )

Setter for property: (NXOpen.Point) AnchorPoint. 

Sets the anchor point

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ Contents()

NXOpen.Annotations.MasterSymbolBuilder.Contents
(
self — )

Getter for property: (NXOpen.SelectNXObjectList) Contents Returns the select object. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
NXOpen.SelectNXObjectList 

## ◆ CreateNewListItem()

NXOpen.Annotations.MasterSymbolBuilder.CreateNewListItem
(
self,

noteTag,

notes )

Create Master Symbol list item builder. 

Returns
listItem (NXOpen.Annotations.MasterSymbolListItemBuilder): .

Created in NX7.5.0 

License requirements: None.

Parameters

noteTag — (NXOpen.Annotations.Annotation)

notes — (List[str]) name of the solution

## ◆ EditImage()

NXOpen.Annotations.MasterSymbolBuilder.EditImage
(
self,

currentSymbolTag,

newImageName )

Changes symbol image. 

Created in NX7.5.0 

License requirements: drafting ("DRAFTING")

Parameters

currentSymbolTag — (NXOpen.Annotations.MasterSymbol) symbol Tag

newImageName — (str) New image name

## ◆ GenerateItemNumber()

NXOpen.Annotations.MasterSymbolBuilder.GenerateItemNumber
(
self — )

Item number assign button. 

This will generate the item number, valid in team center

Created in NX7.5.0 

Deprecated
Deprecated in NX10.0.0. Use NXOpen::Annotations::MasterSymbolBuilder::SetItemNumber instead. 

License requirements: drafting ("DRAFTING") 

## ◆ GenerateRevision()

NXOpen.Annotations.MasterSymbolBuilder.GenerateRevision
(
self — )

Revision assign button, This will generate the revision number, valid in team center. 

Created in NX7.5.0 

Deprecated
Deprecated in NX10.0.0. Use NXOpen::Annotations::MasterSymbolBuilder::SetRevision instead. 

License requirements: drafting ("DRAFTING") 

## ◆ GetLeaderAttachmentPoint()

NXOpen.Annotations.MasterSymbolBuilder.GetLeaderAttachmentPoint
(
self,

attachmentType )

Getting Leader attachment point from builder side. 

Returns
leaderAttachmentPoint (NXOpen.Point): .

Created in NX7.5.0 

License requirements: None.

Parameters

attachmentType — (NXOpen.Annotations.MasterSymbolBuilder.LeaderAttachmentType) Attachment type either of left or right

## ◆ GetMultilineString()

NXOpen.Annotations.MasterSymbolBuilder.GetMultilineString
(
self — )

Returns the multiple notes for a given Text Type. 

This property is valid if NXOpen::Annotations::MasterSymbolListItemBuilder::TextType is either of controlled, partially controlled or arbitory 
Returns
multilineString (List[str]): Multiple notes as Output.

Created in NX7.5.0 

License requirements: None. 

## ◆ GetPartOperationCreateBuilder()

NXOpen.Annotations.MasterSymbolBuilder.GetPartOperationCreateBuilder
(
self — )

Gets NXOpen::PDM::PartOperationBuilder. 

Returns
partOperationCreateBuilder (NXOpen.PDM.PartOperationCreateBuilder): .

Created in NX10.0.0 

License requirements: None. 

## ◆ ImageCapture()

NXOpen.Annotations.MasterSymbolBuilder.ImageCapture
(
self — )

Getter for property: (NXOpen.Gateway.ImageCaptureBuilder) ImageCapture Returns the image capture builder. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
NXOpen.Gateway.ImageCaptureBuilder 

## ◆ ImageName() [1/2]

NXOpen.Annotations.MasterSymbolBuilder.ImageName
(
self — )

Getter for property: (str) ImageName Returns the symbol image name. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
str 

## ◆ ImageName() [2/2]

NXOpen.Annotations.MasterSymbolBuilder.ImageName
(
self,

imageName )

Setter for property: (str) ImageName. 

Sets the symbol image name

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ ItemName() [1/2]

NXOpen.Annotations.MasterSymbolBuilder.ItemName
(
self — )

Getter for property: (str) ItemName Returns the Item Name, valid in team center. 

Getter License requirements: None.

Created in NX7.5.0 

Deprecated
Deprecated in NX10.0.0. Use NXOpen::PDM::PartOperationCreateBuilder instead. 

Returns
str 

## ◆ ItemName() [2/2]

NXOpen.Annotations.MasterSymbolBuilder.ItemName
(
self,

itemName )

Setter for property: (str) ItemName. 

Sets the Item Name, valid in team center

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

Deprecated
Deprecated in NX10.0.0. Use NXOpen::PDM::PartOperationCreateBuilder instead. 

## ◆ ItemNumber() [1/2]

NXOpen.Annotations.MasterSymbolBuilder.ItemNumber
(
self — )

Getter for property: (str) ItemNumber Returns the item number, valid in team center. 

Getter License requirements: None.

Created in NX7.5.0 

Deprecated
Deprecated in NX10.0.0. Use NXOpen::PDM::PartOperationCreateBuilder instead. 

Returns
str 

## ◆ ItemNumber() [2/2]

NXOpen.Annotations.MasterSymbolBuilder.ItemNumber
(
self,

itemNumber )

Setter for property: (str) ItemNumber. 

Sets the item number, valid in team center

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

Deprecated
Deprecated in NX10.0.0. Use NXOpen::PDM::PartOperationCreateBuilder instead. 

## ◆ NoteList()

NXOpen.Annotations.MasterSymbolBuilder.NoteList
(
self — )

Getter for property: (NXOpen.NXObjectList) NoteList Returns the note list. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
NXOpen.NXObjectList 

## ◆ PartFileName() [1/2]

NXOpen.Annotations.MasterSymbolBuilder.PartFileName
(
self — )

Getter for property: (str) PartFileName Returns the part file name. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
str 

## ◆ PartFileName() [2/2]

NXOpen.Annotations.MasterSymbolBuilder.PartFileName
(
self,

partFileName )

Setter for property: (str) PartFileName. 

Sets the part file name

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ Rename()

NXOpen.Annotations.MasterSymbolBuilder.Rename
(
self,

currentSymbolTag,

newSymbolName )

Renames symbol. 

Created in NX7.5.0 

License requirements: drafting ("DRAFTING")

Parameters

currentSymbolTag — (NXOpen.Annotations.MasterSymbol) symbol Tag

newSymbolName — (str) New symbol name

## ◆ Revision() [1/2]

NXOpen.Annotations.MasterSymbolBuilder.Revision
(
self — )

Getter for property: (str) Revision Returns the revision, valid in team center. 

Getter License requirements: None.

Created in NX7.5.0 

Deprecated
Deprecated in NX10.0.0. Use NXOpen::PDM::PartOperationCreateBuilder instead. 

Returns
str 

## ◆ Revision() [2/2]

NXOpen.Annotations.MasterSymbolBuilder.Revision
(
self,

revision )

Setter for property: (str) Revision. 

Sets the revision, valid in team center

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

Deprecated
Deprecated in NX10.0.0. Use NXOpen::PDM::PartOperationCreateBuilder instead. 

## ◆ SetIsPartSymbol()

NXOpen.Annotations.MasterSymbolBuilder.SetIsPartSymbol
(
self,

isPartSymbol )

Sets if it is part symbol. 

Created in NX7.5.0 

License requirements: drafting ("DRAFTING")

Parameters

isPartSymbol — (bool) True If it is part symbol

## ◆ SetLeaderAttachmentPoint()

NXOpen.Annotations.MasterSymbolBuilder.SetLeaderAttachmentPoint
(
self,

attachmentType,

leaderAttachmentPoint )

Setting Leader attachment point on builder side. 

Created in NX7.5.0 

License requirements: drafting ("DRAFTING")

Parameters

attachmentType — (NXOpen.Annotations.MasterSymbolBuilder.LeaderAttachmentType) Attachment type either of left or right

leaderAttachmentPoint — (NXOpen.Point) Attachment point

## ◆ SetPartOperationCreateBuilder()

NXOpen.Annotations.MasterSymbolBuilder.SetPartOperationCreateBuilder
(
self,

partOperationBuilder )

Sets NXOpen::PDM::PartOperationBuilder. 

Created in NX10.0.0 

License requirements: drafting ("DRAFTING")

Parameters

partOperationBuilder — (NXOpen.PDM.PartOperationCreateBuilder)

## ◆ SetPath()

NXOpen.Annotations.MasterSymbolBuilder.SetPath
(
self,

path )

Setting Path retrieved from Global method at builder side. 

Created in NX7.5.0 

License requirements: drafting ("DRAFTING")

Parameters

path — (str) location of symbol

## ◆ SymbolName() [1/2]

NXOpen.Annotations.MasterSymbolBuilder.SymbolName
(
self — )

Getter for property: (str) SymbolName Returns the JA method support for accessing and setting Symbol Name value. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
str 

## ◆ SymbolName() [2/2]

NXOpen.Annotations.MasterSymbolBuilder.SymbolName
(
self,

symbolName )

Setter for property: (str) SymbolName. 

Sets the JA method support for accessing and setting Symbol Name value

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## Member Data Documentation

## ◆ MasterSymbolBuilderLeaderAttachmentType

NXOpen.Annotations.MasterSymbolBuilder.MasterSymbolBuilderLeaderAttachmentType = MasterSymbolBuilder.LeaderAttachmentType

NXOpen.Annotations.MasterSymbolBuilderLeaderAttachmentType is an alias for NXOpen.Annotations.MasterSymbolBuilder.LeaderAttachmentType 

Copyright 2025 Siemens
