# NXOpen.Annotations.BaseFrameBarBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00132.html>

## Classes

class — AxisType

Enum for Ship Axis This is used by NXOpen::Annotations::BaseFrameBarBuilder::Axis and NXOpen::Annotations::BaseFrameBarBuilder::SetAxis to get/set the axis for a frame bar 

Enumerator — Comment

X — Ship X Axis

Y — Ship Y Axis

Z — Ship Z Axis

AlongHull — Ship Along_Hull for Z Axis

More...

class — HorizontalPositionType

Enum for Ship Axis This is used by NXOpen::Annotations::BaseFrameBarBuilder::HorizontalPosition and NXOpen::Annotations::BaseFrameBarBuilder::SetHorizontalPosition to get/set the axis for a frame bar 

Enumerator — Comment

Above — The frame bar is above the view boundary

ShipCenter — The frame bar is at the ship center

ViewCenter — The frame bar is at the view center

Below — The frame bar is below the view boundary

More...

class — OriginOption

Enum for Ship Axis This is used by NXOpen::Annotations::BaseFrameBarBuilder::OriginType and NXOpen::Annotations::BaseFrameBarBuilder::SetOriginType to get/set the axis for a frame bar 

Enumerator — Comment

SpecifyPosition — Specify Position

Distance — Distance to Boundary

More...

class — VerticalPositionType

Enum for Ship Axis This is used by NXOpen::Annotations::BaseFrameBarBuilder::HorizontalPosition and NXOpen::Annotations::BaseFrameBarBuilder::SetHorizontalPosition to get/set the axis for a frame bar 

Enumerator — Comment

Left — The frame bar is at left of the view boundary

ShipCenter — The frame bar is at the ship center

ViewCenter — The frame bar is at the view center

Right — The frame bar is at right of the view boundary

More...

Copyright 2025 Siemens
