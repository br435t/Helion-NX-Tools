# NXOpen.Annotations.SearchCriteriaCalloutBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00207.html>

## Classes

class — CalloutTypes

CalloutTypes 

Enumerator — Comment

Hole — Hole

Diameter — Diameter

Cylindrical — Cylindrical

More...

Copyright 2025 Siemens
