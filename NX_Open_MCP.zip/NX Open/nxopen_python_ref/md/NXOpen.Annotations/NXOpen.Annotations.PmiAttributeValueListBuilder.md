# NXOpen.Annotations.PmiAttributeValueListBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13257.html>

Represents a NXOpen::Annotations::PmiAttributeValueList builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiAttributeValueListBuilder 

More...

Inheritance diagram for NXOpen.Annotations.PmiAttributeValueListBuilder:

## Public Member Functions

ListValue (self)

Getter for property: (str) ListValue Returns the list_value. 

ListValue (self, listValue)

Setter for property: (str) ListValue. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::PmiAttributeValueList builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiAttributeValueListBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ ListValue() [1/2]

NXOpen.Annotations.PmiAttributeValueListBuilder.ListValue
(
self — )

Getter for property: (str) ListValue Returns the list_value. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ ListValue() [2/2]

NXOpen.Annotations.PmiAttributeValueListBuilder.ListValue
(
self,

listValue )

Setter for property: (str) ListValue. 

Sets the list_value

Setter License requirements: None.

Created in NX6.0.0 

Copyright 2025 Siemens
