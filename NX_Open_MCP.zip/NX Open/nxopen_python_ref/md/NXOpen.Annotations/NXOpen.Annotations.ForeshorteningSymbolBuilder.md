# NXOpen.Annotations.ForeshorteningSymbolBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12313.html>

Represents a NXOpen::Annotations::ForeshorteningSymbolBuilder builder 

There is no KF creator for this class. 
More...

Inheritance diagram for NXOpen.Annotations.ForeshorteningSymbolBuilder:

## Public Member Functions

AddSymbol (self, locations)

Add the foreshortening symbol. 

DeleteSymbol (self, symbolIndex)

Delete the foreshortening symbol. 

GetSymbols (self)

Get the foreshortening symbol. 

ModifySymbol (self, symbolIndex, locations)

Modify the foreshortening symbol. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::ForeshorteningSymbolBuilder builder 

There is no KF creator for this class. 

Created in NX10.0.0 

## Member Function Documentation

## ◆ AddSymbol()

NXOpen.Annotations.ForeshorteningSymbolBuilder.AddSymbol
(
self,

locations )

Add the foreshortening symbol. 

Created in NX10.0.0 

License requirements: None.

Parameters

locations — (NXOpen.Point3d)

## ◆ DeleteSymbol()

NXOpen.Annotations.ForeshorteningSymbolBuilder.DeleteSymbol
(
self,

symbolIndex )

Delete the foreshortening symbol. 

Created in NX10.0.0 

License requirements: None.

Parameters

symbolIndex — (int)

## ◆ GetSymbols()

NXOpen.Annotations.ForeshorteningSymbolBuilder.GetSymbols
(
self — )

Get the foreshortening symbol. 

Returns
A tuple consisting of (locations, indices).
locations is: List[NXOpen.Point3d].

indices is: List[int].

Created in NX10.0.0 

License requirements: None. 

## ◆ ModifySymbol()

NXOpen.Annotations.ForeshorteningSymbolBuilder.ModifySymbol
(
self,

symbolIndex,

locations )

Modify the foreshortening symbol. 

Created in NX10.0.0 

License requirements: None.

Parameters

symbolIndex — (int)

locations — (NXOpen.Point3d)

Copyright 2025 Siemens
