# NXOpen.Annotations.PmiDatumTargetData Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00191.html>

## Classes

class — Types

the datum target types 

Enumerator — Comment

NotSet — default target type

Point — point datum target type

Line — line datum target type

Rectangular — rectangular datum target type

Circular — circular datum target type

Cylindrical — cylindrical datum target type

Spherical — spherical datum target type

Arbitrary — arbitrary datum target type

More...

Copyright 2025 Siemens
