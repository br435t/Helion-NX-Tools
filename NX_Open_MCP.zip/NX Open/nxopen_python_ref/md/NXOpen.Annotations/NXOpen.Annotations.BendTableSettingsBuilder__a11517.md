# NXOpen.Annotations.BendTableSettingsBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11517.html>

Represents a NXOpen::Annotations::BendTableSettingsBuilder. 
More...

Inheritance diagram for NXOpen.Annotations.BendTableSettingsBuilder:

## Public Member Functions

AutomaticUpdate (self)

Getter for property: (bool) AutomaticUpdate Returns the automatic update option. 

AutomaticUpdate (self, automaticUpdate)

Setter for property: (bool) AutomaticUpdate. 

GetColumnOrder (self)

Returns the order of the columns in the bend table. 

SetColumnOrder (self, columnOrder)

Sets the order of the columns in the bend table. 

SortColumn (self)

Getter for property: (NXOpen.Annotations.BendTableSettingsBuilder.ColumnType) SortColumn Returns the column that is used to sort the bend table. 

SortColumn (self, sortColumn)

Setter for property: (NXOpen.Annotations.BendTableSettingsBuilder.ColumnType) SortColumn. 

SortOnUpdate (self)

Getter for property: (bool) SortOnUpdate Returns the sort on update option. 

SortOnUpdate (self, sortOnUpdate)

Setter for property: (bool) SortOnUpdate. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

BendTableSettingsBuilderColumnType = BendTableSettingsBuilder.ColumnType

NXOpen.Annotations.BendTableSettingsBuilderColumnType is an alias for NXOpen.Annotations.BendTableSettingsBuilder.ColumnType 

## Detailed Description

Represents a NXOpen::Annotations::BendTableSettingsBuilder. 

Created in NX9.0.0 

## Member Function Documentation

## ◆ AutomaticUpdate() [1/2]

NXOpen.Annotations.BendTableSettingsBuilder.AutomaticUpdate
(
self — )

Getter for property: (bool) AutomaticUpdate Returns the automatic update option. 

Getter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

Returns
bool 

## ◆ AutomaticUpdate() [2/2]

NXOpen.Annotations.BendTableSettingsBuilder.AutomaticUpdate
(
self,

automaticUpdate )

Setter for property: (bool) AutomaticUpdate. 

Sets the automatic update option

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ GetColumnOrder()

NXOpen.Annotations.BendTableSettingsBuilder.GetColumnOrder
(
self — )

Returns the order of the columns in the bend table. 

Returns
columnOrder (List[NXOpen.Annotations.BendTableSettingsBuilder.ColumnType]): .

Created in NX9.0.0 

License requirements: drafting ("DRAFTING") 

## ◆ SetColumnOrder()

NXOpen.Annotations.BendTableSettingsBuilder.SetColumnOrder
(
self,

columnOrder )

Sets the order of the columns in the bend table. 

Created in NX9.0.0 

License requirements: drafting ("DRAFTING")

Parameters

columnOrder — (List[NXOpen.Annotations.BendTableSettingsBuilder.ColumnType])

## ◆ SortColumn() [1/2]

NXOpen.Annotations.BendTableSettingsBuilder.SortColumn
(
self — )

Getter for property: (NXOpen.Annotations.BendTableSettingsBuilder.ColumnType) SortColumn Returns the column that is used to sort the bend table. 

Getter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

Returns
BendTableSettingsBuilder.ColumnType 

## ◆ SortColumn() [2/2]

NXOpen.Annotations.BendTableSettingsBuilder.SortColumn
(
self,

sortColumn )

Setter for property: (NXOpen.Annotations.BendTableSettingsBuilder.ColumnType) SortColumn. 

Sets the column that is used to sort the bend table

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ SortOnUpdate() [1/2]

NXOpen.Annotations.BendTableSettingsBuilder.SortOnUpdate
(
self — )

Getter for property: (bool) SortOnUpdate Returns the sort on update option. 

Getter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

Returns
bool 

## ◆ SortOnUpdate() [2/2]

NXOpen.Annotations.BendTableSettingsBuilder.SortOnUpdate
(
self,

sortOnUpdate )

Setter for property: (bool) SortOnUpdate. 

Sets the sort on update option

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## Member Data Documentation

## ◆ BendTableSettingsBuilderColumnType

NXOpen.Annotations.BendTableSettingsBuilder.BendTableSettingsBuilderColumnType = BendTableSettingsBuilder.ColumnType

NXOpen.Annotations.BendTableSettingsBuilderColumnType is an alias for NXOpen.Annotations.BendTableSettingsBuilder.ColumnType 

Copyright 2025 Siemens
