# NXOpen.Annotations.PmiAttributeValueUrlBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13289.html>

Represents a NXOpen::Annotations::PmiAttributeValueUrl builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiAttributeValueUrlBuilder 

More...

Inheritance diagram for NXOpen.Annotations.PmiAttributeValueUrlBuilder:

## Public Member Functions

UrlValue (self)

Getter for property: (str) UrlValue Returns the url_value. 

UrlValue (self, urlValue)

Setter for property: (str) UrlValue. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::PmiAttributeValueUrl builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiAttributeValueUrlBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ UrlValue() [1/2]

NXOpen.Annotations.PmiAttributeValueUrlBuilder.UrlValue
(
self — )

Getter for property: (str) UrlValue Returns the url_value. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ UrlValue() [2/2]

NXOpen.Annotations.PmiAttributeValueUrlBuilder.UrlValue
(
self,

urlValue )

Setter for property: (str) UrlValue. 

Sets the url_value

Setter License requirements: None.

Created in NX6.0.0 

Copyright 2025 Siemens
