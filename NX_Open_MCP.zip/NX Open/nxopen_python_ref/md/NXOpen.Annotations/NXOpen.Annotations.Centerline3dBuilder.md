# NXOpen.Annotations.Centerline3dBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00142.html>

## Classes

class — Offset

the valid types of 3D Centerline offset method 

Enumerator — Comment

NotSet — No Offset

DistanceMethod — Offset Distance

ObjectMethod — Offset Object, applicable only for creation

More...

Copyright 2025 Siemens
