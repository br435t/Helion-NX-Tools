# NXOpen.Annotations.SearchModelViewBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00212.html>

## Classes

class — PmiTypes

the search criteria pmitype 

Enumerator — Comment

Dimension — dimension type

FeatureControlFrame — feature control frame type

DatumFeatureSymbol — datum feature symbol type

DatumTarget — datum target type

SurfaceFinish — surface finish type

Note — note type

More...

class — SearchScopeOptions

seaerch scope type 

Enumerator — Comment

WorkPart — work part only

WorkPartAndComponents — work part and components

More...

class — TextComparisionOptions

Represents the text comparision options 

Enumerator — Comment

Equals — Equals

Contains — Contains

More...

class — ValueComparisionOptions

Represents the value comparision options 

Enumerator — Comment

Less

LessEqual

Equal

MoreEqual

More

More...

Copyright 2025 Siemens
