# NXOpen.Annotations.SearchCriteriaFeatureControlFrameBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00210.html>

## Classes

class — CharacteristicOptions

Lists the search pmi feature control frame type 

Enumerator — Comment

Straightness — strainhtness

Flatness — flatness

Circularity — circularity

Cylindricity — cylindricity

ProfileOfALine — Profile Of A Line

ProfileOfASurface — profile Of A Surface

Angularity — angularity

Perpendicularity — perpendicularity

Parallelism — parallelism

Position — position

Concentricity — concentricity

Symmetry — symmetry

CircularRunout — circular runout

TotalRunout — total runout

AxisIntersection — axis intersection

More...

class — CircleUOptions

Lists the status of pmi feature control frame circleU 

Enumerator — Comment

Yes — have circle U

No — have no circle U

More...

class — CollectionPlaneOptions

Lists the status of pmi feature control frame collection plane indicator 

Enumerator — Comment

Yes — have collection plane indicator

No — have no collection plane indicator

More...

class — DirectionFeatureOptions

Lists the status of pmi feature control frame direction feature indicator 

Enumerator — Comment

Yes — have direction feature indicator

No — have no direction feature indicator

More...

class — FrameStyleOptions

Lists the search pmi feature control frame style 

Enumerator — Comment

SingleFrame — single frame

CompositeFrame — composite frame

More...

class — FreeStateOptions

Lists the status of pmi feature control frame free state 

Enumerator — Comment

Yes — have free state

No — have no free state

More...

class — IndicatorOptions

Lists the status of pmi feature control frame indicator 

Enumerator — Comment

Yes — have indicator

No — have no indicator

More...

class — IntersectionPlaneOptions

Lists the status of pmi feature control frame intersection plane indicator 

Enumerator — Comment

Yes — have intersection plane indicator

No — have no intersection plane indicator

More...

class — OrientationPlaneOptions

Lists the status of pmi feature control frame orientation plane indicator 

Enumerator — Comment

Yes — have orientation plane indicator

No — have no orientation plane indicator

More...

class — PrimaryDatumDualMCMOptions

Lists the type of pmi feature control frame primary datum dual MCM 

Enumerator — Comment

NotSet — none

LeastMaterialCondition — least material condition

MaximumMaterialCondition — maximum material condition

RegardlessofFeatureSize — regardless of feature size

More...

class — PrimaryDatumMCMOptions

Lists the type of pmi feature control frame primary datum MCM 

Enumerator — Comment

NotSet — none

LeastMaterialCondition — least material condition

MaximumMaterialCondition — maximum material condition

RegardlessofFeatureSize — regardless of feature size

More...

class — ProjectedOptions

Lists the status of pmi feature control frame projected 

Enumerator — Comment

Yes — have projected

No — have no projected

More...

class — SecondaryDatumDualMCMOptions

Lists the type of pmi feature control frame secondary datum dual MCM 

Enumerator — Comment

NotSet — none

LeastMaterialCondition — least material condition

MaximumMaterialCondition — maximum material condition

RegardlessofFeatureSize — regardless of feature size

More...

class — SecondaryDatumMCMOptions

Lists the type of pmi feature control frame secondary datum MCM 

Enumerator — Comment

NotSet — none

LeastMaterialCondition — least material condition

MaximumMaterialCondition — maximum material condition

RegardlessofFeatureSize — regardless of feature size

More...

class — StatisticalOptions

Lists the status of pmi feature control frame statistical 

Enumerator — Comment

Yes — have statistical

No — have no statistical

More...

class — TangentPlaneOptions

Lists the status of pmi feature control frame tangent plane 

Enumerator — Comment

Yes — have tangent plane

No — have no tangent plane

More...

class — TertiaryDatumDualMCMOptions

Lists the type of pmi feature control frame tertiary datum dual MCM 

Enumerator — Comment

NotSet — none

LeastMaterialCondition — least material condition

MaximumMaterialCondition — maximum material condition

RegardlessofFeatureSize — regardless of feature size

More...

class — TertiaryDatumMCMOptions

Lists the type of pmi feature control frame tertiary datum MCM 

Enumerator — Comment

NotSet — none

LeastMaterialCondition — least material condition

MaximumMaterialCondition — maximum material condition

RegardlessofFeatureSize — regardless of feature size

More...

class — ToleranceMCMOptions

Lists the type of pmi feature control frame tolerance MCM 

Enumerator — Comment

NotSet — none

LeastMaterialCondition — least material condition

MaximumMaterialCondition — maximum material condition

RegardlessofFeatureSize — regardless of feature size

More...

class — ZoneShapeOptions

Lists the type of pmi feature control frame zone shape 

Enumerator — Comment

NotSet — none

Diameter — diameter

SphericalDiameter — spherical diameter

Square — square

More...

Copyright 2025 Siemens
