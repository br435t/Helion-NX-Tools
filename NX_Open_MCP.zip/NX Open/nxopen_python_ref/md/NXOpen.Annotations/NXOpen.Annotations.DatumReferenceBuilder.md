# NXOpen.Annotations.DatumReferenceBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00146.html>

## Classes

class — DatumReferenceMaterialCondition

Specifies the material modifier condition for the datum reference 

Enumerator — Comment

NotSet — none

LeastMaterialCondition — least material condition

MaximumMaterialCondition — maximum material condition

RegardlessOfFeatureSize — regardless of size

Basic — basic

More...

Copyright 2025 Siemens
