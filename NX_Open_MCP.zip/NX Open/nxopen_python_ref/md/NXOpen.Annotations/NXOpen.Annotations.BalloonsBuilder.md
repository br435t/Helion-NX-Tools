# NXOpen.Annotations.BalloonsBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11225.html>

Represents a Annotations::BalloonsBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.BalloonsBuilder:

## Public Member Functions

SelectDraftingViews (self)

Getter for property: (NXOpen.Drawings.SelectDraftingViewList) SelectDraftingViews Returns the select drafting views. 

ShowBalloons (self)

Getter for property: (bool) ShowBalloons Returns the show balloons. 

ShowBalloons (self, showBalloons)

Setter for property: (bool) ShowBalloons. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a Annotations::BalloonsBuilder . 

Created in NX1847.0.0 

## Member Function Documentation

## ◆ SelectDraftingViews()

NXOpen.Annotations.BalloonsBuilder.SelectDraftingViews
(
self — )

Getter for property: (NXOpen.Drawings.SelectDraftingViewList) SelectDraftingViews Returns the select drafting views. 

Getter License requirements: None.

Created in NX1847.0.0 

Returns
NXOpen.Drawings.SelectDraftingViewList 

## ◆ ShowBalloons() [1/2]

NXOpen.Annotations.BalloonsBuilder.ShowBalloons
(
self — )

Getter for property: (bool) ShowBalloons Returns the show balloons. 

Getter License requirements: None.

Created in NX1847.0.0 

Returns
bool 

## ◆ ShowBalloons() [2/2]

NXOpen.Annotations.BalloonsBuilder.ShowBalloons
(
self,

showBalloons )

Setter for property: (bool) ShowBalloons. 

Sets the show balloons

Setter License requirements: None.

Created in NX1847.0.0 

Copyright 2025 Siemens
