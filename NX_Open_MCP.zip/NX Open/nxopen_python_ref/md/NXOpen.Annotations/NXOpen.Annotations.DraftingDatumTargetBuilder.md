# NXOpen.Annotations.DraftingDatumTargetBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12009.html>

Represents a NXOpen::Annotations::DraftingDatumTargetBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateDraftingDatumTargetBuilder 

Default values. 
More...

Inheritance diagram for NXOpen.Annotations.DraftingDatumTargetBuilder:

## Public Member Functions

ForeshorteningSymbol (self)

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Public Member Functions inherited from NXOpen.Annotations.DatumTargetBuilder

AreaSize (self)

Getter for property: (str) AreaSize Returns the area size. 

AreaSize (self, areaSize)

Setter for property: (str) AreaSize. 

DatumTargetStandard (self)

Getter for property: (NXOpen.Annotations.DatumTargetBuilder.StandardTypes) DatumTargetStandard Returns the datum target standard. 

DatumTargetStandard (self, standard)

Setter for property: (NXOpen.Annotations.DatumTargetBuilder.StandardTypes) DatumTargetStandard. 

DrawX (self)

Getter for property: (bool) DrawX Returns the draw x. 

DrawX (self, flag)

Setter for property: (bool) DrawX. 

Height (self)

Getter for property: (NXOpen.Expression) Height Returns the height. 

Index (self)

Getter for property: (int) Index Returns the index. 

Index (self, index)

Setter for property: (int) Index. 

InheritFrom (self, inheritTag)

The datum target is inherited form existing datum target. 

InnerDiameter (self)

Getter for property: (NXOpen.Expression) InnerDiameter Returns the inner diameter. 

Label (self)

Getter for property: (str) Label Returns the label. 

Label (self, label)

Setter for property: (str) Label. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Movable (self)

Getter for property: (bool) Movable Returns the flag that indicates movable . 

Movable (self, flag)

Setter for property: (bool) Movable. 

MovableModifierAngle (self)

Getter for property: (NXOpen.Expression) MovableModifierAngle Returns the movable modifier angle. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

OuterDiameter (self)

Getter for property: (NXOpen.Expression) OuterDiameter Returns the outer diameter. 

ReverseMovableModifier (self)

Reverses the Movable datum target direction by 180 degree. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

TerminatorType (self)

Getter for property: (NXOpen.Annotations.DatumTargetBuilder.TerminatorTypes) TerminatorType Returns the terminator type. 

TerminatorType (self, type)

Setter for property: (NXOpen.Annotations.DatumTargetBuilder.TerminatorTypes) TerminatorType. 

Type (self)

Getter for property: (NXOpen.Annotations.DatumTargetBuilder.Types) Type Returns the type. 

Type (self, type)

Setter for property: (NXOpen.Annotations.DatumTargetBuilder.Types) Type. 

Width (self)

Getter for property: (NXOpen.Expression) Width Returns the width. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.Annotations.DatumTargetBuilder

DatumTargetBuilderStandardTypes = DatumTargetBuilder.StandardTypes

NXOpen.Annotations.DatumTargetBuilderStandardTypes is an alias for NXOpen.Annotations.DatumTargetBuilder.StandardTypes 

DatumTargetBuilderTerminatorTypes = DatumTargetBuilder.TerminatorTypes

NXOpen.Annotations.DatumTargetBuilderTerminatorTypes is an alias for NXOpen.Annotations.DatumTargetBuilder.TerminatorTypes 

DatumTargetBuilderTypes = DatumTargetBuilder.Types

NXOpen.Annotations.DatumTargetBuilderTypes is an alias for NXOpen.Annotations.DatumTargetBuilder.Types 

## Detailed Description

Represents a NXOpen::Annotations::DraftingDatumTargetBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateDraftingDatumTargetBuilder 

Default values. 

Property — Value

Height.Value 

10 (millimeters part), 1 (inches part) 

InnerDiameter.Value 

10 (millimeters part), .1 (inches part) 

OuterDiameter.Value 

10 (millimeters part), 1 (inches part) 

Width.Value 

10 (millimeters part), 1 (inches part) 

Created in NX6.0.0 

## Member Function Documentation

## ◆ ForeshorteningSymbol()

NXOpen.Annotations.DraftingDatumTargetBuilder.ForeshorteningSymbol
(
self — )

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
ForeshorteningSymbolBuilder 

Copyright 2025 Siemens
