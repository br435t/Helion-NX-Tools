# NXOpen.Annotations.DraftingImageBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12033.html>

Represents a NXOpen.Annotations.DraftingImageBuilder class. 
More...

Inheritance diagram for NXOpen.Annotations.DraftingImageBuilder:

## Public Member Functions

Image (self)

Getter for property: (NXOpen.Annotations.RasterImageBuilder) Image Returns the raster image builder. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen.Annotations.DraftingImageBuilder class. 

This class enables images to be imported onto drawing sheet (with controls for orientation, sizing, and display). 

To create a new instance of this class, use NXOpen::Annotations::DraftingImageCollection::CreateDraftingImageBuilder 

Created in NX1847.0.0 

## Member Function Documentation

## ◆ Image()

NXOpen.Annotations.DraftingImageBuilder.Image
(
self — )

Getter for property: (NXOpen.Annotations.RasterImageBuilder) Image Returns the raster image builder. 

Getter License requirements: None.

Created in NX1847.0.0 

Returns
RasterImageBuilder 

Copyright 2025 Siemens
