# NXOpen.Annotations.CompoundDatumReferenceBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11753.html>

Represents a NXOpen::Annotations::CompoundDatumReferenceBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateCompoundDatumReferenceBuilder 

More...

Inheritance diagram for NXOpen.Annotations.CompoundDatumReferenceBuilder:

## Public Member Functions

DatumReferenceList (self)

Getter for property: (NXOpen.Annotations.DatumReferenceBuilderList) DatumReferenceList Returns the list of datum references. 

ExtendedText (self)

Getter for property: (NXOpen.Annotations.TextWithSymbolsBuilder) ExtendedText Returns the compound datum reference extended text builder. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::CompoundDatumReferenceBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateCompoundDatumReferenceBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ DatumReferenceList()

NXOpen.Annotations.CompoundDatumReferenceBuilder.DatumReferenceList
(
self — )

Getter for property: (NXOpen.Annotations.DatumReferenceBuilderList) DatumReferenceList Returns the list of datum references. 

Getter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX9.0.0 

Returns
DatumReferenceBuilderList 

## ◆ ExtendedText()

NXOpen.Annotations.CompoundDatumReferenceBuilder.ExtendedText
(
self — )

Getter for property: (NXOpen.Annotations.TextWithSymbolsBuilder) ExtendedText Returns the compound datum reference extended text builder. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
TextWithSymbolsBuilder 

Copyright 2025 Siemens
