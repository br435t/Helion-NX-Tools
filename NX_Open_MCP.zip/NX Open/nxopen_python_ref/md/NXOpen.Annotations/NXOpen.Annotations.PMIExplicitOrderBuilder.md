# NXOpen.Annotations.PMIExplicitOrderBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13469.html>

This is the NXOpen::Annotations::PMIExplicitOrderBuilder for the explicit order 

To create a new instance of this class, use NXOpen::Annotations::PmiManager::CreateExplicitOrderBuilder 

More...

Inheritance diagram for NXOpen.Annotations.PMIExplicitOrderBuilder:

## Additional Inherited Members

Public Member Functions inherited from NXOpen.Gateway.BaseExplicitOrderBuilder

Clear (self)

Clears the current order and restores it to the default order. 

Delete (self, selectedEntries, currentOrder, numOfRemainingEntries)

Deletes the saved order/orders that has/have been selected by the user from the list of saved orders. 

DownArrow (self, selectedEntries, currentOrder)

Moves down the row/rows selected by the user in the lists. 

Paste (self, pastePoint, selectedEntries, currentOrder)

Pastes the rows that have been previously selected using the cut operation. 

Save (self, orderList, saveName)

Saves an explicit order defined by the user. 

SaveAsTextFile (self, savedOrderName, saveFileName, overwriteFile)

Saves the selected saved order in the form of a text file. 

SaveName (self)

Getter for property: (str) SaveName Returns the save name. 

SaveName (self, saveName)

Setter for property: (str) SaveName. 

UpArrow (self, selectedEntries, currentOrder)

Moves up the row/rows selected by the user in the lists. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

This is the NXOpen::Annotations::PMIExplicitOrderBuilder for the explicit order 

To create a new instance of this class, use NXOpen::Annotations::PmiManager::CreateExplicitOrderBuilder 

Created in NX9.0.0 

Copyright 2025 Siemens
