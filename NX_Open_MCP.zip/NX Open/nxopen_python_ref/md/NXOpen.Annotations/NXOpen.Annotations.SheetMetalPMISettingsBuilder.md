# NXOpen.Annotations.SheetMetalPMISettingsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00214.html>

## Classes

class — BendParameters

This represents sheet metal flat pattern bend parameter type. More...

class — BendParameterType

This represents the bend parameters. More...

class — BodyParameterType

This represents the body parameters. More...

class — FlatpatternBendDataType

This represents sheet metal flat pattern bend data type. More...

class — FlatpatternJoggleParametersType

This represents sheet metal flat pattern joggle parameter type. More...

class — FlatpatternLighteningCutoutParametersType

This represents sheet metal flat pattern lightening cutout parameter type. More...

class — FlatpatternNotePropertiesType

This represents sheet metal flat pattern note properties type. More...

class — FpProperties

This represents sheet metal flat pattern properties note type. More...

class — LabelPlacementTypes

This represents sheet metal flat pattern pmi orientation type. More...

class — PmiLayerOptions

The enum defines how layer should be applied to Flat Pattern PMI labels and note. More...

class — SmPmiNoteType

This represents sheet metal pmi note type. More...

class — SmPmiType

This represents sheet metal pmi type. More...

Copyright 2025 Siemens
