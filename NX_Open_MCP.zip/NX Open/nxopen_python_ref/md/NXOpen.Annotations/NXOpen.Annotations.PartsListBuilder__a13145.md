# NXOpen.Annotations.PartsListBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13145.html>

Represents a NXOpen::Annotations::PartsListBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.PartsListBuilder:

## Public Member Functions

AllowManualRows (self)

Getter for property: (bool) AllowManualRows Returns the allow manual rows option that determines whether or not manual rows are allowed to be inserted into a parts list. 

AllowManualRows (self, allowManualRows)

Setter for property: (bool) AllowManualRows. 

AutomaticUpdate (self)

Getter for property: (bool) AutomaticUpdate Returns the automatic update option to determine whether or not the parts list updates automatically whenever a change occurs to a referenced object in the model. 

AutomaticUpdate (self, automaticUpdate)

Setter for property: (bool) AutomaticUpdate. 

CalloutSuffix (self)

Getter for property: (str) CalloutSuffix Returns the callout suffix specifies the suffix to be used for reference symbol text. 

CalloutSuffix (self, calloutSuffix)

Setter for property: (str) CalloutSuffix. 

CharToSkip (self)

Getter for property: (str) CharToSkip Returns the characters to skip specifies the characters to be skipped for callouts. 

CharToSkip (self, charsToSkip)

Setter for property: (str) CharToSkip. 

CreateNewRowAsLocked (self)

Getter for property: (bool) CreateNewRowAsLocked Returns the create new row as locked option that determines whether new rows in the parts list are locked automatically on creation. 

CreateNewRowAsLocked (self, createNewRowAsLocked)

Setter for property: (bool) CreateNewRowAsLocked. 

EnableCrossHighlighting (self)

Getter for property: (bool) EnableCrossHighlighting Returns the flag to enable cross highlighting. 

EnableCrossHighlighting (self, enableCrossHighlighting)

Setter for property: (bool) EnableCrossHighlighting. 

GrowDirectionOptions (self)

Getter for property: (NXOpen.Annotations.PartsListBuilder.PartsListGrowDirectionOptions) GrowDirectionOptions Returns the grow direction options that specify the direction of growth for the parts list. 

GrowDirectionOptions (self, growDirectionOptions)

Setter for property: (NXOpen.Annotations.PartsListBuilder.PartsListGrowDirectionOptions) GrowDirectionOptions. 

HighlightColor (self)

Getter for property: (NXOpen.NXColor) HighlightColor Returns the highlight color specifies the color used for the delimiters that highlight manual cell text. 

HighlightColor (self, highlightColor)

Setter for property: (NXOpen.NXColor) HighlightColor. 

HighlightManualText (self)

Getter for property: (bool) HighlightManualText Returns the highlight manual text specifies whether manual cell text is to be highlighted by delimiters. 

HighlightManualText (self, highlightManualText)

Setter for property: (bool) HighlightManualText. 

Increment (self)

Getter for property: (int) Increment Returns the increment specifies the value by which consecutive callout values are be incremented. 

Increment (self, increment)

Setter for property: (int) Increment. 

InitialCallout (self)

Getter for property: (str) InitialCallout Returns the initial callout specifies the text string used to represent the first callout in the parts list. 

InitialCallout (self, initialCallout)

Setter for property: (str) InitialCallout. 

LockPartsListSetup (self)

Getter for property: (bool) LockPartsListSetup Returns the Lock Parts List Setup option that determines Is the parts list setup protected/locked. 

LockPartsListSetup (self, lockPartsListSetup)

Setter for property: (bool) LockPartsListSetup. 

MainSymbolCustomText (self)

Getter for property: (str) MainSymbolCustomText Returns the main symbol custom text specifies the custom text to display in the main callout symbol. 

MainSymbolCustomText (self, mainSymbolCustomText)

Setter for property: (str) MainSymbolCustomText. 

MainSymbolText (self)

Getter for property: (NXOpen.Annotations.PartsListBuilder.PartsListMainSymbolText) MainSymbolText Returns the main symbol text specifies the text to display in the main callout symbol. 

MainSymbolText (self, mainSymbolText)

Setter for property: (NXOpen.Annotations.PartsListBuilder.PartsListMainSymbolText) MainSymbolText. 

PackRoutedStockComponents (self)

Getter for property: (bool) PackRoutedStockComponents Returns the flag indicating whether packing routed stock and insulation components is enabled. 

PackRoutedStockComponents (self, packRoutedStockComponents)

Setter for property: (bool) PackRoutedStockComponents. 

ReferenceSymbolCustomText (self)

Getter for property: (str) ReferenceSymbolCustomText Returns the reference symbol custom text specifies the custom text to display in the main callout symbol. 

ReferenceSymbolCustomText (self, referenceSymbolCustomText)

Setter for property: (str) ReferenceSymbolCustomText. 

ReferenceSymbolText (self)

Getter for property: (NXOpen.Annotations.PartsListBuilder.PartsListReferenceSymbolText) ReferenceSymbolText Returns the reference symbol text specifies the text to display in the reference callout symbol. 

ReferenceSymbolText (self, referenceSymbolText)

Setter for property: (NXOpen.Annotations.PartsListBuilder.PartsListReferenceSymbolText) ReferenceSymbolText. 

ShowLockedDeletedRows (self)

Getter for property: (NXOpen.Annotations.PartsListBuilder.PartsListShowLockedDeletedRows) ShowLockedDeletedRows Returns the show locked deleted rows option to show rows that are locked, but reference components that have been removed from the assembly. 

ShowLockedDeletedRows (self, showLockedDeletedRows)

Setter for property: (NXOpen.Annotations.PartsListBuilder.PartsListShowLockedDeletedRows) ShowLockedDeletedRows. 

ShowReferenceCalloutSuffix (self)

Getter for property: (bool) ShowReferenceCalloutSuffix Returns the flag indicating whether the reference callout suffix will be displayed. 

ShowReferenceCalloutSuffix (self, showReferenceCalloutSuffix)

Setter for property: (bool) ShowReferenceCalloutSuffix. 

SortOnUpdate (self)

Getter for property: (bool) SortOnUpdate Returns the sort on update option that determines whether or not the parts list sorts automatically during update. 

SortOnUpdate (self, sortOnUpdate)

Setter for property: (bool) SortOnUpdate. 

Symbol (self)

Getter for property: (NXOpen.Annotations.PartsListBuilder.PartsListSymbolType) Symbol Returns the symbol type specifies the balloon type used to call out members. 

Symbol (self, symbol)

Setter for property: (NXOpen.Annotations.PartsListBuilder.PartsListSymbolType) Symbol. 

VerticalGroupAttachment (self)

Getter for property: (NXOpen.Annotations.PartsListBuilder.PartsListVerticalGroupLeaderAttachment) VerticalGroupAttachment Returns the leader attachment to vertical callout groups. 

VerticalGroupAttachment (self, position)

Setter for property: (NXOpen.Annotations.PartsListBuilder.PartsListVerticalGroupLeaderAttachment) VerticalGroupAttachment. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

PartsListBuilderPartsListGrowDirectionOptions = PartsListBuilder.PartsListGrowDirectionOptions

NXOpen.Annotations.PartsListBuilderPartsListGrowDirectionOptions is an alias for NXOpen.Annotations.PartsListBuilder.PartsListGrowDirectionOptions 

PartsListBuilderPartsListMainSymbolText = PartsListBuilder.PartsListMainSymbolText

NXOpen.Annotations.PartsListBuilderPartsListMainSymbolText is an alias for NXOpen.Annotations.PartsListBuilder.PartsListMainSymbolText 

PartsListBuilderPartsListReferenceSymbolText = PartsListBuilder.PartsListReferenceSymbolText

NXOpen.Annotations.PartsListBuilderPartsListReferenceSymbolText is an alias for NXOpen.Annotations.PartsListBuilder.PartsListReferenceSymbolText 

PartsListBuilderPartsListShowLockedDeletedRows = PartsListBuilder.PartsListShowLockedDeletedRows

NXOpen.Annotations.PartsListBuilderPartsListShowLockedDeletedRows is an alias for NXOpen.Annotations.PartsListBuilder.PartsListShowLockedDeletedRows 

PartsListBuilderPartsListSymbolType = PartsListBuilder.PartsListSymbolType

NXOpen.Annotations.PartsListBuilderPartsListSymbolType is an alias for NXOpen.Annotations.PartsListBuilder.PartsListSymbolType 

PartsListBuilderPartsListVerticalGroupLeaderAttachment = PartsListBuilder.PartsListVerticalGroupLeaderAttachment

NXOpen.Annotations.PartsListBuilderPartsListVerticalGroupLeaderAttachment is an alias for NXOpen.Annotations.PartsListBuilder.PartsListVerticalGroupLeaderAttachment 

## Detailed Description

Represents a NXOpen::Annotations::PartsListBuilder . 

This class queries and sets settings specific to parts list when creating or editing parts list settings. 

This is a sub-builder class and cannot be directly instantiated 

Created in NX9.0.0 

## Member Function Documentation

## ◆ AllowManualRows() [1/2]

NXOpen.Annotations.PartsListBuilder.AllowManualRows
(
self — )

Getter for property: (bool) AllowManualRows Returns the allow manual rows option that determines whether or not manual rows are allowed to be inserted into a parts list. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ AllowManualRows() [2/2]

NXOpen.Annotations.PartsListBuilder.AllowManualRows
(
self,

allowManualRows )

Setter for property: (bool) AllowManualRows. 

Sets the allow manual rows option that determines whether or not manual rows are allowed to be inserted into a parts list

Setter License requirements: None.

Created in NX9.0.0 

## ◆ AutomaticUpdate() [1/2]

NXOpen.Annotations.PartsListBuilder.AutomaticUpdate
(
self — )

Getter for property: (bool) AutomaticUpdate Returns the automatic update option to determine whether or not the parts list updates automatically whenever a change occurs to a referenced object in the model. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ AutomaticUpdate() [2/2]

NXOpen.Annotations.PartsListBuilder.AutomaticUpdate
(
self,

automaticUpdate )

Setter for property: (bool) AutomaticUpdate. 

Sets the automatic update option to determine whether or not the parts list updates automatically whenever a change occurs to a referenced object in the model

Setter License requirements: None.

Created in NX9.0.0 

## ◆ CalloutSuffix() [1/2]

NXOpen.Annotations.PartsListBuilder.CalloutSuffix
(
self — )

Getter for property: (str) CalloutSuffix Returns the callout suffix specifies the suffix to be used for reference symbol text. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
str 

## ◆ CalloutSuffix() [2/2]

NXOpen.Annotations.PartsListBuilder.CalloutSuffix
(
self,

calloutSuffix )

Setter for property: (str) CalloutSuffix. 

Sets the callout suffix specifies the suffix to be used for reference symbol text

Setter License requirements: None.

Created in NX9.0.0 

## ◆ CharToSkip() [1/2]

NXOpen.Annotations.PartsListBuilder.CharToSkip
(
self — )

Getter for property: (str) CharToSkip Returns the characters to skip specifies the characters to be skipped for callouts. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
str 

## ◆ CharToSkip() [2/2]

NXOpen.Annotations.PartsListBuilder.CharToSkip
(
self,

charsToSkip )

Setter for property: (str) CharToSkip. 

Sets the characters to skip specifies the characters to be skipped for callouts

Setter License requirements: None.

Created in NX9.0.0 

## ◆ CreateNewRowAsLocked() [1/2]

NXOpen.Annotations.PartsListBuilder.CreateNewRowAsLocked
(
self — )

Getter for property: (bool) CreateNewRowAsLocked Returns the create new row as locked option that determines whether new rows in the parts list are locked automatically on creation. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ CreateNewRowAsLocked() [2/2]

NXOpen.Annotations.PartsListBuilder.CreateNewRowAsLocked
(
self,

createNewRowAsLocked )

Setter for property: (bool) CreateNewRowAsLocked. 

Sets the create new row as locked option that determines whether new rows in the parts list are locked automatically on creation

Setter License requirements: None.

Created in NX9.0.0 

## ◆ EnableCrossHighlighting() [1/2]

NXOpen.Annotations.PartsListBuilder.EnableCrossHighlighting
(
self — )

Getter for property: (bool) EnableCrossHighlighting Returns the flag to enable cross highlighting. 

Getter License requirements: None.

Created in NX1847.0.0 

Returns
bool 

## ◆ EnableCrossHighlighting() [2/2]

NXOpen.Annotations.PartsListBuilder.EnableCrossHighlighting
(
self,

enableCrossHighlighting )

Setter for property: (bool) EnableCrossHighlighting. 

Sets the flag to enable cross highlighting

Setter License requirements: None.

Created in NX1847.0.0 

## ◆ GrowDirectionOptions() [1/2]

NXOpen.Annotations.PartsListBuilder.GrowDirectionOptions
(
self — )

Getter for property: (NXOpen.Annotations.PartsListBuilder.PartsListGrowDirectionOptions) GrowDirectionOptions Returns the grow direction options that specify the direction of growth for the parts list. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
PartsListBuilder.PartsListGrowDirectionOptions 

## ◆ GrowDirectionOptions() [2/2]

NXOpen.Annotations.PartsListBuilder.GrowDirectionOptions
(
self,

growDirectionOptions )

Setter for property: (NXOpen.Annotations.PartsListBuilder.PartsListGrowDirectionOptions) GrowDirectionOptions. 

Sets the grow direction options that specify the direction of growth for the parts list

Setter License requirements: None.

Created in NX9.0.0 

## ◆ HighlightColor() [1/2]

NXOpen.Annotations.PartsListBuilder.HighlightColor
(
self — )

Getter for property: (NXOpen.NXColor) HighlightColor Returns the highlight color specifies the color used for the delimiters that highlight manual cell text. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
NXOpen.NXColor 

## ◆ HighlightColor() [2/2]

NXOpen.Annotations.PartsListBuilder.HighlightColor
(
self,

highlightColor )

Setter for property: (NXOpen.NXColor) HighlightColor. 

Sets the highlight color specifies the color used for the delimiters that highlight manual cell text

Setter License requirements: None.

Created in NX9.0.0 

## ◆ HighlightManualText() [1/2]

NXOpen.Annotations.PartsListBuilder.HighlightManualText
(
self — )

Getter for property: (bool) HighlightManualText Returns the highlight manual text specifies whether manual cell text is to be highlighted by delimiters. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ HighlightManualText() [2/2]

NXOpen.Annotations.PartsListBuilder.HighlightManualText
(
self,

highlightManualText )

Setter for property: (bool) HighlightManualText. 

Sets the highlight manual text specifies whether manual cell text is to be highlighted by delimiters

Setter License requirements: None.

Created in NX9.0.0 

## ◆ Increment() [1/2]

NXOpen.Annotations.PartsListBuilder.Increment
(
self — )

Getter for property: (int) Increment Returns the increment specifies the value by which consecutive callout values are be incremented. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
int 

## ◆ Increment() [2/2]

NXOpen.Annotations.PartsListBuilder.Increment
(
self,

increment )

Setter for property: (int) Increment. 

Sets the increment specifies the value by which consecutive callout values are be incremented

Setter License requirements: None.

Created in NX9.0.0 

## ◆ InitialCallout() [1/2]

NXOpen.Annotations.PartsListBuilder.InitialCallout
(
self — )

Getter for property: (str) InitialCallout Returns the initial callout specifies the text string used to represent the first callout in the parts list. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
str 

## ◆ InitialCallout() [2/2]

NXOpen.Annotations.PartsListBuilder.InitialCallout
(
self,

initialCallout )

Setter for property: (str) InitialCallout. 

Sets the initial callout specifies the text string used to represent the first callout in the parts list

Setter License requirements: None.

Created in NX9.0.0 

## ◆ LockPartsListSetup() [1/2]

NXOpen.Annotations.PartsListBuilder.LockPartsListSetup
(
self — )

Getter for property: (bool) LockPartsListSetup Returns the Lock Parts List Setup option that determines Is the parts list setup protected/locked. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ LockPartsListSetup() [2/2]

NXOpen.Annotations.PartsListBuilder.LockPartsListSetup
(
self,

lockPartsListSetup )

Setter for property: (bool) LockPartsListSetup. 

Sets the Lock Parts List Setup option that determines Is the parts list setup protected/locked

Setter License requirements: None.

Created in NX9.0.0 

## ◆ MainSymbolCustomText() [1/2]

NXOpen.Annotations.PartsListBuilder.MainSymbolCustomText
(
self — )

Getter for property: (str) MainSymbolCustomText Returns the main symbol custom text specifies the custom text to display in the main callout symbol. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
str 

## ◆ MainSymbolCustomText() [2/2]

NXOpen.Annotations.PartsListBuilder.MainSymbolCustomText
(
self,

mainSymbolCustomText )

Setter for property: (str) MainSymbolCustomText. 

Sets the main symbol custom text specifies the custom text to display in the main callout symbol

Setter License requirements: None.

Created in NX9.0.0 

## ◆ MainSymbolText() [1/2]

NXOpen.Annotations.PartsListBuilder.MainSymbolText
(
self — )

Getter for property: (NXOpen.Annotations.PartsListBuilder.PartsListMainSymbolText) MainSymbolText Returns the main symbol text specifies the text to display in the main callout symbol. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
PartsListBuilder.PartsListMainSymbolText 

## ◆ MainSymbolText() [2/2]

NXOpen.Annotations.PartsListBuilder.MainSymbolText
(
self,

mainSymbolText )

Setter for property: (NXOpen.Annotations.PartsListBuilder.PartsListMainSymbolText) MainSymbolText. 

Sets the main symbol text specifies the text to display in the main callout symbol

Setter License requirements: None.

Created in NX9.0.0 

## ◆ PackRoutedStockComponents() [1/2]

NXOpen.Annotations.PartsListBuilder.PackRoutedStockComponents
(
self — )

Getter for property: (bool) PackRoutedStockComponents Returns the flag indicating whether packing routed stock and insulation components is enabled. 

Getter License requirements: drafting ("DRAFTING")

Created in NX2206.0.0 

Returns
bool 

## ◆ PackRoutedStockComponents() [2/2]

NXOpen.Annotations.PartsListBuilder.PackRoutedStockComponents
(
self,

packRoutedStockComponents )

Setter for property: (bool) PackRoutedStockComponents. 

Sets the flag indicating whether packing routed stock and insulation components is enabled.

Setter License requirements: drafting ("DRAFTING")

Created in NX2206.0.0 

## ◆ ReferenceSymbolCustomText() [1/2]

NXOpen.Annotations.PartsListBuilder.ReferenceSymbolCustomText
(
self — )

Getter for property: (str) ReferenceSymbolCustomText Returns the reference symbol custom text specifies the custom text to display in the main callout symbol. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
str 

## ◆ ReferenceSymbolCustomText() [2/2]

NXOpen.Annotations.PartsListBuilder.ReferenceSymbolCustomText
(
self,

referenceSymbolCustomText )

Setter for property: (str) ReferenceSymbolCustomText. 

Sets the reference symbol custom text specifies the custom text to display in the main callout symbol

Setter License requirements: None.

Created in NX9.0.0 

## ◆ ReferenceSymbolText() [1/2]

NXOpen.Annotations.PartsListBuilder.ReferenceSymbolText
(
self — )

Getter for property: (NXOpen.Annotations.PartsListBuilder.PartsListReferenceSymbolText) ReferenceSymbolText Returns the reference symbol text specifies the text to display in the reference callout symbol. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
PartsListBuilder.PartsListReferenceSymbolText 

## ◆ ReferenceSymbolText() [2/2]

NXOpen.Annotations.PartsListBuilder.ReferenceSymbolText
(
self,

referenceSymbolText )

Setter for property: (NXOpen.Annotations.PartsListBuilder.PartsListReferenceSymbolText) ReferenceSymbolText. 

Sets the reference symbol text specifies the text to display in the reference callout symbol

Setter License requirements: None.

Created in NX9.0.0 

## ◆ ShowLockedDeletedRows() [1/2]

NXOpen.Annotations.PartsListBuilder.ShowLockedDeletedRows
(
self — )

Getter for property: (NXOpen.Annotations.PartsListBuilder.PartsListShowLockedDeletedRows) ShowLockedDeletedRows Returns the show locked deleted rows option to show rows that are locked, but reference components that have been removed from the assembly. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
PartsListBuilder.PartsListShowLockedDeletedRows 

## ◆ ShowLockedDeletedRows() [2/2]

NXOpen.Annotations.PartsListBuilder.ShowLockedDeletedRows
(
self,

showLockedDeletedRows )

Setter for property: (NXOpen.Annotations.PartsListBuilder.PartsListShowLockedDeletedRows) ShowLockedDeletedRows. 

Sets the show locked deleted rows option to show rows that are locked, but reference components that have been removed from the assembly

Setter License requirements: None.

Created in NX9.0.0 

## ◆ ShowReferenceCalloutSuffix() [1/2]

NXOpen.Annotations.PartsListBuilder.ShowReferenceCalloutSuffix
(
self — )

Getter for property: (bool) ShowReferenceCalloutSuffix Returns the flag indicating whether the reference callout suffix will be displayed. 

A value of true indicates that the suffix will be displayed.

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ ShowReferenceCalloutSuffix() [2/2]

NXOpen.Annotations.PartsListBuilder.ShowReferenceCalloutSuffix
(
self,

showReferenceCalloutSuffix )

Setter for property: (bool) ShowReferenceCalloutSuffix. 

Sets the flag indicating whether the reference callout suffix will be displayed. A value of true indicates that the suffix will be displayed.

Setter License requirements: None.

Created in NX9.0.0 

## ◆ SortOnUpdate() [1/2]

NXOpen.Annotations.PartsListBuilder.SortOnUpdate
(
self — )

Getter for property: (bool) SortOnUpdate Returns the sort on update option that determines whether or not the parts list sorts automatically during update. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ SortOnUpdate() [2/2]

NXOpen.Annotations.PartsListBuilder.SortOnUpdate
(
self,

sortOnUpdate )

Setter for property: (bool) SortOnUpdate. 

Sets the sort on update option that determines whether or not the parts list sorts automatically during update

Setter License requirements: None.

Created in NX9.0.0 

## ◆ Symbol() [1/2]

NXOpen.Annotations.PartsListBuilder.Symbol
(
self — )

Getter for property: (NXOpen.Annotations.PartsListBuilder.PartsListSymbolType) Symbol Returns the symbol type specifies the balloon type used to call out members. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
PartsListBuilder.PartsListSymbolType 

## ◆ Symbol() [2/2]

NXOpen.Annotations.PartsListBuilder.Symbol
(
self,

symbol )

Setter for property: (NXOpen.Annotations.PartsListBuilder.PartsListSymbolType) Symbol. 

Sets the symbol type specifies the balloon type used to call out members

Setter License requirements: None.

Created in NX9.0.0 

## ◆ VerticalGroupAttachment() [1/2]

NXOpen.Annotations.PartsListBuilder.VerticalGroupAttachment
(
self — )

Getter for property: (NXOpen.Annotations.PartsListBuilder.PartsListVerticalGroupLeaderAttachment) VerticalGroupAttachment Returns the leader attachment to vertical callout groups. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
PartsListBuilder.PartsListVerticalGroupLeaderAttachment 

## ◆ VerticalGroupAttachment() [2/2]

NXOpen.Annotations.PartsListBuilder.VerticalGroupAttachment
(
self,

position )

Setter for property: (NXOpen.Annotations.PartsListBuilder.PartsListVerticalGroupLeaderAttachment) VerticalGroupAttachment. 

Sets the leader attachment to vertical callout groups

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## Member Data Documentation

## ◆ PartsListBuilderPartsListGrowDirectionOptions

NXOpen.Annotations.PartsListBuilder.PartsListBuilderPartsListGrowDirectionOptions = PartsListBuilder.PartsListGrowDirectionOptions

NXOpen.Annotations.PartsListBuilderPartsListGrowDirectionOptions is an alias for NXOpen.Annotations.PartsListBuilder.PartsListGrowDirectionOptions 

## ◆ PartsListBuilderPartsListMainSymbolText

NXOpen.Annotations.PartsListBuilder.PartsListBuilderPartsListMainSymbolText = PartsListBuilder.PartsListMainSymbolText

NXOpen.Annotations.PartsListBuilderPartsListMainSymbolText is an alias for NXOpen.Annotations.PartsListBuilder.PartsListMainSymbolText 

## ◆ PartsListBuilderPartsListReferenceSymbolText

NXOpen.Annotations.PartsListBuilder.PartsListBuilderPartsListReferenceSymbolText = PartsListBuilder.PartsListReferenceSymbolText

NXOpen.Annotations.PartsListBuilderPartsListReferenceSymbolText is an alias for NXOpen.Annotations.PartsListBuilder.PartsListReferenceSymbolText 

## ◆ PartsListBuilderPartsListShowLockedDeletedRows

NXOpen.Annotations.PartsListBuilder.PartsListBuilderPartsListShowLockedDeletedRows = PartsListBuilder.PartsListShowLockedDeletedRows

NXOpen.Annotations.PartsListBuilderPartsListShowLockedDeletedRows is an alias for NXOpen.Annotations.PartsListBuilder.PartsListShowLockedDeletedRows 

## ◆ PartsListBuilderPartsListSymbolType

NXOpen.Annotations.PartsListBuilder.PartsListBuilderPartsListSymbolType = PartsListBuilder.PartsListSymbolType

NXOpen.Annotations.PartsListBuilderPartsListSymbolType is an alias for NXOpen.Annotations.PartsListBuilder.PartsListSymbolType 

## ◆ PartsListBuilderPartsListVerticalGroupLeaderAttachment

NXOpen.Annotations.PartsListBuilder.PartsListBuilderPartsListVerticalGroupLeaderAttachment = PartsListBuilder.PartsListVerticalGroupLeaderAttachment

NXOpen.Annotations.PartsListBuilderPartsListVerticalGroupLeaderAttachment is an alias for NXOpen.Annotations.PartsListBuilder.PartsListVerticalGroupLeaderAttachment 

Copyright 2025 Siemens
