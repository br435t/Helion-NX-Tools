# NXOpen.Annotations.CommonWorkflowBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11733.html>

Represents a NXOpen::Annotations::CommonWorkflowBuilder. 
More...

Inheritance diagram for NXOpen.Annotations.CommonWorkflowBuilder:

## Public Member Functions

DynamicAlignmentInGlobalSelection (self)

Getter for property: (bool) DynamicAlignmentInGlobalSelection Returns the dynamic alignment in global selection determines whether drafting annotations and dimensions will automatically align or not when moving them in Global Selection. 

DynamicAlignmentInGlobalSelection (self, dynamicAlignmentInGlobalSelection)

Setter for property: (bool) DynamicAlignmentInGlobalSelection. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::CommonWorkflowBuilder. 

Created in NX9.0.0 

## Member Function Documentation

## ◆ DynamicAlignmentInGlobalSelection() [1/2]

NXOpen.Annotations.CommonWorkflowBuilder.DynamicAlignmentInGlobalSelection
(
self — )

Getter for property: (bool) DynamicAlignmentInGlobalSelection Returns the dynamic alignment in global selection determines whether drafting annotations and dimensions will automatically align or not when moving them in Global Selection. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ DynamicAlignmentInGlobalSelection() [2/2]

NXOpen.Annotations.CommonWorkflowBuilder.DynamicAlignmentInGlobalSelection
(
self,

dynamicAlignmentInGlobalSelection )

Setter for property: (bool) DynamicAlignmentInGlobalSelection. 

Sets the dynamic alignment in global selection determines whether drafting annotations and dimensions will automatically align or not when moving them in Global Selection.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

Copyright 2025 Siemens
