# NXOpen.Annotations.DatumReferenceBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11845.html>

Represents a NXOpen::Annotations::DatumReferenceBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateEmptyDatumReferenceBuilder 

More...

Inheritance diagram for NXOpen.Annotations.DatumReferenceBuilder:

## Public Member Functions

AnyCrossSection (self)

Getter for property: (bool) AnyCrossSection Returns the datum reference Any Cross Section. 

AnyCrossSection (self, datumReferenceAnyCrossSection)

Setter for property: (bool) AnyCrossSection. 

AnyLongitudinalSection (self)

Getter for property: (bool) AnyLongitudinalSection Returns the datum reference Any Longitudinal Section. 

AnyLongitudinalSection (self, datumReferenceAnyLongitudinalSection)

Setter for property: (bool) AnyLongitudinalSection. 

ContactingFeature (self)

Getter for property: (bool) ContactingFeature Returns the datum reference Contacting Feature. 

ContactingFeature (self, datumReferenceContactingFeature)

Setter for property: (bool) ContactingFeature. 

DatumTranslation (self)

Getter for property: (bool) DatumTranslation Returns the datum reference Datum Translation. 

DatumTranslation (self, datumReferenceDatumTranslation)

Setter for property: (bool) DatumTranslation. 

FreeState (self)

Getter for property: (bool) FreeState Returns the datum reference free state. 

FreeState (self, datumReferenceFreeState)

Setter for property: (bool) FreeState. 

LeftBracket (self)

Getter for property: (bool) LeftBracket Returns the datum reference Left Bracket. 

LeftBracket (self, datumReferenceLeftBracket)

Setter for property: (bool) LeftBracket. 

Letter (self)

Getter for property: (str) Letter Returns the datum reference datum letter. 

Letter (self, datumReferenceDatum)

Setter for property: (str) Letter. 

MajorDiameter (self)

Getter for property: (bool) MajorDiameter Returns the datum reference Major Diameter. 

MajorDiameter (self, datumReferenceMajorDiameter)

Setter for property: (bool) MajorDiameter. 

MaterialCondition (self)

Getter for property: (NXOpen.Annotations.DatumReferenceBuilder.DatumReferenceMaterialCondition) MaterialCondition Returns the datum reference material condition. 

MaterialCondition (self, materialCondition)

Setter for property: (NXOpen.Annotations.DatumReferenceBuilder.DatumReferenceMaterialCondition) MaterialCondition. 

MinorDiameter (self)

Getter for property: (bool) MinorDiameter Returns the datum reference Minor Diameter. 

MinorDiameter (self, datumReferenceMinorDiameter)

Setter for property: (bool) MinorDiameter. 

OrientationConstraint (self)

Getter for property: (bool) OrientationConstraint Returns the datum reference Orientation Constraint. 

OrientationConstraint (self, datumReferenceOrientationConstraint)

Setter for property: (bool) OrientationConstraint. 

PitchDiameter (self)

Getter for property: (bool) PitchDiameter Returns the datum reference Pitch Diameter. 

PitchDiameter (self, datumReferencePitchDiameter)

Setter for property: (bool) PitchDiameter. 

Projected (self)

Getter for property: (bool) Projected Returns the datum reference projected. 

Projected (self, datumReferenceProjected)

Setter for property: (bool) Projected. 

RightBracket (self)

Getter for property: (bool) RightBracket Returns the datum reference Orientation Constraint. 

RightBracket (self, datumReferenceRightBracket)

Setter for property: (bool) RightBracket. 

SituationFeatureLine (self)

Getter for property: (bool) SituationFeatureLine Returns the datum reference Situation Feature Line. 

SituationFeatureLine (self, datumReferenceSituationFeatureLine)

Setter for property: (bool) SituationFeatureLine. 

SituationFeaturePlane (self)

Getter for property: (bool) SituationFeaturePlane Returns the datum reference Situation Feature Plane. 

SituationFeaturePlane (self, datumReferenceSituationFeaturePlane)

Setter for property: (bool) SituationFeaturePlane. 

SituationFeaturePoint (self)

Getter for property: (bool) SituationFeaturePoint Returns the datum reference Situation Feature Point. 

SituationFeaturePoint (self, datumReferenceSituationFeaturePoint)

Setter for property: (bool) SituationFeaturePoint. 

VariableDistance (self)

Getter for property: (bool) VariableDistance Returns the datum reference Variable Distance. 

VariableDistance (self, datumReferenceVariableDistance)

Setter for property: (bool) VariableDistance. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

DatumReferenceBuilderDatumReferenceMaterialCondition = DatumReferenceBuilder.DatumReferenceMaterialCondition

NXOpen.Annotations.DatumReferenceBuilderDatumReferenceMaterialCondition is an alias for NXOpen.Annotations.DatumReferenceBuilder.DatumReferenceMaterialCondition 

## Detailed Description

Represents a NXOpen::Annotations::DatumReferenceBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateEmptyDatumReferenceBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ AnyCrossSection() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.AnyCrossSection
(
self — )

Getter for property: (bool) AnyCrossSection Returns the datum reference Any Cross Section. 

Getter License requirements: None.

Created in NX2406.0.0 

Returns
bool 

## ◆ AnyCrossSection() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.AnyCrossSection
(
self,

datumReferenceAnyCrossSection )

Setter for property: (bool) AnyCrossSection. 

Sets the datum reference Any Cross Section

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX2406.0.0 

## ◆ AnyLongitudinalSection() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.AnyLongitudinalSection
(
self — )

Getter for property: (bool) AnyLongitudinalSection Returns the datum reference Any Longitudinal Section. 

Getter License requirements: None.

Created in NX2406.0.0 

Returns
bool 

## ◆ AnyLongitudinalSection() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.AnyLongitudinalSection
(
self,

datumReferenceAnyLongitudinalSection )

Setter for property: (bool) AnyLongitudinalSection. 

Sets the datum reference Any Longitudinal Section

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX2406.0.0 

## ◆ ContactingFeature() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.ContactingFeature
(
self — )

Getter for property: (bool) ContactingFeature Returns the datum reference Contacting Feature. 

Getter License requirements: None.

Created in NX2406.0.0 

Returns
bool 

## ◆ ContactingFeature() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.ContactingFeature
(
self,

datumReferenceContactingFeature )

Setter for property: (bool) ContactingFeature. 

Sets the datum reference Contacting Feature

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX2406.0.0 

## ◆ DatumTranslation() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.DatumTranslation
(
self — )

Getter for property: (bool) DatumTranslation Returns the datum reference Datum Translation. 

Getter License requirements: None.

Created in NX2506.0.0 

Returns
bool 

## ◆ DatumTranslation() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.DatumTranslation
(
self,

datumReferenceDatumTranslation )

Setter for property: (bool) DatumTranslation. 

Sets the datum reference Datum Translation

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX2506.0.0 

## ◆ FreeState() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.FreeState
(
self — )

Getter for property: (bool) FreeState Returns the datum reference free state. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ FreeState() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.FreeState
(
self,

datumReferenceFreeState )

Setter for property: (bool) FreeState. 

Sets the datum reference free state

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ LeftBracket() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.LeftBracket
(
self — )

Getter for property: (bool) LeftBracket Returns the datum reference Left Bracket. 

Getter License requirements: None.

Created in NX2506.0.0 

Returns
bool 

## ◆ LeftBracket() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.LeftBracket
(
self,

datumReferenceLeftBracket )

Setter for property: (bool) LeftBracket. 

Sets the datum reference Left Bracket

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX2506.0.0 

## ◆ Letter() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.Letter
(
self — )

Getter for property: (str) Letter Returns the datum reference datum letter. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Letter() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.Letter
(
self,

datumReferenceDatum )

Setter for property: (str) Letter. 

Sets the datum reference datum letter

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ MajorDiameter() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.MajorDiameter
(
self — )

Getter for property: (bool) MajorDiameter Returns the datum reference Major Diameter. 

Getter License requirements: None.

Created in NX2406.0.0 

Returns
bool 

## ◆ MajorDiameter() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.MajorDiameter
(
self,

datumReferenceMajorDiameter )

Setter for property: (bool) MajorDiameter. 

Sets the datum reference Major Diameter

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX2406.0.0 

## ◆ MaterialCondition() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.MaterialCondition
(
self — )

Getter for property: (NXOpen.Annotations.DatumReferenceBuilder.DatumReferenceMaterialCondition) MaterialCondition Returns the datum reference material condition. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
DatumReferenceBuilder.DatumReferenceMaterialCondition 

## ◆ MaterialCondition() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.MaterialCondition
(
self,

materialCondition )

Setter for property: (NXOpen.Annotations.DatumReferenceBuilder.DatumReferenceMaterialCondition) MaterialCondition. 

Sets the datum reference material condition

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ MinorDiameter() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.MinorDiameter
(
self — )

Getter for property: (bool) MinorDiameter Returns the datum reference Minor Diameter. 

Getter License requirements: None.

Created in NX2406.0.0 

Returns
bool 

## ◆ MinorDiameter() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.MinorDiameter
(
self,

datumReferenceMinorDiameter )

Setter for property: (bool) MinorDiameter. 

Sets the datum reference Minor Diameter

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX2406.0.0 

## ◆ OrientationConstraint() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.OrientationConstraint
(
self — )

Getter for property: (bool) OrientationConstraint Returns the datum reference Orientation Constraint. 

Getter License requirements: None.

Created in NX2406.0.0 

Returns
bool 

## ◆ OrientationConstraint() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.OrientationConstraint
(
self,

datumReferenceOrientationConstraint )

Setter for property: (bool) OrientationConstraint. 

Sets the datum reference Orientation Constraint

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX2406.0.0 

## ◆ PitchDiameter() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.PitchDiameter
(
self — )

Getter for property: (bool) PitchDiameter Returns the datum reference Pitch Diameter. 

Getter License requirements: None.

Created in NX2406.0.0 

Returns
bool 

## ◆ PitchDiameter() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.PitchDiameter
(
self,

datumReferencePitchDiameter )

Setter for property: (bool) PitchDiameter. 

Sets the datum reference Pitch Diameter

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX2406.0.0 

## ◆ Projected() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.Projected
(
self — )

Getter for property: (bool) Projected Returns the datum reference projected. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
bool 

## ◆ Projected() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.Projected
(
self,

datumReferenceProjected )

Setter for property: (bool) Projected. 

Sets the datum reference projected

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX10.0.0 

## ◆ RightBracket() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.RightBracket
(
self — )

Getter for property: (bool) RightBracket Returns the datum reference Orientation Constraint. 

Getter License requirements: None.

Created in NX2506.0.0 

Returns
bool 

## ◆ RightBracket() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.RightBracket
(
self,

datumReferenceRightBracket )

Setter for property: (bool) RightBracket. 

Sets the datum reference Orientation Constraint

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX2506.0.0 

## ◆ SituationFeatureLine() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.SituationFeatureLine
(
self — )

Getter for property: (bool) SituationFeatureLine Returns the datum reference Situation Feature Line. 

Getter License requirements: None.

Created in NX2406.0.0 

Returns
bool 

## ◆ SituationFeatureLine() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.SituationFeatureLine
(
self,

datumReferenceSituationFeatureLine )

Setter for property: (bool) SituationFeatureLine. 

Sets the datum reference Situation Feature Line

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX2406.0.0 

## ◆ SituationFeaturePlane() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.SituationFeaturePlane
(
self — )

Getter for property: (bool) SituationFeaturePlane Returns the datum reference Situation Feature Plane. 

Getter License requirements: None.

Created in NX2406.0.0 

Returns
bool 

## ◆ SituationFeaturePlane() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.SituationFeaturePlane
(
self,

datumReferenceSituationFeaturePlane )

Setter for property: (bool) SituationFeaturePlane. 

Sets the datum reference Situation Feature Plane

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX2406.0.0 

## ◆ SituationFeaturePoint() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.SituationFeaturePoint
(
self — )

Getter for property: (bool) SituationFeaturePoint Returns the datum reference Situation Feature Point. 

Getter License requirements: None.

Created in NX2406.0.0 

Returns
bool 

## ◆ SituationFeaturePoint() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.SituationFeaturePoint
(
self,

datumReferenceSituationFeaturePoint )

Setter for property: (bool) SituationFeaturePoint. 

Sets the datum reference Situation Feature Point

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX2406.0.0 

## ◆ VariableDistance() [1/2]

NXOpen.Annotations.DatumReferenceBuilder.VariableDistance
(
self — )

Getter for property: (bool) VariableDistance Returns the datum reference Variable Distance. 

Getter License requirements: None.

Created in NX2406.0.0 

Returns
bool 

## ◆ VariableDistance() [2/2]

NXOpen.Annotations.DatumReferenceBuilder.VariableDistance
(
self,

datumReferenceVariableDistance )

Setter for property: (bool) VariableDistance. 

Sets the datum reference Variable Distance

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX2406.0.0 

## Member Data Documentation

## ◆ DatumReferenceBuilderDatumReferenceMaterialCondition

NXOpen.Annotations.DatumReferenceBuilder.DatumReferenceBuilderDatumReferenceMaterialCondition = DatumReferenceBuilder.DatumReferenceMaterialCondition

NXOpen.Annotations.DatumReferenceBuilderDatumReferenceMaterialCondition is an alias for NXOpen.Annotations.DatumReferenceBuilder.DatumReferenceMaterialCondition 

Copyright 2025 Siemens
