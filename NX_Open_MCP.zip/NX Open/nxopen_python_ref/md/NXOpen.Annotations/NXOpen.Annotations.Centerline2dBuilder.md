# NXOpen.Annotations.Centerline2dBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00141.html>

## Classes

class — Offset

the valid types of 2D Centerline offset method 

Enumerator — Comment

NotSet — no offset

DistanceMethod — offset distance method

ObjectMethod — offset object method

More...

class — Types

the valid types of 2D Centerline, applicable only for creation 

Enumerator — Comment

FromCurves — centerline from curves

ByPoints — centerline by points

More...

Copyright 2025 Siemens
