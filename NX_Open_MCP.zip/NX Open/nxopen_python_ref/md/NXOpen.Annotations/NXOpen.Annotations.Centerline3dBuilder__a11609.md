# NXOpen.Annotations.Centerline3dBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11609.html>

Builder for creating 3D Centerline. 
More...

Inheritance diagram for NXOpen.Annotations.Centerline3dBuilder:

## Public Member Functions

AlignedCenterlines (self)

Getter for property: (bool) AlignedCenterlines Returns the aligned centerlines, applicable only for creation. 

AlignedCenterlines (self, alignedCenterlines)

Setter for property: (bool) AlignedCenterlines. 

Inherit (self)

Getter for property: (NXOpen.SelectNXObject) Inherit Returns the inherit object. 

OffsetDistance (self)

Getter for property: (float) OffsetDistance Returns the offset distance, it is used only when aligned centerlines toggle is off. 

OffsetDistance (self, offsetDistance)

Setter for property: (float) OffsetDistance. 

OffsetMethod (self)

Getter for property: (NXOpen.Annotations.Centerline3dBuilder.Offset) OffsetMethod Returns the offset method , it is used only when aligned centerlines toggle is off. 

OffsetMethod (self, offsetMethod)

Setter for property: (NXOpen.Annotations.Centerline3dBuilder.Offset) OffsetMethod. 

OffsetObject (self)

Getter for property: (NXOpen.SelectNXObject) OffsetObject Returns the offset object, it is used only when aligned centerlines toggle is off. 

Public Member Functions inherited from NXOpen.Annotations.BaseCenterline3dBuilder

Face (self)

Getter for property: (NXOpen.SelectNXObjectList) Face Returns the face. 

ReferenceIndex (self)

Getter for property: (int) ReferenceIndex Returns the reference index. 

ReferenceIndex (self, referenceIndex)

Setter for property: (int) ReferenceIndex. 

Settings (self)

Getter for property: (NXOpen.Annotations.Centerline3dSettingsBuilder) Settings Returns the settings builder. 

Public Member Functions inherited from NXOpen.Annotations.CenterlineBuilder

AddEndExtensions (self, start, end)

Adds extensions only at ends. 

AddExtension (self, index, defaultValue)

Adds extension based on select object index. 

GetAllExtensions (self)

Returns all extensions. 

GetAllIndividualExtensions (self)

Returns individual extensions. 

GetEndExtensions (self)

Returns end extensions only. 

RemoveEndExtensions (self)

Removes extensions only at ends. 

RemoveExtension (self, index)

Removes extension based on select object index. 

ResetAllExtensions (self, defaultValue)

Reset all extensions by the supplied defaultValue. 

SetAllIndividualExtensions (self, extensionValues)

Sets all individual extensions. 

SetEndExtensions (self, start, end)

Modifies end extensions only. 

SetIndividualExtensions (self, index, value1, value2)

Modifies extensions based on select object index. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

Centerline3dBuilderOffset = Centerline3dBuilder.Offset

NXOpen.Annotations.Centerline3dBuilderOffset is an alias for NXOpen.Annotations.Centerline3dBuilder.Offset 

## Detailed Description

Builder for creating 3D Centerline. 

It creates or edits 3D Centerlines 

To create a new instance of this class, use NXOpen::Annotations::CenterlineCollection::CreateCenterline3dBuilder 

Default values. 

Property — Value

AlignedCenterlines 

false 

OffsetDistance 

0 

OffsetMethod 

None 

Created in NX6.0.0 

## Member Function Documentation

## ◆ AlignedCenterlines() [1/2]

NXOpen.Annotations.Centerline3dBuilder.AlignedCenterlines
(
self — )

Getter for property: (bool) AlignedCenterlines Returns the aligned centerlines, applicable only for creation. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ AlignedCenterlines() [2/2]

NXOpen.Annotations.Centerline3dBuilder.AlignedCenterlines
(
self,

alignedCenterlines )

Setter for property: (bool) AlignedCenterlines. 

Sets the aligned centerlines, applicable only for creation

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ Inherit()

NXOpen.Annotations.Centerline3dBuilder.Inherit
(
self — )

Getter for property: (NXOpen.SelectNXObject) Inherit Returns the inherit object. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ OffsetDistance() [1/2]

NXOpen.Annotations.Centerline3dBuilder.OffsetDistance
(
self — )

Getter for property: (float) OffsetDistance Returns the offset distance, it is used only when aligned centerlines toggle is off. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ OffsetDistance() [2/2]

NXOpen.Annotations.Centerline3dBuilder.OffsetDistance
(
self,

offsetDistance )

Setter for property: (float) OffsetDistance. 

Sets the offset distance, it is used only when aligned centerlines toggle is off

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ OffsetMethod() [1/2]

NXOpen.Annotations.Centerline3dBuilder.OffsetMethod
(
self — )

Getter for property: (NXOpen.Annotations.Centerline3dBuilder.Offset) OffsetMethod Returns the offset method , it is used only when aligned centerlines toggle is off. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
Centerline3dBuilder.Offset 

## ◆ OffsetMethod() [2/2]

NXOpen.Annotations.Centerline3dBuilder.OffsetMethod
(
self,

offsetMethod )

Setter for property: (NXOpen.Annotations.Centerline3dBuilder.Offset) OffsetMethod. 

Sets the offset method , it is used only when aligned centerlines toggle is off

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ OffsetObject()

NXOpen.Annotations.Centerline3dBuilder.OffsetObject
(
self — )

Getter for property: (NXOpen.SelectNXObject) OffsetObject Returns the offset object, it is used only when aligned centerlines toggle is off. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectNXObject 

## Member Data Documentation

## ◆ Centerline3dBuilderOffset

NXOpen.Annotations.Centerline3dBuilder.Centerline3dBuilderOffset = Centerline3dBuilder.Offset

NXOpen.Annotations.Centerline3dBuilderOffset is an alias for NXOpen.Annotations.Centerline3dBuilder.Offset 

Copyright 2025 Siemens
