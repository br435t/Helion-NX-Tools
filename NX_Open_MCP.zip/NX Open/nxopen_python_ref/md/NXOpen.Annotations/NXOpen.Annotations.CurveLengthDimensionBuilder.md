# NXOpen.Annotations.CurveLengthDimensionBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11777.html>

Represents a NXOpen::Annotations::ArcLengthDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateCurveLengthDimensionBuilder 

More...

Inheritance diagram for NXOpen.Annotations.CurveLengthDimensionBuilder:

## Public Member Functions

ForeshorteningSymbol (self)

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Public Member Functions inherited from NXOpen.Annotations.BaseCurveLengthDimensionBuilder

AppendedText (self)

Getter for property: (NXOpen.Annotations.AppendedTextBuilder) AppendedText Returns the appended text. 

FirstAssociativity (self)

Getter for property: (NXOpen.SelectDisplayableObject) FirstAssociativity Returns the first associativity. 

Inherit (self)

Getter for property: (NXOpen.Annotations.SelectDimension) Inherit Returns the inherit. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::ArcLengthDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateCurveLengthDimensionBuilder 

Created in NX9.0.0 

## Member Function Documentation

## ◆ ForeshorteningSymbol()

NXOpen.Annotations.CurveLengthDimensionBuilder.ForeshorteningSymbol
(
self — )

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
ForeshorteningSymbolBuilder 

Copyright 2025 Siemens
