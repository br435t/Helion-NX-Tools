# NXOpen.Annotations.DraftingSurfaceFinishBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12069.html>

Represents a NXOpen::Annotations::DraftingSurfaceFinish builder 

To create a new instance of this class, use NXOpen::Annotations::DraftingSurfaceFinishCollection::CreateDraftingSurfaceFinishBuilder 

More...

Inheritance diagram for NXOpen.Annotations.DraftingSurfaceFinishBuilder:

## Public Member Functions

A1 (self)

Getter for property: (str) A1 Returns the a1. 

A1 (self, a1)

Setter for property: (str) A1. 

A2 (self)

Getter for property: (str) A2 Returns the a2. 

A2 (self, a2)

Setter for property: (str) A2. 

Angle (self)

Getter for property: (float) Angle Returns the angle. 

Angle (self, angle)

Setter for property: (float) Angle. 

B (self)

Getter for property: (str) B Returns the b. 

B (self, b)

Setter for property: (str) B. 

C (self)

Getter for property: (str) C Returns the c. 

C (self, c)

Setter for property: (str) C. 

D (self)

Getter for property: (str) D Returns the d. 

D (self, d)

Setter for property: (str) D. 

E (self)

Getter for property: (str) E Returns the e. 

E (self, e)

Setter for property: (str) E. 

F1 (self)

Getter for property: (str) F1 Returns the f1. 

F1 (self, f1)

Setter for property: (str) F1. 

F2 (self)

Getter for property: (str) F2 Returns the f2. 

F2 (self, f2)

Setter for property: (str) F2. 

Finish (self)

Getter for property: (NXOpen.Annotations.DraftingSurfaceFinishBuilder.FinishType) Finish Returns the finish. 

Finish (self, finish)

Setter for property: (NXOpen.Annotations.DraftingSurfaceFinishBuilder.FinishType) Finish. 

ForeshorteningSymbol (self)

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

InheritFrom (self, inheritTag)

The drafting surface finish is inherited form existing drafting surface finish. 

InvertSymbol (self)

Getter for property: (bool) InvertSymbol Returns the invert symbol. 

InvertSymbol (self, invertSymbol)

Setter for property: (bool) InvertSymbol. 

InvertText (self)

Getter for property: (bool) InvertText Returns the invert Text. 

InvertText (self, invertText)

Setter for property: (bool) InvertText. 

LowerTolerance (self)

Getter for property: (float) LowerTolerance Returns the lower tolerance applicable for all the tolerance types other than Bilateral. 

LowerTolerance (self, lowerTolerance)

Setter for property: (float) LowerTolerance. 

Parantheses (self)

Getter for property: (NXOpen.Annotations.BaseSurfaceFinishBuilder.ParanthesesType) Parantheses Returns the parantheses. 

Parantheses (self, paranthesesType)

Setter for property: (NXOpen.Annotations.BaseSurfaceFinishBuilder.ParanthesesType) Parantheses. 

Parentheses (self)

Getter for property: (NXOpen.Annotations.BaseSurfaceFinishBuilder.ParenthesesType) Parentheses Returns the parentheses. 

Parentheses (self, parenthesesType)

Setter for property: (NXOpen.Annotations.BaseSurfaceFinishBuilder.ParenthesesType) Parentheses. 

SingleRoughnessValue (self)

Getter for property: (bool) SingleRoughnessValue Returns the single roughness value. 

SingleRoughnessValue (self, singleRoughnessValue)

Setter for property: (bool) SingleRoughnessValue. 

Tolerance (self)

Getter for property: (float) Tolerance Returns the tolerance in case of bilateral tolerance type otherwise upper tolerance. 

Tolerance (self, tolerance)

Setter for property: (float) Tolerance. 

ToleranceType (self)

Getter for property: (NXOpen.Annotations.BaseSurfaceFinishBuilder.ToleranceOption) ToleranceType Returns the tolerance type applicable only for all the 3 cases of finish type where Material Removal Required. 

ToleranceType (self, toleranceType)

Setter for property: (NXOpen.Annotations.BaseSurfaceFinishBuilder.ToleranceOption) ToleranceType. 

Public Member Functions inherited from NXOpen.Annotations.PmiAttributeBuilder

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the NXOpen::Annotations::AssociatedObjectsBuilder for the annotation. 

Attribute (self)

Getter for property: (NXOpen.Annotations.Pmi) Attribute Returns the NXOpen::Annotations::Pmi for this annotation. 

Attribute (self, attribute)

Setter for property: (NXOpen.Annotations.Pmi) Attribute. 

BusinessModifier (self)

Getter for property: (NXOpen.NXObject) BusinessModifier Returns the business modifier. 

BusinessModifier (self, businessModifier)

Setter for property: (NXOpen.NXObject) BusinessModifier. 

GetAttributeValues (self)

Returns the attribute values. 

KnowledgeFusionClassName (self)

Getter for property: (str) KnowledgeFusionClassName Returns the knowledge fusion class name file, the default class is UG provided pmi KF class. 

KnowledgeFusionClassName (self, knowledgeFusionClassName)

Setter for property: (str) KnowledgeFusionClassName. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the NXOpen::Annotations::OriginBuilder for the annotation. 

SetAttributeValues (self, attributeValues)

Sets the attribute values. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the NXOpen::Annotations::StyleBuilder for the annotation. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

DraftingSurfaceFinishBuilderFinishType = DraftingSurfaceFinishBuilder.FinishType

NXOpen.Annotations.DraftingSurfaceFinishBuilderFinishType is an alias for NXOpen.Annotations.DraftingSurfaceFinishBuilder.FinishType 

Public Attributes inherited from NXOpen.Annotations.BaseSurfaceFinishBuilder

BaseSurfaceFinishBuilderParanthesesType = BaseSurfaceFinishBuilder.ParanthesesType

NXOpen.Annotations.BaseSurfaceFinishBuilderParanthesesType is an alias for NXOpen.Annotations.BaseSurfaceFinishBuilder.ParanthesesType 

BaseSurfaceFinishBuilderParenthesesType = BaseSurfaceFinishBuilder.ParenthesesType

NXOpen.Annotations.BaseSurfaceFinishBuilderParenthesesType is an alias for NXOpen.Annotations.BaseSurfaceFinishBuilder.ParenthesesType 

BaseSurfaceFinishBuilderToleranceOption = BaseSurfaceFinishBuilder.ToleranceOption

NXOpen.Annotations.BaseSurfaceFinishBuilderToleranceOption is an alias for NXOpen.Annotations.BaseSurfaceFinishBuilder.ToleranceOption 

## Detailed Description

Represents a NXOpen::Annotations::DraftingSurfaceFinish builder 

To create a new instance of this class, use NXOpen::Annotations::DraftingSurfaceFinishCollection::CreateDraftingSurfaceFinishBuilder 

Created in NX7.5.0 

## Member Function Documentation

## ◆ A1() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.A1
(
self — )

Getter for property: (str) A1 Returns the a1. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
str 

## ◆ A1() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.A1
(
self,

a1 )

Setter for property: (str) A1. 

Sets the a1

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ A2() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.A2
(
self — )

Getter for property: (str) A2 Returns the a2. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
str 

## ◆ A2() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.A2
(
self,

a2 )

Setter for property: (str) A2. 

Sets the a2

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ Angle() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.Angle
(
self — )

Getter for property: (float) Angle Returns the angle. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
float 

## ◆ Angle() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.Angle
(
self,

angle )

Setter for property: (float) Angle. 

Sets the angle

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ B() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.B
(
self — )

Getter for property: (str) B Returns the b. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
str 

## ◆ B() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.B
(
self,

b )

Setter for property: (str) B. 

Sets the b

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ C() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.C
(
self — )

Getter for property: (str) C Returns the c. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
str 

## ◆ C() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.C
(
self,

c )

Setter for property: (str) C. 

Sets the c

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ D() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.D
(
self — )

Getter for property: (str) D Returns the d. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
str 

## ◆ D() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.D
(
self,

d )

Setter for property: (str) D. 

Sets the d

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ E() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.E
(
self — )

Getter for property: (str) E Returns the e. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
str 

## ◆ E() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.E
(
self,

e )

Setter for property: (str) E. 

Sets the e

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ F1() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.F1
(
self — )

Getter for property: (str) F1 Returns the f1. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
str 

## ◆ F1() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.F1
(
self,

f1 )

Setter for property: (str) F1. 

Sets the f1

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ F2() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.F2
(
self — )

Getter for property: (str) F2 Returns the f2. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
str 

## ◆ F2() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.F2
(
self,

f2 )

Setter for property: (str) F2. 

Sets the f2

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ Finish() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.Finish
(
self — )

Getter for property: (NXOpen.Annotations.DraftingSurfaceFinishBuilder.FinishType) Finish Returns the finish. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
DraftingSurfaceFinishBuilder.FinishType 

## ◆ Finish() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.Finish
(
self,

finish )

Setter for property: (NXOpen.Annotations.DraftingSurfaceFinishBuilder.FinishType) Finish. 

Sets the finish

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ ForeshorteningSymbol()

NXOpen.Annotations.DraftingSurfaceFinishBuilder.ForeshorteningSymbol
(
self — )

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
ForeshorteningSymbolBuilder 

## ◆ InheritFrom()

NXOpen.Annotations.DraftingSurfaceFinishBuilder.InheritFrom
(
self,

inheritTag )

The drafting surface finish is inherited form existing drafting surface finish. 

Created in NX8.5.0 

License requirements: None.

Parameters

inheritTag — (NXOpen.Annotations.BaseSurfaceFinish)

## ◆ InvertSymbol() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.InvertSymbol
(
self — )

Getter for property: (bool) InvertSymbol Returns the invert symbol. 

Getter License requirements: None.

Created in NX7.5.2 

Returns
bool 

## ◆ InvertSymbol() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.InvertSymbol
(
self,

invertSymbol )

Setter for property: (bool) InvertSymbol. 

Sets the invert symbol

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.2 

## ◆ InvertText() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.InvertText
(
self — )

Getter for property: (bool) InvertText Returns the invert Text. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
bool 

## ◆ InvertText() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.InvertText
(
self,

invertText )

Setter for property: (bool) InvertText. 

Sets the invert Text

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ LowerTolerance() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.LowerTolerance
(
self — )

Getter for property: (float) LowerTolerance Returns the lower tolerance applicable for all the tolerance types other than Bilateral. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
float 

## ◆ LowerTolerance() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.LowerTolerance
(
self,

lowerTolerance )

Setter for property: (float) LowerTolerance. 

Sets the lower tolerance applicable for all the tolerance types other than Bilateral

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ Parantheses() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.Parantheses
(
self — )

Getter for property: (NXOpen.Annotations.BaseSurfaceFinishBuilder.ParanthesesType) Parantheses Returns the parantheses. 

This method is deprecated.

Getter License requirements: None.

Created in NX7.5.0 

Deprecated
Deprecated in NX8.0.0. Use NXOpen::Annotations::DraftingSurfaceFinishBuilder::Parentheses instead. 

Returns
BaseSurfaceFinishBuilder.ParanthesesType 

## ◆ Parantheses() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.Parantheses
(
self,

paranthesesType )

Setter for property: (NXOpen.Annotations.BaseSurfaceFinishBuilder.ParanthesesType) Parantheses. 

Sets the parantheses. This method is deprecated.

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

Deprecated
Deprecated in NX8.0.0. Use NXOpen::Annotations::DraftingSurfaceFinishBuilder::SetParentheses instead. 

## ◆ Parentheses() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.Parentheses
(
self — )

Getter for property: (NXOpen.Annotations.BaseSurfaceFinishBuilder.ParenthesesType) Parentheses Returns the parentheses. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
BaseSurfaceFinishBuilder.ParenthesesType 

## ◆ Parentheses() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.Parentheses
(
self,

parenthesesType )

Setter for property: (NXOpen.Annotations.BaseSurfaceFinishBuilder.ParenthesesType) Parentheses. 

Sets the parentheses

Setter License requirements: drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ SingleRoughnessValue() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.SingleRoughnessValue
(
self — )

Getter for property: (bool) SingleRoughnessValue Returns the single roughness value. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
bool 

## ◆ SingleRoughnessValue() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.SingleRoughnessValue
(
self,

singleRoughnessValue )

Setter for property: (bool) SingleRoughnessValue. 

Sets the single roughness value

Setter License requirements: drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ Tolerance() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.Tolerance
(
self — )

Getter for property: (float) Tolerance Returns the tolerance in case of bilateral tolerance type otherwise upper tolerance. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
float 

## ◆ Tolerance() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.Tolerance
(
self,

tolerance )

Setter for property: (float) Tolerance. 

Sets the tolerance in case of bilateral tolerance type otherwise upper tolerance

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ ToleranceType() [1/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.ToleranceType
(
self — )

Getter for property: (NXOpen.Annotations.BaseSurfaceFinishBuilder.ToleranceOption) ToleranceType Returns the tolerance type applicable only for all the 3 cases of finish type where Material Removal Required. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
BaseSurfaceFinishBuilder.ToleranceOption 

## ◆ ToleranceType() [2/2]

NXOpen.Annotations.DraftingSurfaceFinishBuilder.ToleranceType
(
self,

toleranceType )

Setter for property: (NXOpen.Annotations.BaseSurfaceFinishBuilder.ToleranceOption) ToleranceType. 

Sets the tolerance type applicable only for all the 3 cases of finish type where Material Removal Required

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## Member Data Documentation

## ◆ DraftingSurfaceFinishBuilderFinishType

NXOpen.Annotations.DraftingSurfaceFinishBuilder.DraftingSurfaceFinishBuilderFinishType = DraftingSurfaceFinishBuilder.FinishType

NXOpen.Annotations.DraftingSurfaceFinishBuilderFinishType is an alias for NXOpen.Annotations.DraftingSurfaceFinishBuilder.FinishType 

Copyright 2025 Siemens
