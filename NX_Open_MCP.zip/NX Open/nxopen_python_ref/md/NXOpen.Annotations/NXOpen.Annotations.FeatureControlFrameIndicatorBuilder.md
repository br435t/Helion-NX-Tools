# NXOpen.Annotations.FeatureControlFrameIndicatorBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00160.html>

## Classes

class — FcfIndicatorCharacteristic

Specifies the characteristic of the FCF indicator 

Enumerator — Comment

Parallel

Perpendicular

Angular

Including

Runout

More...

class — FcfIndicatorDirection

Specifies the direction of the FCF indicator 

Enumerator — Comment

After

Before

More...

class — FcfIndicatorType

Specifies the type of FCF indicator 

Enumerator — Comment

IntersectionPlane

OrientationPlane

CollectionPlane

DirectionFeature

More...

Copyright 2025 Siemens
