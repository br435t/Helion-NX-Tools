# NXOpen.Annotations.PmiAttributeValueNumberBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13273.html>

Represents a NXOpen::Annotations::PmiAttributeValueNumber builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiAttributeValueNumberBuilder 

More...

Inheritance diagram for NXOpen.Annotations.PmiAttributeValueNumberBuilder:

## Public Member Functions

NumberValue (self)

Getter for property: (float) NumberValue Returns the number_value. 

NumberValue (self, numberValue)

Setter for property: (float) NumberValue. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::PmiAttributeValueNumber builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiAttributeValueNumberBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ NumberValue() [1/2]

NXOpen.Annotations.PmiAttributeValueNumberBuilder.NumberValue
(
self — )

Getter for property: (float) NumberValue Returns the number_value. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ NumberValue() [2/2]

NXOpen.Annotations.PmiAttributeValueNumberBuilder.NumberValue
(
self,

numberValue )

Setter for property: (float) NumberValue. 

Sets the number_value

Setter License requirements: None.

Created in NX6.0.0 

Copyright 2025 Siemens
