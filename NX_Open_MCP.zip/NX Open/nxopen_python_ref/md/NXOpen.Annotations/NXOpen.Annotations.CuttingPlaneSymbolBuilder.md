# NXOpen.Annotations.CuttingPlaneSymbolBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00145.html>

## Classes

class — ArrowDirectionOption

Represents position of the arrow direction relative to cutting plane 

Enumerator — Comment

Towards — The Direction of the PMI Cutting Plane Symbol Arrow Towards Plane.

More...

class — TextPlaneRelativeArrow

Represents position of the text relative to the arrow option 

Enumerator — Comment

Parallel — The Plane of the PMI Cutting Plane Symbol Text is Parallel to its Arrow.

More...

class — ViewNameFormatOption

Represents whether the view name is derived from the PMI cutting plane symbol text. More...

Copyright 2025 Siemens
