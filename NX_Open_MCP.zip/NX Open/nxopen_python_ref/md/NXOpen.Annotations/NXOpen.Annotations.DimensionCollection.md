# NXOpen.Annotations.DimensionCollection Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11921.html>

Represents a collection of NXOpen::Annotations::Dimension objects 

This is an collection class. 
More...

Inheritance diagram for NXOpen.Annotations.DimensionCollection:

## Public Member Functions

CreateAngularDimensionBuilder (self, angularDimension)

Creates a NXOpen::Annotations::AngularDimensionBuilder. 

CreateAppendedTextEditorBuilder (self, dimension)

Creates a NXOpen::Annotations::AppendedTextEditorBuilder. 

CreateArcLengthDimension (self, dimension_data, origin)

Creates an arc length dimension. 

CreateChamferDimension (self, dimension_data, origin)

Creates a chamfer dimension. 

CreateChamferDimensionBuilder (self, chamferDimension)

Creates a NXOpen::Annotations::ChamferDimensionBuilder. 

CreateConcentricCircleDimension (self, dimension_data, origin)

Creates a concentric circle dimension. 

CreateCurveLengthDimensionBuilder (self, curveLengthDimension)

Creates a NXOpen::Annotations::CurveLengthDimensionBuilder. 

CreateCylindricalDimension (self, dimension_data, origin)

Creates a cylindrical dimension. 

CreateDiameterDimension (self, dimension_data, origin)

Creates a diameter dimension. 

CreateFoldedRadiusDimension (self, dimension_data, origin)

Creates a folded radius dimension. 

CreateGeodesicDimensionBuilder (self, dimension)

Creates a NXOpen::Annotations::GeodesicDimensionBuilder. 

CreateHoleCalloutDimensionBuilder (self, holecalloutDimension)

Creates a NXOpen::Annotations::HoleCalloutDimensionBuilder. 

CreateHoleDimension (self, dimension_data, origin)

Creates a hole dimension. 

CreateHorizontalDimension (self, dimension_data, origin)

Creates a horizontal dimension. 

CreateHorizontalOrdinateAutoDimension (self, dimension_data, origin, allow_duplicate, reposition_dim)

Creates a horizontal ordinate automatic dimension. 

CreateHorizontalOrdinateDimension (self, dimension_data, origin)

Creates a horizontal ordinate dimension. 

CreateLinearDimensionBuilder (self, linearDimension)

Creates a NXOpen::Annotations::LinearDimensionBuilder. 

CreateMajorAngularDimension (self, dimension_data, origin)

Creates a major angular dimension. 

CreateMajorAngularDimensionBuilder (self, angularDimension)

Creates a NXOpen::Annotations::AngularDimensionBuilder. 

CreateMinorAngularDimension (self, dimension_data, origin)

Creates a minor angular dimension. 

CreateMinorAngularDimensionBuilder (self, angularDimension)

Creates a NXOpen::Annotations::AngularDimensionBuilder. 

CreateOrdinateDimensionBuilder (self, ordinateDimension)

Creates a NXOpen::Annotations::OrdinateDimensionBuilder. 

CreateOrdinateOriginDimension (self, dimension_data, origin)

Creates an ordinate origin dimension. 

CreateParallelDimension (self, dimension_data, origin)

Creates a parallel dimension. 

CreatePerpendicularDimension (self, dimension_data, origin)

Creates a perpendicular dimension. 

CreatePmiAngularDimensionBuilder (self, angularDimension)

Creates a NXOpen::Annotations::PmiAngularDimensionBuilder. 

CreatePmiArcLengthDimension (self, dimension_data, pmi_data, annotation_plane, origin)

Creates a PMI arc length dimension. 

CreatePmiChamferDimension (self, dimension_data, pmi_data, annotation_plane, origin)

Creates a PMI chamfer dimnension. 

CreatePmiChamferDimensionBuilder (self, chamferDimension)

Creates a NXOpen::Annotations::PmiChamferDimensionBuilder. 

CreatePmiConcentricCircleDimension (self, dimension_data, pmi_data, annotation_plane, origin)

Creates a PMI concentric circle dimension. 

CreatePmiCurveLengthDimensionBuilder (self, curveLengthDimension)

Creates a NXOpen::Annotations::PmiCurveLengthDimensionBuilder. 

CreatePmiCylindricalDimension (self, dimension_data, pmi_data, annotation_plane, origin)

Creates a PMI cylindrical dimension. 

CreatePmiDiameterDimension (self, dimension_data, pmi_data, annotation_plane, origin)

Creates a PMI diameter dimension. 

CreatePmiFoldedRadiusDimension (self, dimension_data, pmi_data, annotation_plane, origin)

Creates a PMI folded radius dimension. 

CreatePmiHoleCalloutDimensionBuilder (self, measurementDimension)

Creates a NXOpen::Annotations::PmiHoleCalloutDimensionBuilder. 

CreatePmiHoleDimension (self, dimension_data, pmi_data, annotation_plane, origin)

Creates a PMI hole dimension. 

CreatePmiHorizontalDimension (self, dimension_data, pmi_data, annotation_plane, origin)

Creates a PMI horizontal dimension. 

CreatePmiHorizontalOrdinateAutoDimension (self, dimension_data, pmi_data, annotation_plane, origin, allow_duplicate, reposition_dim)

Creates a PMI horizontal ordinate automatic dimension. 

CreatePmiHorizontalOrdinateDimension (self, dimension_data, pmi_data, annotation_plane, origin)

Creates a PMI horizontal ordinate dimension. 

CreatePmiLinearDimensionBuilder (self, linearDimension)

Creates a NXOpen::Annotations::PmiLinearDimensionBuilder. 

CreatePmiMajorAngularDimension (self, dimension_data, pmi_data, annotation_plane, origin)

Creates a PMI major angular dimension. 

CreatePmiMajorAngularDimensionBuilder (self, angularDimension)

Creates a NXOpen::Annotations::PmiMajorAngularDimensionBuilder. 

CreatePmiMinorAngularDimension (self, dimension_data, pmi_data, annotation_plane, origin)

Creates a PMI minor angular dimension. 

CreatePmiMinorAngularDimensionBuilder (self, angularDimension)

Creates a NXOpen::Annotations::PmiMinorAngularDimensionBuilder. 

CreatePmiOrdinateDimensionBuilder (self, ordinateDimension)

Creates a NXOpen::Annotations::PmiOrdinateDimensionBuilder. 

CreatePmiOrdinateOriginDimension (self, dimension_data, pmi_data, annotation_plane, origin)

Creates a PMI ordinate origin dimension. 

CreatePmiParallelDimension (self, dimension_data, pmi_data, annotation_plane, origin)

Creates a PMI parallel dimension. 

CreatePmiPerpendicularDimension (self, dimension_data, pmi_data, annotation_plane, origin)

Creates a PMI perpendicular dimension. 

CreatePmiRadialDimensionBuilder (self, radialDimension)

Creates a NXOpen::Annotations::PmiRadialDimensionBuilder. 

CreatePmiRadiusDimension (self, dimension_data, radius_type, pmi_data, annotation_plane, origin)

Creates a PMI radius dimension. 

CreatePmiRapidDimensionBuilder (self, rapidDimension)

Creates a NXOpen::Annotations::PmiRapidDimensionBuilder. 

CreatePmiThicknessDimensionBuilder (self, thicknessDimension)

Creates a NXOpen::Annotations::PmiThicknessDimensionBuilder. 

CreatePmiVerticalDimension (self, dimension_data, pmi_data, annotation_plane, origin)

Creates a PMI vertical dimension. 

CreatePmiVerticalOrdinateAutoDimension (self, dimension_data, pmi_data, annotation_plane, origin, allow_duplicate, reposition_dim)

Creates a PMI vertical ordinate automatic dimension. 

CreatePmiVerticalOrdinateDimension (self, dimension_data, pmi_data, annotation_plane, origin)

Creates a PMI vertical ordinate dimension. 

CreateRadialDimensionBuilder (self, radialDimension)

Creates a NXOpen::Annotations::RadialDimensionBuilder. 

CreateRadiusDimension (self, dimension_data, radius_type, origin)

Creates a radius dimension. 

CreateRapidDimensionBuilder (self, rapidDimension)

Creates a NXOpen::Annotations::RapidDimensionBuilder. 

CreateThicknessDimensionBuilder (self, thicknessDimension)

Creates a NXOpen::Annotations::ThicknessDimensionBuilder. 

CreateVerticalDimension (self, dimension_data, origin)

Creates a vertical dimension. 

CreateVerticalOrdinateAutoDimension (self, dimension_data, origin, allow_duplicate, reposition_dim)

Creates a vertical ordinate automatic dimension. 

CreateVerticalOrdinateDimension (self, dimension_data, origin)

Creates a vertical ordinate dimension. 

## Detailed Description

Represents a collection of NXOpen::Annotations::Dimension objects 

This is an collection class. 

Created in NX3.0.0 

## Member Function Documentation

## ◆ CreateAngularDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreateAngularDimensionBuilder
(
self,

angularDimension )

Creates a NXOpen::Annotations::AngularDimensionBuilder. 

Returns
builder (NXOpen.Annotations.AngularDimensionBuilder): the Angular dimension builder .

Created in NX9.0.0 

License requirements: drafting ("DRAFTING")

Parameters

angularDimension — (NXOpen.Annotations.BaseAngularDimension) the Drafting or PMI inherited angular dimension to be edited, if NULL, then create an angular dimension

## ◆ CreateAppendedTextEditorBuilder()

NXOpen.Annotations.DimensionCollection.CreateAppendedTextEditorBuilder
(
self,

dimension )

Creates a NXOpen::Annotations::AppendedTextEditorBuilder. 

Returns
builder (NXOpen.Annotations.AppendedTextEditorBuilder): .

Created in NX9.0.0 

License requirements: None.

Parameters

dimension — (NXOpen.Annotations.Dimension) NXOpen::Annotations::Dimension to be edited

## ◆ CreateArcLengthDimension()

NXOpen.Annotations.DimensionCollection.CreateArcLengthDimension
(
self,

dimension_data,

origin )

Creates an arc length dimension. 

Returns
dimension (NXOpen.Annotations.ArcLengthDimension): New arc length dimension .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreateChamferDimension()

NXOpen.Annotations.DimensionCollection.CreateChamferDimension
(
self,

dimension_data,

origin )

Creates a chamfer dimension. 

Returns
dimension (NXOpen.Annotations.ChamferDimension): New chamfer dimension .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreateChamferDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreateChamferDimensionBuilder
(
self,

chamferDimension )

Creates a NXOpen::Annotations::ChamferDimensionBuilder. 

Returns
builder (NXOpen.Annotations.ChamferDimensionBuilder): the chamfer dimension builder .

Created in NX9.0.0 

License requirements: drafting ("DRAFTING")

Parameters

chamferDimension — (NXOpen.Annotations.BaseChamferDimension) the Drafting or PMI Inherited PMI chamfer dimension to be edited, if NULL, then create an chamfer dimension

## ◆ CreateConcentricCircleDimension()

NXOpen.Annotations.DimensionCollection.CreateConcentricCircleDimension
(
self,

dimension_data,

origin )

Creates a concentric circle dimension. 

Returns
dimension (NXOpen.Annotations.ConcentricCircleDimension): New concentric circle dimension .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreateCurveLengthDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreateCurveLengthDimensionBuilder
(
self,

curveLengthDimension )

Creates a NXOpen::Annotations::CurveLengthDimensionBuilder. 

Returns
builder (NXOpen.Annotations.CurveLengthDimensionBuilder): the curve length dimension builder .

Created in NX9.0.0 

License requirements: drafting ("DRAFTING")

Parameters

curveLengthDimension — (NXOpen.Annotations.BaseArcLengthDimension) the Drafting or Inherited PMI curve length dimension to be edited, if NULL, then create an curve length dimension

## ◆ CreateCylindricalDimension()

NXOpen.Annotations.DimensionCollection.CreateCylindricalDimension
(
self,

dimension_data,

origin )

Creates a cylindrical dimension. 

Returns
dimension (NXOpen.Annotations.CylindricalDimension): New cylindrical dimension .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreateDiameterDimension()

NXOpen.Annotations.DimensionCollection.CreateDiameterDimension
(
self,

dimension_data,

origin )

Creates a diameter dimension. 

Returns
dimension (NXOpen.Annotations.DiameterDimension): New diameter dimension .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreateFoldedRadiusDimension()

NXOpen.Annotations.DimensionCollection.CreateFoldedRadiusDimension
(
self,

dimension_data,

origin )

Creates a folded radius dimension. 

Returns
dimension (NXOpen.Annotations.FoldedRadiusDimension): New folded radius dimension .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreateGeodesicDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreateGeodesicDimensionBuilder
(
self,

dimension )

Creates a NXOpen::Annotations::GeodesicDimensionBuilder. 

Returns
builder (NXOpen.Annotations.GeodesicDimensionBuilder): the geodesic dimension builder .

Created in NX10.0.0 

License requirements: solid_modeling ("SOLIDS MODELING")

Parameters

dimension — (NXOpen.Annotations.Dimension) NXOpen::Annotations::Dimension to be edited

## ◆ CreateHoleCalloutDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreateHoleCalloutDimensionBuilder
(
self,

holecalloutDimension )

Creates a NXOpen::Annotations::HoleCalloutDimensionBuilder. 

Returns
builder (NXOpen.Annotations.HoleCalloutDimensionBuilder): the hole callout dimension builder .

Created in NX2206.0.0 

License requirements: drafting ("DRAFTING")

Parameters

holecalloutDimension — (NXOpen.Annotations.Dimension) the hole callout dimension to be edited, if NULL, then create a hole callout dimension

## ◆ CreateHoleDimension()

NXOpen.Annotations.DimensionCollection.CreateHoleDimension
(
self,

dimension_data,

origin )

Creates a hole dimension. 

Returns
dimension (NXOpen.Annotations.HoleDimension): New hole dimension .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreateHorizontalDimension()

NXOpen.Annotations.DimensionCollection.CreateHorizontalDimension
(
self,

dimension_data,

origin )

Creates a horizontal dimension. 

Returns
dimension (NXOpen.Annotations.HorizontalDimension): New horizontal dimension .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreateHorizontalOrdinateAutoDimension()

NXOpen.Annotations.DimensionCollection.CreateHorizontalOrdinateAutoDimension
(
self,

dimension_data,

origin,

allow_duplicate,

reposition_dim )

Creates a horizontal ordinate automatic dimension. 

Created in NX5.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

allow_duplicate — (bool) TRUE - Allow dimensions with duplicate values

reposition_dim — (bool) TRUE - Reposition existing dimensions

## ◆ CreateHorizontalOrdinateDimension()

NXOpen.Annotations.DimensionCollection.CreateHorizontalOrdinateDimension
(
self,

dimension_data,

origin )

Creates a horizontal ordinate dimension. 

Returns
dimension (NXOpen.Annotations.HorizontalOrdinateDimension): New horizontal ordinate dimension .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreateLinearDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreateLinearDimensionBuilder
(
self,

linearDimension )

Creates a NXOpen::Annotations::LinearDimensionBuilder. 

Returns
builder (NXOpen.Annotations.LinearDimensionBuilder): the linear dimension builder .

Created in NX9.0.0 

License requirements: drafting ("DRAFTING")

Parameters

linearDimension — (NXOpen.Annotations.Dimension) the Drafting or PMI linear dimension to be edited, if NULL, then create an linear dimension

## ◆ CreateMajorAngularDimension()

NXOpen.Annotations.DimensionCollection.CreateMajorAngularDimension
(
self,

dimension_data,

origin )

Creates a major angular dimension. 

Returns
dimension (NXOpen.Annotations.MajorAngularDimension): New major angular dimension .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreateMajorAngularDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreateMajorAngularDimensionBuilder
(
self,

angularDimension )

Creates a NXOpen::Annotations::AngularDimensionBuilder. 

Returns
builder (NXOpen.Annotations.MajorAngularDimensionBuilder): the Angular dimension builder .

Created in NX9.0.0 

License requirements: drafting ("DRAFTING")

Parameters

angularDimension — (NXOpen.Annotations.BaseAngularDimension) the Drafting or PMI inherited angular dimension to be edited, if NULL, then create an angular dimension

## ◆ CreateMinorAngularDimension()

NXOpen.Annotations.DimensionCollection.CreateMinorAngularDimension
(
self,

dimension_data,

origin )

Creates a minor angular dimension. 

Returns
dimension (NXOpen.Annotations.MinorAngularDimension): New minor angular dimension .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreateMinorAngularDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreateMinorAngularDimensionBuilder
(
self,

angularDimension )

Creates a NXOpen::Annotations::AngularDimensionBuilder. 

Returns
builder (NXOpen.Annotations.MinorAngularDimensionBuilder): the Angular dimension builder .

Created in NX9.0.0 

License requirements: drafting ("DRAFTING")

Parameters

angularDimension — (NXOpen.Annotations.BaseAngularDimension) the Drafting or PMI inherited angular dimension to be edited, if NULL, then create an angular dimension

## ◆ CreateOrdinateDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreateOrdinateDimensionBuilder
(
self,

ordinateDimension )

Creates a NXOpen::Annotations::OrdinateDimensionBuilder. 

Returns
builder (NXOpen.Annotations.OrdinateDimensionBuilder): the ordinate dimension builder .

Created in NX9.0.0 

License requirements: drafting ("DRAFTING")

Parameters

ordinateDimension — (NXOpen.Annotations.OrdinateDimension) the Drafting or PMI inherited ordinate dimension to be edited, if NULL, then create an ordinate dimension

## ◆ CreateOrdinateOriginDimension()

NXOpen.Annotations.DimensionCollection.CreateOrdinateOriginDimension
(
self,

dimension_data,

origin )

Creates an ordinate origin dimension. 

Returns
dimension (NXOpen.Annotations.OrdinateOriginDimension): New ordinate origin dimension .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreateParallelDimension()

NXOpen.Annotations.DimensionCollection.CreateParallelDimension
(
self,

dimension_data,

origin )

Creates a parallel dimension. 

Returns
dimension (NXOpen.Annotations.ParallelDimension): New parallel dimension .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePerpendicularDimension()

NXOpen.Annotations.DimensionCollection.CreatePerpendicularDimension
(
self,

dimension_data,

origin )

Creates a perpendicular dimension. 

Returns
dimension (NXOpen.Annotations.PerpendicularDimension): New perpendicular dimension .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePmiAngularDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreatePmiAngularDimensionBuilder
(
self,

angularDimension )

Creates a NXOpen::Annotations::PmiAngularDimensionBuilder. 

Returns
builder (NXOpen.Annotations.PmiAngularDimensionBuilder): the Angular dimension builder .

Created in NX9.0.0 

License requirements: geometric_tol ("GDT")

Parameters

angularDimension — (NXOpen.Annotations.Dimension) the PMI angular dimension to be edited, if NULL, then create an angular dimension

## ◆ CreatePmiArcLengthDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiArcLengthDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin )

Creates a PMI arc length dimension. 

Returns
dimension (NXOpen.Annotations.PmiArcLengthDimension): New PMI arc length dimension .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePmiChamferDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiChamferDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin )

Creates a PMI chamfer dimnension. 

Returns
dimension (NXOpen.Annotations.PmiChamferDimension): New PMI chamfer dimension .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePmiChamferDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreatePmiChamferDimensionBuilder
(
self,

chamferDimension )

Creates a NXOpen::Annotations::PmiChamferDimensionBuilder. 

Returns
builder (NXOpen.Annotations.PmiChamferDimensionBuilder): the chamfer dimension builder .

Created in NX9.0.0 

License requirements: geometric_tol ("GDT")

Parameters

chamferDimension — (NXOpen.Annotations.PmiChamferDimension) the PMI chamfer dimension to be edited, if NULL, then create an chamfer dimension

## ◆ CreatePmiConcentricCircleDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiConcentricCircleDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin )

Creates a PMI concentric circle dimension. 

Returns
dimension (NXOpen.Annotations.PmiConcentricCircleDimension): New PMI concentric circle dimension .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePmiCurveLengthDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreatePmiCurveLengthDimensionBuilder
(
self,

curveLengthDimension )

Creates a NXOpen::Annotations::PmiCurveLengthDimensionBuilder. 

Returns
builder (NXOpen.Annotations.PmiCurveLengthDimensionBuilder): the curve length dimension builder .

Created in NX9.0.0 

License requirements: geometric_tol ("GDT")

Parameters

curveLengthDimension — (NXOpen.Annotations.PmiArcLengthDimension) the PMI curve length dimension to be edited, if NULL, then create an curve length dimension

## ◆ CreatePmiCylindricalDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiCylindricalDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin )

Creates a PMI cylindrical dimension. 

Returns
dimension (NXOpen.Annotations.PmiCylindricalDimension): New PMI cylindrical dimension .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePmiDiameterDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiDiameterDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin )

Creates a PMI diameter dimension. 

Returns
dimension (NXOpen.Annotations.PmiDiameterDimension): New PMI diameter dimension .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePmiFoldedRadiusDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiFoldedRadiusDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin )

Creates a PMI folded radius dimension. 

Returns
dimension (NXOpen.Annotations.PmiFoldedRadiusDimension): New PMI folded radius dimension .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePmiHoleCalloutDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreatePmiHoleCalloutDimensionBuilder
(
self,

measurementDimension )

Creates a NXOpen::Annotations::PmiHoleCalloutDimensionBuilder. 

Returns
builder (NXOpen.Annotations.PmiHoleCalloutDimensionBuilder): the PMI hole callout dimension builder .

Created in NX2206.0.0 

License requirements: geometric_tol ("GDT")

Parameters

measurementDimension — (NXOpen.Annotations.Dimension) the PMI hole callout dimension to be edited, if NULL, then create a PMI hole callout dimension

## ◆ CreatePmiHoleDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiHoleDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin )

Creates a PMI hole dimension. 

Returns
dimension (NXOpen.Annotations.PmiHoleDimension): New PMI hole dimension .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePmiHorizontalDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiHorizontalDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin )

Creates a PMI horizontal dimension. 

Returns
dimension (NXOpen.Annotations.PmiHorizontalDimension): New PMI horizontal dimension .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePmiHorizontalOrdinateAutoDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiHorizontalOrdinateAutoDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin,

allow_duplicate,

reposition_dim )

Creates a PMI horizontal ordinate automatic dimension. 

Created in NX5.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

allow_duplicate — (bool) TRUE - Allow dimensions with duplicate values

reposition_dim — (bool) TRUE - Reposition existing dimensions

## ◆ CreatePmiHorizontalOrdinateDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiHorizontalOrdinateDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin )

Creates a PMI horizontal ordinate dimension. 

Returns
dimension (NXOpen.Annotations.PmiHorizontalOrdinateDimension): New PMI horizontal ordinate dimension .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePmiLinearDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreatePmiLinearDimensionBuilder
(
self,

linearDimension )

Creates a NXOpen::Annotations::PmiLinearDimensionBuilder. 

Returns
builder (NXOpen.Annotations.PmiLinearDimensionBuilder): the linear dimension builder .

Created in NX9.0.0 

License requirements: geometric_tol ("GDT")

Parameters

linearDimension — (NXOpen.Annotations.Dimension) the PMI linear dimension to be edited, if NULL, then create an linear dimension

## ◆ CreatePmiMajorAngularDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiMajorAngularDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin )

Creates a PMI major angular dimension. 

Returns
dimension (NXOpen.Annotations.PmiMajorAngularDimension): New PMI major angular dimension .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePmiMajorAngularDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreatePmiMajorAngularDimensionBuilder
(
self,

angularDimension )

Creates a NXOpen::Annotations::PmiMajorAngularDimensionBuilder. 

Returns
builder (NXOpen.Annotations.PmiMajorAngularDimensionBuilder): the Angular dimension builder .

Created in NX9.0.0 

License requirements: geometric_tol ("GDT")

Parameters

angularDimension — (NXOpen.Annotations.BaseAngularDimension) the Drafting or PMI inherited angular dimension to be edited, if NULL, then create an angular dimension

## ◆ CreatePmiMinorAngularDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiMinorAngularDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin )

Creates a PMI minor angular dimension. 

Returns
dimension (NXOpen.Annotations.PmiMinorAngularDimension): New PMI minor angular dimension .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePmiMinorAngularDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreatePmiMinorAngularDimensionBuilder
(
self,

angularDimension )

Creates a NXOpen::Annotations::PmiMinorAngularDimensionBuilder. 

Returns
builder (NXOpen.Annotations.PmiMinorAngularDimensionBuilder): the Angular dimension builder .

Created in NX9.0.0 

License requirements: geometric_tol ("GDT")

Parameters

angularDimension — (NXOpen.Annotations.BaseAngularDimension) the Drafting or PMI inherited angular dimension to be edited, if NULL, then create an angular dimension

## ◆ CreatePmiOrdinateDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreatePmiOrdinateDimensionBuilder
(
self,

ordinateDimension )

Creates a NXOpen::Annotations::PmiOrdinateDimensionBuilder. 

Returns
builder (NXOpen.Annotations.PmiOrdinateDimensionBuilder): the ordinate dimension builder .

Created in NX9.0.0 

License requirements: geometric_tol ("GDT")

Parameters

ordinateDimension — (NXOpen.Annotations.OrdinateDimension) the PMI ordinate dimension to be edited, if NULL, then create an ordinate dimension

## ◆ CreatePmiOrdinateOriginDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiOrdinateOriginDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin )

Creates a PMI ordinate origin dimension. 

Returns
dimension (NXOpen.Annotations.PmiOrdinateOriginDimension): New PMI ordinate origin dimension .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePmiParallelDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiParallelDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin )

Creates a PMI parallel dimension. 

Returns
dimension (NXOpen.Annotations.PmiParallelDimension): New PMI parallel dimension .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePmiPerpendicularDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiPerpendicularDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin )

Creates a PMI perpendicular dimension. 

Returns
dimension (NXOpen.Annotations.PmiPerpendicularDimension): New PMI perpendicular dimension .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePmiRadialDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreatePmiRadialDimensionBuilder
(
self,

radialDimension )

Creates a NXOpen::Annotations::PmiRadialDimensionBuilder. 

Returns
builder (NXOpen.Annotations.PmiRadialDimensionBuilder): the radial dimension builder .

Created in NX9.0.0 

License requirements: geometric_tol ("GDT")

Parameters

radialDimension — (NXOpen.Annotations.Dimension) the PMI radial dimension to be edited, if NULL, then create an radial dimension

## ◆ CreatePmiRadiusDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiRadiusDimension
(
self,

dimension_data,

radius_type,

pmi_data,

annotation_plane,

origin )

Creates a PMI radius dimension. 

Returns
dimension (NXOpen.Annotations.PmiRadiusDimension): New PMI radius dimension .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

radius_type — (NXOpen.Annotations.RadiusDimensionType) Radius type

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePmiRapidDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreatePmiRapidDimensionBuilder
(
self,

rapidDimension )

Creates a NXOpen::Annotations::PmiRapidDimensionBuilder. 

Returns
builder (NXOpen.Annotations.PmiRapidDimensionBuilder): the Rapid dimension builder .

Created in NX9.0.0 

License requirements: geometric_tol ("GDT")

Parameters

rapidDimension — (NXOpen.Annotations.Dimension) NULL. Create only.

## ◆ CreatePmiThicknessDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreatePmiThicknessDimensionBuilder
(
self,

thicknessDimension )

Creates a NXOpen::Annotations::PmiThicknessDimensionBuilder. 

Returns
builder (NXOpen.Annotations.PmiThicknessDimensionBuilder): the thickness dimension builder .

Created in NX9.0.0 

License requirements: geometric_tol ("GDT")

Parameters

thicknessDimension — (NXOpen.Annotations.PmiConcentricCircleDimension) the PMI thickness dimension to be edited, if NULL, then create an thickness dimension

## ◆ CreatePmiVerticalDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiVerticalDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin )

Creates a PMI vertical dimension. 

Returns
dimension (NXOpen.Annotations.PmiVerticalDimension): New PMI vertical dimension .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreatePmiVerticalOrdinateAutoDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiVerticalOrdinateAutoDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin,

allow_duplicate,

reposition_dim )

Creates a PMI vertical ordinate automatic dimension. 

Created in NX5.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

allow_duplicate — (bool) TRUE - Allow dimensions with duplicate values

reposition_dim — (bool) TRUE - Reposition existing dimensions

## ◆ CreatePmiVerticalOrdinateDimension()

NXOpen.Annotations.DimensionCollection.CreatePmiVerticalOrdinateDimension
(
self,

dimension_data,

pmi_data,

annotation_plane,

origin )

Creates a PMI vertical ordinate dimension. 

Returns
dimension (NXOpen.Annotations.PmiVerticalOrdinateDimension): New PMI vertical ordinate dimension .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the dimension lies

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreateRadialDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreateRadialDimensionBuilder
(
self,

radialDimension )

Creates a NXOpen::Annotations::RadialDimensionBuilder. 

Returns
builder (NXOpen.Annotations.RadialDimensionBuilder): the radial dimension builder .

Created in NX9.0.0 

License requirements: drafting ("DRAFTING")

Parameters

radialDimension — (NXOpen.Annotations.Dimension) the Drafting or PMI inherited radial dimension to be edited, if NULL, then create an radial dimension

## ◆ CreateRadiusDimension()

NXOpen.Annotations.DimensionCollection.CreateRadiusDimension
(
self,

dimension_data,

radius_type,

origin )

Creates a radius dimension. 

Returns
dimension (NXOpen.Annotations.RadiusDimension): New radius dimension .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

radius_type — (NXOpen.Annotations.RadiusDimensionType) Radius type

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreateRapidDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreateRapidDimensionBuilder
(
self,

rapidDimension )

Creates a NXOpen::Annotations::RapidDimensionBuilder. 

Returns
builder (NXOpen.Annotations.RapidDimensionBuilder): the Rapid dimension builder .

Created in NX9.0.0 

License requirements: drafting ("DRAFTING")

Parameters

rapidDimension — (NXOpen.Annotations.Dimension) NULL. Create only.

## ◆ CreateThicknessDimensionBuilder()

NXOpen.Annotations.DimensionCollection.CreateThicknessDimensionBuilder
(
self,

thicknessDimension )

Creates a NXOpen::Annotations::ThicknessDimensionBuilder. 

Returns
builder (NXOpen.Annotations.ThicknessDimensionBuilder): the thickness dimension builder .

Created in NX9.0.0 

License requirements: drafting ("DRAFTING")

Parameters

thicknessDimension — (NXOpen.Annotations.BaseConcentricCircleDimension) the Drafting or Inherited PMI thickness dimension to be edited, if NULL, then create an thickness dimension

## ◆ CreateVerticalDimension()

NXOpen.Annotations.DimensionCollection.CreateVerticalDimension
(
self,

dimension_data,

origin )

Creates a vertical dimension. 

Returns
dimension (NXOpen.Annotations.VerticalDimension): New vertical dimension .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

## ◆ CreateVerticalOrdinateAutoDimension()

NXOpen.Annotations.DimensionCollection.CreateVerticalOrdinateAutoDimension
(
self,

dimension_data,

origin,

allow_duplicate,

reposition_dim )

Creates a vertical ordinate automatic dimension. 

Created in NX5.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

allow_duplicate — (bool) TRUE - Allow dimensions with duplicate values

reposition_dim — (bool) TRUE - Reposition existing dimensions

## ◆ CreateVerticalOrdinateDimension()

NXOpen.Annotations.DimensionCollection.CreateVerticalOrdinateDimension
(
self,

dimension_data,

origin )

Creates a vertical ordinate dimension. 

Returns
dimension (NXOpen.Annotations.VerticalOrdinateDimension): New vertical ordinate dimension .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

dimension_data — (NXOpen.Annotations.DimensionData) Dimension data

origin — (NXOpen.Point3d) Origin for the dimension

Copyright 2025 Siemens
