# NXOpen.Annotations.PartFamilyTableBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13121.html>

Represents a NXOpen::Annotations::PartFamilyTableBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.PartFamilyTableBuilder:

## Public Member Functions

AssignTemplateName (self, templateName)

Assign part family tempate name. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the part family table origin. 

SelectPartFamilyMember (self)

Getter for property: (NXOpen.Assemblies.SelectComponent) SelectPartFamilyMember Returns the part family part. 

Style (self)

Getter for property: (NXOpen.Annotations.TableStyleBuilder) Style Returns the part family table style. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::PartFamilyTableBuilder . 

This class queries and sets settings specific to part family data when creating or editing part family table. 

To create a new instance of this class, use NXOpen::Annotations::PartFamilyTableCollection::CreatePartFamilyTableBuilder 

Created in NX1980.0.0 

## Member Function Documentation

## ◆ AssignTemplateName()

NXOpen.Annotations.PartFamilyTableBuilder.AssignTemplateName
(
self,

templateName )

Assign part family tempate name. 

Created in NX1980.0.0 

License requirements: None.

Parameters

templateName — (str) Full pathname of the Part Family template.

## ◆ Origin()

NXOpen.Annotations.PartFamilyTableBuilder.Origin
(
self — )

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the part family table origin. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
OriginBuilder 

## ◆ SelectPartFamilyMember()

NXOpen.Annotations.PartFamilyTableBuilder.SelectPartFamilyMember
(
self — )

Getter for property: (NXOpen.Assemblies.SelectComponent) SelectPartFamilyMember Returns the part family part. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
NXOpen.Assemblies.SelectComponent 

## ◆ Style()

NXOpen.Annotations.PartFamilyTableBuilder.Style
(
self — )

Getter for property: (NXOpen.Annotations.TableStyleBuilder) Style Returns the part family table style. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
TableStyleBuilder 

Copyright 2025 Siemens
