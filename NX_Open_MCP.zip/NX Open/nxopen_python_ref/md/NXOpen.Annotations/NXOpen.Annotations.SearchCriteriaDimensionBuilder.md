# NXOpen.Annotations.SearchCriteriaDimensionBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00209.html>

## Classes

class — DiameterSymbolOptions

Specifies diameter symbol option 

Enumerator — Comment

Diameter

Dia

SphericalDiameter

UserDefined — UserDefined

More...

class — DimensionTypes

Specifies dimension types 

Enumerator — Comment

Linear — Linear

Angular — Angular

Diameter — Diameter

Radial — Radial

Chamfer — Chamfer

Thickness — Thickness

ArcLength — ArcLength

Chain — Chain

Ordinate — Ordinate

Baseline — Baseline

More...

class — MeasurementTypes

Specifies measurement types 

Enumerator — Comment

All — Linear ALL

Directed — Linear Directed

FeatureOfSize — Linear Feature of Size

More...

class — RadialSymbolOptions

Specifies radial symbol option 

Enumerator — Comment

R — R

Rad — RAD

Sr — SR

Cr — CR

UserDefined — UserDefined

More...

class — ToleranceTypes

Specifies tolerance types 

Enumerator — Comment

NoTolerance — NoTolerance

EqualBilateralTolerance — qualBilateralTolerance

BilateralTolerance — BilateralTolerance

UnilateralPlus — UnilateralPlus

UnilateralMinus — UnilateralMinus

PlusLimitTwoLines — PlusLimitTwoLines

MinusLimitTwoLines — MinusLimitTwoLines

PlusLimitOneLine — PlusLimitOneLine

MinusLimitOneLine — MinusLimitOneLine

LimitsAndFits — LimitsAndFits

Basic — Basic

Reference — Reference

DiameterReference — DiameterReference

NotToScale — NotToScale

BasicDimensionNotToScale — BasicDimensionNotToScale

More...

Copyright 2025 Siemens
