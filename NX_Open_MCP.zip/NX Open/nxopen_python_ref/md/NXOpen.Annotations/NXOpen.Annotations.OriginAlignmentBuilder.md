# NXOpen.Annotations.OriginAlignmentBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00183.html>

## Classes

class — AutoAlignmentType

This represents the Auto-alignment types. More...

Copyright 2025 Siemens
