# NXOpen.Annotations.OrdinateStyleBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13097.html>

Represents a NXOpen::Annotations::OrdinateStyleBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.OrdinateStyleBuilder:

## Public Member Functions

AlignSymbolWithBaseline (self)

Getter for property: (bool) AlignSymbolWithBaseline Returns the align symbol with baseline preference. 

AlignSymbolWithBaseline (self, alignSymbolWithBaseline)

Setter for property: (bool) AlignSymbolWithBaseline. 

DisplayDimensionLine (self)

Getter for property: (NXOpen.Annotations.OrdinateLineArrowDisplayOption) DisplayDimensionLine Returns the display dimension line preference for an ordinate set. 

DisplayDimensionLine (self, displayDimensionLine)

Setter for property: (NXOpen.Annotations.OrdinateLineArrowDisplayOption) DisplayDimensionLine. 

DisplayNameStyle (self)

Getter for property: (NXOpen.Annotations.OrdinateOriginDisplayOption) DisplayNameStyle Returns the name display style for an ordinate set. 

DisplayNameStyle (self, displayNameStyle)

Setter for property: (NXOpen.Annotations.OrdinateOriginDisplayOption) DisplayNameStyle. 

DisplayZeroAtBaseline (self)

Getter for property: (bool) DisplayZeroAtBaseline Returns the display zero at baseline flag. 

DisplayZeroAtBaseline (self, zeroTextsDisplay)

Setter for property: (bool) DisplayZeroAtBaseline. 

DoglegAngle (self)

Getter for property: (float) DoglegAngle Returns the dogleg angle. 

DoglegAngle (self, doglegAngle)

Setter for property: (float) DoglegAngle. 

DoglegCreationOption (self)

Getter for property: (NXOpen.Annotations.OrdinateDoglegCreationOption) DoglegCreationOption Returns the dogleg creation option. 

DoglegCreationOption (self, doglegCreationOption)

Setter for property: (NXOpen.Annotations.OrdinateDoglegCreationOption) DoglegCreationOption. 

DoglegEndOffset (self)

Getter for property: (float) DoglegEndOffset Returns the dogleg end offset. 

DoglegEndOffset (self, doglegEndOffset)

Setter for property: (float) DoglegEndOffset. 

DoglegSetting (self)

Getter for property: (NXOpen.Annotations.OrdinateDoglegDefinition) DoglegSetting Returns the dogleg setting. 

DoglegSetting (self, doglegSetting)

Setter for property: (NXOpen.Annotations.OrdinateDoglegDefinition) DoglegSetting. 

DoglegStartOffset (self)

Getter for property: (float) DoglegStartOffset Returns the dogleg start offset. 

DoglegStartOffset (self, doglegStartOffset)

Setter for property: (float) DoglegStartOffset. 

MarginFirstOffset (self)

Getter for property: (float) MarginFirstOffset Returns the distance from the baseline to the first margin. 

MarginFirstOffset (self, marginFirstOffset)

Setter for property: (float) MarginFirstOffset. 

MarginSpacing (self)

Getter for property: (float) MarginSpacing Returns the interval distance between successive margins. 

MarginSpacing (self, marginSpacing)

Setter for property: (float) MarginSpacing. 

NumberOfMargins (self)

Getter for property: (int) NumberOfMargins Returns the number of margins to create. 

NumberOfMargins (self, numberOfMargins)

Setter for property: (int) NumberOfMargins. 

OrdinateTextAngle (self)

Getter for property: (float) OrdinateTextAngle Returns the ordinate text angle. 

OrdinateTextAngle (self, ordinateTextAngle)

Setter for property: (float) OrdinateTextAngle. 

OrdinateTextOrientation (self)

Getter for property: (NXOpen.Annotations.TextOrientation) OrdinateTextOrientation Returns the ordinate text orientation. 

OrdinateTextOrientation (self, ordinateTextOrientation)

Setter for property: (NXOpen.Annotations.TextOrientation) OrdinateTextOrientation. 

PositiveDirection (self)

Getter for property: (NXOpen.Annotations.OrdinatePositiveDirection) PositiveDirection Returns the positive direction of measurement for an ordinate set. 

PositiveDirection (self, positiveDirection)

Setter for property: (NXOpen.Annotations.OrdinatePositiveDirection) PositiveDirection. 

SymbolAngle (self)

Getter for property: (float) SymbolAngle Returns the symbol angle in degress with respect to the baseline. 

SymbolAngle (self, symbolAngle)

Setter for property: (float) SymbolAngle. 

SymbolAspectRatio (self)

Getter for property: (float) SymbolAspectRatio Returns the symbol aspect ratio. 

SymbolAspectRatio (self, symbolAspectRatio)

Setter for property: (float) SymbolAspectRatio. 

SymbolHeight (self)

Getter for property: (float) SymbolHeight Returns the symbol height. 

SymbolHeight (self, symbolHeight)

Setter for property: (float) SymbolHeight. 

SymbolLength (self)

Getter for property: (float) SymbolLength Returns the symbol length. 

SymbolLength (self, symbolLength)

Setter for property: (float) SymbolLength. 

SymbolScale (self)

Getter for property: (float) SymbolScale Returns the symbol scale. 

SymbolScale (self, symbolScale)

Setter for property: (float) SymbolScale. 

UserDefinedText (self)

Getter for property: (str) UserDefinedText Returns the ordinate origin user defined text. 

UserDefinedText (self, userDefinedText)

Setter for property: (str) UserDefinedText. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::OrdinateStyleBuilder . 

This class queries and sets ordinate specific preferences when creating or editing an ordinate set or ordinate dimension.

Created in NX6.0.0 

## Member Function Documentation

## ◆ AlignSymbolWithBaseline() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.AlignSymbolWithBaseline
(
self — )

Getter for property: (bool) AlignSymbolWithBaseline Returns the align symbol with baseline preference. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ AlignSymbolWithBaseline() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.AlignSymbolWithBaseline
(
self,

alignSymbolWithBaseline )

Setter for property: (bool) AlignSymbolWithBaseline. 

Sets the align symbol with baseline preference

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DisplayDimensionLine() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.DisplayDimensionLine
(
self — )

Getter for property: (NXOpen.Annotations.OrdinateLineArrowDisplayOption) DisplayDimensionLine Returns the display dimension line preference for an ordinate set. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
OrdinateLineArrowDisplayOption 

## ◆ DisplayDimensionLine() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.DisplayDimensionLine
(
self,

displayDimensionLine )

Setter for property: (NXOpen.Annotations.OrdinateLineArrowDisplayOption) DisplayDimensionLine. 

Sets the display dimension line preference for an ordinate set

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DisplayNameStyle() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.DisplayNameStyle
(
self — )

Getter for property: (NXOpen.Annotations.OrdinateOriginDisplayOption) DisplayNameStyle Returns the name display style for an ordinate set. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
OrdinateOriginDisplayOption 

## ◆ DisplayNameStyle() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.DisplayNameStyle
(
self,

displayNameStyle )

Setter for property: (NXOpen.Annotations.OrdinateOriginDisplayOption) DisplayNameStyle. 

Sets the name display style for an ordinate set

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DisplayZeroAtBaseline() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.DisplayZeroAtBaseline
(
self — )

Getter for property: (bool) DisplayZeroAtBaseline Returns the display zero at baseline flag. 

If this is true, then ordinate set will have zero text displayed at extension lines.

Getter License requirements: None.

Created in NX12.0.0 

Returns
bool 

## ◆ DisplayZeroAtBaseline() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.DisplayZeroAtBaseline
(
self,

zeroTextsDisplay )

Setter for property: (bool) DisplayZeroAtBaseline. 

Sets the display zero at baseline flag.

If this is true, then ordinate set will have zero text displayed at extension lines.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX12.0.0 

## ◆ DoglegAngle() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.DoglegAngle
(
self — )

Getter for property: (float) DoglegAngle Returns the dogleg angle. 

The valid range is greater than zero and less than or equal to 90 degrees

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ DoglegAngle() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.DoglegAngle
(
self,

doglegAngle )

Setter for property: (float) DoglegAngle. 

Sets the dogleg angle.

The valid range is greater than zero and less than or equal to 90 degrees

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DoglegCreationOption() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.DoglegCreationOption
(
self — )

Getter for property: (NXOpen.Annotations.OrdinateDoglegCreationOption) DoglegCreationOption Returns the dogleg creation option. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
OrdinateDoglegCreationOption 

## ◆ DoglegCreationOption() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.DoglegCreationOption
(
self,

doglegCreationOption )

Setter for property: (NXOpen.Annotations.OrdinateDoglegCreationOption) DoglegCreationOption. 

Sets the dogleg creation option

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DoglegEndOffset() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.DoglegEndOffset
(
self — )

Getter for property: (float) DoglegEndOffset Returns the dogleg end offset. 

This is the offset between the dimension line and the end position of the dogleg. This value must be greater than or equal to zero and less than or equal to the start offset

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ DoglegEndOffset() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.DoglegEndOffset
(
self,

doglegEndOffset )

Setter for property: (float) DoglegEndOffset. 

Sets the dogleg end offset.

This is the offset between the dimension line and the end position of the dogleg. This value must be greater than or equal to zero and less than or equal to the start offset

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DoglegSetting() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.DoglegSetting
(
self — )

Getter for property: (NXOpen.Annotations.OrdinateDoglegDefinition) DoglegSetting Returns the dogleg setting. 

This specifies which options are used to specify the dogleg

Getter License requirements: None.

Created in NX6.0.0 

Returns
OrdinateDoglegDefinition 

## ◆ DoglegSetting() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.DoglegSetting
(
self,

doglegSetting )

Setter for property: (NXOpen.Annotations.OrdinateDoglegDefinition) DoglegSetting. 

Sets the dogleg setting.

This specifies which options are used to specify the dogleg

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DoglegStartOffset() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.DoglegStartOffset
(
self — )

Getter for property: (float) DoglegStartOffset Returns the dogleg start offset. 

This is the offset between the dimension line and the start position of the dogleg. The value must be greater than or equal to zero

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ DoglegStartOffset() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.DoglegStartOffset
(
self,

doglegStartOffset )

Setter for property: (float) DoglegStartOffset. 

Sets the dogleg start offset.

This is the offset between the dimension line and the start position of the dogleg. The value must be greater than or equal to zero

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ MarginFirstOffset() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.MarginFirstOffset
(
self — )

Getter for property: (float) MarginFirstOffset Returns the distance from the baseline to the first margin. 

This can be a positive or negative number. The positive direction is away from the view's center

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ MarginFirstOffset() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.MarginFirstOffset
(
self,

marginFirstOffset )

Setter for property: (float) MarginFirstOffset. 

Sets the distance from the baseline to the first margin.

This can be a positive or negative number. The positive direction is away from the view's center

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ MarginSpacing() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.MarginSpacing
(
self — )

Getter for property: (float) MarginSpacing Returns the interval distance between successive margins. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ MarginSpacing() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.MarginSpacing
(
self,

marginSpacing )

Setter for property: (float) MarginSpacing. 

Sets the interval distance between successive margins

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ NumberOfMargins() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.NumberOfMargins
(
self — )

Getter for property: (int) NumberOfMargins Returns the number of margins to create. 

The maximum is 32

Getter License requirements: None.

Created in NX6.0.0 

Returns
int 

## ◆ NumberOfMargins() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.NumberOfMargins
(
self,

numberOfMargins )

Setter for property: (int) NumberOfMargins. 

Sets the number of margins to create.

The maximum is 32

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ OrdinateTextAngle() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.OrdinateTextAngle
(
self — )

Getter for property: (float) OrdinateTextAngle Returns the ordinate text angle. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ OrdinateTextAngle() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.OrdinateTextAngle
(
self,

ordinateTextAngle )

Setter for property: (float) OrdinateTextAngle. 

Sets the ordinate text angle

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ OrdinateTextOrientation() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.OrdinateTextOrientation
(
self — )

Getter for property: (NXOpen.Annotations.TextOrientation) OrdinateTextOrientation Returns the ordinate text orientation. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
TextOrientation 

## ◆ OrdinateTextOrientation() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.OrdinateTextOrientation
(
self,

ordinateTextOrientation )

Setter for property: (NXOpen.Annotations.TextOrientation) OrdinateTextOrientation. 

Sets the ordinate text orientation

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ PositiveDirection() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.PositiveDirection
(
self — )

Getter for property: (NXOpen.Annotations.OrdinatePositiveDirection) PositiveDirection Returns the positive direction of measurement for an ordinate set. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
OrdinatePositiveDirection 

## ◆ PositiveDirection() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.PositiveDirection
(
self,

positiveDirection )

Setter for property: (NXOpen.Annotations.OrdinatePositiveDirection) PositiveDirection. 

Sets the positive direction of measurement for an ordinate set

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SymbolAngle() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.SymbolAngle
(
self — )

Getter for property: (float) SymbolAngle Returns the symbol angle in degress with respect to the baseline. 

This option only applies if the name display style is User-Defined and the the value of the Align Symbol with Baseline preference is false

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ SymbolAngle() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.SymbolAngle
(
self,

symbolAngle )

Setter for property: (float) SymbolAngle. 

Sets the symbol angle in degress with respect to the baseline.

This option only applies if the name display style is User-Defined and the the value of the Align Symbol with Baseline preference is false

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SymbolAspectRatio() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.SymbolAspectRatio
(
self — )

Getter for property: (float) SymbolAspectRatio Returns the symbol aspect ratio. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ SymbolAspectRatio() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.SymbolAspectRatio
(
self,

symbolAspectRatio )

Setter for property: (float) SymbolAspectRatio. 

Sets the symbol aspect ratio

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SymbolHeight() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.SymbolHeight
(
self — )

Getter for property: (float) SymbolHeight Returns the symbol height. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ SymbolHeight() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.SymbolHeight
(
self,

symbolHeight )

Setter for property: (float) SymbolHeight. 

Sets the symbol height

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SymbolLength() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.SymbolLength
(
self — )

Getter for property: (float) SymbolLength Returns the symbol length. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ SymbolLength() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.SymbolLength
(
self,

symbolLength )

Setter for property: (float) SymbolLength. 

Sets the symbol length

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SymbolScale() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.SymbolScale
(
self — )

Getter for property: (float) SymbolScale Returns the symbol scale. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ SymbolScale() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.SymbolScale
(
self,

symbolScale )

Setter for property: (float) SymbolScale. 

Sets the symbol scale

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ UserDefinedText() [1/2]

NXOpen.Annotations.OrdinateStyleBuilder.UserDefinedText
(
self — )

Getter for property: (str) UserDefinedText Returns the ordinate origin user defined text. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ UserDefinedText() [2/2]

NXOpen.Annotations.OrdinateStyleBuilder.UserDefinedText
(
self,

userDefinedText )

Setter for property: (str) UserDefinedText. 

Sets the ordinate origin user defined text

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

Copyright 2025 Siemens
