# NXOpen.Annotations.DrawingFormatTitleBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12097.html>

Represents a NXOpen::Annotations::DrawingFormatTitleBuilder. 
More...

Inheritance diagram for NXOpen.Annotations.DrawingFormatTitleBuilder:

## Public Member Functions

Automatic (self)

Getter for property: (bool) Automatic Returns the flag that determines whether or not the title block updates automatically whenever a change occurs to a referenced object in the model. 

Automatic (self, automatic)

Setter for property: (bool) Automatic. 

TitleBlockAlignmentPosition (self)

Getter for property: (NXOpen.Annotations.DrawingFormatTitleBuilder.TitleBlockPositionType) TitleBlockAlignmentPosition Returns the option that specifies how the title block aligns relative to the cursor during placement. 

TitleBlockAlignmentPosition (self, titleBlockAlignmentPosition)

Setter for property: (NXOpen.Annotations.DrawingFormatTitleBuilder.TitleBlockPositionType) TitleBlockAlignmentPosition. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

DrawingFormatTitleBuilderTitleBlockPositionType = DrawingFormatTitleBuilder.TitleBlockPositionType

NXOpen.Annotations.DrawingFormatTitleBuilderTitleBlockPositionType is an alias for NXOpen.Annotations.DrawingFormatTitleBuilder.TitleBlockPositionType 

## Detailed Description

Represents a NXOpen::Annotations::DrawingFormatTitleBuilder. 

Created in NX9.0.0 

## Member Function Documentation

## ◆ Automatic() [1/2]

NXOpen.Annotations.DrawingFormatTitleBuilder.Automatic
(
self — )

Getter for property: (bool) Automatic Returns the flag that determines whether or not the title block updates automatically whenever a change occurs to a referenced object in the model. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ Automatic() [2/2]

NXOpen.Annotations.DrawingFormatTitleBuilder.Automatic
(
self,

automatic )

Setter for property: (bool) Automatic. 

Sets the flag that determines whether or not the title block updates automatically whenever a change occurs to a referenced object in the model

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ TitleBlockAlignmentPosition() [1/2]

NXOpen.Annotations.DrawingFormatTitleBuilder.TitleBlockAlignmentPosition
(
self — )

Getter for property: (NXOpen.Annotations.DrawingFormatTitleBuilder.TitleBlockPositionType) TitleBlockAlignmentPosition Returns the option that specifies how the title block aligns relative to the cursor during placement. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
DrawingFormatTitleBuilder.TitleBlockPositionType 

## ◆ TitleBlockAlignmentPosition() [2/2]

NXOpen.Annotations.DrawingFormatTitleBuilder.TitleBlockAlignmentPosition
(
self,

titleBlockAlignmentPosition )

Setter for property: (NXOpen.Annotations.DrawingFormatTitleBuilder.TitleBlockPositionType) TitleBlockAlignmentPosition. 

Sets the option that specifies how the title block aligns relative to the cursor during placement

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## Member Data Documentation

## ◆ DrawingFormatTitleBuilderTitleBlockPositionType

NXOpen.Annotations.DrawingFormatTitleBuilder.DrawingFormatTitleBuilderTitleBlockPositionType = DrawingFormatTitleBuilder.TitleBlockPositionType

NXOpen.Annotations.DrawingFormatTitleBuilderTitleBlockPositionType is an alias for NXOpen.Annotations.DrawingFormatTitleBuilder.TitleBlockPositionType 

Copyright 2025 Siemens
