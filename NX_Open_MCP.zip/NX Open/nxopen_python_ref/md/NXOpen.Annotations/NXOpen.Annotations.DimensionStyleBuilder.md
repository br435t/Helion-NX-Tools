# NXOpen.Annotations.DimensionStyleBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11957.html>

Represents a NXOpen::Annotations::DimensionStyleBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.DimensionStyleBuilder:

## Public Member Functions

AngularDimensionValuePrecision (self)

Getter for property: (int) AngularDimensionValuePrecision Returns the angular dimension value precision. 

AngularDimensionValuePrecision (self, angularDimensionValuePrecision)

Setter for property: (int) AngularDimensionValuePrecision. 

AngularToleranceValuePrecision (self)

Getter for property: (int) AngularToleranceValuePrecision Returns the angular tolerance value precision. 

AngularToleranceValuePrecision (self, angularToleranceValuePrecision)

Setter for property: (int) AngularToleranceValuePrecision. 

BaselineOffset (self)

Getter for property: (float) BaselineOffset Returns the offset between dimension lines of baseline dimensions. 

BaselineOffset (self, baselineOffset)

Setter for property: (float) BaselineOffset. 

ChainOffset (self)

Getter for property: (float) ChainOffset Returns the offset between dimension lines of chain dimensions. 

ChainOffset (self, chainOffset)

Setter for property: (float) ChainOffset. 

ChamferForm (self)

Getter for property: (NXOpen.Annotations.ChamferForm) ChamferForm Returns the chamfer dimension form. 

ChamferForm (self, chamferForm)

Setter for property: (NXOpen.Annotations.ChamferForm) ChamferForm. 

ChamferLeaderType (self)

Getter for property: (NXOpen.Annotations.ChamferLeaderPlacement) ChamferLeaderType Returns the chamfer dimension leader type. 

ChamferLeaderType (self, chamferLeaderType)

Setter for property: (NXOpen.Annotations.ChamferLeaderPlacement) ChamferLeaderType. 

ChamferSeparator (self)

Getter for property: (NXOpen.Annotations.ChamferSeparatorType) ChamferSeparator Returns the chamfer separator type. 

ChamferSeparator (self, separator)

Setter for property: (NXOpen.Annotations.ChamferSeparatorType) ChamferSeparator. 

ChamferSpaceFactor (self)

Getter for property: (float) ChamferSpaceFactor Returns the chamfer dimension space factor. 

ChamferSpaceFactor (self, chamferSpaceFactor)

Setter for property: (float) ChamferSpaceFactor. 

ChamferStubType (self)

Getter for property: (NXOpen.Annotations.ChamferStubType) ChamferStubType Returns the chamfer dimension stub type. 

ChamferStubType (self, chamferStubType)

Setter for property: (NXOpen.Annotations.ChamferStubType) ChamferStubType. 

ChamferSymbolName (self)

Getter for property: (str) ChamferSymbolName Returns the chamfer dimension symbol name. 

ChamferSymbolName (self, chamferSymbolName)

Setter for property: (str) ChamferSymbolName. 

ChamferSymbolType (self)

Getter for property: (NXOpen.Annotations.ChamferSymbolPlacement) ChamferSymbolType Returns the chamfer dimension symbol type. 

ChamferSymbolType (self, chamferSymbolType)

Setter for property: (NXOpen.Annotations.ChamferSymbolPlacement) ChamferSymbolType. 

DimArrowDisplay (self)

Getter for property: (NXOpen.Annotations.ArrowDisplay) DimArrowDisplay Returns the dimension arrow display option. 

DimArrowDisplay (self, dimArrowDisplay)

Setter for property: (NXOpen.Annotations.ArrowDisplay) DimArrowDisplay. 

DimensionReferenceIncludeType (self)

Getter for property: (NXOpen.Annotations.ReferenceIncludeType) DimensionReferenceIncludeType Returns the dimension reference include type. 

DimensionReferenceIncludeType (self, referenceIncludeType)

Setter for property: (NXOpen.Annotations.ReferenceIncludeType) DimensionReferenceIncludeType. 

DimensionValuePrecision (self)

Getter for property: (int) DimensionValuePrecision Returns the dimension value precision. 

DimensionValuePrecision (self, dimensionValuePrecision)

Setter for property: (int) DimensionValuePrecision. 

DimZeroToleranceDisplayStyle (self)

Getter for property: (NXOpen.Annotations.ZeroToleranceDisplayStyle) DimZeroToleranceDisplayStyle Returns the dimension zero tolerance display style. 

DimZeroToleranceDisplayStyle (self, dimZeroToleranceDisplayStyle)

Setter for property: (NXOpen.Annotations.ZeroToleranceDisplayStyle) DimZeroToleranceDisplayStyle. 

DualDimensionFractionDenominator (self)

Getter for property: (NXOpen.Annotations.FractionDenominatorFormat) DualDimensionFractionDenominator Returns the dual dimension fractional denominator. 

DualDimensionFractionDenominator (self, dualDimensionFractionDenominator)

Setter for property: (NXOpen.Annotations.FractionDenominatorFormat) DualDimensionFractionDenominator. 

DualDimensionValuePrecision (self)

Getter for property: (int) DualDimensionValuePrecision Returns the dual dimension value precision. 

DualDimensionValuePrecision (self, dualDimensionValuePrecision)

Setter for property: (int) DualDimensionValuePrecision. 

DualToleranceValuePrecision (self)

Getter for property: (int) DualToleranceValuePrecision Returns the dual tolerance value precision. 

DualToleranceValuePrecision (self, dualToleranceValuePrecision)

Setter for property: (int) DualToleranceValuePrecision. 

ExtensionLineDisplay (self)

Getter for property: (NXOpen.Annotations.ExtensionLineDisplay) ExtensionLineDisplay Returns the extension line display option. 

ExtensionLineDisplay (self, extensionLineDisplay)

Setter for property: (NXOpen.Annotations.ExtensionLineDisplay) ExtensionLineDisplay. 

FitToleranceParentheses (self)

Getter for property: (bool) FitToleranceParentheses Returns the fit tolerance parentheses option. 

FitToleranceParentheses (self, showFitParentheses)

Setter for property: (bool) FitToleranceParentheses. 

FitToleranceSeparator (self)

Getter for property: (bool) FitToleranceSeparator Returns the fit tolerance separator option. 

FitToleranceSeparator (self, showFitSeparator)

Setter for property: (bool) FitToleranceSeparator. 

GetOverriddenDimensionText (self)

Returns the overridden dimension text value. 

InspectionDimension (self)

Getter for property: (bool) InspectionDimension Returns the inspection dimension flag. 

InspectionDimension (self, inspectionDimension)

Setter for property: (bool) InspectionDimension. 

InspectionSymbolAroundAppendedText (self)

Getter for property: (NXOpen.Annotations.InspectionSymbolAroundAppendedText) InspectionSymbolAroundAppendedText Returns the inspection symbol around appended text option. 

InspectionSymbolAroundAppendedText (self, inspectionSymbolAroundAppendedText)

Setter for property: (NXOpen.Annotations.InspectionSymbolAroundAppendedText) InspectionSymbolAroundAppendedText. 

LimitFitAnsiHoleType (self)

Getter for property: (NXOpen.Annotations.FitAnsiHoleType) LimitFitAnsiHoleType Returns the dimension limit fit ANSI hole type. 

LimitFitAnsiHoleType (self, fitHoleType)

Setter for property: (NXOpen.Annotations.FitAnsiHoleType) LimitFitAnsiHoleType. 

LimitFitAssemblyDisplayStyle (self)

Getter for property: (NXOpen.Annotations.FitAssemblyDisplayStyle) LimitFitAssemblyDisplayStyle Returns the display style of fit tolerance for assembly dimensions. 

LimitFitAssemblyDisplayStyle (self, fitAssemblyDisplayStyle)

Setter for property: (NXOpen.Annotations.FitAssemblyDisplayStyle) LimitFitAssemblyDisplayStyle. 

LimitFitAssemblyNewDisplayStyle (self)

Getter for property: (NXOpen.Annotations.FitAssemblyNewDisplayStyle) LimitFitAssemblyNewDisplayStyle Returns the new display style of fit tolerance for assembly dimensions. 

LimitFitAssemblyNewDisplayStyle (self, fitAssemblyDisplayStyle)

Setter for property: (NXOpen.Annotations.FitAssemblyNewDisplayStyle) LimitFitAssemblyNewDisplayStyle. 

LimitFitDeviation (self)

Getter for property: (str) LimitFitDeviation Returns the dimension limit fit deviation. 

LimitFitDeviation (self, fitDeviation)

Setter for property: (str) LimitFitDeviation. 

LimitFitDisplayAlignment (self)

Getter for property: (NXOpen.Annotations.FitDisplayAlignment) LimitFitDisplayAlignment Returns the dimension limit fit display alignment. 

LimitFitDisplayAlignment (self, fitDisplayAlignment)

Setter for property: (NXOpen.Annotations.FitDisplayAlignment) LimitFitDisplayAlignment. 

LimitFitDisplaySplitByDimline (self)

Getter for property: (NXOpen.Annotations.FitDisplaySplitByDimline) LimitFitDisplaySplitByDimline Returns the dimension limit fit assembly display when split by dimension line. 

LimitFitDisplaySplitByDimline (self, fitDisplaySplitByDimline)

Setter for property: (NXOpen.Annotations.FitDisplaySplitByDimline) LimitFitDisplaySplitByDimline. 

LimitFitDisplayStyle (self)

Getter for property: (NXOpen.Annotations.FitDisplayStyle) LimitFitDisplayStyle Returns the dimension limit fit display style. 

LimitFitDisplayStyle (self, fitDisplayStyle)

Setter for property: (NXOpen.Annotations.FitDisplayStyle) LimitFitDisplayStyle. 

LimitFitGrade (self)

Getter for property: (int) LimitFitGrade Returns the dimension limit fit grade. 

LimitFitGrade (self, fitGrade)

Setter for property: (int) LimitFitGrade. 

LimitFitShaftDeviation (self)

Getter for property: (str) LimitFitShaftDeviation Returns the shaft deviation for fit tolerance of a dimension. 

LimitFitShaftDeviation (self, fitShaftDeviation)

Setter for property: (str) LimitFitShaftDeviation. 

LimitFitShaftGrade (self)

Getter for property: (int) LimitFitShaftGrade Returns the shaft grade for fit tolerance of a dimension. 

LimitFitShaftGrade (self, fitShaftGrade)

Setter for property: (int) LimitFitShaftGrade. 

LineBetweenArrows (self)

Getter for property: (bool) LineBetweenArrows Returns the line between arrows. 

LineBetweenArrows (self, lineBetweenArrows)

Setter for property: (bool) LineBetweenArrows. 

LowerToleranceDegrees (self)

Getter for property: (float) LowerToleranceDegrees Returns the lower angular tolerance in degrees. 

LowerToleranceDegrees (self, lowerToleranceDegrees)

Setter for property: (float) LowerToleranceDegrees. 

LowerToleranceEnglish (self)

Getter for property: (float) LowerToleranceEnglish Returns the lower english tolerance. 

LowerToleranceEnglish (self, lowerToleranceEnglish)

Setter for property: (float) LowerToleranceEnglish. 

LowerToleranceMetric (self)

Getter for property: (float) LowerToleranceMetric Returns the lower metric tolerance. 

LowerToleranceMetric (self, lowerToleranceMetric)

Setter for property: (float) LowerToleranceMetric. 

NarrowArrowType (self)

Getter for property: (NXOpen.Annotations.ArrowheadType) NarrowArrowType Returns the narrow dimension arrowhead type which is used when there is no space for normal arrowheads. 

NarrowArrowType (self, narrowArrowType)

Setter for property: (NXOpen.Annotations.ArrowheadType) NarrowArrowType. 

NarrowDisplayType (self)

Getter for property: (NXOpen.Annotations.NarrowDisplayOption) NarrowDisplayType Returns the display type for narrow dimensions. 

NarrowDisplayType (self, narrowDisplayType)

Setter for property: (NXOpen.Annotations.NarrowDisplayOption) NarrowDisplayType. 

NarrowLeaderAngle (self)

Getter for property: (float) NarrowLeaderAngle Returns the narrow dimension leader angle. 

NarrowLeaderAngle (self, narrowLeaderAngle)

Setter for property: (float) NarrowLeaderAngle. 

NarrowTextOffset (self)

Getter for property: (float) NarrowTextOffset Returns the narrow dimension text offset. 

NarrowTextOffset (self, narrowTextOffset)

Setter for property: (float) NarrowTextOffset. 

NarrowTextOrientation (self)

Getter for property: (NXOpen.Annotations.NarrowTextOrientation) NarrowTextOrientation Returns the narrow dimension text orientation. 

NarrowTextOrientation (self, narrowTextOrientation)

Setter for property: (NXOpen.Annotations.NarrowTextOrientation) NarrowTextOrientation. 

Orientation (self)

Getter for property: (NXOpen.Annotations.TextOrientation) Orientation Returns the dimension text orientation. 

Orientation (self, orientation)

Setter for property: (NXOpen.Annotations.TextOrientation) Orientation. 

OverrideDimensionText (self)

Getter for property: (bool) OverrideDimensionText Returns the override dimension text. 

OverrideDimensionText (self, overrideDimensionText)

Setter for property: (bool) OverrideDimensionText. 

PrefixSuffixReference (self)

Getter for property: (bool) PrefixSuffixReference Returns the flag indicating whether prefix suffix reference toggle is turned on or not. 

PrefixSuffixReference (self, prefixSuffixReference)

Setter for property: (bool) PrefixSuffixReference. 

PrimaryDimensionFractionDenominator (self)

Getter for property: (NXOpen.Annotations.FractionDenominatorFormat) PrimaryDimensionFractionDenominator Returns the primary dimension fractional denominator. 

PrimaryDimensionFractionDenominator (self, primaryDimensionFractionDenominator)

Setter for property: (NXOpen.Annotations.FractionDenominatorFormat) PrimaryDimensionFractionDenominator. 

ReferenceDimension (self)

Getter for property: (bool) ReferenceDimension Returns the reference dimension flag. 

ReferenceDimension (self, referenceDimension)

Setter for property: (bool) ReferenceDimension. 

ReferenceDimensionPrefix (self)

Getter for property: (str) ReferenceDimensionPrefix Returns the prefix characters for reference dimension. 

ReferenceDimensionPrefix (self, prefix)

Setter for property: (str) ReferenceDimensionPrefix. 

ReferenceDimensionSuffix (self)

Getter for property: (str) ReferenceDimensionSuffix Returns the suffix characters for reference dimension. 

ReferenceDimensionSuffix (self, suffix)

Setter for property: (str) ReferenceDimensionSuffix. 

ReverseArrowDirection (self)

Getter for property: (bool) ReverseArrowDirection Returns the reverse arrow direction flag. 

ReverseArrowDirection (self, reverseArrowDirection)

Setter for property: (bool) ReverseArrowDirection. 

SeparateBrackets (self)

Getter for property: (bool) SeparateBrackets Returns the separate brackets with show as reference. 

SeparateBrackets (self, separateBrackets)

Setter for property: (bool) SeparateBrackets. 

SetOverriddenDimensionText (self, customizedText)

Sets the overridden dimension text value. 

ShowAsReferenceDimension (self)

Getter for property: (bool) ShowAsReferenceDimension Returns the show as reference dimension flag. 

ShowAsReferenceDimension (self, showAsreference)

Setter for property: (bool) ShowAsReferenceDimension. 

SingleLimitOffsetIncludeFlag (self)

Getter for property: (bool) SingleLimitOffsetIncludeFlag Returns the single limit offset option to add the value to or subtract the value from the size of the dimension. 

SingleLimitOffsetIncludeFlag (self, isSingleLimitOffSetIncluded)

Setter for property: (bool) SingleLimitOffsetIncludeFlag. 

SingleLimitOffsetValueEnglish (self)

Getter for property: (float) SingleLimitOffsetValueEnglish Returns the single limit offset english value to add to or subtract from the size of the dimension. 

SingleLimitOffsetValueEnglish (self, singleLimitOffSetValueEnglish)

Setter for property: (float) SingleLimitOffsetValueEnglish. 

SingleLimitOffsetValueMetric (self)

Getter for property: (float) SingleLimitOffsetValueMetric Returns the single limit offset metric value to add to or subtract from the size of the dimension. 

SingleLimitOffsetValueMetric (self, singleLimitOffSetValueMetric)

Setter for property: (float) SingleLimitOffsetValueMetric. 

TextAngle (self)

Getter for property: (float) TextAngle Returns the dimension text angle. 

TextAngle (self, textAngle)

Setter for property: (float) TextAngle. 

TextArrowPlacement (self)

Getter for property: (NXOpen.Annotations.TextPlacement) TextArrowPlacement Returns the text arrow placement. 

TextArrowPlacement (self, textArrowPlacement)

Setter for property: (NXOpen.Annotations.TextPlacement) TextArrowPlacement. 

TextCentered (self)

Getter for property: (bool) TextCentered Returns the dimension text centered option. 

TextCentered (self, textCentered)

Setter for property: (bool) TextCentered. 

TextPosition (self)

Getter for property: (NXOpen.Annotations.TextPosition) TextPosition Returns the dimension text position representing above or after stub. 

TextPosition (self, position)

Setter for property: (NXOpen.Annotations.TextPosition) TextPosition. 

ToleranceType (self)

Getter for property: (NXOpen.Annotations.ToleranceType) ToleranceType Returns the dimension tolerance type. 

ToleranceType (self, dimToleranceType)

Setter for property: (NXOpen.Annotations.ToleranceType) ToleranceType. 

ToleranceValuePrecision (self)

Getter for property: (int) ToleranceValuePrecision Returns the tolerance value precision. 

ToleranceValuePrecision (self, toleranceValuePrecision)

Setter for property: (int) ToleranceValuePrecision. 

TrimDimLine (self)

Getter for property: (NXOpen.Annotations.TrimDimensionLineStyle) TrimDimLine Returns the trim dimension line flag. 

TrimDimLine (self, trimDimLine)

Setter for property: (NXOpen.Annotations.TrimDimensionLineStyle) TrimDimLine. 

TrueLengthText (self)

Getter for property: (str) TrueLengthText Returns the true length dimension text. 

TrueLengthText (self, trueLengthText)

Setter for property: (str) TrueLengthText. 

TrueLengthTextPosition (self)

Getter for property: (NXOpen.Annotations.TrueLengthTextPosition) TrueLengthTextPosition Returns the true length text position. 

TrueLengthTextPosition (self, trueLengthTextPosition)

Setter for property: (NXOpen.Annotations.TrueLengthTextPosition) TrueLengthTextPosition. 

UpperToleranceDegrees (self)

Getter for property: (float) UpperToleranceDegrees Returns the upper angular tolerance in degrees. 

UpperToleranceDegrees (self, upperToleranceDegrees)

Setter for property: (float) UpperToleranceDegrees. 

UpperToleranceEnglish (self)

Getter for property: (float) UpperToleranceEnglish Returns the upper english tolerance. 

UpperToleranceEnglish (self, upperToleranceEnglish)

Setter for property: (float) UpperToleranceEnglish. 

UpperToleranceMetric (self)

Getter for property: (float) UpperToleranceMetric Returns the upper metric tolerance. 

UpperToleranceMetric (self, upperToleranceMetric)

Setter for property: (float) UpperToleranceMetric. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::DimensionStyleBuilder . 

This class queries and sets dimension preferences when creating or editing a dimension.

Created in NX6.0.0 

## Member Function Documentation

## ◆ AngularDimensionValuePrecision() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.AngularDimensionValuePrecision
(
self — )

Getter for property: (int) AngularDimensionValuePrecision Returns the angular dimension value precision. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
int 

## ◆ AngularDimensionValuePrecision() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.AngularDimensionValuePrecision
(
self,

angularDimensionValuePrecision )

Setter for property: (int) AngularDimensionValuePrecision. 

Sets the angular dimension value precision

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ AngularToleranceValuePrecision() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.AngularToleranceValuePrecision
(
self — )

Getter for property: (int) AngularToleranceValuePrecision Returns the angular tolerance value precision. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
int 

## ◆ AngularToleranceValuePrecision() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.AngularToleranceValuePrecision
(
self,

angularToleranceValuePrecision )

Setter for property: (int) AngularToleranceValuePrecision. 

Sets the angular tolerance value precision

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ BaselineOffset() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.BaselineOffset
(
self — )

Getter for property: (float) BaselineOffset Returns the offset between dimension lines of baseline dimensions. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ BaselineOffset() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.BaselineOffset
(
self,

baselineOffset )

Setter for property: (float) BaselineOffset. 

Sets the offset between dimension lines of baseline dimensions

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ChainOffset() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.ChainOffset
(
self — )

Getter for property: (float) ChainOffset Returns the offset between dimension lines of chain dimensions. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ ChainOffset() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.ChainOffset
(
self,

chainOffset )

Setter for property: (float) ChainOffset. 

Sets the offset between dimension lines of chain dimensions

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ChamferForm() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.ChamferForm
(
self — )

Getter for property: (NXOpen.Annotations.ChamferForm) ChamferForm Returns the chamfer dimension form. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
ChamferForm 

## ◆ ChamferForm() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.ChamferForm
(
self,

chamferForm )

Setter for property: (NXOpen.Annotations.ChamferForm) ChamferForm. 

Sets the chamfer dimension form

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ChamferLeaderType() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.ChamferLeaderType
(
self — )

Getter for property: (NXOpen.Annotations.ChamferLeaderPlacement) ChamferLeaderType Returns the chamfer dimension leader type. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
ChamferLeaderPlacement 

## ◆ ChamferLeaderType() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.ChamferLeaderType
(
self,

chamferLeaderType )

Setter for property: (NXOpen.Annotations.ChamferLeaderPlacement) ChamferLeaderType. 

Sets the chamfer dimension leader type

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ChamferSeparator() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.ChamferSeparator
(
self — )

Getter for property: (NXOpen.Annotations.ChamferSeparatorType) ChamferSeparator Returns the chamfer separator type. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
ChamferSeparatorType 

## ◆ ChamferSeparator() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.ChamferSeparator
(
self,

separator )

Setter for property: (NXOpen.Annotations.ChamferSeparatorType) ChamferSeparator. 

Sets the chamfer separator type

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ ChamferSpaceFactor() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.ChamferSpaceFactor
(
self — )

Getter for property: (float) ChamferSpaceFactor Returns the chamfer dimension space factor. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ ChamferSpaceFactor() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.ChamferSpaceFactor
(
self,

chamferSpaceFactor )

Setter for property: (float) ChamferSpaceFactor. 

Sets the chamfer dimension space factor

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ChamferStubType() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.ChamferStubType
(
self — )

Getter for property: (NXOpen.Annotations.ChamferStubType) ChamferStubType Returns the chamfer dimension stub type. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
ChamferStubType 

## ◆ ChamferStubType() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.ChamferStubType
(
self,

chamferStubType )

Setter for property: (NXOpen.Annotations.ChamferStubType) ChamferStubType. 

Sets the chamfer dimension stub type

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ChamferSymbolName() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.ChamferSymbolName
(
self — )

Getter for property: (str) ChamferSymbolName Returns the chamfer dimension symbol name. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ ChamferSymbolName() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.ChamferSymbolName
(
self,

chamferSymbolName )

Setter for property: (str) ChamferSymbolName. 

Sets the chamfer dimension symbol name

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ChamferSymbolType() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.ChamferSymbolType
(
self — )

Getter for property: (NXOpen.Annotations.ChamferSymbolPlacement) ChamferSymbolType Returns the chamfer dimension symbol type. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
ChamferSymbolPlacement 

## ◆ ChamferSymbolType() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.ChamferSymbolType
(
self,

chamferSymbolType )

Setter for property: (NXOpen.Annotations.ChamferSymbolPlacement) ChamferSymbolType. 

Sets the chamfer dimension symbol type

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DimArrowDisplay() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.DimArrowDisplay
(
self — )

Getter for property: (NXOpen.Annotations.ArrowDisplay) DimArrowDisplay Returns the dimension arrow display option. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
ArrowDisplay 

## ◆ DimArrowDisplay() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.DimArrowDisplay
(
self,

dimArrowDisplay )

Setter for property: (NXOpen.Annotations.ArrowDisplay) DimArrowDisplay. 

Sets the dimension arrow display option

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DimensionReferenceIncludeType() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.DimensionReferenceIncludeType
(
self — )

Getter for property: (NXOpen.Annotations.ReferenceIncludeType) DimensionReferenceIncludeType Returns the dimension reference include type. 

Getter License requirements: None.

Created in NX1953.0.0 

Returns
ReferenceIncludeType 

## ◆ DimensionReferenceIncludeType() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.DimensionReferenceIncludeType
(
self,

referenceIncludeType )

Setter for property: (NXOpen.Annotations.ReferenceIncludeType) DimensionReferenceIncludeType. 

Sets the dimension reference include type

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX1953.0.0 

## ◆ DimensionValuePrecision() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.DimensionValuePrecision
(
self — )

Getter for property: (int) DimensionValuePrecision Returns the dimension value precision. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
int 

## ◆ DimensionValuePrecision() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.DimensionValuePrecision
(
self,

dimensionValuePrecision )

Setter for property: (int) DimensionValuePrecision. 

Sets the dimension value precision

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DimZeroToleranceDisplayStyle() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.DimZeroToleranceDisplayStyle
(
self — )

Getter for property: (NXOpen.Annotations.ZeroToleranceDisplayStyle) DimZeroToleranceDisplayStyle Returns the dimension zero tolerance display style. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
ZeroToleranceDisplayStyle 

## ◆ DimZeroToleranceDisplayStyle() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.DimZeroToleranceDisplayStyle
(
self,

dimZeroToleranceDisplayStyle )

Setter for property: (NXOpen.Annotations.ZeroToleranceDisplayStyle) DimZeroToleranceDisplayStyle. 

Sets the dimension zero tolerance display style

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DualDimensionFractionDenominator() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.DualDimensionFractionDenominator
(
self — )

Getter for property: (NXOpen.Annotations.FractionDenominatorFormat) DualDimensionFractionDenominator Returns the dual dimension fractional denominator. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
FractionDenominatorFormat 

## ◆ DualDimensionFractionDenominator() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.DualDimensionFractionDenominator
(
self,

dualDimensionFractionDenominator )

Setter for property: (NXOpen.Annotations.FractionDenominatorFormat) DualDimensionFractionDenominator. 

Sets the dual dimension fractional denominator

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DualDimensionValuePrecision() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.DualDimensionValuePrecision
(
self — )

Getter for property: (int) DualDimensionValuePrecision Returns the dual dimension value precision. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
int 

## ◆ DualDimensionValuePrecision() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.DualDimensionValuePrecision
(
self,

dualDimensionValuePrecision )

Setter for property: (int) DualDimensionValuePrecision. 

Sets the dual dimension value precision

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DualToleranceValuePrecision() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.DualToleranceValuePrecision
(
self — )

Getter for property: (int) DualToleranceValuePrecision Returns the dual tolerance value precision. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
int 

## ◆ DualToleranceValuePrecision() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.DualToleranceValuePrecision
(
self,

dualToleranceValuePrecision )

Setter for property: (int) DualToleranceValuePrecision. 

Sets the dual tolerance value precision

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ExtensionLineDisplay() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.ExtensionLineDisplay
(
self — )

Getter for property: (NXOpen.Annotations.ExtensionLineDisplay) ExtensionLineDisplay Returns the extension line display option. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
ExtensionLineDisplay 

## ◆ ExtensionLineDisplay() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.ExtensionLineDisplay
(
self,

extensionLineDisplay )

Setter for property: (NXOpen.Annotations.ExtensionLineDisplay) ExtensionLineDisplay. 

Sets the extension line display option.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ FitToleranceParentheses() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.FitToleranceParentheses
(
self — )

Getter for property: (bool) FitToleranceParentheses Returns the fit tolerance parentheses option. 

When the value is true, parentheses will be shown on the fit tolerance text. Otherwise, a blank space will be used.

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ FitToleranceParentheses() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.FitToleranceParentheses
(
self,

showFitParentheses )

Setter for property: (bool) FitToleranceParentheses. 

Sets the fit tolerance parentheses option. When the value is true, parentheses will be shown on the fit tolerance text. Otherwise, a blank space will be used.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ FitToleranceSeparator() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.FitToleranceSeparator
(
self — )

Getter for property: (bool) FitToleranceSeparator Returns the fit tolerance separator option. 

When the limit fit type is FIT and the value true, a line will be drawn to separate the hole and shaft tolerance texts.

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ FitToleranceSeparator() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.FitToleranceSeparator
(
self,

showFitSeparator )

Setter for property: (bool) FitToleranceSeparator. 

Sets the fit tolerance separator option. When the limit fit type is FIT and the value true, a line will be drawn to separate the hole and shaft tolerance texts.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ GetOverriddenDimensionText()

NXOpen.Annotations.DimensionStyleBuilder.GetOverriddenDimensionText
(
self — )

Returns the overridden dimension text value. 

Returns
customizedText (List[str]): .

Created in NX10.0.0 

License requirements: None. 

## ◆ InspectionDimension() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.InspectionDimension
(
self — )

Getter for property: (bool) InspectionDimension Returns the inspection dimension flag. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ InspectionDimension() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.InspectionDimension
(
self,

inspectionDimension )

Setter for property: (bool) InspectionDimension. 

Sets the inspection dimension flag

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ InspectionSymbolAroundAppendedText() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.InspectionSymbolAroundAppendedText
(
self — )

Getter for property: (NXOpen.Annotations.InspectionSymbolAroundAppendedText) InspectionSymbolAroundAppendedText Returns the inspection symbol around appended text option. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
InspectionSymbolAroundAppendedText 

## ◆ InspectionSymbolAroundAppendedText() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.InspectionSymbolAroundAppendedText
(
self,

inspectionSymbolAroundAppendedText )

Setter for property: (NXOpen.Annotations.InspectionSymbolAroundAppendedText) InspectionSymbolAroundAppendedText. 

Sets the inspection symbol around appended text option

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX11.0.0 

## ◆ LimitFitAnsiHoleType() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitAnsiHoleType
(
self — )

Getter for property: (NXOpen.Annotations.FitAnsiHoleType) LimitFitAnsiHoleType Returns the dimension limit fit ANSI hole type. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
FitAnsiHoleType 

## ◆ LimitFitAnsiHoleType() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitAnsiHoleType
(
self,

fitHoleType )

Setter for property: (NXOpen.Annotations.FitAnsiHoleType) LimitFitAnsiHoleType. 

Sets the dimension limit fit ANSI hole type

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ LimitFitAssemblyDisplayStyle() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitAssemblyDisplayStyle
(
self — )

Getter for property: (NXOpen.Annotations.FitAssemblyDisplayStyle) LimitFitAssemblyDisplayStyle Returns the display style of fit tolerance for assembly dimensions. 

When the limit fit type is FIT, the display can be on a single line, or two lines centered with the dimension text or two lines with the shaft text in line with the dimension text. This property is obsolete.

Getter License requirements: None.

Created in NX9.0.0 

Deprecated
Deprecated in NX11.0.0. Use NXOpen::Annotations::DimensionStyleBuilder::LimitFitAssemblyNewDisplayStyle instead. 

Returns
FitAssemblyDisplayStyle 

## ◆ LimitFitAssemblyDisplayStyle() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitAssemblyDisplayStyle
(
self,

fitAssemblyDisplayStyle )

Setter for property: (NXOpen.Annotations.FitAssemblyDisplayStyle) LimitFitAssemblyDisplayStyle. 

Sets the display style of fit tolerance for assembly dimensions. When the limit fit type is FIT, the display can be on a single line, or two lines centered with the dimension text or two lines with the shaft text in line with the dimension text. This property is obsolete.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

Deprecated
Deprecated in NX11.0.0. Use NXOpen::Annotations::DimensionStyleBuilder::SetLimitFitAssemblyNewDisplayStyle instead. 

## ◆ LimitFitAssemblyNewDisplayStyle() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitAssemblyNewDisplayStyle
(
self — )

Getter for property: (NXOpen.Annotations.FitAssemblyNewDisplayStyle) LimitFitAssemblyNewDisplayStyle Returns the new display style of fit tolerance for assembly dimensions. 

When the limit fit type is FIT, the display can be on a single line or double line

Getter License requirements: None.

Created in NX11.0.0 

Returns
FitAssemblyNewDisplayStyle 

## ◆ LimitFitAssemblyNewDisplayStyle() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitAssemblyNewDisplayStyle
(
self,

fitAssemblyDisplayStyle )

Setter for property: (NXOpen.Annotations.FitAssemblyNewDisplayStyle) LimitFitAssemblyNewDisplayStyle. 

Sets the new display style of fit tolerance for assembly dimensions. When the limit fit type is FIT, the display can be on a single line or double line

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX11.0.0 

## ◆ LimitFitDeviation() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitDeviation
(
self — )

Getter for property: (str) LimitFitDeviation Returns the dimension limit fit deviation. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
str 

## ◆ LimitFitDeviation() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitDeviation
(
self,

fitDeviation )

Setter for property: (str) LimitFitDeviation. 

Sets the dimension limit fit deviation

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ LimitFitDisplayAlignment() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitDisplayAlignment
(
self — )

Getter for property: (NXOpen.Annotations.FitDisplayAlignment) LimitFitDisplayAlignment Returns the dimension limit fit display alignment. 

When the limit fit type is FIT, the hole and shaft tolerances can be aligned as centered value, centered value and fit or bottom

Getter License requirements: None.

Created in NX11.0.0 

Returns
FitDisplayAlignment 

## ◆ LimitFitDisplayAlignment() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitDisplayAlignment
(
self,

fitDisplayAlignment )

Setter for property: (NXOpen.Annotations.FitDisplayAlignment) LimitFitDisplayAlignment. 

Sets the dimension limit fit display alignment. When the limit fit type is FIT, the hole and shaft tolerances can be aligned as centered value, centered value and fit or bottom

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX11.0.0 

## ◆ LimitFitDisplaySplitByDimline() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitDisplaySplitByDimline
(
self — )

Getter for property: (NXOpen.Annotations.FitDisplaySplitByDimline) LimitFitDisplaySplitByDimline Returns the dimension limit fit assembly display when split by dimension line. 

When the limit fit type is FIT or layout is SINGLE LINE, the hole and shaft tolerances can be shown without any split, splitting tolerance by the dimension line or splitting tolerance and value by the dimension line

Getter License requirements: None.

Created in NX11.0.0 

Returns
FitDisplaySplitByDimline 

## ◆ LimitFitDisplaySplitByDimline() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitDisplaySplitByDimline
(
self,

fitDisplaySplitByDimline )

Setter for property: (NXOpen.Annotations.FitDisplaySplitByDimline) LimitFitDisplaySplitByDimline. 

Sets the dimension limit fit assembly display when split by dimension line.

When the limit fit type is FIT or layout is SINGLE LINE, the hole and shaft tolerances can be shown without any split, splitting tolerance by the dimension line or splitting tolerance and value by the dimension line

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX11.0.0 

## ◆ LimitFitDisplayStyle() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitDisplayStyle
(
self — )

Getter for property: (NXOpen.Annotations.FitDisplayStyle) LimitFitDisplayStyle Returns the dimension limit fit display style. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
FitDisplayStyle 

## ◆ LimitFitDisplayStyle() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitDisplayStyle
(
self,

fitDisplayStyle )

Setter for property: (NXOpen.Annotations.FitDisplayStyle) LimitFitDisplayStyle. 

Sets the dimension limit fit display style

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ LimitFitGrade() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitGrade
(
self — )

Getter for property: (int) LimitFitGrade Returns the dimension limit fit grade. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
int 

## ◆ LimitFitGrade() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitGrade
(
self,

fitGrade )

Setter for property: (int) LimitFitGrade. 

Sets the dimension limit fit grade

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ LimitFitShaftDeviation() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitShaftDeviation
(
self — )

Getter for property: (str) LimitFitShaftDeviation Returns the shaft deviation for fit tolerance of a dimension. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
str 

## ◆ LimitFitShaftDeviation() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitShaftDeviation
(
self,

fitShaftDeviation )

Setter for property: (str) LimitFitShaftDeviation. 

Sets the shaft deviation for fit tolerance of a dimension

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ LimitFitShaftGrade() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitShaftGrade
(
self — )

Getter for property: (int) LimitFitShaftGrade Returns the shaft grade for fit tolerance of a dimension. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
int 

## ◆ LimitFitShaftGrade() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.LimitFitShaftGrade
(
self,

fitShaftGrade )

Setter for property: (int) LimitFitShaftGrade. 

Sets the shaft grade for fit tolerance of a dimension

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ LineBetweenArrows() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.LineBetweenArrows
(
self — )

Getter for property: (bool) LineBetweenArrows Returns the line between arrows. 

A value of True means a line is to be displayed between the arrows

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ LineBetweenArrows() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.LineBetweenArrows
(
self,

lineBetweenArrows )

Setter for property: (bool) LineBetweenArrows. 

Sets the line between arrows.

A value of True means a line is to be displayed between the arrows

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ LowerToleranceDegrees() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.LowerToleranceDegrees
(
self — )

Getter for property: (float) LowerToleranceDegrees Returns the lower angular tolerance in degrees. 

This value should be interpreted with the tolerance type from NXOpen::Annotations::DimensionStyleBuilder::ToleranceType .

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ LowerToleranceDegrees() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.LowerToleranceDegrees
(
self,

lowerToleranceDegrees )

Setter for property: (float) LowerToleranceDegrees. 

Sets the lower angular tolerance in degrees.

This value should be interpreted with the tolerance type from NXOpen::Annotations::DimensionStyleBuilder::ToleranceType .

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ LowerToleranceEnglish() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.LowerToleranceEnglish
(
self — )

Getter for property: (float) LowerToleranceEnglish Returns the lower english tolerance. 

This value should be interpreted with the tolerance type from NXOpen::Annotations::DimensionStyleBuilder::ToleranceType .

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ LowerToleranceEnglish() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.LowerToleranceEnglish
(
self,

lowerToleranceEnglish )

Setter for property: (float) LowerToleranceEnglish. 

Sets the lower english tolerance.

This value should be interpreted with the tolerance type from NXOpen::Annotations::DimensionStyleBuilder::ToleranceType .

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ LowerToleranceMetric() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.LowerToleranceMetric
(
self — )

Getter for property: (float) LowerToleranceMetric Returns the lower metric tolerance. 

This value should be interpreted with the tolerance type from NXOpen::Annotations::DimensionStyleBuilder::ToleranceType .

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ LowerToleranceMetric() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.LowerToleranceMetric
(
self,

lowerToleranceMetric )

Setter for property: (float) LowerToleranceMetric. 

Sets the lower metric tolerance.

This value should be interpreted with the tolerance type from NXOpen::Annotations::DimensionStyleBuilder::ToleranceType .

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ NarrowArrowType() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.NarrowArrowType
(
self — )

Getter for property: (NXOpen.Annotations.ArrowheadType) NarrowArrowType Returns the narrow dimension arrowhead type which is used when there is no space for normal arrowheads. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
ArrowheadType 

## ◆ NarrowArrowType() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.NarrowArrowType
(
self,

narrowArrowType )

Setter for property: (NXOpen.Annotations.ArrowheadType) NarrowArrowType. 

Sets the narrow dimension arrowhead type which is used when there is no space for normal arrowheads

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ NarrowDisplayType() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.NarrowDisplayType
(
self — )

Getter for property: (NXOpen.Annotations.NarrowDisplayOption) NarrowDisplayType Returns the display type for narrow dimensions. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NarrowDisplayOption 

## ◆ NarrowDisplayType() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.NarrowDisplayType
(
self,

narrowDisplayType )

Setter for property: (NXOpen.Annotations.NarrowDisplayOption) NarrowDisplayType. 

Sets the display type for narrow dimensions

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ NarrowLeaderAngle() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.NarrowLeaderAngle
(
self — )

Getter for property: (float) NarrowLeaderAngle Returns the narrow dimension leader angle. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ NarrowLeaderAngle() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.NarrowLeaderAngle
(
self,

narrowLeaderAngle )

Setter for property: (float) NarrowLeaderAngle. 

Sets the narrow dimension leader angle

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ NarrowTextOffset() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.NarrowTextOffset
(
self — )

Getter for property: (float) NarrowTextOffset Returns the narrow dimension text offset. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ NarrowTextOffset() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.NarrowTextOffset
(
self,

narrowTextOffset )

Setter for property: (float) NarrowTextOffset. 

Sets the narrow dimension text offset

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ NarrowTextOrientation() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.NarrowTextOrientation
(
self — )

Getter for property: (NXOpen.Annotations.NarrowTextOrientation) NarrowTextOrientation Returns the narrow dimension text orientation. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NarrowTextOrientation 

## ◆ NarrowTextOrientation() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.NarrowTextOrientation
(
self,

narrowTextOrientation )

Setter for property: (NXOpen.Annotations.NarrowTextOrientation) NarrowTextOrientation. 

Sets the narrow dimension text orientation

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ Orientation() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.Orientation
(
self — )

Getter for property: (NXOpen.Annotations.TextOrientation) Orientation Returns the dimension text orientation. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
TextOrientation 

## ◆ Orientation() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.Orientation
(
self,

orientation )

Setter for property: (NXOpen.Annotations.TextOrientation) Orientation. 

Sets the dimension text orientation

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ OverrideDimensionText() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.OverrideDimensionText
(
self — )

Getter for property: (bool) OverrideDimensionText Returns the override dimension text. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
bool 

## ◆ OverrideDimensionText() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.OverrideDimensionText
(
self,

overrideDimensionText )

Setter for property: (bool) OverrideDimensionText. 

Sets the override dimension text

Setter License requirements: None.

Created in NX10.0.0 

## ◆ PrefixSuffixReference() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.PrefixSuffixReference
(
self — )

Getter for property: (bool) PrefixSuffixReference Returns the flag indicating whether prefix suffix reference toggle is turned on or not. 

Getter License requirements: None.

Created in NX8.5.0 

Returns
bool 

## ◆ PrefixSuffixReference() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.PrefixSuffixReference
(
self,

prefixSuffixReference )

Setter for property: (bool) PrefixSuffixReference. 

Sets the flag indicating whether prefix suffix reference toggle is turned on or not

Setter License requirements: None.

Created in NX8.5.0 

## ◆ PrimaryDimensionFractionDenominator() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.PrimaryDimensionFractionDenominator
(
self — )

Getter for property: (NXOpen.Annotations.FractionDenominatorFormat) PrimaryDimensionFractionDenominator Returns the primary dimension fractional denominator. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
FractionDenominatorFormat 

## ◆ PrimaryDimensionFractionDenominator() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.PrimaryDimensionFractionDenominator
(
self,

primaryDimensionFractionDenominator )

Setter for property: (NXOpen.Annotations.FractionDenominatorFormat) PrimaryDimensionFractionDenominator. 

Sets the primary dimension fractional denominator

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ReferenceDimension() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.ReferenceDimension
(
self — )

Getter for property: (bool) ReferenceDimension Returns the reference dimension flag. 

Getter License requirements: None.

Created in NX6.0.0 

Deprecated
Deprecated in NX1953.0.0. Use NXOpen::Annotations::DimensionStyleBuilder::DimensionReferenceIncludeType and NXOpen::Annotations::DimensionStyleBuilder::ShowAsReferenceDimension instead. 

Returns
bool 

## ◆ ReferenceDimension() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.ReferenceDimension
(
self,

referenceDimension )

Setter for property: (bool) ReferenceDimension. 

Sets the reference dimension flag

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

Deprecated
Deprecated in NX1953.0.0. Use NXOpen::Annotations::DimensionStyleBuilder::SetDimensionReferenceIncludeType and NXOpen::Annotations::DimensionStyleBuilder::SetShowAsReferenceDimension instead. 

## ◆ ReferenceDimensionPrefix() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.ReferenceDimensionPrefix
(
self — )

Getter for property: (str) ReferenceDimensionPrefix Returns the prefix characters for reference dimension. 

Getter License requirements: None.

Created in NX8.5.0 

Returns
str 

## ◆ ReferenceDimensionPrefix() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.ReferenceDimensionPrefix
(
self,

prefix )

Setter for property: (str) ReferenceDimensionPrefix. 

Sets the prefix characters for reference dimension

Setter License requirements: None.

Created in NX8.5.0 

## ◆ ReferenceDimensionSuffix() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.ReferenceDimensionSuffix
(
self — )

Getter for property: (str) ReferenceDimensionSuffix Returns the suffix characters for reference dimension. 

Getter License requirements: None.

Created in NX8.5.0 

Returns
str 

## ◆ ReferenceDimensionSuffix() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.ReferenceDimensionSuffix
(
self,

suffix )

Setter for property: (str) ReferenceDimensionSuffix. 

Sets the suffix characters for reference dimension

Setter License requirements: None.

Created in NX8.5.0 

## ◆ ReverseArrowDirection() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.ReverseArrowDirection
(
self — )

Getter for property: (bool) ReverseArrowDirection Returns the reverse arrow direction flag. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
bool 

## ◆ ReverseArrowDirection() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.ReverseArrowDirection
(
self,

reverseArrowDirection )

Setter for property: (bool) ReverseArrowDirection. 

Sets the reverse arrow direction flag

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ SeparateBrackets() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.SeparateBrackets
(
self — )

Getter for property: (bool) SeparateBrackets Returns the separate brackets with show as reference. 

Getter License requirements: None.

Created in NX2312.0.0 

Returns
bool 

## ◆ SeparateBrackets() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.SeparateBrackets
(
self,

separateBrackets )

Setter for property: (bool) SeparateBrackets. 

Sets the separate brackets with show as reference

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2312.0.0 

## ◆ SetOverriddenDimensionText()

NXOpen.Annotations.DimensionStyleBuilder.SetOverriddenDimensionText
(
self,

customizedText )

Sets the overridden dimension text value. 

Created in NX10.0.0 

License requirements: None.

Parameters

customizedText — (List[str])

## ◆ ShowAsReferenceDimension() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.ShowAsReferenceDimension
(
self — )

Getter for property: (bool) ShowAsReferenceDimension Returns the show as reference dimension flag. 

Getter License requirements: None.

Created in NX1953.0.0 

Returns
bool 

## ◆ ShowAsReferenceDimension() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.ShowAsReferenceDimension
(
self,

showAsreference )

Setter for property: (bool) ShowAsReferenceDimension. 

Sets the show as reference dimension flag

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX1953.0.0 

## ◆ SingleLimitOffsetIncludeFlag() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.SingleLimitOffsetIncludeFlag
(
self — )

Getter for property: (bool) SingleLimitOffsetIncludeFlag Returns the single limit offset option to add the value to or subtract the value from the size of the dimension. 

This value should be interpreted with the value from NXOpen::Annotations::DimensionStyleBuilder::SingleLimitOffsetValueEnglish or NXOpen::Annotations::DimensionStyleBuilder::SingleLimitOffsetValueMetric .

Getter License requirements: None.

Created in NX2312.0.0 

Returns
bool 

## ◆ SingleLimitOffsetIncludeFlag() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.SingleLimitOffsetIncludeFlag
(
self,

isSingleLimitOffSetIncluded )

Setter for property: (bool) SingleLimitOffsetIncludeFlag. 

Sets the single limit offset option to add the value to or subtract the value from the size of the dimension.

This value should be interpreted with the value from NXOpen::Annotations::DimensionStyleBuilder::SingleLimitOffsetValueEnglish or NXOpen::Annotations::DimensionStyleBuilder::SingleLimitOffsetValueMetric .

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2312.0.0 

## ◆ SingleLimitOffsetValueEnglish() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.SingleLimitOffsetValueEnglish
(
self — )

Getter for property: (float) SingleLimitOffsetValueEnglish Returns the single limit offset english value to add to or subtract from the size of the dimension. 

This value should be interpreted with the option from NXOpen::Annotations::DimensionStyleBuilder::SingleLimitOffsetIncludeFlag .

Getter License requirements: None.

Created in NX2312.0.0 

Returns
float 

## ◆ SingleLimitOffsetValueEnglish() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.SingleLimitOffsetValueEnglish
(
self,

singleLimitOffSetValueEnglish )

Setter for property: (float) SingleLimitOffsetValueEnglish. 

Sets the single limit offset english value to add to or subtract from the size of the dimension.

This value should be interpreted with the option from NXOpen::Annotations::DimensionStyleBuilder::SingleLimitOffsetIncludeFlag .

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2312.0.0 

## ◆ SingleLimitOffsetValueMetric() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.SingleLimitOffsetValueMetric
(
self — )

Getter for property: (float) SingleLimitOffsetValueMetric Returns the single limit offset metric value to add to or subtract from the size of the dimension. 

This value should be interpreted with the option from NXOpen::Annotations::DimensionStyleBuilder::SingleLimitOffsetIncludeFlag .

Getter License requirements: None.

Created in NX2312.0.0 

Returns
float 

## ◆ SingleLimitOffsetValueMetric() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.SingleLimitOffsetValueMetric
(
self,

singleLimitOffSetValueMetric )

Setter for property: (float) SingleLimitOffsetValueMetric. 

Sets the single limit offset metric value to add to or subtract from the size of the dimension.

This value should be interpreted with the option from NXOpen::Annotations::DimensionStyleBuilder::SingleLimitOffsetIncludeFlag .

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2312.0.0 

## ◆ TextAngle() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.TextAngle
(
self — )

Getter for property: (float) TextAngle Returns the dimension text angle. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ TextAngle() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.TextAngle
(
self,

textAngle )

Setter for property: (float) TextAngle. 

Sets the dimension text angle

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ TextArrowPlacement() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.TextArrowPlacement
(
self — )

Getter for property: (NXOpen.Annotations.TextPlacement) TextArrowPlacement Returns the text arrow placement. 

This specifies manual or automatic placement and display of arrows in or out

Getter License requirements: None.

Created in NX6.0.0 

Returns
TextPlacement 

## ◆ TextArrowPlacement() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.TextArrowPlacement
(
self,

textArrowPlacement )

Setter for property: (NXOpen.Annotations.TextPlacement) TextArrowPlacement. 

Sets the text arrow placement.

This specifies manual or automatic placement and display of arrows in or out

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ TextCentered() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.TextCentered
(
self — )

Getter for property: (bool) TextCentered Returns the dimension text centered option. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
bool 

## ◆ TextCentered() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.TextCentered
(
self,

textCentered )

Setter for property: (bool) TextCentered. 

Sets the dimension text centered option

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX11.0.0 

## ◆ TextPosition() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.TextPosition
(
self — )

Getter for property: (NXOpen.Annotations.TextPosition) TextPosition Returns the dimension text position representing above or after stub. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
TextPosition 

## ◆ TextPosition() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.TextPosition
(
self,

position )

Setter for property: (NXOpen.Annotations.TextPosition) TextPosition. 

Sets the dimension text position representing above or after stub

Setter License requirements: None.

Created in NX9.0.0 

## ◆ ToleranceType() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.ToleranceType
(
self — )

Getter for property: (NXOpen.Annotations.ToleranceType) ToleranceType Returns the dimension tolerance type. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
ToleranceType 

## ◆ ToleranceType() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.ToleranceType
(
self,

dimToleranceType )

Setter for property: (NXOpen.Annotations.ToleranceType) ToleranceType. 

Sets the dimension tolerance type

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ToleranceValuePrecision() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.ToleranceValuePrecision
(
self — )

Getter for property: (int) ToleranceValuePrecision Returns the tolerance value precision. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
int 

## ◆ ToleranceValuePrecision() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.ToleranceValuePrecision
(
self,

toleranceValuePrecision )

Setter for property: (int) ToleranceValuePrecision. 

Sets the tolerance value precision

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ TrimDimLine() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.TrimDimLine
(
self — )

Getter for property: (NXOpen.Annotations.TrimDimensionLineStyle) TrimDimLine Returns the trim dimension line flag. 

A value of True means the dimension line will be trimmed when the text crosses both extension lines

Getter License requirements: None.

Created in NX6.0.0 

Returns
TrimDimensionLineStyle 

## ◆ TrimDimLine() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.TrimDimLine
(
self,

trimDimLine )

Setter for property: (NXOpen.Annotations.TrimDimensionLineStyle) TrimDimLine. 

Sets the trim dimension line flag.

A value of True means the dimension line will be trimmed when the text crosses both extension lines

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ TrueLengthText() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.TrueLengthText
(
self — )

Getter for property: (str) TrueLengthText Returns the true length dimension text. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
str 

## ◆ TrueLengthText() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.TrueLengthText
(
self,

trueLengthText )

Setter for property: (str) TrueLengthText. 

Sets the true length dimension text

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ TrueLengthTextPosition() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.TrueLengthTextPosition
(
self — )

Getter for property: (NXOpen.Annotations.TrueLengthTextPosition) TrueLengthTextPosition Returns the true length text position. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
TrueLengthTextPosition 

## ◆ TrueLengthTextPosition() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.TrueLengthTextPosition
(
self,

trueLengthTextPosition )

Setter for property: (NXOpen.Annotations.TrueLengthTextPosition) TrueLengthTextPosition. 

Sets the true length text position

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ UpperToleranceDegrees() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.UpperToleranceDegrees
(
self — )

Getter for property: (float) UpperToleranceDegrees Returns the upper angular tolerance in degrees. 

This value should be interpreted with the tolerance type from NXOpen::Annotations::DimensionStyleBuilder::ToleranceType .

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ UpperToleranceDegrees() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.UpperToleranceDegrees
(
self,

upperToleranceDegrees )

Setter for property: (float) UpperToleranceDegrees. 

Sets the upper angular tolerance in degrees.

This value should be interpreted with the tolerance type from NXOpen::Annotations::DimensionStyleBuilder::ToleranceType .

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ UpperToleranceEnglish() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.UpperToleranceEnglish
(
self — )

Getter for property: (float) UpperToleranceEnglish Returns the upper english tolerance. 

This value should be interpreted with the tolerance type from NXOpen::Annotations::DimensionStyleBuilder::ToleranceType .

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ UpperToleranceEnglish() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.UpperToleranceEnglish
(
self,

upperToleranceEnglish )

Setter for property: (float) UpperToleranceEnglish. 

Sets the upper english tolerance.

This value should be interpreted with the tolerance type from NXOpen::Annotations::DimensionStyleBuilder::ToleranceType .

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ UpperToleranceMetric() [1/2]

NXOpen.Annotations.DimensionStyleBuilder.UpperToleranceMetric
(
self — )

Getter for property: (float) UpperToleranceMetric Returns the upper metric tolerance. 

This value should be interpreted with the tolerance type from NXOpen::Annotations::DimensionStyleBuilder::ToleranceType .

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ UpperToleranceMetric() [2/2]

NXOpen.Annotations.DimensionStyleBuilder.UpperToleranceMetric
(
self,

upperToleranceMetric )

Setter for property: (float) UpperToleranceMetric. 

Sets the upper metric tolerance.

This value should be interpreted with the tolerance type from NXOpen::Annotations::DimensionStyleBuilder::ToleranceType .

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

Copyright 2025 Siemens
