# NXOpen.Annotations.HoleTableSettingsLabelBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00169.html>

## Classes

class — IndexType

Represents Index Options 

Enumerator — Comment

HoleTypeSymbolAndNumber — Hole Type Symbol and Number

Number — Number

LetterAndNumber — Letter and Number

More...

class — RelativeLocationType

Represents Relative Location Options 

Enumerator — Comment

TopLeft — Top Left

TopMiddle — Top Middle

TopRight — Top Right

CenterLeft — Center Left

Center — Center

CenterRight — Center Right

BottomLeft — Bottom Left

BottomMiddle — Bottom Middle

BottomRight — Bottom Right

More...

Copyright 2025 Siemens
