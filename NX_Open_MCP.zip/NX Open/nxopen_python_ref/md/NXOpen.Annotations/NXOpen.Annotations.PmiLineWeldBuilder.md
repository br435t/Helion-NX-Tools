# NXOpen.Annotations.PmiLineWeldBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13617.html>

Represents a NXOpen::Annotations::PmiLineWeld builder 

To create a new instance of this class, use NXOpen::Annotations::WeldCollection::CreatePmiLineWeldBuilder 

Default values. 
More...

Inheritance diagram for NXOpen.Annotations.PmiLineWeldBuilder:

## Public Member Functions

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the NXOpen::Annotations::AssociatedObjectsBuilder for weld symbol. 

Public Member Functions inherited from NXOpen.Annotations.LineWeldBuilder

ArrowSideWeldData (self)

Getter for property: (NXOpen.Annotations.LineWeldDataBuilder) ArrowSideWeldData Returns the NXOpen::Annotations::LineWeldDataBuilder for the arrow side of the weld symbol. 

FieldWeld (self)

Getter for property: (NXOpen.Annotations.LineWeldBuilder.FieldWeldType) FieldWeld Returns the field indicating the weld is done at the field site. 

FieldWeld (self, fieldWeld)

Setter for property: (NXOpen.Annotations.LineWeldBuilder.FieldWeldType) FieldWeld. 

FlipDirection (self)

Getter for property: (bool) FlipDirection Returns the flip direction for top seam. 

FlipDirection (self, flipDirection)

Setter for property: (bool) FlipDirection. 

FlipHorizontal (self)

Getter for property: (bool) FlipHorizontal Returns the flip horizontal direction for side seam. 

FlipHorizontal (self, flipHorizontal)

Setter for property: (bool) FlipHorizontal. 

FlipVertical (self)

Getter for property: (bool) FlipVertical Returns the flip vertical direction for side seam. 

FlipVertical (self, flipVertical)

Setter for property: (bool) FlipVertical. 

ForeshorteningSymbol (self)

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

GetReference (self)

Returns the reference or specification text. 

IdLine (self)

Getter for property: (NXOpen.Annotations.LineWeldBuilder.IdLineType) IdLine Returns the identification or reference line. 

IdLine (self, idLine)

Setter for property: (NXOpen.Annotations.LineWeldBuilder.IdLineType) IdLine. 

Inherit (self)

Getter for property: (NXOpen.SelectDisplayableObject) Inherit Returns the weld symbol from which the style properties are inherited. 

InheritProperties (self, annotation)

This inherits the properties from the existing weld symbol. 

InheritPropertiesFromWeldFeature (self, feature)

This inherits the properties from the existing weld feature. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for weld symbol. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the NXOpen::Annotations::OriginBuilder for the weld symbol. 

OtherSideWeldData (self)

Getter for property: (NXOpen.Annotations.LineWeldDataBuilder) OtherSideWeldData Returns the NXOpen::Annotations::LineWeldDataBuilder for the other side of the weld symbol. 

Scale (self)

Getter for property: (float) Scale Returns the scaling factor for the welding symbol. 

Scale (self, scale)

Setter for property: (float) Scale. 

SetReference (self, reference)

Sets the reference or specification text. 

SideSeamObjects (self)

Getter for property: (NXOpen.SelectDisplayableObjectList) SideSeamObjects Returns the side seam object. 

SpaceFactor (self)

Getter for property: (float) SpaceFactor Returns the space factor for the welding symbol. 

SpaceFactor (self, spaceFactor)

Setter for property: (float) SpaceFactor. 

StaggeredWeld (self)

Getter for property: (NXOpen.Annotations.LineWeldBuilder.StaggeredWeldType) StaggeredWeld Returns the staggered weld. 

StaggeredWeld (self, staggeredWeld)

Setter for property: (NXOpen.Annotations.LineWeldBuilder.StaggeredWeldType) StaggeredWeld. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the NXOpen::Annotations::StyleBuilder for the weld symbol. 

Tail (self)

Getter for property: (NXOpen.Annotations.LineWeldBuilder.TailType) Tail Returns the weld tail. 

Tail (self, tail)

Setter for property: (NXOpen.Annotations.LineWeldBuilder.TailType) Tail. 

TopSeamObject (self)

Getter for property: (NXOpen.SelectDisplayableObject) TopSeamObject Returns the top seam object. 

WeldAlongContour (self)

Getter for property: (NXOpen.Annotations.LineWeldBuilder.WeldSymbolWeldAlongContourType) WeldAlongContour Returns the weld along contour option. 

WeldAlongContour (self, alongContour)

Setter for property: (NXOpen.Annotations.LineWeldBuilder.WeldSymbolWeldAlongContourType) WeldAlongContour. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.Annotations.LineWeldBuilder

LineWeldBuilderFieldWeldType = LineWeldBuilder.FieldWeldType

NXOpen.Annotations.LineWeldBuilderFieldWeldType is an alias for NXOpen.Annotations.LineWeldBuilder.FieldWeldType 

LineWeldBuilderIdLineType = LineWeldBuilder.IdLineType

NXOpen.Annotations.LineWeldBuilderIdLineType is an alias for NXOpen.Annotations.LineWeldBuilder.IdLineType 

LineWeldBuilderStaggeredWeldType = LineWeldBuilder.StaggeredWeldType

NXOpen.Annotations.LineWeldBuilderStaggeredWeldType is an alias for NXOpen.Annotations.LineWeldBuilder.StaggeredWeldType 

LineWeldBuilderTailType = LineWeldBuilder.TailType

NXOpen.Annotations.LineWeldBuilderTailType is an alias for NXOpen.Annotations.LineWeldBuilder.TailType 

LineWeldBuilderWeldSymbolWeldAlongContourType = LineWeldBuilder.WeldSymbolWeldAlongContourType

NXOpen.Annotations.LineWeldBuilderWeldSymbolWeldAlongContourType is an alias for NXOpen.Annotations.LineWeldBuilder.WeldSymbolWeldAlongContourType 

## Detailed Description

Represents a NXOpen::Annotations::PmiLineWeld builder 

To create a new instance of this class, use NXOpen::Annotations::WeldCollection::CreatePmiLineWeldBuilder 

Default values. 

Property — Value

FieldWeld 

Plain 

FlipDirection 

False 

FlipHorizontal 

False 

FlipVertical 

False 

IdLine 

Plain 

Scale 

1 

StaggeredWeld 

NoStaggeredSymbol 

Tail 

NoTail 

WeldAlongContour 

None 

Created in NX6.0.0 

## Member Function Documentation

## ◆ AssociatedObjects()

NXOpen.Annotations.PmiLineWeldBuilder.AssociatedObjects
(
self — )

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the NXOpen::Annotations::AssociatedObjectsBuilder for weld symbol. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
AssociatedObjectsBuilder 

Copyright 2025 Siemens
