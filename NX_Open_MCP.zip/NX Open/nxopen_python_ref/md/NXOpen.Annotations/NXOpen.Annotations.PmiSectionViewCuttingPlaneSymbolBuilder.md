# NXOpen.Annotations.PmiSectionViewCuttingPlaneSymbolBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00202.html>

## Classes

class — ArrowDirectionOptions

The arrow direction options for cutting plane symbol 

Enumerator — Comment

TowardPlane — toward plane

AwayfromPlane — away from plane

More...

class — TextPlaneRelativeToArrowOptions

The text plane relative to arrow options for cutting plane symbol 

Enumerator — Comment

Parallel — parallel

Perpendicular — perpendicular

More...

class — ViewNameFormatOption

Represents whether the view name is derived from the PMI cutting plane symbol text. More...

Copyright 2025 Siemens
