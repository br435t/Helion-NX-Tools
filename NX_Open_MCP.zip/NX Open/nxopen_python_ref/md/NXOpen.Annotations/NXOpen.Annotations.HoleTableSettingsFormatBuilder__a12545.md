# NXOpen.Annotations.HoleTableSettingsFormatBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12545.html>

Represents a NXOpen::Annotations::HoleTableSettingsFormatBuilder. 
More...

Inheritance diagram for NXOpen.Annotations.HoleTableSettingsFormatBuilder:

## Public Member Functions

DecimalPlaces (self)

Getter for property: (int) DecimalPlaces Returns the decimal places. 

DecimalPlaces (self, decimalPlaces)

Setter for property: (int) DecimalPlaces. 

DeletedHolesDisplay (self)

Getter for property: (NXOpen.Annotations.HoleTableSettingsFormatBuilder.DeletedHolesDisplayType) DeletedHolesDisplay Returns the deleted holes display. 

DeletedHolesDisplay (self, deletedHolesDisplay)

Setter for property: (NXOpen.Annotations.HoleTableSettingsFormatBuilder.DeletedHolesDisplayType) DeletedHolesDisplay. 

DepthMeasurementDatum (self)

Getter for property: (NXOpen.Annotations.HoleTableSettingsFormatBuilder.DepthMeasurementDatumType) DepthMeasurementDatum Returns the depth measurement datum. 

DepthMeasurementDatum (self, depthMeasurementDatum)

Setter for property: (NXOpen.Annotations.HoleTableSettingsFormatBuilder.DepthMeasurementDatumType) DepthMeasurementDatum. 

DisplayAllTextInUpperCase (self)

Getter for property: (bool) DisplayAllTextInUpperCase Returns the display all text in upper case. 

DisplayAllTextInUpperCase (self, displayAllTextInUpperCase)

Setter for property: (bool) DisplayAllTextInUpperCase. 

DisplayPartBodyName (self)

Getter for property: (bool) DisplayPartBodyName Returns the display part and body name. 

DisplayPartBodyName (self, displayPartBodyName)

Setter for property: (bool) DisplayPartBodyName. 

MergeCellsWithSameSize (self)

Getter for property: (bool) MergeCellsWithSameSize Returns the merge cells with same size. 

MergeCellsWithSameSize (self, mergeCellsWithSameSize)

Setter for property: (bool) MergeCellsWithSameSize. 

ReportTapHoleSizeForThreadedHoles (self)

Getter for property: (bool) ReportTapHoleSizeForThreadedHoles Returns the report tap hole size for threaded holes. 

ReportTapHoleSizeForThreadedHoles (self, reportTapHoleSizeForThreadedHoles)

Setter for property: (bool) ReportTapHoleSizeForThreadedHoles. 

ShowColumns (self)

Getter for property: (NXOpen.Annotations.HoleTableSettingsFormatBuilder.ShowColumnsType) ShowColumns Returns the show columns. 

ShowColumns (self, showColumns)

Setter for property: (NXOpen.Annotations.HoleTableSettingsFormatBuilder.ShowColumnsType) ShowColumns. 

SizeFormat (self)

Getter for property: (NXOpen.Annotations.HoleTableSettingsFormatBuilder.SizeFormatType) SizeFormat Returns the size format. 

SizeFormat (self, sizeFormat)

Setter for property: (NXOpen.Annotations.HoleTableSettingsFormatBuilder.SizeFormatType) SizeFormat. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

HoleTableSettingsFormatBuilderDeletedHolesDisplayType = HoleTableSettingsFormatBuilder.DeletedHolesDisplayType

NXOpen.Annotations.HoleTableSettingsFormatBuilderDeletedHolesDisplayType is an alias for NXOpen.Annotations.HoleTableSettingsFormatBuilder.DeletedHolesDisplayType 

HoleTableSettingsFormatBuilderDepthMeasurementDatumType = HoleTableSettingsFormatBuilder.DepthMeasurementDatumType

NXOpen.Annotations.HoleTableSettingsFormatBuilderDepthMeasurementDatumType is an alias for NXOpen.Annotations.HoleTableSettingsFormatBuilder.DepthMeasurementDatumType 

HoleTableSettingsFormatBuilderShowColumnsType = HoleTableSettingsFormatBuilder.ShowColumnsType

NXOpen.Annotations.HoleTableSettingsFormatBuilderShowColumnsType is an alias for NXOpen.Annotations.HoleTableSettingsFormatBuilder.ShowColumnsType 

HoleTableSettingsFormatBuilderSizeFormatType = HoleTableSettingsFormatBuilder.SizeFormatType

NXOpen.Annotations.HoleTableSettingsFormatBuilderSizeFormatType is an alias for NXOpen.Annotations.HoleTableSettingsFormatBuilder.SizeFormatType 

## Detailed Description

Represents a NXOpen::Annotations::HoleTableSettingsFormatBuilder. 

Created in NX9.0.0 

## Member Function Documentation

## ◆ DecimalPlaces() [1/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.DecimalPlaces
(
self — )

Getter for property: (int) DecimalPlaces Returns the decimal places. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
int 

## ◆ DecimalPlaces() [2/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.DecimalPlaces
(
self,

decimalPlaces )

Setter for property: (int) DecimalPlaces. 

Sets the decimal places

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ DeletedHolesDisplay() [1/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.DeletedHolesDisplay
(
self — )

Getter for property: (NXOpen.Annotations.HoleTableSettingsFormatBuilder.DeletedHolesDisplayType) DeletedHolesDisplay Returns the deleted holes display. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
HoleTableSettingsFormatBuilder.DeletedHolesDisplayType 

## ◆ DeletedHolesDisplay() [2/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.DeletedHolesDisplay
(
self,

deletedHolesDisplay )

Setter for property: (NXOpen.Annotations.HoleTableSettingsFormatBuilder.DeletedHolesDisplayType) DeletedHolesDisplay. 

Sets the deleted holes display

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ DepthMeasurementDatum() [1/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.DepthMeasurementDatum
(
self — )

Getter for property: (NXOpen.Annotations.HoleTableSettingsFormatBuilder.DepthMeasurementDatumType) DepthMeasurementDatum Returns the depth measurement datum. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
HoleTableSettingsFormatBuilder.DepthMeasurementDatumType 

## ◆ DepthMeasurementDatum() [2/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.DepthMeasurementDatum
(
self,

depthMeasurementDatum )

Setter for property: (NXOpen.Annotations.HoleTableSettingsFormatBuilder.DepthMeasurementDatumType) DepthMeasurementDatum. 

Sets the depth measurement datum

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ DisplayAllTextInUpperCase() [1/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.DisplayAllTextInUpperCase
(
self — )

Getter for property: (bool) DisplayAllTextInUpperCase Returns the display all text in upper case. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ DisplayAllTextInUpperCase() [2/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.DisplayAllTextInUpperCase
(
self,

displayAllTextInUpperCase )

Setter for property: (bool) DisplayAllTextInUpperCase. 

Sets the display all text in upper case

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ DisplayPartBodyName() [1/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.DisplayPartBodyName
(
self — )

Getter for property: (bool) DisplayPartBodyName Returns the display part and body name. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ DisplayPartBodyName() [2/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.DisplayPartBodyName
(
self,

displayPartBodyName )

Setter for property: (bool) DisplayPartBodyName. 

Sets the display part and body name

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ MergeCellsWithSameSize() [1/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.MergeCellsWithSameSize
(
self — )

Getter for property: (bool) MergeCellsWithSameSize Returns the merge cells with same size. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ MergeCellsWithSameSize() [2/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.MergeCellsWithSameSize
(
self,

mergeCellsWithSameSize )

Setter for property: (bool) MergeCellsWithSameSize. 

Sets the merge cells with same size

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ ReportTapHoleSizeForThreadedHoles() [1/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.ReportTapHoleSizeForThreadedHoles
(
self — )

Getter for property: (bool) ReportTapHoleSizeForThreadedHoles Returns the report tap hole size for threaded holes. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ ReportTapHoleSizeForThreadedHoles() [2/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.ReportTapHoleSizeForThreadedHoles
(
self,

reportTapHoleSizeForThreadedHoles )

Setter for property: (bool) ReportTapHoleSizeForThreadedHoles. 

Sets the report tap hole size for threaded holes

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ ShowColumns() [1/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.ShowColumns
(
self — )

Getter for property: (NXOpen.Annotations.HoleTableSettingsFormatBuilder.ShowColumnsType) ShowColumns Returns the show columns. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
HoleTableSettingsFormatBuilder.ShowColumnsType 

## ◆ ShowColumns() [2/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.ShowColumns
(
self,

showColumns )

Setter for property: (NXOpen.Annotations.HoleTableSettingsFormatBuilder.ShowColumnsType) ShowColumns. 

Sets the show columns

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ SizeFormat() [1/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.SizeFormat
(
self — )

Getter for property: (NXOpen.Annotations.HoleTableSettingsFormatBuilder.SizeFormatType) SizeFormat Returns the size format. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
HoleTableSettingsFormatBuilder.SizeFormatType 

## ◆ SizeFormat() [2/2]

NXOpen.Annotations.HoleTableSettingsFormatBuilder.SizeFormat
(
self,

sizeFormat )

Setter for property: (NXOpen.Annotations.HoleTableSettingsFormatBuilder.SizeFormatType) SizeFormat. 

Sets the size format

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## Member Data Documentation

## ◆ HoleTableSettingsFormatBuilderDeletedHolesDisplayType

NXOpen.Annotations.HoleTableSettingsFormatBuilder.HoleTableSettingsFormatBuilderDeletedHolesDisplayType = HoleTableSettingsFormatBuilder.DeletedHolesDisplayType

NXOpen.Annotations.HoleTableSettingsFormatBuilderDeletedHolesDisplayType is an alias for NXOpen.Annotations.HoleTableSettingsFormatBuilder.DeletedHolesDisplayType 

## ◆ HoleTableSettingsFormatBuilderDepthMeasurementDatumType

NXOpen.Annotations.HoleTableSettingsFormatBuilder.HoleTableSettingsFormatBuilderDepthMeasurementDatumType = HoleTableSettingsFormatBuilder.DepthMeasurementDatumType

NXOpen.Annotations.HoleTableSettingsFormatBuilderDepthMeasurementDatumType is an alias for NXOpen.Annotations.HoleTableSettingsFormatBuilder.DepthMeasurementDatumType 

## ◆ HoleTableSettingsFormatBuilderShowColumnsType

NXOpen.Annotations.HoleTableSettingsFormatBuilder.HoleTableSettingsFormatBuilderShowColumnsType = HoleTableSettingsFormatBuilder.ShowColumnsType

NXOpen.Annotations.HoleTableSettingsFormatBuilderShowColumnsType is an alias for NXOpen.Annotations.HoleTableSettingsFormatBuilder.ShowColumnsType 

## ◆ HoleTableSettingsFormatBuilderSizeFormatType

NXOpen.Annotations.HoleTableSettingsFormatBuilder.HoleTableSettingsFormatBuilderSizeFormatType = HoleTableSettingsFormatBuilder.SizeFormatType

NXOpen.Annotations.HoleTableSettingsFormatBuilderSizeFormatType is an alias for NXOpen.Annotations.HoleTableSettingsFormatBuilder.SizeFormatType 

Copyright 2025 Siemens
