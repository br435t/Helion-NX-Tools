# NXOpen.Annotations.PmiDimensionData Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00192.html>

## Classes

class — DimensionType

Specifies PMI dimension types 

Enumerator — Comment

NotSet — None

Chamfer — Chamfer dimension type

Radial — Radial dimension type

Linear — Linear dimension type

Angular — Angular dimension type

CurveLength — Curve length dimension type

Holecallout — Holecallout dimension type

More...

Copyright 2025 Siemens
