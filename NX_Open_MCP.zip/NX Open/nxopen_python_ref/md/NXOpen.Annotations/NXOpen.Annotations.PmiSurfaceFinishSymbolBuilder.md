# NXOpen.Annotations.PmiSurfaceFinishSymbolBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13861.html>

Represents builder for Pmi Surface Finish Symbol 

To create a new instance of this class, use NXOpen::Annotations::PmiSurfaceFinishSymbolCollection::CreatePmiSurfaceFinishSymbolBuilder 

More...

Inheritance diagram for NXOpen.Annotations.PmiSurfaceFinishSymbolBuilder:

## Public Member Functions

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the select associated objects. 

Public Member Functions inherited from NXOpen.Annotations.BaseSurfaceFinishSymbolBuilder

A1 (self)

Getter for property: (str) A1 Returns the a1. 

A1 (self, a1)

Setter for property: (str) A1. 

A2 (self)

Getter for property: (str) A2 Returns the a2. 

A2 (self, a2)

Setter for property: (str) A2. 

Angle (self)

Getter for property: (float) Angle Returns the angle. 

Angle (self, angle)

Setter for property: (float) Angle. 

B (self)

Getter for property: (str) B Returns the b. 

B (self, b)

Setter for property: (str) B. 

C (self)

Getter for property: (str) C Returns the c. 

C (self, c)

Setter for property: (str) C. 

D (self)

Getter for property: (str) D Returns the d. 

D (self, d)

Setter for property: (str) D. 

E (self)

Getter for property: (str) E Returns the e. 

E (self, e)

Setter for property: (str) E. 

F1 (self)

Getter for property: (str) F1 Returns the f1. 

F1 (self, f1)

Setter for property: (str) F1. 

F2 (self)

Getter for property: (str) F2 Returns the f2. 

F2 (self, f2)

Setter for property: (str) F2. 

Finish (self)

Getter for property: (NXOpen.Annotations.BaseSurfaceFinishSymbolBuilder.SymbolType) Finish Returns the finish. 

Finish (self, finish)

Setter for property: (NXOpen.Annotations.BaseSurfaceFinishSymbolBuilder.SymbolType) Finish. 

G (self)

Getter for property: (str) G Returns the g. 

G (self, g)

Setter for property: (str) G. 

Inherit (self)

Getter for property: (NXOpen.Annotations.SelectBaseSurfaceFinishSymbol) Inherit Returns the inherit. 

InheritFrom (self, inheritTag)

The drafting surface finish is inherited form existing drafting surface finish. 

InvertSymbol (self)

Getter for property: (bool) InvertSymbol Returns the invert symbol. 

InvertSymbol (self, invertSymbol)

Setter for property: (bool) InvertSymbol. 

InvertText (self)

Getter for property: (bool) InvertText Returns the invert text. 

InvertText (self, invertText)

Setter for property: (bool) InvertText. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the Annotations::LeaderBuilder for the annotation. 

LowerTolerance (self)

Getter for property: (float) LowerTolerance Returns the lower tolerance. 

LowerTolerance (self, lowerTolerance)

Setter for property: (float) LowerTolerance. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

Parentheses (self)

Getter for property: (NXOpen.Annotations.BaseSurfaceFinishSymbolBuilder.ParenthesesType) Parentheses Returns the parentheses. 

Parentheses (self, parentheses)

Setter for property: (NXOpen.Annotations.BaseSurfaceFinishSymbolBuilder.ParenthesesType) Parentheses. 

ProfileAngle (self)

Getter for property: (str) ProfileAngle Returns the profile direction angle. 

ProfileAngle (self, angle)

Setter for property: (str) ProfileAngle. 

ProfileDirection (self)

Getter for property: (NXOpen.Annotations.BaseSurfaceFinishSymbolBuilder.ProfileDirectionEnum) ProfileDirection Returns the profile direction. 

ProfileDirection (self, u)

Setter for property: (NXOpen.Annotations.BaseSurfaceFinishSymbolBuilder.ProfileDirectionEnum) ProfileDirection. 

SingleRoughnessValue (self)

Getter for property: (bool) SingleRoughnessValue Returns the single roughness value. 

SingleRoughnessValue (self, singleRoughnessValue)

Setter for property: (bool) SingleRoughnessValue. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

Tolerance (self)

Getter for property: (float) Tolerance Returns the tolerance in case of bilateral tolerance type otherwise upper tolerance. 

Tolerance (self, tolerance)

Setter for property: (float) Tolerance. 

ToleranceType (self)

Getter for property: (NXOpen.Annotations.BaseSurfaceFinishSymbolBuilder.ToleranceTypeEnum) ToleranceType Returns the tolerance type. 

ToleranceType (self, toleranceType)

Setter for property: (NXOpen.Annotations.BaseSurfaceFinishSymbolBuilder.ToleranceTypeEnum) ToleranceType. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.Annotations.BaseSurfaceFinishSymbolBuilder

BaseSurfaceFinishSymbolBuilderParenthesesType = BaseSurfaceFinishSymbolBuilder.ParenthesesType

NXOpen.Annotations.BaseSurfaceFinishSymbolBuilderParenthesesType is an alias for NXOpen.Annotations.BaseSurfaceFinishSymbolBuilder.ParenthesesType 

BaseSurfaceFinishSymbolBuilderProfileDirectionEnum = BaseSurfaceFinishSymbolBuilder.ProfileDirectionEnum

NXOpen.Annotations.BaseSurfaceFinishSymbolBuilderProfileDirectionEnum is an alias for NXOpen.Annotations.BaseSurfaceFinishSymbolBuilder.ProfileDirectionEnum 

BaseSurfaceFinishSymbolBuilderSymbolType = BaseSurfaceFinishSymbolBuilder.SymbolType

NXOpen.Annotations.BaseSurfaceFinishSymbolBuilderSymbolType is an alias for NXOpen.Annotations.BaseSurfaceFinishSymbolBuilder.SymbolType 

BaseSurfaceFinishSymbolBuilderToleranceTypeEnum = BaseSurfaceFinishSymbolBuilder.ToleranceTypeEnum

NXOpen.Annotations.BaseSurfaceFinishSymbolBuilderToleranceTypeEnum is an alias for NXOpen.Annotations.BaseSurfaceFinishSymbolBuilder.ToleranceTypeEnum 

## Detailed Description

Represents builder for Pmi Surface Finish Symbol 

To create a new instance of this class, use NXOpen::Annotations::PmiSurfaceFinishSymbolCollection::CreatePmiSurfaceFinishSymbolBuilder 

Created in NX2212.0.0 

## Member Function Documentation

## ◆ AssociatedObjects()

NXOpen.Annotations.PmiSurfaceFinishSymbolBuilder.AssociatedObjects
(
self — )

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the select associated objects. 

Getter License requirements: None.

Created in NX2212.0.0 

Returns
AssociatedObjectsBuilder 

Copyright 2025 Siemens
