# NXOpen.Annotations.HoleTableSettingsWorkflowBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12585.html>

Represents a NXOpen::Annotations::HoleTableSettingsWorkflowBuilder. 
More...

Inheritance diagram for NXOpen.Annotations.HoleTableSettingsWorkflowBuilder:

## Additional Inherited Members

Public Member Functions inherited from NXOpen.Annotations.TabularNoteStyleBuilder

AutomaticUpdate (self)

Getter for property: (bool) AutomaticUpdate Returns the automatic update. 

AutomaticUpdate (self, automaticUpdate)

Setter for property: (bool) AutomaticUpdate. 

LockTableContents (self)

Getter for property: (bool) LockTableContents Returns the lock table contents. 

LockTableContents (self, lockedTableContents)

Setter for property: (bool) LockTableContents. 

LockTableFormat (self)

Getter for property: (bool) LockTableFormat Returns the lock table format. 

LockTableFormat (self, lockedTableFormat)

Setter for property: (bool) LockTableFormat. 

ShowLockedDeletedContent (self)

Getter for property: (NXOpen.Annotations.TabularNoteStyleBuilder.ShowLockedDeletedRowMethod) ShowLockedDeletedContent Returns the locked deleted row method. 

ShowLockedDeletedContent (self, showLockedDeletedContent)

Setter for property: (NXOpen.Annotations.TabularNoteStyleBuilder.ShowLockedDeletedRowMethod) ShowLockedDeletedContent. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

Public Attributes inherited from NXOpen.Annotations.TabularNoteStyleBuilder

TabularNoteStyleBuilderShowLockedDeletedRowMethod = TabularNoteStyleBuilder.ShowLockedDeletedRowMethod

NXOpen.Annotations.TabularNoteStyleBuilderShowLockedDeletedRowMethod is an alias for NXOpen.Annotations.TabularNoteStyleBuilder.ShowLockedDeletedRowMethod 

## Detailed Description

Represents a NXOpen::Annotations::HoleTableSettingsWorkflowBuilder. 

Created in NX9.0.0 

Copyright 2025 Siemens
