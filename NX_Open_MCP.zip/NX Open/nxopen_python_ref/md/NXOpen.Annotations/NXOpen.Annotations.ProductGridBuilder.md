# NXOpen.Annotations.ProductGridBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13969.html>

Represents a NXOpen::Annotations::ProductGridBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.ProductGridBuilder:

## Additional Inherited Members

Public Member Functions inherited from NXOpen.Annotations.BaseProductGridBuilder

CoordinateSystem (self)

Getter for property: (NXOpen.CoordinateSystem) CoordinateSystem Returns the coordinate system. 

CoordinateSystem (self, coordinateSystem)

Setter for property: (NXOpen.CoordinateSystem) CoordinateSystem. 

GridSpacing (self)

Getter for property: (float) GridSpacing Returns the grid spacing. 

GridSpacing (self, gridSpacing)

Setter for property: (float) GridSpacing. 

HorizontalMaximumValue (self)

Getter for property: (float) HorizontalMaximumValue Returns the horizontal maximum value. 

HorizontalMaximumValue (self, horizontalMaximumValue)

Setter for property: (float) HorizontalMaximumValue. 

HorizontalMinimumValue (self)

Getter for property: (float) HorizontalMinimumValue Returns the horizontal minimum value. 

HorizontalMinimumValue (self, horizontalMinimumValue)

Setter for property: (float) HorizontalMinimumValue. 

ShowHorizontalLines (self)

Getter for property: (bool) ShowHorizontalLines Returns the horizontal line display. 

ShowHorizontalLines (self, showHorizontalLines)

Setter for property: (bool) ShowHorizontalLines. 

ShowVerticalLines (self)

Getter for property: (bool) ShowVerticalLines Returns the vertical line display. 

ShowVerticalLines (self, showVerticalLines)

Setter for property: (bool) ShowVerticalLines. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

VerticalMaximumValue (self)

Getter for property: (float) VerticalMaximumValue Returns the vertical maximum value. 

VerticalMaximumValue (self, verticalMaximumValue)

Setter for property: (float) VerticalMaximumValue. 

VerticalMinimumValue (self)

Getter for property: (float) VerticalMinimumValue Returns the vertical minimum value. 

VerticalMinimumValue (self, verticalMinimumValue)

Setter for property: (float) VerticalMinimumValue. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::ProductGridBuilder . 

This class allows creation of product grid annotations 

To create a new instance of this class, use NXOpen::Annotations::ProductGridCollection::CreateProductGridBuilder 

Default values. 

Property — Value

GridSpacing 

100 

HorizontalMaximumValue 

500 

HorizontalMinimumValue 

0 

ShowHorizontalLines 

1 

ShowVerticalLines 

1 

VerticalMaximumValue 

500 

VerticalMinimumValue 

0 

Created in NX1980.0.0 

Copyright 2025 Siemens
