# NXOpen.Annotations.SearchModelViewBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a14237.html>

Represents a NXOpen::Annotations::SearchModelViewBuilder 

To create a new instance of this class, use NXOpen::Annotations::SearchModelViewCollection::CreateSearchModelViewBuilder 

Default values. 
More...

Inheritance diagram for NXOpen.Annotations.SearchModelViewBuilder:

## Public Member Functions

CreateCriteriaObject (self, searchType)

Create search criteria object in search model view builder. 

CriteriaList (self)

Getter for property: (NXOpen.TaggedObjectList) CriteriaList Returns the criteria list. 

DeleteCriteriaObject (self, criteriaObject)

Delete search criteria object in search model view builder. 

ExecuteSearch (self)

TODO: fill in a description for this. 

GetResults (self)

All results. 

ModelViewName (self)

Getter for property: (str) ModelViewName Returns the name. 

ModelViewName (self, name)

Setter for property: (str) ModelViewName. 

PmiType (self)

Getter for property: (NXOpen.Annotations.SearchModelViewBuilder.PmiTypes) PmiType Returns the pmi type. 

PmiType (self, pmiType)

Setter for property: (NXOpen.Annotations.SearchModelViewBuilder.PmiTypes) PmiType. 

SaveAsModelView (self)

TODO: fill in a description for this. 

SearchScope (self)

Getter for property: (NXOpen.Annotations.SearchModelViewBuilder.SearchScopeOptions) SearchScope Returns the search scope. 

SearchScope (self, searchScope)

Setter for property: (NXOpen.Annotations.SearchModelViewBuilder.SearchScopeOptions) SearchScope. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

SearchModelViewBuilderPmiTypes = SearchModelViewBuilder.PmiTypes

NXOpen.Annotations.SearchModelViewBuilderPmiTypes is an alias for NXOpen.Annotations.SearchModelViewBuilder.PmiTypes 

SearchModelViewBuilderSearchScopeOptions = SearchModelViewBuilder.SearchScopeOptions

NXOpen.Annotations.SearchModelViewBuilderSearchScopeOptions is an alias for NXOpen.Annotations.SearchModelViewBuilder.SearchScopeOptions 

SearchModelViewBuilderTextComparisionOptions = SearchModelViewBuilder.TextComparisionOptions

NXOpen.Annotations.SearchModelViewBuilderTextComparisionOptions is an alias for NXOpen.Annotations.SearchModelViewBuilder.TextComparisionOptions 

SearchModelViewBuilderValueComparisionOptions = SearchModelViewBuilder.ValueComparisionOptions

NXOpen.Annotations.SearchModelViewBuilderValueComparisionOptions is an alias for NXOpen.Annotations.SearchModelViewBuilder.ValueComparisionOptions 

## Detailed Description

Represents a NXOpen::Annotations::SearchModelViewBuilder 

To create a new instance of this class, use NXOpen::Annotations::SearchModelViewCollection::CreateSearchModelViewBuilder 

Default values. 

Property — Value

PmiType 

Dimension 

Created in NX7.5.0 

## Member Function Documentation

## ◆ CreateCriteriaObject()

NXOpen.Annotations.SearchModelViewBuilder.CreateCriteriaObject
(
self,

searchType )

Create search criteria object in search model view builder. 

Returns
criteriaObject (NXOpen.NXObject): criteria object .

Created in NX7.5.0 

License requirements: None.

Parameters

searchType — (NXOpen.Annotations.SearchModelViewBuilder.PmiTypes) search type

## ◆ CriteriaList()

NXOpen.Annotations.SearchModelViewBuilder.CriteriaList
(
self — )

Getter for property: (NXOpen.TaggedObjectList) CriteriaList Returns the criteria list. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
NXOpen.TaggedObjectList 

## ◆ DeleteCriteriaObject()

NXOpen.Annotations.SearchModelViewBuilder.DeleteCriteriaObject
(
self,

criteriaObject )

Delete search criteria object in search model view builder. 

Created in NX7.5.0 

License requirements: None.

Parameters

criteriaObject — (NXOpen.NXObject) criteria Object

## ◆ ExecuteSearch()

NXOpen.Annotations.SearchModelViewBuilder.ExecuteSearch
(
self — )

TODO: fill in a description for this. 

Created in NX7.5.0 

License requirements: None. 

## ◆ GetResults()

NXOpen.Annotations.SearchModelViewBuilder.GetResults
(
self — )

All results. 

Returns
results (List[NXOpen.NXObject]): .

Created in NX7.5.0 

License requirements: None. 

## ◆ ModelViewName() [1/2]

NXOpen.Annotations.SearchModelViewBuilder.ModelViewName
(
self — )

Getter for property: (str) ModelViewName Returns the name. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
str 

## ◆ ModelViewName() [2/2]

NXOpen.Annotations.SearchModelViewBuilder.ModelViewName
(
self,

name )

Setter for property: (str) ModelViewName. 

Sets the name

Setter License requirements: None.

Created in NX7.5.0 

## ◆ PmiType() [1/2]

NXOpen.Annotations.SearchModelViewBuilder.PmiType
(
self — )

Getter for property: (NXOpen.Annotations.SearchModelViewBuilder.PmiTypes) PmiType Returns the pmi type. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
SearchModelViewBuilder.PmiTypes 

## ◆ PmiType() [2/2]

NXOpen.Annotations.SearchModelViewBuilder.PmiType
(
self,

pmiType )

Setter for property: (NXOpen.Annotations.SearchModelViewBuilder.PmiTypes) PmiType. 

Sets the pmi type

Setter License requirements: None.

Created in NX7.5.0 

## ◆ SaveAsModelView()

NXOpen.Annotations.SearchModelViewBuilder.SaveAsModelView
(
self — )

TODO: fill in a description for this. 

Created in NX7.5.0 

License requirements: None. 

## ◆ SearchScope() [1/2]

NXOpen.Annotations.SearchModelViewBuilder.SearchScope
(
self — )

Getter for property: (NXOpen.Annotations.SearchModelViewBuilder.SearchScopeOptions) SearchScope Returns the search scope. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
SearchModelViewBuilder.SearchScopeOptions 

## ◆ SearchScope() [2/2]

NXOpen.Annotations.SearchModelViewBuilder.SearchScope
(
self,

searchScope )

Setter for property: (NXOpen.Annotations.SearchModelViewBuilder.SearchScopeOptions) SearchScope. 

Sets the search scope

Setter License requirements: None.

Created in NX7.5.0 

## Member Data Documentation

## ◆ SearchModelViewBuilderPmiTypes

NXOpen.Annotations.SearchModelViewBuilder.SearchModelViewBuilderPmiTypes = SearchModelViewBuilder.PmiTypes

NXOpen.Annotations.SearchModelViewBuilderPmiTypes is an alias for NXOpen.Annotations.SearchModelViewBuilder.PmiTypes 

## ◆ SearchModelViewBuilderSearchScopeOptions

NXOpen.Annotations.SearchModelViewBuilder.SearchModelViewBuilderSearchScopeOptions = SearchModelViewBuilder.SearchScopeOptions

NXOpen.Annotations.SearchModelViewBuilderSearchScopeOptions is an alias for NXOpen.Annotations.SearchModelViewBuilder.SearchScopeOptions 

## ◆ SearchModelViewBuilderTextComparisionOptions

NXOpen.Annotations.SearchModelViewBuilder.SearchModelViewBuilderTextComparisionOptions = SearchModelViewBuilder.TextComparisionOptions

NXOpen.Annotations.SearchModelViewBuilderTextComparisionOptions is an alias for NXOpen.Annotations.SearchModelViewBuilder.TextComparisionOptions 

## ◆ SearchModelViewBuilderValueComparisionOptions

NXOpen.Annotations.SearchModelViewBuilder.SearchModelViewBuilderValueComparisionOptions = SearchModelViewBuilder.ValueComparisionOptions

NXOpen.Annotations.SearchModelViewBuilderValueComparisionOptions is an alias for NXOpen.Annotations.SearchModelViewBuilder.ValueComparisionOptions 

Copyright 2025 Siemens
