# NXOpen.Annotations.BaseSurfaceFinishSymbolBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00136.html>

## Classes

class — ParenthesesType

the valid parentheses types 

Enumerator — Comment

NotSet

Left

Right

Both

More...

class — ProfileDirectionEnum

the valid profile direction types 

Enumerator — Comment

NotSet

Perpendicular

Parallel

Circular

DefinedAngle

More...

class — SymbolType

the valid types for pmi finish type 

Enumerator — Comment

Basic

Modifier

ModifierAllAround

MaterialRemovalRequired

ModifierMaterialRemovalRequired

ModifierMaterialRemovalRequiredAllAround

MaterialRemovalProhibited

ModifierMaterialRemovalProhibited

ModifierMaterialRemovalProhibitedAllAround

More...

class — ToleranceTypeEnum

the valid surface finish tolerance types 

Enumerator — Comment

NotSet

EqualBilateral

Bilateral

UnilateralPlus

UnilateralMinus

PlusLimitTwoLines

MinusLimitTwoLines

PlusLimitOneLine

MinusLimitOneLine

More...

Copyright 2025 Siemens
