# NXOpen.Annotations.RegionBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a14045.html>

Represents a NXOpen::Annotations::RegionBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::PmiRegionCollection::CreateRegionBuilder 

Default values. 
More...

Inheritance diagram for NXOpen.Annotations.RegionBuilder:

## Public Member Functions

Anchor (self)

Getter for property: (NXOpen.Annotations.RegionBuilder.AlignmentPosition) Anchor Returns the anchor Only available when region type is NXOpen::Annotations::RegionBuilder::TypesRectangularRegion , NXOpen::Annotations::RegionBuilder::TypesCircularRegion , NXOpen::Annotations::RegionBuilder::TypesAnnularRegion. 

Anchor (self, anchor)

Setter for property: (NXOpen.Annotations.RegionBuilder.AlignmentPosition) Anchor. 

ArbitraryAreaList (self)

Getter for property: (NXOpen.Annotations.ArbitraryAreaSeedBuilderList) ArbitraryAreaList Returns the arbitrary area list Only available when the region type is NXOpen::Annotations::RegionBuilder::TypesArbitraryRegion. 

BoundaryColorFontWidth (self)

Getter for property: (NXOpen.LineColorFontWidthBuilder) BoundaryColorFontWidth Returns the boundary curve settings block. 

ConformToSurface (self)

Getter for property: (bool) ConformToSurface Returns the conform to surface toggle Only available when region type is NXOpen::Annotations::RegionBuilder::TypesRectangularRegion , NXOpen::Annotations::RegionBuilder::TypesCircularRegion , NXOpen::Annotations::RegionBuilder::TypesAnnularRegion. 

ConformToSurface (self, conformToSurfaceToggle)

Setter for property: (bool) ConformToSurface. 

CrosshatchColor (self)

Getter for property: (NXOpen.NXColor) CrosshatchColor Returns the crosshatch color. 

CrosshatchColor (self, crosshatchColor)

Setter for property: (NXOpen.NXColor) CrosshatchColor. 

CrosshatchSettings (self)

Getter for property: (NXOpen.Annotations.HatchFillSettingsBuilder) CrosshatchSettings Returns the crosshatch settings block. 

DisplayCrosshatch (self)

Getter for property: (bool) DisplayCrosshatch Returns the display crosshatch toggle. 

DisplayCrosshatch (self, displayCrosshatch)

Setter for property: (bool) DisplayCrosshatch. 

EndPoint (self)

Getter for property: (NXOpen.Point) EndPoint Returns the end point Only available when the region type is NXOpen::Annotations::RegionBuilder::TypesCylindricalRegion. 

EndPoint (self, endPoint)

Setter for property: (NXOpen.Point) EndPoint. 

Height (self)

Getter for property: (NXOpen.Expression) Height Returns the height Only available when region type is NXOpen::Annotations::RegionBuilder::TypesRectangularRegion. 

InheritFrom (self, inheritTag)

The region is inherited from the given region. 

InnerDiameter (self)

Getter for property: (NXOpen.Expression) InnerDiameter Returns the inner diameter Only available when region type is NXOpen::Annotations::RegionBuilder::TypesAnnularRegion. 

Origin (self)

Getter for property: (NXOpen.Point) Origin Returns the origin Only available when region type is NXOpen::Annotations::RegionBuilder::TypesRectangularRegion , NXOpen::Annotations::RegionBuilder::TypesCircularRegion , NXOpen::Annotations::RegionBuilder::TypesAnnularRegion. 

Origin (self, origin)

Setter for property: (NXOpen.Point) Origin. 

OuterDiameter (self)

Getter for property: (NXOpen.Expression) OuterDiameter Returns the outer diameter Only available when region type is NXOpen::Annotations::RegionBuilder::TypesCircularRegion , NXOpen::Annotations::RegionBuilder::TypesAnnularRegion. 

Plane (self)

Getter for property: (NXOpen.Annotations.PlaneBuilder) Plane Returns the plane. 

SelectCylindricalFace (self)

Getter for property: (NXOpen.SelectDisplayableObjectList) SelectCylindricalFace Returns the select cylindrical face Only available when region type is NXOpen::Annotations::RegionBuilder::TypesCylindricalRegion. 

SelectFace (self)

Getter for property: (NXOpen.SelectDisplayableObjectList) SelectFace Returns the select face Only available when region type is NXOpen::Annotations::RegionBuilder::TypesRectangularRegion , NXOpen::Annotations::RegionBuilder::TypesCircularRegion , NXOpen::Annotations::RegionBuilder::TypesAnnularRegion. 

Settings (self)

Getter for property: (NXOpen.Annotations.PmiRegionSettingsBuilder) Settings Returns the region settings builder. 

StartPoint (self)

Getter for property: (NXOpen.Point) StartPoint Returns the start point Only available when the region type is NXOpen::Annotations::RegionBuilder::TypesCylindricalRegion. 

StartPoint (self, startPoint)

Setter for property: (NXOpen.Point) StartPoint. 

Type (self)

Getter for property: (NXOpen.Annotations.RegionBuilder.Types) Type Returns the type. 

Type (self, type)

Setter for property: (NXOpen.Annotations.RegionBuilder.Types) Type. 

Width (self)

Getter for property: (NXOpen.Expression) Width Returns the width Only available when region type is NXOpen::Annotations::RegionBuilder::TypesRectangularRegion. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

RegionBuilderAlignmentPosition = RegionBuilder.AlignmentPosition

NXOpen.Annotations.RegionBuilderAlignmentPosition is an alias for NXOpen.Annotations.RegionBuilder.AlignmentPosition 

RegionBuilderCrosshatchPatterns = RegionBuilder.CrosshatchPatterns

NXOpen.Annotations.RegionBuilderCrosshatchPatterns is an alias for NXOpen.Annotations.RegionBuilder.CrosshatchPatterns 

RegionBuilderTypes = RegionBuilder.Types

NXOpen.Annotations.RegionBuilderTypes is an alias for NXOpen.Annotations.RegionBuilder.Types 

## Detailed Description

Represents a NXOpen::Annotations::RegionBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::PmiRegionCollection::CreateRegionBuilder 

Default values. 

Property — Value

ConformToSurface 

0 

Created in NX6.0.0 

## Member Function Documentation

## ◆ Anchor() [1/2]

NXOpen.Annotations.RegionBuilder.Anchor
(
self — )

Getter for property: (NXOpen.Annotations.RegionBuilder.AlignmentPosition) Anchor Returns the anchor Only available when region type is NXOpen::Annotations::RegionBuilder::TypesRectangularRegion , NXOpen::Annotations::RegionBuilder::TypesCircularRegion , NXOpen::Annotations::RegionBuilder::TypesAnnularRegion. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
RegionBuilder.AlignmentPosition 

## ◆ Anchor() [2/2]

NXOpen.Annotations.RegionBuilder.Anchor
(
self,

anchor )

Setter for property: (NXOpen.Annotations.RegionBuilder.AlignmentPosition) Anchor. 

Sets the anchor Only available when region type is NXOpen::Annotations::RegionBuilder::TypesRectangularRegion , NXOpen::Annotations::RegionBuilder::TypesCircularRegion , NXOpen::Annotations::RegionBuilder::TypesAnnularRegion

Setter License requirements: geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ ArbitraryAreaList()

NXOpen.Annotations.RegionBuilder.ArbitraryAreaList
(
self — )

Getter for property: (NXOpen.Annotations.ArbitraryAreaSeedBuilderList) ArbitraryAreaList Returns the arbitrary area list Only available when the region type is NXOpen::Annotations::RegionBuilder::TypesArbitraryRegion. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
ArbitraryAreaSeedBuilderList 

## ◆ BoundaryColorFontWidth()

NXOpen.Annotations.RegionBuilder.BoundaryColorFontWidth
(
self — )

Getter for property: (NXOpen.LineColorFontWidthBuilder) BoundaryColorFontWidth Returns the boundary curve settings block. 

Getter License requirements: None.

Created in NX11.0.0 

Deprecated
Deprecated in NX2306.0.0. Use NXOpen::RegionBuilder::Settings::Region::RegionBoundaryCurveCFW and NXOpen::RegionBuilder::Settings::Region::SetRegionBoundaryCurveCFW instead. 

Returns
NXOpen.LineColorFontWidthBuilder 

## ◆ ConformToSurface() [1/2]

NXOpen.Annotations.RegionBuilder.ConformToSurface
(
self — )

Getter for property: (bool) ConformToSurface Returns the conform to surface toggle Only available when region type is NXOpen::Annotations::RegionBuilder::TypesRectangularRegion , NXOpen::Annotations::RegionBuilder::TypesCircularRegion , NXOpen::Annotations::RegionBuilder::TypesAnnularRegion. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ ConformToSurface() [2/2]

NXOpen.Annotations.RegionBuilder.ConformToSurface
(
self,

conformToSurfaceToggle )

Setter for property: (bool) ConformToSurface. 

Sets the conform to surface toggle Only available when region type is NXOpen::Annotations::RegionBuilder::TypesRectangularRegion , NXOpen::Annotations::RegionBuilder::TypesCircularRegion , NXOpen::Annotations::RegionBuilder::TypesAnnularRegion

Setter License requirements: geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ CrosshatchColor() [1/2]

NXOpen.Annotations.RegionBuilder.CrosshatchColor
(
self — )

Getter for property: (NXOpen.NXColor) CrosshatchColor Returns the crosshatch color. 

Getter License requirements: None.

Created in NX6.0.0 

Deprecated
Deprecated in NX2306.0.0. Use NXOpen::RegionBuilder::Settings::Crosshatch::Color and NXOpen::RegionBuilder::Settings::Crosshatch::SetColor instead. 

Returns
NXOpen.NXColor 

## ◆ CrosshatchColor() [2/2]

NXOpen.Annotations.RegionBuilder.CrosshatchColor
(
self,

crosshatchColor )

Setter for property: (NXOpen.NXColor) CrosshatchColor. 

Sets the crosshatch color

Setter License requirements: geometric_tol ("GDT")

Created in NX6.0.0 

Deprecated
Deprecated in NX2306.0.0. Use NXOpen::RegionBuilder::Settings::Crosshatch::Color and NXOpen::RegionBuilder::Settings::Crosshatch::SetColor instead. 

## ◆ CrosshatchSettings()

NXOpen.Annotations.RegionBuilder.CrosshatchSettings
(
self — )

Getter for property: (NXOpen.Annotations.HatchFillSettingsBuilder) CrosshatchSettings Returns the crosshatch settings block. 

Getter License requirements: None.

Created in NX8.5.0 

Deprecated
Deprecated in NX2306.0.0. Use NXOpen::RegionBuilder::Settings::Crosshatch and NXOpen::RegionBuilder::Settings::SetCrosshatch instead. 

Returns
HatchFillSettingsBuilder 

## ◆ DisplayCrosshatch() [1/2]

NXOpen.Annotations.RegionBuilder.DisplayCrosshatch
(
self — )

Getter for property: (bool) DisplayCrosshatch Returns the display crosshatch toggle. 

Getter License requirements: None.

Created in NX8.5.0 

Deprecated
Deprecated in NX2306.0.0. Use NXOpen::RegionBuilder::Settings::Region::DisplayCrosshatch and NXOpen::RegionBuilder::Settings::Region::SetDisplayCrosshatch instead. 

Returns
bool 

## ◆ DisplayCrosshatch() [2/2]

NXOpen.Annotations.RegionBuilder.DisplayCrosshatch
(
self,

displayCrosshatch )

Setter for property: (bool) DisplayCrosshatch. 

Sets the display crosshatch toggle

Setter License requirements: geometric_tol ("GDT")

Created in NX8.5.0 

Deprecated
Deprecated in NX2306.0.0. Use NXOpen::RegionBuilder::Settings::Region::DisplayCrosshatch and NXOpen::RegionBuilder::Settings::Region::SetDisplayCrosshatch instead. 

## ◆ EndPoint() [1/2]

NXOpen.Annotations.RegionBuilder.EndPoint
(
self — )

Getter for property: (NXOpen.Point) EndPoint Returns the end point Only available when the region type is NXOpen::Annotations::RegionBuilder::TypesCylindricalRegion. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.Point 

## ◆ EndPoint() [2/2]

NXOpen.Annotations.RegionBuilder.EndPoint
(
self,

endPoint )

Setter for property: (NXOpen.Point) EndPoint. 

Sets the end point Only available when the region type is NXOpen::Annotations::RegionBuilder::TypesCylindricalRegion

Setter License requirements: geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ Height()

NXOpen.Annotations.RegionBuilder.Height
(
self — )

Getter for property: (NXOpen.Expression) Height Returns the height Only available when region type is NXOpen::Annotations::RegionBuilder::TypesRectangularRegion. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.Expression 

## ◆ InheritFrom()

NXOpen.Annotations.RegionBuilder.InheritFrom
(
self,

inheritTag )

The region is inherited from the given region. 

Created in NX2306.0.0 

License requirements: None.

Parameters

inheritTag — (NXOpen.Annotations.Annotation)

## ◆ InnerDiameter()

NXOpen.Annotations.RegionBuilder.InnerDiameter
(
self — )

Getter for property: (NXOpen.Expression) InnerDiameter Returns the inner diameter Only available when region type is NXOpen::Annotations::RegionBuilder::TypesAnnularRegion. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.Expression 

## ◆ Origin() [1/2]

NXOpen.Annotations.RegionBuilder.Origin
(
self — )

Getter for property: (NXOpen.Point) Origin Returns the origin Only available when region type is NXOpen::Annotations::RegionBuilder::TypesRectangularRegion , NXOpen::Annotations::RegionBuilder::TypesCircularRegion , NXOpen::Annotations::RegionBuilder::TypesAnnularRegion. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.Point 

## ◆ Origin() [2/2]

NXOpen.Annotations.RegionBuilder.Origin
(
self,

origin )

Setter for property: (NXOpen.Point) Origin. 

Sets the origin Only available when region type is NXOpen::Annotations::RegionBuilder::TypesRectangularRegion , NXOpen::Annotations::RegionBuilder::TypesCircularRegion , NXOpen::Annotations::RegionBuilder::TypesAnnularRegion

Setter License requirements: geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ OuterDiameter()

NXOpen.Annotations.RegionBuilder.OuterDiameter
(
self — )

Getter for property: (NXOpen.Expression) OuterDiameter Returns the outer diameter Only available when region type is NXOpen::Annotations::RegionBuilder::TypesCircularRegion , NXOpen::Annotations::RegionBuilder::TypesAnnularRegion. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.Expression 

## ◆ Plane()

NXOpen.Annotations.RegionBuilder.Plane
(
self — )

Getter for property: (NXOpen.Annotations.PlaneBuilder) Plane Returns the plane. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
PlaneBuilder 

## ◆ SelectCylindricalFace()

NXOpen.Annotations.RegionBuilder.SelectCylindricalFace
(
self — )

Getter for property: (NXOpen.SelectDisplayableObjectList) SelectCylindricalFace Returns the select cylindrical face Only available when region type is NXOpen::Annotations::RegionBuilder::TypesCylindricalRegion. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectDisplayableObjectList 

## ◆ SelectFace()

NXOpen.Annotations.RegionBuilder.SelectFace
(
self — )

Getter for property: (NXOpen.SelectDisplayableObjectList) SelectFace Returns the select face Only available when region type is NXOpen::Annotations::RegionBuilder::TypesRectangularRegion , NXOpen::Annotations::RegionBuilder::TypesCircularRegion , NXOpen::Annotations::RegionBuilder::TypesAnnularRegion. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectDisplayableObjectList 

## ◆ Settings()

NXOpen.Annotations.RegionBuilder.Settings
(
self — )

Getter for property: (NXOpen.Annotations.PmiRegionSettingsBuilder) Settings Returns the region settings builder. 

Getter License requirements: None.

Created in NX2306.0.0 

Returns
PmiRegionSettingsBuilder 

## ◆ StartPoint() [1/2]

NXOpen.Annotations.RegionBuilder.StartPoint
(
self — )

Getter for property: (NXOpen.Point) StartPoint Returns the start point Only available when the region type is NXOpen::Annotations::RegionBuilder::TypesCylindricalRegion. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.Point 

## ◆ StartPoint() [2/2]

NXOpen.Annotations.RegionBuilder.StartPoint
(
self,

startPoint )

Setter for property: (NXOpen.Point) StartPoint. 

Sets the start point Only available when the region type is NXOpen::Annotations::RegionBuilder::TypesCylindricalRegion

Setter License requirements: geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ Type() [1/2]

NXOpen.Annotations.RegionBuilder.Type
(
self — )

Getter for property: (NXOpen.Annotations.RegionBuilder.Types) Type Returns the type. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
RegionBuilder.Types 

## ◆ Type() [2/2]

NXOpen.Annotations.RegionBuilder.Type
(
self,

type )

Setter for property: (NXOpen.Annotations.RegionBuilder.Types) Type. 

Sets the type

Setter License requirements: geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ Width()

NXOpen.Annotations.RegionBuilder.Width
(
self — )

Getter for property: (NXOpen.Expression) Width Returns the width Only available when region type is NXOpen::Annotations::RegionBuilder::TypesRectangularRegion. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.Expression 

## Member Data Documentation

## ◆ RegionBuilderAlignmentPosition

NXOpen.Annotations.RegionBuilder.RegionBuilderAlignmentPosition = RegionBuilder.AlignmentPosition

NXOpen.Annotations.RegionBuilderAlignmentPosition is an alias for NXOpen.Annotations.RegionBuilder.AlignmentPosition 

## ◆ RegionBuilderCrosshatchPatterns

NXOpen.Annotations.RegionBuilder.RegionBuilderCrosshatchPatterns = RegionBuilder.CrosshatchPatterns

NXOpen.Annotations.RegionBuilderCrosshatchPatterns is an alias for NXOpen.Annotations.RegionBuilder.CrosshatchPatterns 

## ◆ RegionBuilderTypes

NXOpen.Annotations.RegionBuilder.RegionBuilderTypes = RegionBuilder.Types

NXOpen.Annotations.RegionBuilderTypes is an alias for NXOpen.Annotations.RegionBuilder.Types 

Copyright 2025 Siemens
