# NXOpen.Annotations.BaseOrdinateDimensionBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00134.html>

## Classes

class — Types

the type of dimension being created 

Enumerator — Comment

SingleDimension — singular dimension

MultipleDimension — group or set of dimensions

More...

Copyright 2025 Siemens
