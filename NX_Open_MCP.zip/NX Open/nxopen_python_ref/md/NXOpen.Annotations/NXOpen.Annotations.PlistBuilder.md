# NXOpen.Annotations.PlistBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13225.html>

Represents a Annotations::PlistBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.PlistBuilder:

## Public Member Functions

Balloons (self)

Getter for property: (NXOpen.Annotations.BalloonsBuilder) Balloons Returns the parts list balloons. 

Contents (self)

Getter for property: (NXOpen.Annotations.PartsListContentsBuilder) Contents Returns the parts list contents. 

CreatePreviewView (self)

Creates preview view of parts list section. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the parts list origin. 

SetTemplateLocation (self, templateLocation)

Sets the parts list template location. 

Settings (self)

Getter for property: (NXOpen.Annotations.TableStyleBuilder) Settings Returns the parts list settings. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a Annotations::PlistBuilder . 

Used to create or edit parts list. 

To create a new instance of this class, use NXOpen::Annotations::PartsListCollection::CreatePartsListBuilder 

Default values. 

Property — Value

Balloons.ShowBalloons 

0 

Contents.Scope 

AllLevels 

Contents.TopLevelAssembly 

ChildPart 

Created in NX1847.0.0 

## Member Function Documentation

## ◆ Balloons()

NXOpen.Annotations.PlistBuilder.Balloons
(
self — )

Getter for property: (NXOpen.Annotations.BalloonsBuilder) Balloons Returns the parts list balloons. 

Getter License requirements: None.

Created in NX1847.0.0 

Returns
BalloonsBuilder 

## ◆ Contents()

NXOpen.Annotations.PlistBuilder.Contents
(
self — )

Getter for property: (NXOpen.Annotations.PartsListContentsBuilder) Contents Returns the parts list contents. 

Getter License requirements: None.

Created in NX1847.0.0 

Returns
PartsListContentsBuilder 

## ◆ CreatePreviewView()

NXOpen.Annotations.PlistBuilder.CreatePreviewView
(
self — )

Creates preview view of parts list section. 

Returns
partListPreview (NXOpen.Annotations.TableSection): the parts list section preview .

Created in NX2406.0.0 

License requirements: None. 

## ◆ Origin()

NXOpen.Annotations.PlistBuilder.Origin
(
self — )

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the parts list origin. 

Getter License requirements: None.

Created in NX1847.0.0 

Returns
OriginBuilder 

## ◆ SetTemplateLocation()

NXOpen.Annotations.PlistBuilder.SetTemplateLocation
(
self,

templateLocation )

Sets the parts list template location. 

Created in NX1847.0.0 

License requirements: None.

Parameters

templateLocation — (str) the qualified path to the template file name

## ◆ Settings()

NXOpen.Annotations.PlistBuilder.Settings
(
self — )

Getter for property: (NXOpen.Annotations.TableStyleBuilder) Settings Returns the parts list settings. 

Getter License requirements: None.

Created in NX1847.0.0 

Returns
TableStyleBuilder 

Copyright 2025 Siemens
