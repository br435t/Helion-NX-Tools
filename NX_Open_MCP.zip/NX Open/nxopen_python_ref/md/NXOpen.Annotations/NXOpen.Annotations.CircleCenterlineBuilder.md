# NXOpen.Annotations.CircleCenterlineBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00144.html>

## Classes

class — Types

the valid enumeration used for the creation types, applicable only while creation Once created type centerpoint will be set for all bolt circle/circular centerline 

Enumerator — Comment

Through3Points — Centerline using 3 or More Points Method

Centerpoint — Centerline using Centerpoint Method

More...

Copyright 2025 Siemens
