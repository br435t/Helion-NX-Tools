# NXOpen.Annotations.EditTitleBlockBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12165.html>

Represents a NXOpen::Annotations::EditTitleBlockBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::TitleBlockCollection::CreateEditTitleBlockBuilder 

More...

Inheritance diagram for NXOpen.Annotations.EditTitleBlockBuilder:

## Public Member Functions

GetCellValueForLabel (self, label)

Return the value of the cell for given label. 

SetCellValueForLabel (self, label, value)

Sets the value of the cell for given label. 

Public Member Functions inherited from NXOpen.Annotations.BaseTitleBlockBuilder

Cells (self)

Getter for property: (NXOpen.Annotations.TitleBlockCellBuilderList) Cells Returns the cells. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::EditTitleBlockBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::TitleBlockCollection::CreateEditTitleBlockBuilder 

Created in NX8.0.0 

## Member Function Documentation

## ◆ GetCellValueForLabel()

NXOpen.Annotations.EditTitleBlockBuilder.GetCellValueForLabel
(
self,

label )

Return the value of the cell for given label. 

If multiple title blocks are selected, then value of the cell from the first title block, which has the cell with given label, is returned. 
Returns
value (str): Value of the label .

Created in NX8.0.0 

License requirements: None.

Parameters

label — (str) Label whose value is queried

## ◆ SetCellValueForLabel()

NXOpen.Annotations.EditTitleBlockBuilder.SetCellValueForLabel
(
self,

label,

value )

Sets the value of the cell for given label. 

If multiple title blocks are selected, then values of cells with the given label in all the title blocks are set.

Created in NX8.0.0 

License requirements: drafting ("DRAFTING") OR nx_2d_edit (" NX 2D Edit")

Parameters

label — (str) Label whose value is to be set

value — (str) Value of the label

Copyright 2025 Siemens
