# NXOpen.Annotations.QueryPmiBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13997.html>

Represents a NXOpen::Annotations::QueryPmiBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateQueryPmiBuilder 

Default values. 
More...

Inheritance diagram for NXOpen.Annotations.QueryPmiBuilder:

## Public Member Functions

AreAllOccurrencesIncluded (self)

Getter for property: (bool) AreAllOccurrencesIncluded Returns an all occurrences of selected component to be included toggle. 

AreAllOccurrencesIncluded (self, areOccurrencesIncluded)

Setter for property: (bool) AreAllOccurrencesIncluded. 

AreAttachedPmiIncluded (self)

Getter for property: (bool) AreAttachedPmiIncluded Returns an attached pmi to selected geometry to be included toggle. 

AreAttachedPmiIncluded (self, areAttachedPMIIncluded)

Setter for property: (bool) AreAttachedPmiIncluded. 

AreReferencingMemberObjectsIncluded (self)

Getter for property: (bool) AreReferencingMemberObjectsIncluded Returns a referencing member objects of selected geometry to be included toggle. 

AreReferencingMemberObjectsIncluded (self, areReferencingMemberObjectsIncluded)

Setter for property: (bool) AreReferencingMemberObjectsIncluded. 

CreateQueryResultsView (self)

Getter for property: (bool) CreateQueryResultsView Returns the create query results view. 

CreateQueryResultsView (self, createQueryResultsView)

Setter for property: (bool) CreateQueryResultsView. 

Geometry (self)

Getter for property: (NXOpen.SelectObjectList) Geometry Returns the geometry. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::QueryPmiBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateQueryPmiBuilder 

Default values. 

Property — Value

CreateQueryResultsView 

true 

Created in NX5.0.0 

## Member Function Documentation

## ◆ AreAllOccurrencesIncluded() [1/2]

NXOpen.Annotations.QueryPmiBuilder.AreAllOccurrencesIncluded
(
self — )

Getter for property: (bool) AreAllOccurrencesIncluded Returns an all occurrences of selected component to be included toggle. 

Getter License requirements: None.

Created in NX8.5.1 

Returns
bool 

## ◆ AreAllOccurrencesIncluded() [2/2]

NXOpen.Annotations.QueryPmiBuilder.AreAllOccurrencesIncluded
(
self,

areOccurrencesIncluded )

Setter for property: (bool) AreAllOccurrencesIncluded. 

Sets an all occurrences of selected component to be included toggle

Setter License requirements: None.

Created in NX8.5.1 

## ◆ AreAttachedPmiIncluded() [1/2]

NXOpen.Annotations.QueryPmiBuilder.AreAttachedPmiIncluded
(
self — )

Getter for property: (bool) AreAttachedPmiIncluded Returns an attached pmi to selected geometry to be included toggle. 

Getter License requirements: None.

Created in NX8.5.1 

Returns
bool 

## ◆ AreAttachedPmiIncluded() [2/2]

NXOpen.Annotations.QueryPmiBuilder.AreAttachedPmiIncluded
(
self,

areAttachedPMIIncluded )

Setter for property: (bool) AreAttachedPmiIncluded. 

Sets an attached pmi to selected geometry to be included toggle

Setter License requirements: None.

Created in NX8.5.1 

## ◆ AreReferencingMemberObjectsIncluded() [1/2]

NXOpen.Annotations.QueryPmiBuilder.AreReferencingMemberObjectsIncluded
(
self — )

Getter for property: (bool) AreReferencingMemberObjectsIncluded Returns a referencing member objects of selected geometry to be included toggle. 

Getter License requirements: None.

Created in NX8.5.1 

Returns
bool 

## ◆ AreReferencingMemberObjectsIncluded() [2/2]

NXOpen.Annotations.QueryPmiBuilder.AreReferencingMemberObjectsIncluded
(
self,

areReferencingMemberObjectsIncluded )

Setter for property: (bool) AreReferencingMemberObjectsIncluded. 

Sets a referencing member objects of selected geometry to be included toggle

Setter License requirements: None.

Created in NX8.5.1 

## ◆ CreateQueryResultsView() [1/2]

NXOpen.Annotations.QueryPmiBuilder.CreateQueryResultsView
(
self — )

Getter for property: (bool) CreateQueryResultsView Returns the create query results view. 

A value of false results in a temporary display that is not supported through NXOpen.

Getter License requirements: None.

Created in NX8.5.0 

Returns
bool 

## ◆ CreateQueryResultsView() [2/2]

NXOpen.Annotations.QueryPmiBuilder.CreateQueryResultsView
(
self,

createQueryResultsView )

Setter for property: (bool) CreateQueryResultsView. 

Sets the create query results view.

A value of false results in a temporary display that is not supported through NXOpen.

Setter License requirements: None.

Created in NX8.5.0 

## ◆ Geometry()

NXOpen.Annotations.QueryPmiBuilder.Geometry
(
self — )

Getter for property: (NXOpen.SelectObjectList) Geometry Returns the geometry. 

Getter License requirements: None.

Created in NX5.0.0 

Returns
NXOpen.SelectObjectList 

Copyright 2025 Siemens
