# NXOpen.Annotations.BaseCustomSymbolBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00130.html>

## Classes

class — AnnotationPreferences

Enum for Annotation Preferences This is used by NXOpen::Annotations::BaseCustomSymbolBuilder::AnnotationPreference and NXOpen::Annotations::BaseCustomSymbolBuilder::SetAnnotationPreference to set the annotation preferences for a symbol 

Enumerator — Comment

UseCurrent — Current preferences

UseDefinition — Defined preferences

More...

class — GeometryPreferences

Enum for Geometric Preferences This is used by NXOpen::Annotations::BaseCustomSymbolBuilder::GeometryPreference and NXOpen::Annotations::BaseCustomSymbolBuilder::SetGeometryPreference to set the geometric preferences for a symbol 

Enumerator — Comment

UseCurrent — Current preferences

UseDefinition — Defined preferences

More...

Copyright 2025 Siemens
