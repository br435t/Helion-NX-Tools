# NXOpen.Annotations.EditText Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00157.html>

## Classes

class — TextType

the text type 

Enumerator — Comment

MainText — Main text of annotation

More...

Copyright 2025 Siemens
