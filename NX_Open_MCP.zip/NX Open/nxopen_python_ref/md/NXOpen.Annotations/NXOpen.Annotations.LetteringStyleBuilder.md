# NXOpen.Annotations.LetteringStyleBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12801.html>

Represents a NXOpen::Annotations::LetteringStyleBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.LetteringStyleBuilder:

## Public Member Functions

AlignPosition (self)

Getter for property: (NXOpen.Annotations.AlignmentPosition) AlignPosition Returns the alignment position. 

AlignPosition (self, alignPosition)

Setter for property: (NXOpen.Annotations.AlignmentPosition) AlignPosition. 

Angle (self)

Getter for property: (float) Angle Returns the angle for general text. 

Angle (self, angle)

Setter for property: (float) Angle. 

AppendedNxTextCharacterSpaceFactor (self)

Getter for property: (float) AppendedNxTextCharacterSpaceFactor Returns the appended NX text character space factor. 

AppendedNxTextCharacterSpaceFactor (self, appendedNXTextCharSpaceFactor)

Setter for property: (float) AppendedNxTextCharacterSpaceFactor. 

AppendedStandardTextCharacterSpaceFactor (self)

Getter for property: (float) AppendedStandardTextCharacterSpaceFactor Returns the appended Standard text character space factor. 

AppendedStandardTextCharacterSpaceFactor (self, appendedStandardTextCharSpaceFactor)

Setter for property: (float) AppendedStandardTextCharacterSpaceFactor. 

AppendedTextAspectRatio (self)

Getter for property: (float) AppendedTextAspectRatio Returns the appended text aspect ratio. 

AppendedTextAspectRatio (self, appendedTextAspectRatio)

Setter for property: (float) AppendedTextAspectRatio. 

AppendedTextCharSpaceFactor (self)

Getter for property: (float) AppendedTextCharSpaceFactor Returns the appended text character space factor. 

AppendedTextCharSpaceFactor (self, appendedTextCharSpaceFactor)

Setter for property: (float) AppendedTextCharSpaceFactor. 

AppendedTextColor (self)

Getter for property: (NXOpen.NXColor) AppendedTextColor Returns the appended text color. 

AppendedTextColor (self, appendedTextColor)

Setter for property: (NXOpen.NXColor) AppendedTextColor. 

AppendedTextFont (self)

Getter for property: (int) AppendedTextFont Returns the appended text font. 

AppendedTextFont (self, appendedTextFont)

Setter for property: (int) AppendedTextFont. 

AppendedTextItalicized (self)

Getter for property: (bool) AppendedTextItalicized Returns the appended text italic status. 

AppendedTextItalicized (self, appendedTextItalicized)

Setter for property: (bool) AppendedTextItalicized. 

AppendedTextLineSpaceFactor (self)

Getter for property: (float) AppendedTextLineSpaceFactor Returns the appended text line space factor. 

AppendedTextLineSpaceFactor (self, appendedTextLineSpaceFactor)

Setter for property: (float) AppendedTextLineSpaceFactor. 

AppendedTextLineWidth (self)

Getter for property: (NXOpen.Annotations.LineWidth) AppendedTextLineWidth Returns the appended text line width. 

AppendedTextLineWidth (self, appendedTextLineWidth)

Setter for property: (NXOpen.Annotations.LineWidth) AppendedTextLineWidth. 

AppendedTextSize (self)

Getter for property: (float) AppendedTextSize Returns the appended text character size. 

AppendedTextSize (self, appendedTextSize)

Setter for property: (float) AppendedTextSize. 

AppendedTextSpaceFactor (self)

Getter for property: (float) AppendedTextSpaceFactor Returns the appended text space factor. 

AppendedTextSpaceFactor (self, appendedTextSpaceFactor)

Setter for property: (float) AppendedTextSpaceFactor. 

AppendedTextSymbolAspectRatio (self)

Getter for property: (float) AppendedTextSymbolAspectRatio Returns the symbol aspect ratio for appended text (only available for symbols when using standard font). 

AppendedTextSymbolAspectRatio (self, appendedTextSymbolAspect)

Setter for property: (float) AppendedTextSymbolAspectRatio. 

DimensionNxTextCharacterSpaceFactor (self)

Getter for property: (float) DimensionNxTextCharacterSpaceFactor Returns the dimension NX text character space factor. 

DimensionNxTextCharacterSpaceFactor (self, dimensionNXTextCharSpaceFactor)

Setter for property: (float) DimensionNxTextCharacterSpaceFactor. 

DimensionStandardTextCharacterSpaceFactor (self)

Getter for property: (float) DimensionStandardTextCharacterSpaceFactor Returns the dimension Standard text character space factor. 

DimensionStandardTextCharacterSpaceFactor (self, dimensionStandardTextCharSpaceFactor)

Setter for property: (float) DimensionStandardTextCharacterSpaceFactor. 

DimensionTextAspectRatio (self)

Getter for property: (float) DimensionTextAspectRatio Returns the dimension text aspect ratio. 

DimensionTextAspectRatio (self, dimensionTextAspectRatio)

Setter for property: (float) DimensionTextAspectRatio. 

DimensionTextCharSpaceFactor (self)

Getter for property: (float) DimensionTextCharSpaceFactor Returns the dimension text space factor. 

DimensionTextCharSpaceFactor (self, dimensionTextCharSpaceFactor)

Setter for property: (float) DimensionTextCharSpaceFactor. 

DimensionTextColor (self)

Getter for property: (NXOpen.NXColor) DimensionTextColor Returns the dimension text color. 

DimensionTextColor (self, dimensionTextColor)

Setter for property: (NXOpen.NXColor) DimensionTextColor. 

DimensionTextFont (self)

Getter for property: (int) DimensionTextFont Returns the dimension text font. 

DimensionTextFont (self, dimensionTextFont)

Setter for property: (int) DimensionTextFont. 

DimensionTextItalicized (self)

Getter for property: (bool) DimensionTextItalicized Returns the dimension text italic status. 

DimensionTextItalicized (self, dimensionTextItalic)

Setter for property: (bool) DimensionTextItalicized. 

DimensionTextLineSpaceFactor (self)

Getter for property: (float) DimensionTextLineSpaceFactor Returns the dimension text line space factor. 

DimensionTextLineSpaceFactor (self, dimensionTextLineSpaceFactor)

Setter for property: (float) DimensionTextLineSpaceFactor. 

DimensionTextLineWidth (self)

Getter for property: (NXOpen.Annotations.LineWidth) DimensionTextLineWidth Returns the dimension text line width. 

DimensionTextLineWidth (self, dimensionTextLineWidth)

Setter for property: (NXOpen.Annotations.LineWidth) DimensionTextLineWidth. 

DimensionTextSize (self)

Getter for property: (float) DimensionTextSize Returns the dimension text character size. 

DimensionTextSize (self, dimensionTextSize)

Setter for property: (float) DimensionTextSize. 

DimensionTextSymbolAspectRatio (self)

Getter for property: (float) DimensionTextSymbolAspectRatio Returns the symbol aspect ratio for dimension text (only available for symbols when using standard font). 

DimensionTextSymbolAspectRatio (self, dimensionTextSymbolAspect)

Setter for property: (float) DimensionTextSymbolAspectRatio. 

DimLineSpaceFactor (self)

Getter for property: (float) DimLineSpaceFactor Returns the dimension line space factor. 

DimLineSpaceFactor (self, dimLineSpaceFactor)

Setter for property: (float) DimLineSpaceFactor. 

GdtFrameHeightFactor (self)

Getter for property: (float) GdtFrameHeightFactor Returns the GD and T frame height factor. 

GdtFrameHeightFactor (self, gdtFrameHeightFactor)

Setter for property: (float) GdtFrameHeightFactor. 

GeneralNxTextCharacterSpaceFactor (self)

Getter for property: (float) GeneralNxTextCharacterSpaceFactor Returns the general NX text character space factor. 

GeneralNxTextCharacterSpaceFactor (self, generalNXTextCharSpaceFactor)

Setter for property: (float) GeneralNxTextCharacterSpaceFactor. 

GeneralStandardTextCharacterSpaceFactor (self)

Getter for property: (float) GeneralStandardTextCharacterSpaceFactor Returns the general Standard text character space factor. 

GeneralStandardTextCharacterSpaceFactor (self, generalStandardTextCharSpaceFactor)

Setter for property: (float) GeneralStandardTextCharacterSpaceFactor. 

GeneralTextAspectRatio (self)

Getter for property: (float) GeneralTextAspectRatio Returns the general text aspect ratio. 

GeneralTextAspectRatio (self, generalTextAspectRatio)

Setter for property: (float) GeneralTextAspectRatio. 

GeneralTextCharSpaceFactor (self)

Getter for property: (float) GeneralTextCharSpaceFactor Returns the general text character space factor. 

GeneralTextCharSpaceFactor (self, generalTextCharSpaceFactor)

Setter for property: (float) GeneralTextCharSpaceFactor. 

GeneralTextColor (self)

Getter for property: (NXOpen.NXColor) GeneralTextColor Returns the general text color. 

GeneralTextColor (self, generalTextColor)

Setter for property: (NXOpen.NXColor) GeneralTextColor. 

GeneralTextFont (self)

Getter for property: (int) GeneralTextFont Returns the general text font. 

GeneralTextFont (self, generalTextFont)

Setter for property: (int) GeneralTextFont. 

GeneralTextItalicized (self)

Getter for property: (bool) GeneralTextItalicized Returns the general text italic status. 

GeneralTextItalicized (self, generalTextItalicized)

Setter for property: (bool) GeneralTextItalicized. 

GeneralTextLineSpaceFactor (self)

Getter for property: (float) GeneralTextLineSpaceFactor Returns the general text line space factor. 

GeneralTextLineSpaceFactor (self, generalTextLineSpaceFactor)

Setter for property: (float) GeneralTextLineSpaceFactor. 

GeneralTextLineWidth (self)

Getter for property: (NXOpen.Annotations.LineWidth) GeneralTextLineWidth Returns the general text line width. 

GeneralTextLineWidth (self, generalTextLineWidth)

Setter for property: (NXOpen.Annotations.LineWidth) GeneralTextLineWidth. 

GeneralTextSize (self)

Getter for property: (float) GeneralTextSize Returns the general text character size. 

GeneralTextSize (self, generalTextSize)

Setter for property: (float) GeneralTextSize. 

GeneralTextSymbolAspectRatio (self)

Getter for property: (float) GeneralTextSymbolAspectRatio Returns the symbol aspect ratio for general text (only available for symbols when using standard font). 

GeneralTextSymbolAspectRatio (self, generalTextSymbolAspect)

Setter for property: (float) GeneralTextSymbolAspectRatio. 

HorizontalTextJustification (self)

Getter for property: (NXOpen.Annotations.TextJustification) HorizontalTextJustification Returns the horizontal text justification. 

HorizontalTextJustification (self, horizontalTextJustification)

Setter for property: (NXOpen.Annotations.TextJustification) HorizontalTextJustification. 

MultilineVerticalTextDisplayFormat (self)

Getter for property: (int) MultilineVerticalTextDisplayFormat Returns the multiline vertical text display format. 

MultilineVerticalTextDisplayFormat (self, multilineVerticalTextDisplayFormat)

Setter for property: (int) MultilineVerticalTextDisplayFormat. 

StackAboveSpaceFactor (self)

Getter for property: (float) StackAboveSpaceFactor Returns the stack above space factor. 

StackAboveSpaceFactor (self, stackAboveSpaceFactor)

Setter for property: (float) StackAboveSpaceFactor. 

StackAutospace (self)

Getter for property: (bool) StackAutospace Returns the stack autospace setting. 

StackAutospace (self, stackAutospace)

Setter for property: (bool) StackAutospace. 

StackBelowSpaceFactor (self)

Getter for property: (float) StackBelowSpaceFactor Returns the stack below space factor. 

StackBelowSpaceFactor (self, stackBelowSpaceFactor)

Setter for property: (float) StackBelowSpaceFactor. 

StackHorizontalAlignment (self)

Getter for property: (NXOpen.Annotations.StackHorizontalAlignment) StackHorizontalAlignment Returns the stack horizontal alignment. 

StackHorizontalAlignment (self, stackHorizontalAlignment)

Setter for property: (NXOpen.Annotations.StackHorizontalAlignment) StackHorizontalAlignment. 

StackInheritAssociatedObjects (self)

Getter for property: (bool) StackInheritAssociatedObjects Returns the stack inherit associated objects setting. 

StackInheritAssociatedObjects (self, stackInheritAssociatedObjects)

Setter for property: (bool) StackInheritAssociatedObjects. 

StackLeftSpaceFactor (self)

Getter for property: (float) StackLeftSpaceFactor Returns the stack left space factor. 

StackLeftSpaceFactor (self, stackLeftSpaceFactor)

Setter for property: (float) StackLeftSpaceFactor. 

StackRightSpaceFactor (self)

Getter for property: (float) StackRightSpaceFactor Returns the stack right space factor. 

StackRightSpaceFactor (self, stackRightSpaceFactor)

Setter for property: (float) StackRightSpaceFactor. 

StackVerticalAlignment (self)

Getter for property: (NXOpen.Annotations.StackVerticalAlignment) StackVerticalAlignment Returns the stack vertical alignment. 

StackVerticalAlignment (self, stackVerticalAlignment)

Setter for property: (NXOpen.Annotations.StackVerticalAlignment) StackVerticalAlignment. 

SymbolFontFile (self)

Getter for property: (str) SymbolFontFile Returns the symbol font file setting. 

SymbolFontFile (self, symbolFontFile)

Setter for property: (str) SymbolFontFile. 

ToleranceNxTextCharacterSpaceFactor (self)

Getter for property: (float) ToleranceNxTextCharacterSpaceFactor Returns the tolerance NX text character space factor. 

ToleranceNxTextCharacterSpaceFactor (self, toleranceNXTextCharSpaceFactor)

Setter for property: (float) ToleranceNxTextCharacterSpaceFactor. 

ToleranceStandardTextCharacterSpaceFactor (self)

Getter for property: (float) ToleranceStandardTextCharacterSpaceFactor Returns the tolerance Standard text character space factor. 

ToleranceStandardTextCharacterSpaceFactor (self, toleranceStandardTextCharSpaceFactor)

Setter for property: (float) ToleranceStandardTextCharacterSpaceFactor. 

ToleranceTextAspectRatio (self)

Getter for property: (float) ToleranceTextAspectRatio Returns the tolerance text aspect ratio. 

ToleranceTextAspectRatio (self, toleranceTextAspectRatio)

Setter for property: (float) ToleranceTextAspectRatio. 

ToleranceTextCharSpaceFactor (self)

Getter for property: (float) ToleranceTextCharSpaceFactor Returns the tolerance text character space factor. 

ToleranceTextCharSpaceFactor (self, toleranceTextCharSpaceFactor)

Setter for property: (float) ToleranceTextCharSpaceFactor. 

ToleranceTextColor (self)

Getter for property: (NXOpen.NXColor) ToleranceTextColor Returns the tolerance text color. 

ToleranceTextColor (self, toleranceTextColor)

Setter for property: (NXOpen.NXColor) ToleranceTextColor. 

ToleranceTextFont (self)

Getter for property: (int) ToleranceTextFont Returns the tolerance text font. 

ToleranceTextFont (self, toleranceTextFont)

Setter for property: (int) ToleranceTextFont. 

ToleranceTextItalicized (self)

Getter for property: (bool) ToleranceTextItalicized Returns the tolerance text italic status. 

ToleranceTextItalicized (self, toleranceTextItalicized)

Setter for property: (bool) ToleranceTextItalicized. 

ToleranceTextLineSpaceFactor (self)

Getter for property: (float) ToleranceTextLineSpaceFactor Returns the tolerance text line space factor. 

ToleranceTextLineSpaceFactor (self, toleranceTextLineSpaceFactor)

Setter for property: (float) ToleranceTextLineSpaceFactor. 

ToleranceTextLineWidth (self)

Getter for property: (NXOpen.Annotations.LineWidth) ToleranceTextLineWidth Returns the tolerance text line width. 

ToleranceTextLineWidth (self, toleranceTextLineWidth)

Setter for property: (NXOpen.Annotations.LineWidth) ToleranceTextLineWidth. 

ToleranceTextSize (self)

Getter for property: (float) ToleranceTextSize Returns the tolerance text character size. 

ToleranceTextSize (self, toleranceTextSize)

Setter for property: (float) ToleranceTextSize. 

ToleranceTextSpaceFactor (self)

Getter for property: (float) ToleranceTextSpaceFactor Returns the tolerance text space factor. 

ToleranceTextSpaceFactor (self, toleranceTextSpaceFactor)

Setter for property: (float) ToleranceTextSpaceFactor. 

ToleranceTextSymbolAspectRatio (self)

Getter for property: (float) ToleranceTextSymbolAspectRatio Returns the symbol aspect ratio for tolerance text (only available for symbols when using standard font). 

ToleranceTextSymbolAspectRatio (self, toleranceTextSymbolAspect)

Setter for property: (float) ToleranceTextSymbolAspectRatio. 

TwoLineToleranceTextSize (self)

Getter for property: (float) TwoLineToleranceTextSize Returns the two-line tolerance text character size. 

TwoLineToleranceTextSize (self, twoLineToleranceTextSize)

Setter for property: (float) TwoLineToleranceTextSize. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::LetteringStyleBuilder . 

This class queries and sets lettering preferences when creating or editing annotations.

Created in NX6.0.0 

## Member Function Documentation

## ◆ AlignPosition() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.AlignPosition
(
self — )

Getter for property: (NXOpen.Annotations.AlignmentPosition) AlignPosition Returns the alignment position. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
AlignmentPosition 

## ◆ AlignPosition() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.AlignPosition
(
self,

alignPosition )

Setter for property: (NXOpen.Annotations.AlignmentPosition) AlignPosition. 

Sets the alignment position

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ Angle() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.Angle
(
self — )

Getter for property: (float) Angle Returns the angle for general text. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ Angle() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.Angle
(
self,

angle )

Setter for property: (float) Angle. 

Sets the angle for general text

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ AppendedNxTextCharacterSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedNxTextCharacterSpaceFactor
(
self — )

Getter for property: (float) AppendedNxTextCharacterSpaceFactor Returns the appended NX text character space factor. 

This defines the spacing between characters in text as a multiple of the standard character spacing for the NX font. This setting is specific to preferences and object style in create mode.

Getter License requirements: None.

Created in NX9.0.0 

Returns
float 

## ◆ AppendedNxTextCharacterSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedNxTextCharacterSpaceFactor
(
self,

appendedNXTextCharSpaceFactor )

Setter for property: (float) AppendedNxTextCharacterSpaceFactor. 

Sets the appended NX text character space factor.

This defines the spacing between characters in text as a multiple of the standard character spacing for the NX font. This setting is specific to preferences and object style in create mode.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ AppendedStandardTextCharacterSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedStandardTextCharacterSpaceFactor
(
self — )

Getter for property: (float) AppendedStandardTextCharacterSpaceFactor Returns the appended Standard text character space factor. 

This defines the spacing between characters in text as a multiple of the standard character spacing for the Standard font. This setting is specific to preferences and object style in create mode.

Getter License requirements: None.

Created in NX9.0.0 

Returns
float 

## ◆ AppendedStandardTextCharacterSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedStandardTextCharacterSpaceFactor
(
self,

appendedStandardTextCharSpaceFactor )

Setter for property: (float) AppendedStandardTextCharacterSpaceFactor. 

Sets the appended Standard text character space factor.

This defines the spacing between characters in text as a multiple of the standard character spacing for the Standard font. This setting is specific to preferences and object style in create mode.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ AppendedTextAspectRatio() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextAspectRatio
(
self — )

Getter for property: (float) AppendedTextAspectRatio Returns the appended text aspect ratio. 

This specifies a ratio of length to height which represents the size of character text. This only defines the aspect ratio for text. LetteringStyleBuilder::AppendedTextSymbolAspectRatio controls the aspect ratio of symbol text control sequences.

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ AppendedTextAspectRatio() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextAspectRatio
(
self,

appendedTextAspectRatio )

Setter for property: (float) AppendedTextAspectRatio. 

Sets the appended text aspect ratio.

This specifies a ratio of length to height which represents the size of character text. This only defines the aspect ratio for text. LetteringStyleBuilder::AppendedTextSymbolAspectRatio controls the aspect ratio of symbol text control sequences.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ AppendedTextCharSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextCharSpaceFactor
(
self — )

Getter for property: (float) AppendedTextCharSpaceFactor Returns the appended text character space factor. 

This defines the spacing between characters in text as a multiple of the standard character spacing for the current font

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ AppendedTextCharSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextCharSpaceFactor
(
self,

appendedTextCharSpaceFactor )

Setter for property: (float) AppendedTextCharSpaceFactor. 

Sets the appended text character space factor.

This defines the spacing between characters in text as a multiple of the standard character spacing for the current font

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ AppendedTextColor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextColor
(
self — )

Getter for property: (NXOpen.NXColor) AppendedTextColor Returns the appended text color. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.NXColor 

## ◆ AppendedTextColor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextColor
(
self,

appendedTextColor )

Setter for property: (NXOpen.NXColor) AppendedTextColor. 

Sets the appended text color

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ AppendedTextFont() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextFont
(
self — )

Getter for property: (int) AppendedTextFont Returns the appended text font. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
int 

## ◆ AppendedTextFont() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextFont
(
self,

appendedTextFont )

Setter for property: (int) AppendedTextFont. 

Sets the appended text font

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ AppendedTextItalicized() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextItalicized
(
self — )

Getter for property: (bool) AppendedTextItalicized Returns the appended text italic status. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ AppendedTextItalicized() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextItalicized
(
self,

appendedTextItalicized )

Setter for property: (bool) AppendedTextItalicized. 

Sets the appended text italic status

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ AppendedTextLineSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextLineSpaceFactor
(
self — )

Getter for property: (float) AppendedTextLineSpaceFactor Returns the appended text line space factor. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ AppendedTextLineSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextLineSpaceFactor
(
self,

appendedTextLineSpaceFactor )

Setter for property: (float) AppendedTextLineSpaceFactor. 

Sets the appended text line space factor

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ AppendedTextLineWidth() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextLineWidth
(
self — )

Getter for property: (NXOpen.Annotations.LineWidth) AppendedTextLineWidth Returns the appended text line width. 

The values for NXOpen::Annotations::LineWidth when using standard font : A value of NXOpen::Annotations::LineWidthThin is equivalent to a value of "Regular" or "Italic" (if NXOpen::Annotations::LetteringStyleBuilder::AppendedTextItalicized is set). Any value other than NXOpen::Annotations::LineWidthThin is equivalent to a value of "Bold" or "Bold Italic" (if NXOpen::Annotations::LetteringStyleBuilder::AppendedTextItalicized is set).

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWidth 

## ◆ AppendedTextLineWidth() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextLineWidth
(
self,

appendedTextLineWidth )

Setter for property: (NXOpen.Annotations.LineWidth) AppendedTextLineWidth. 

Sets the appended text line width.

The values for NXOpen::Annotations::LineWidth when using standard font : A value of NXOpen::Annotations::LineWidthThin is equivalent to a value of "Regular" or "Italic" (if NXOpen::Annotations::LetteringStyleBuilder::AppendedTextItalicized is set). Any value other than NXOpen::Annotations::LineWidthThin is equivalent to a value of "Bold" or "Bold Italic" (if NXOpen::Annotations::LetteringStyleBuilder::AppendedTextItalicized is set).

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ AppendedTextSize() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextSize
(
self — )

Getter for property: (float) AppendedTextSize Returns the appended text character size. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ AppendedTextSize() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextSize
(
self,

appendedTextSize )

Setter for property: (float) AppendedTextSize. 

Sets the appended text character size

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ AppendedTextSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextSpaceFactor
(
self — )

Getter for property: (float) AppendedTextSpaceFactor Returns the appended text space factor. 

This controls the spacing between the before appended text and the next piece of dimension text to its right; and the spacing between the after appended text and the next piece of text to its left. The space is equal to the appended text character size multiplied by the space factor

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ AppendedTextSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextSpaceFactor
(
self,

appendedTextSpaceFactor )

Setter for property: (float) AppendedTextSpaceFactor. 

Sets the appended text space factor.

This controls the spacing between the before appended text and the next piece of dimension text to its right; and the spacing between the after appended text and the next piece of text to its left. The space is equal to the appended text character size multiplied by the space factor

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ AppendedTextSymbolAspectRatio() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextSymbolAspectRatio
(
self — )

Getter for property: (float) AppendedTextSymbolAspectRatio Returns the symbol aspect ratio for appended text (only available for symbols when using standard font). 

This value controls the aspect ratio of text control sequences such as the diameter symbol (represented by the &x3C;O&x3E; text control sequence), the counterbore symbol (represented by the &x3C;&x23;C&x3E; text control sequence), the degree symbol (represented by the &x3C;&x24;s&x3E; text control sequence), the true position symbol (represented by the &x3C;&x26;10&x3E; text control sequence), etc.

Getter License requirements: None.

Created in NX11.0.0 

Returns
float 

## ◆ AppendedTextSymbolAspectRatio() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.AppendedTextSymbolAspectRatio
(
self,

appendedTextSymbolAspect )

Setter for property: (float) AppendedTextSymbolAspectRatio. 

Sets the symbol aspect ratio for appended text (only available for symbols when using standard font).

This value controls the aspect ratio of text control sequences such as the diameter symbol (represented by the &x3C;O&x3E; text control sequence), the counterbore symbol (represented by the &x3C;&x23;C&x3E; text control sequence), the degree symbol (represented by the &x3C;&x24;s&x3E; text control sequence), the true position symbol (represented by the &x3C;&x26;10&x3E; text control sequence), etc.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX11.0.0 

## ◆ DimensionNxTextCharacterSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionNxTextCharacterSpaceFactor
(
self — )

Getter for property: (float) DimensionNxTextCharacterSpaceFactor Returns the dimension NX text character space factor. 

This defines the spacing between characters in text as a multiple of the standard character spacing for the NX font. This setting is specific to preferences and object style in create mode.

Getter License requirements: None.

Created in NX9.0.0 

Returns
float 

## ◆ DimensionNxTextCharacterSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionNxTextCharacterSpaceFactor
(
self,

dimensionNXTextCharSpaceFactor )

Setter for property: (float) DimensionNxTextCharacterSpaceFactor. 

Sets the dimension NX text character space factor.

This defines the spacing between characters in text as a multiple of the standard character spacing for the NX font. This setting is specific to preferences and object style in create mode.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ DimensionStandardTextCharacterSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionStandardTextCharacterSpaceFactor
(
self — )

Getter for property: (float) DimensionStandardTextCharacterSpaceFactor Returns the dimension Standard text character space factor. 

This defines the spacing between characters in text as a multiple of the standard character spacing for the Standard font. This setting is specific to preferences and object style in create mode.

Getter License requirements: None.

Created in NX9.0.0 

Returns
float 

## ◆ DimensionStandardTextCharacterSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionStandardTextCharacterSpaceFactor
(
self,

dimensionStandardTextCharSpaceFactor )

Setter for property: (float) DimensionStandardTextCharacterSpaceFactor. 

Sets the dimension Standard text character space factor.

This defines the spacing between characters in text as a multiple of the standard character spacing for the Standard font. This setting is specific to preferences and object style in create mode.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ DimensionTextAspectRatio() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextAspectRatio
(
self — )

Getter for property: (float) DimensionTextAspectRatio Returns the dimension text aspect ratio. 

This specifies a ratio of length to height which represents the size of character text. This only defines the aspect ratio for text. LetteringStyleBuilder::DimensionTextSymbolAspectRatio controls the aspect ratio of symbol text control sequences.

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ DimensionTextAspectRatio() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextAspectRatio
(
self,

dimensionTextAspectRatio )

Setter for property: (float) DimensionTextAspectRatio. 

Sets the dimension text aspect ratio.

This specifies a ratio of length to height which represents the size of character text. This only defines the aspect ratio for text. LetteringStyleBuilder::DimensionTextSymbolAspectRatio controls the aspect ratio of symbol text control sequences.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DimensionTextCharSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextCharSpaceFactor
(
self — )

Getter for property: (float) DimensionTextCharSpaceFactor Returns the dimension text space factor. 

This defines the spacing between characters in text as a multiple of the standard character spacing for the current font

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ DimensionTextCharSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextCharSpaceFactor
(
self,

dimensionTextCharSpaceFactor )

Setter for property: (float) DimensionTextCharSpaceFactor. 

Sets the dimension text space factor.

This defines the spacing between characters in text as a multiple of the standard character spacing for the current font

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DimensionTextColor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextColor
(
self — )

Getter for property: (NXOpen.NXColor) DimensionTextColor Returns the dimension text color. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.NXColor 

## ◆ DimensionTextColor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextColor
(
self,

dimensionTextColor )

Setter for property: (NXOpen.NXColor) DimensionTextColor. 

Sets the dimension text color

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DimensionTextFont() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextFont
(
self — )

Getter for property: (int) DimensionTextFont Returns the dimension text font. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
int 

## ◆ DimensionTextFont() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextFont
(
self,

dimensionTextFont )

Setter for property: (int) DimensionTextFont. 

Sets the dimension text font

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DimensionTextItalicized() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextItalicized
(
self — )

Getter for property: (bool) DimensionTextItalicized Returns the dimension text italic status. 

Getter License requirements: None.

Created in NX8.5.0 

Returns
bool 

## ◆ DimensionTextItalicized() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextItalicized
(
self,

dimensionTextItalic )

Setter for property: (bool) DimensionTextItalicized. 

Sets the dimension text italic status

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX8.5.0 

## ◆ DimensionTextLineSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextLineSpaceFactor
(
self — )

Getter for property: (float) DimensionTextLineSpaceFactor Returns the dimension text line space factor. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ DimensionTextLineSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextLineSpaceFactor
(
self,

dimensionTextLineSpaceFactor )

Setter for property: (float) DimensionTextLineSpaceFactor. 

Sets the dimension text line space factor

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DimensionTextLineWidth() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextLineWidth
(
self — )

Getter for property: (NXOpen.Annotations.LineWidth) DimensionTextLineWidth Returns the dimension text line width. 

The values for NXOpen::Annotations::LineWidth when using standard font : A value of NXOpen::Annotations::LineWidthThin is equivalent to a value of "Regular" or "Italic" (if NXOpen::Annotations::LetteringStyleBuilder::DimensionTextItalicized is set). Any value other than NXOpen::Annotations::LineWidthThin is equivalent to a value of "Bold" or "Bold Italic" (if NXOpen::Annotations::LetteringStyleBuilder::DimensionTextItalicized is set).

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWidth 

## ◆ DimensionTextLineWidth() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextLineWidth
(
self,

dimensionTextLineWidth )

Setter for property: (NXOpen.Annotations.LineWidth) DimensionTextLineWidth. 

Sets the dimension text line width.

The values for NXOpen::Annotations::LineWidth when using standard font : A value of NXOpen::Annotations::LineWidthThin is equivalent to a value of "Regular" or "Italic" (if NXOpen::Annotations::LetteringStyleBuilder::DimensionTextItalicized is set). Any value other than NXOpen::Annotations::LineWidthThin is equivalent to a value of "Bold" or "Bold Italic" (if NXOpen::Annotations::LetteringStyleBuilder::DimensionTextItalicized is set).

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DimensionTextSize() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextSize
(
self — )

Getter for property: (float) DimensionTextSize Returns the dimension text character size. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ DimensionTextSize() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextSize
(
self,

dimensionTextSize )

Setter for property: (float) DimensionTextSize. 

Sets the dimension text character size

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DimensionTextSymbolAspectRatio() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextSymbolAspectRatio
(
self — )

Getter for property: (float) DimensionTextSymbolAspectRatio Returns the symbol aspect ratio for dimension text (only available for symbols when using standard font). 

This value controls the aspect ratio of text control sequences such as the diameter symbol (represented by the &x3C;O&x3E; text control sequence), the counterbore symbol (represented by the &x3C;&x23;C&x3E; text control sequence), the degree symbol (represented by the &x3C;&x24;s&x3E; text control sequence), the true position symbol (represented by the &x3C;&x26;10&x3E; text control sequence), etc.

Getter License requirements: None.

Created in NX11.0.0 

Returns
float 

## ◆ DimensionTextSymbolAspectRatio() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.DimensionTextSymbolAspectRatio
(
self,

dimensionTextSymbolAspect )

Setter for property: (float) DimensionTextSymbolAspectRatio. 

Sets the symbol aspect ratio for dimension text (only available for symbols when using standard font).

This value controls the aspect ratio of text control sequences such as the diameter symbol (represented by the &x3C;O&x3E; text control sequence), the counterbore symbol (represented by the &x3C;&x23;C&x3E; text control sequence), the degree symbol (represented by the &x3C;&x24;s&x3E; text control sequence), the true position symbol (represented by the &x3C;&x26;10&x3E; text control sequence), etc.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX11.0.0 

## ◆ DimLineSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.DimLineSpaceFactor
(
self — )

Getter for property: (float) DimLineSpaceFactor Returns the dimension line space factor. 

This controls the spacing between the bottom most piece of text on the dimension and the dimension line. This only applies when the text orientation is text over dimension line. The space is equal to the dimension text character size multiplied by the space factor

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ DimLineSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.DimLineSpaceFactor
(
self,

dimLineSpaceFactor )

Setter for property: (float) DimLineSpaceFactor. 

Sets the dimension line space factor.

This controls the spacing between the bottom most piece of text on the dimension and the dimension line. This only applies when the text orientation is text over dimension line. The space is equal to the dimension text character size multiplied by the space factor

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ GdtFrameHeightFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.GdtFrameHeightFactor
(
self — )

Getter for property: (float) GdtFrameHeightFactor Returns the GD and T frame height factor. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ GdtFrameHeightFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.GdtFrameHeightFactor
(
self,

gdtFrameHeightFactor )

Setter for property: (float) GdtFrameHeightFactor. 

Sets the GD and T frame height factor

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ GeneralNxTextCharacterSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralNxTextCharacterSpaceFactor
(
self — )

Getter for property: (float) GeneralNxTextCharacterSpaceFactor Returns the general NX text character space factor. 

This defines the spacing between characters in text as a multiple of the standard character spacing for the NX font. This setting is specific to preferences and object style in create mode.

Getter License requirements: None.

Created in NX9.0.0 

Returns
float 

## ◆ GeneralNxTextCharacterSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralNxTextCharacterSpaceFactor
(
self,

generalNXTextCharSpaceFactor )

Setter for property: (float) GeneralNxTextCharacterSpaceFactor. 

Sets the general NX text character space factor.

This defines the spacing between characters in text as a multiple of the standard character spacing for the NX font. This setting is specific to preferences and object style in create mode.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ GeneralStandardTextCharacterSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralStandardTextCharacterSpaceFactor
(
self — )

Getter for property: (float) GeneralStandardTextCharacterSpaceFactor Returns the general Standard text character space factor. 

This defines the spacing between characters in text as a multiple of the standard character spacing for the Standard font. This setting is specific to preferences and object style in create mode.

Getter License requirements: None.

Created in NX9.0.0 

Returns
float 

## ◆ GeneralStandardTextCharacterSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralStandardTextCharacterSpaceFactor
(
self,

generalStandardTextCharSpaceFactor )

Setter for property: (float) GeneralStandardTextCharacterSpaceFactor. 

Sets the general Standard text character space factor.

This defines the spacing between characters in text as a multiple of the standard character spacing for the Standard font. This setting is specific to preferences and object style in create mode.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ GeneralTextAspectRatio() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextAspectRatio
(
self — )

Getter for property: (float) GeneralTextAspectRatio Returns the general text aspect ratio. 

This specifies a ratio of length to height which represents the size of character text. This only defines the aspect ratio for text. LetteringStyleBuilder::GeneralTextSymbolAspectRatio controls the aspect ratio of symbol text control sequences.

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ GeneralTextAspectRatio() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextAspectRatio
(
self,

generalTextAspectRatio )

Setter for property: (float) GeneralTextAspectRatio. 

Sets the general text aspect ratio.

This specifies a ratio of length to height which represents the size of character text. This only defines the aspect ratio for text. LetteringStyleBuilder::GeneralTextSymbolAspectRatio controls the aspect ratio of symbol text control sequences.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ GeneralTextCharSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextCharSpaceFactor
(
self — )

Getter for property: (float) GeneralTextCharSpaceFactor Returns the general text character space factor. 

This defines the spacing between characters in text as a multiple of the standard character spacing for the current font

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ GeneralTextCharSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextCharSpaceFactor
(
self,

generalTextCharSpaceFactor )

Setter for property: (float) GeneralTextCharSpaceFactor. 

Sets the general text character space factor.

This defines the spacing between characters in text as a multiple of the standard character spacing for the current font

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ GeneralTextColor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextColor
(
self — )

Getter for property: (NXOpen.NXColor) GeneralTextColor Returns the general text color. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.NXColor 

## ◆ GeneralTextColor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextColor
(
self,

generalTextColor )

Setter for property: (NXOpen.NXColor) GeneralTextColor. 

Sets the general text color

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ GeneralTextFont() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextFont
(
self — )

Getter for property: (int) GeneralTextFont Returns the general text font. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
int 

## ◆ GeneralTextFont() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextFont
(
self,

generalTextFont )

Setter for property: (int) GeneralTextFont. 

Sets the general text font

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ GeneralTextItalicized() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextItalicized
(
self — )

Getter for property: (bool) GeneralTextItalicized Returns the general text italic status. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ GeneralTextItalicized() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextItalicized
(
self,

generalTextItalicized )

Setter for property: (bool) GeneralTextItalicized. 

Sets the general text italic status

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ GeneralTextLineSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextLineSpaceFactor
(
self — )

Getter for property: (float) GeneralTextLineSpaceFactor Returns the general text line space factor. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ GeneralTextLineSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextLineSpaceFactor
(
self,

generalTextLineSpaceFactor )

Setter for property: (float) GeneralTextLineSpaceFactor. 

Sets the general text line space factor

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ GeneralTextLineWidth() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextLineWidth
(
self — )

Getter for property: (NXOpen.Annotations.LineWidth) GeneralTextLineWidth Returns the general text line width. 

The values for NXOpen::Annotations::LineWidth when using standard font : A value of NXOpen::Annotations::LineWidthThin is equivalent to a value of "Regular" or "Italic" (if NXOpen::Annotations::LetteringStyleBuilder::GeneralTextItalicized is set). Any value other than NXOpen::Annotations::LineWidthThin is equivalent to a value of "Bold" or "Bold Italic" (if NXOpen::Annotations::LetteringStyleBuilder::GeneralTextItalicized is set).

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWidth 

## ◆ GeneralTextLineWidth() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextLineWidth
(
self,

generalTextLineWidth )

Setter for property: (NXOpen.Annotations.LineWidth) GeneralTextLineWidth. 

Sets the general text line width.

The values for NXOpen::Annotations::LineWidth when using standard font : A value of NXOpen::Annotations::LineWidthThin is equivalent to a value of "Regular" or "Italic" (if NXOpen::Annotations::LetteringStyleBuilder::GeneralTextItalicized is set). Any value other than NXOpen::Annotations::LineWidthThin is equivalent to a value of "Bold" or "Bold Italic" (if NXOpen::Annotations::LetteringStyleBuilder::GeneralTextItalicized is set).

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ GeneralTextSize() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextSize
(
self — )

Getter for property: (float) GeneralTextSize Returns the general text character size. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ GeneralTextSize() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextSize
(
self,

generalTextSize )

Setter for property: (float) GeneralTextSize. 

Sets the general text character size

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ GeneralTextSymbolAspectRatio() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextSymbolAspectRatio
(
self — )

Getter for property: (float) GeneralTextSymbolAspectRatio Returns the symbol aspect ratio for general text (only available for symbols when using standard font). 

This value controls the aspect ratio of text control sequences such as the diameter symbol (represented by the &x3C;O&x3E; text control sequence), the counterbore symbol (represented by the &x3C;&x23;C&x3E; text control sequence), the degree symbol (represented by the &x3C;&x24;s&x3E; text control sequence), the true position symbol (represented by the &x3C;&x26;10&x3E; text control sequence), etc.

Getter License requirements: None.

Created in NX11.0.0 

Returns
float 

## ◆ GeneralTextSymbolAspectRatio() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.GeneralTextSymbolAspectRatio
(
self,

generalTextSymbolAspect )

Setter for property: (float) GeneralTextSymbolAspectRatio. 

Sets the symbol aspect ratio for general text (only available for symbols when using standard font).

This value controls the aspect ratio of text control sequences such as the diameter symbol (represented by the &x3C;O&x3E; text control sequence), the counterbore symbol (represented by the &x3C;&x23;C&x3E; text control sequence), the degree symbol (represented by the &x3C;&x24;s&x3E; text control sequence), the true position symbol (represented by the &x3C;&x26;10&x3E; text control sequence), etc.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX11.0.0 

## ◆ HorizontalTextJustification() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.HorizontalTextJustification
(
self — )

Getter for property: (NXOpen.Annotations.TextJustification) HorizontalTextJustification Returns the horizontal text justification. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
TextJustification 

## ◆ HorizontalTextJustification() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.HorizontalTextJustification
(
self,

horizontalTextJustification )

Setter for property: (NXOpen.Annotations.TextJustification) HorizontalTextJustification. 

Sets the horizontal text justification

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ MultilineVerticalTextDisplayFormat() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.MultilineVerticalTextDisplayFormat
(
self — )

Getter for property: (int) MultilineVerticalTextDisplayFormat Returns the multiline vertical text display format. 

Getter License requirements: None.

Created in NX2312.0.0 

Returns
int 

## ◆ MultilineVerticalTextDisplayFormat() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.MultilineVerticalTextDisplayFormat
(
self,

multilineVerticalTextDisplayFormat )

Setter for property: (int) MultilineVerticalTextDisplayFormat. 

Sets the multiline vertical text display format

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2312.0.0 

## ◆ StackAboveSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.StackAboveSpaceFactor
(
self — )

Getter for property: (float) StackAboveSpaceFactor Returns the stack above space factor. 

This specifies the space buffer above the annotation within a stack as a factor of a multiple of the character size

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ StackAboveSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.StackAboveSpaceFactor
(
self,

stackAboveSpaceFactor )

Setter for property: (float) StackAboveSpaceFactor. 

Sets the stack above space factor.

This specifies the space buffer above the annotation within a stack as a factor of a multiple of the character size

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ StackAutospace() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.StackAutospace
(
self — )

Getter for property: (bool) StackAutospace Returns the stack autospace setting. 

A value of True means that system defined spacing values will be used when a symbol is inserted into a stack

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ StackAutospace() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.StackAutospace
(
self,

stackAutospace )

Setter for property: (bool) StackAutospace. 

Sets the stack autospace setting.

A value of True means that system defined spacing values will be used when a symbol is inserted into a stack

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ StackBelowSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.StackBelowSpaceFactor
(
self — )

Getter for property: (float) StackBelowSpaceFactor Returns the stack below space factor. 

This specifies the space buffer below the annotation within a stack as a factor of a multiple of the character size

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ StackBelowSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.StackBelowSpaceFactor
(
self,

stackBelowSpaceFactor )

Setter for property: (float) StackBelowSpaceFactor. 

Sets the stack below space factor.

This specifies the space buffer below the annotation within a stack as a factor of a multiple of the character size

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ StackHorizontalAlignment() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.StackHorizontalAlignment
(
self — )

Getter for property: (NXOpen.Annotations.StackHorizontalAlignment) StackHorizontalAlignment Returns the stack horizontal alignment. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
StackHorizontalAlignment 

## ◆ StackHorizontalAlignment() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.StackHorizontalAlignment
(
self,

stackHorizontalAlignment )

Setter for property: (NXOpen.Annotations.StackHorizontalAlignment) StackHorizontalAlignment. 

Sets the stack horizontal alignment

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ StackInheritAssociatedObjects() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.StackInheritAssociatedObjects
(
self — )

Getter for property: (bool) StackInheritAssociatedObjects Returns the stack inherit associated objects setting. 

A value of True means that a PMI annotation when added to a stack will automatically inherit the associated objects of the stack

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ StackInheritAssociatedObjects() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.StackInheritAssociatedObjects
(
self,

stackInheritAssociatedObjects )

Setter for property: (bool) StackInheritAssociatedObjects. 

Sets the stack inherit associated objects setting.

A value of True means that a PMI annotation when added to a stack will automatically inherit the associated objects of the stack

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ StackLeftSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.StackLeftSpaceFactor
(
self — )

Getter for property: (float) StackLeftSpaceFactor Returns the stack left space factor. 

This specifies the space buffer to the left of the annotation within a stack as a factor of a multiple of the character size

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ StackLeftSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.StackLeftSpaceFactor
(
self,

stackLeftSpaceFactor )

Setter for property: (float) StackLeftSpaceFactor. 

Sets the stack left space factor.

This specifies the space buffer to the left of the annotation within a stack as a factor of a multiple of the character size

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ StackRightSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.StackRightSpaceFactor
(
self — )

Getter for property: (float) StackRightSpaceFactor Returns the stack right space factor. 

This specifies the space buffer to the rght of the annotation within a stack as a factor of a multiple of the character size

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ StackRightSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.StackRightSpaceFactor
(
self,

stackRightSpaceFactor )

Setter for property: (float) StackRightSpaceFactor. 

Sets the stack right space factor.

This specifies the space buffer to the rght of the annotation within a stack as a factor of a multiple of the character size

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ StackVerticalAlignment() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.StackVerticalAlignment
(
self — )

Getter for property: (NXOpen.Annotations.StackVerticalAlignment) StackVerticalAlignment Returns the stack vertical alignment. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
StackVerticalAlignment 

## ◆ StackVerticalAlignment() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.StackVerticalAlignment
(
self,

stackVerticalAlignment )

Setter for property: (NXOpen.Annotations.StackVerticalAlignment) StackVerticalAlignment. 

Sets the stack vertical alignment

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SymbolFontFile() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.SymbolFontFile
(
self — )

Getter for property: (str) SymbolFontFile Returns the symbol font file setting. 

This is global preferences setting.

Getter License requirements: None.

Created in NX9.0.0 

Returns
str 

## ◆ SymbolFontFile() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.SymbolFontFile
(
self,

symbolFontFile )

Setter for property: (str) SymbolFontFile. 

Sets the symbol font file setting.

This is global preferences setting.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ ToleranceNxTextCharacterSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceNxTextCharacterSpaceFactor
(
self — )

Getter for property: (float) ToleranceNxTextCharacterSpaceFactor Returns the tolerance NX text character space factor. 

This defines the spacing between characters in text as a multiple of the standard character spacing for the NX font. This setting is specific to preferences and object style in create mode.

Getter License requirements: None.

Created in NX9.0.0 

Returns
float 

## ◆ ToleranceNxTextCharacterSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceNxTextCharacterSpaceFactor
(
self,

toleranceNXTextCharSpaceFactor )

Setter for property: (float) ToleranceNxTextCharacterSpaceFactor. 

Sets the tolerance NX text character space factor.

This defines the spacing between characters in text as a multiple of the standard character spacing for the NX font. This setting is specific to preferences and object style in create mode.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ ToleranceStandardTextCharacterSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceStandardTextCharacterSpaceFactor
(
self — )

Getter for property: (float) ToleranceStandardTextCharacterSpaceFactor Returns the tolerance Standard text character space factor. 

This defines the spacing between characters in text as a multiple of the standard character spacing for the Standard font. This setting is specific to preferences and object style in create mode.

Getter License requirements: None.

Created in NX9.0.0 

Returns
float 

## ◆ ToleranceStandardTextCharacterSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceStandardTextCharacterSpaceFactor
(
self,

toleranceStandardTextCharSpaceFactor )

Setter for property: (float) ToleranceStandardTextCharacterSpaceFactor. 

Sets the tolerance Standard text character space factor.

This defines the spacing between characters in text as a multiple of the standard character spacing for the Standard font. This setting is specific to preferences and object style in create mode.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ ToleranceTextAspectRatio() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextAspectRatio
(
self — )

Getter for property: (float) ToleranceTextAspectRatio Returns the tolerance text aspect ratio. 

This specifies a ratio of length to height which represents the size of character text. This only defines the aspect ratio for text. LetteringStyleBuilder::ToleranceTextSymbolAspectRatio controls the aspect ratio of symbol text control sequences.

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ ToleranceTextAspectRatio() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextAspectRatio
(
self,

toleranceTextAspectRatio )

Setter for property: (float) ToleranceTextAspectRatio. 

Sets the tolerance text aspect ratio.

This specifies a ratio of length to height which represents the size of character text. This only defines the aspect ratio for text. LetteringStyleBuilder::ToleranceTextSymbolAspectRatio controls the aspect ratio of symbol text control sequences.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ToleranceTextCharSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextCharSpaceFactor
(
self — )

Getter for property: (float) ToleranceTextCharSpaceFactor Returns the tolerance text character space factor. 

This defines the spacing between characters in text as a multiple of the standard character spacing for the current font

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ ToleranceTextCharSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextCharSpaceFactor
(
self,

toleranceTextCharSpaceFactor )

Setter for property: (float) ToleranceTextCharSpaceFactor. 

Sets the tolerance text character space factor.

This defines the spacing between characters in text as a multiple of the standard character spacing for the current font

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ToleranceTextColor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextColor
(
self — )

Getter for property: (NXOpen.NXColor) ToleranceTextColor Returns the tolerance text color. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.NXColor 

## ◆ ToleranceTextColor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextColor
(
self,

toleranceTextColor )

Setter for property: (NXOpen.NXColor) ToleranceTextColor. 

Sets the tolerance text color

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ToleranceTextFont() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextFont
(
self — )

Getter for property: (int) ToleranceTextFont Returns the tolerance text font. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
int 

## ◆ ToleranceTextFont() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextFont
(
self,

toleranceTextFont )

Setter for property: (int) ToleranceTextFont. 

Sets the tolerance text font

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ToleranceTextItalicized() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextItalicized
(
self — )

Getter for property: (bool) ToleranceTextItalicized Returns the tolerance text italic status. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ ToleranceTextItalicized() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextItalicized
(
self,

toleranceTextItalicized )

Setter for property: (bool) ToleranceTextItalicized. 

Sets the tolerance text italic status

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ToleranceTextLineSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextLineSpaceFactor
(
self — )

Getter for property: (float) ToleranceTextLineSpaceFactor Returns the tolerance text line space factor. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ ToleranceTextLineSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextLineSpaceFactor
(
self,

toleranceTextLineSpaceFactor )

Setter for property: (float) ToleranceTextLineSpaceFactor. 

Sets the tolerance text line space factor

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ToleranceTextLineWidth() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextLineWidth
(
self — )

Getter for property: (NXOpen.Annotations.LineWidth) ToleranceTextLineWidth Returns the tolerance text line width. 

The values for NXOpen::Annotations::LineWidth when using standard font : A value of NXOpen::Annotations::LineWidthThin is equivalent to a value of "Regular" or "Italic" (if NXOpen::Annotations::LetteringStyleBuilder::ToleranceTextItalicized is set). Any value other than NXOpen::Annotations::LineWidthThin is equivalent to a value of "Bold" or "Bold Italic" (if NXOpen::Annotations::LetteringStyleBuilder::ToleranceTextItalicized is set).

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWidth 

## ◆ ToleranceTextLineWidth() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextLineWidth
(
self,

toleranceTextLineWidth )

Setter for property: (NXOpen.Annotations.LineWidth) ToleranceTextLineWidth. 

Sets the tolerance text line width.

The values for NXOpen::Annotations::LineWidth when using standard font : A value of NXOpen::Annotations::LineWidthThin is equivalent to a value of "Regular" or "Italic" (if NXOpen::Annotations::LetteringStyleBuilder::ToleranceTextItalicized is set). Any value other than NXOpen::Annotations::LineWidthThin is equivalent to a value of "Bold" or "Bold Italic" (if NXOpen::Annotations::LetteringStyleBuilder::ToleranceTextItalicized is set).

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ToleranceTextSize() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextSize
(
self — )

Getter for property: (float) ToleranceTextSize Returns the tolerance text character size. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ ToleranceTextSize() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextSize
(
self,

toleranceTextSize )

Setter for property: (float) ToleranceTextSize. 

Sets the tolerance text character size

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ToleranceTextSpaceFactor() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextSpaceFactor
(
self — )

Getter for property: (float) ToleranceTextSpaceFactor Returns the tolerance text space factor. 

This contols the spacing between the dimension main text and the after tolerance text. The space is equal to the tolerance text character size multiplied by the space factor

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ ToleranceTextSpaceFactor() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextSpaceFactor
(
self,

toleranceTextSpaceFactor )

Setter for property: (float) ToleranceTextSpaceFactor. 

Sets the tolerance text space factor.

This contols the spacing between the dimension main text and the after tolerance text. The space is equal to the tolerance text character size multiplied by the space factor

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ToleranceTextSymbolAspectRatio() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextSymbolAspectRatio
(
self — )

Getter for property: (float) ToleranceTextSymbolAspectRatio Returns the symbol aspect ratio for tolerance text (only available for symbols when using standard font). 

This value controls the aspect ratio of text control sequences such as the diameter symbol (represented by the &x3C;O&x3E; text control sequence), the counterbore symbol (represented by the &x3C;&x23;C&x3E; text control sequence), the degree symbol (represented by the &x3C;&x24;s&x3E; text control sequence), the true position symbol (represented by the &x3C;&x26;10&x3E; text control sequence), etc.

Getter License requirements: None.

Created in NX11.0.0 

Returns
float 

## ◆ ToleranceTextSymbolAspectRatio() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.ToleranceTextSymbolAspectRatio
(
self,

toleranceTextSymbolAspect )

Setter for property: (float) ToleranceTextSymbolAspectRatio. 

Sets the symbol aspect ratio for tolerance text (only available for symbols when using standard font).

This value controls the aspect ratio of text control sequences such as the diameter symbol (represented by the &x3C;O&x3E; text control sequence), the counterbore symbol (represented by the &x3C;&x23;C&x3E; text control sequence), the degree symbol (represented by the &x3C;&x24;s&x3E; text control sequence), the true position symbol (represented by the &x3C;&x26;10&x3E; text control sequence), etc.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX11.0.0 

## ◆ TwoLineToleranceTextSize() [1/2]

NXOpen.Annotations.LetteringStyleBuilder.TwoLineToleranceTextSize
(
self — )

Getter for property: (float) TwoLineToleranceTextSize Returns the two-line tolerance text character size. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
float 

## ◆ TwoLineToleranceTextSize() [2/2]

NXOpen.Annotations.LetteringStyleBuilder.TwoLineToleranceTextSize
(
self,

twoLineToleranceTextSize )

Setter for property: (float) TwoLineToleranceTextSize. 

Sets the two-line tolerance text character size

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX11.0.0 

Copyright 2025 Siemens
