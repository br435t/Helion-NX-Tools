# NXOpen.Annotations.OffsetCenterPointBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00181.html>

## Classes

class — Display

the valid types of display styles 

Enumerator — Comment

CenterPoint — center point

CenterLine — center line

CenterLineWithExtension — center line with extension

More...

class — Offset

the valid offset method types 

Enumerator — Comment

HorizontalDistanceFromArc — horizontal distance from arc

HorizontalDistanceFromCenter — horizontal distance from center

HorizontalDistanceByPosition — horizontal distance by position, applicable only for creation

VerticalDistanceFromArc — vertical distance from arc

VerticalDistanceFromCenter — vertical distance from center

VerticalDistanceByPosition — vertical distance by position, applicable only for creation

More...

class — Thickness

the valid types of offset center point thickness 

Enumerator — Comment

Thin — thin

Normal — normal

Thick — thick

One — Width One

Two — Width Two

Three — Width Three

Four — Width Four

Five — Width Five

Six — Width Six

Seven — Width Seven

Eight — Width Eight

Nine — Width Nine

More...

Copyright 2025 Siemens
