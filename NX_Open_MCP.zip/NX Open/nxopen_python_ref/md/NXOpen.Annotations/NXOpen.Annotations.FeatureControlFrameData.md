# NXOpen.Annotations.FeatureControlFrameData Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12245.html>

Represents a NXOpen::Annotations::FeatureControlFrameData. 
More...

Inheritance diagram for NXOpen.Annotations.FeatureControlFrameData:

## Additional Inherited Members

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::FeatureControlFrameData. 

Created in NX6.0.0 

Copyright 2025 Siemens
