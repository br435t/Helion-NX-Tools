# NXOpen.Annotations.BaseThicknessDimensionBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11497.html>

Represents a NXOpen::Annotations::BaseThicknessDimensionBuilder builder 

This is an abstract class and cannot be instantiated. 
More...

Inheritance diagram for NXOpen.Annotations.BaseThicknessDimensionBuilder:

## Public Member Functions

AppendedText (self)

Getter for property: (NXOpen.Annotations.AppendedTextBuilder) AppendedText Returns the appended text. 

FirstAssociativity (self)

Getter for property: (NXOpen.SelectDisplayableObject) FirstAssociativity Returns the first associativity. 

Inherit (self)

Getter for property: (NXOpen.Annotations.SelectDimension) Inherit Returns the inherit. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

SecondAssociativity (self)

Getter for property: (NXOpen.SelectDisplayableObject) SecondAssociativity Returns the second associativity. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::BaseThicknessDimensionBuilder builder 

This is an abstract class and cannot be instantiated. 

Created in NX9.0.0 

## Member Function Documentation

## ◆ AppendedText()

NXOpen.Annotations.BaseThicknessDimensionBuilder.AppendedText
(
self — )

Getter for property: (NXOpen.Annotations.AppendedTextBuilder) AppendedText Returns the appended text. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
AppendedTextBuilder 

## ◆ FirstAssociativity()

NXOpen.Annotations.BaseThicknessDimensionBuilder.FirstAssociativity
(
self — )

Getter for property: (NXOpen.SelectDisplayableObject) FirstAssociativity Returns the first associativity. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
NXOpen.SelectDisplayableObject 

## ◆ Inherit()

NXOpen.Annotations.BaseThicknessDimensionBuilder.Inherit
(
self — )

Getter for property: (NXOpen.Annotations.SelectDimension) Inherit Returns the inherit. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
SelectDimension 

## ◆ Origin()

NXOpen.Annotations.BaseThicknessDimensionBuilder.Origin
(
self — )

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
OriginBuilder 

## ◆ SecondAssociativity()

NXOpen.Annotations.BaseThicknessDimensionBuilder.SecondAssociativity
(
self — )

Getter for property: (NXOpen.SelectDisplayableObject) SecondAssociativity Returns the second associativity. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
NXOpen.SelectDisplayableObject 

## ◆ Style()

NXOpen.Annotations.BaseThicknessDimensionBuilder.Style
(
self — )

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
StyleBuilder 

Copyright 2025 Siemens
