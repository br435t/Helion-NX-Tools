# NXOpen.Annotations.PmiBoltCircleCenterlineBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13317.html>

Builder for creating or editing PMI Bolt Circle Centerline 

To create a new instance of this class, use NXOpen::Annotations::CenterlineCollection::CreatePmiBoltCircleCenterlineBuilder 

Default values. 
More...

Inheritance diagram for NXOpen.Annotations.PmiBoltCircleCenterlineBuilder:

## Public Member Functions

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the associated objects for the center mark. 

Plane (self)

Getter for property: (NXOpen.Annotations.PlaneBuilder) Plane Returns the plane for the creation of center mark. 

Public Member Functions inherited from NXOpen.Annotations.CircleCenterlineBuilder

FullCircle (self)

Getter for property: (bool) FullCircle Returns the method which returns full or partial circle flag. 

FullCircle (self, fullType)

Setter for property: (bool) FullCircle. 

Inherit (self)

Getter for property: (NXOpen.SelectNXObject) Inherit Returns the inherit object. 

Locations (self)

Getter for property: (NXOpen.SelectNXObjectList) Locations Returns the selction object of the centerline. 

RemoveLocation (self, index)

Removes location object for a given index from the Select Object List. 

Settings (self)

Getter for property: (NXOpen.Annotations.CircleCenterlineSettingsBuilder) Settings Returns the settings builder object for the centerline. 

Type (self)

Getter for property: (NXOpen.Annotations.CircleCenterlineBuilder.Types) Type Returns the method which returns type of centerline. 

Type (self, method)

Setter for property: (NXOpen.Annotations.CircleCenterlineBuilder.Types) Type. 

Public Member Functions inherited from NXOpen.Annotations.CenterlineBuilder

AddEndExtensions (self, start, end)

Adds extensions only at ends. 

AddExtension (self, index, defaultValue)

Adds extension based on select object index. 

GetAllExtensions (self)

Returns all extensions. 

GetAllIndividualExtensions (self)

Returns individual extensions. 

GetEndExtensions (self)

Returns end extensions only. 

RemoveEndExtensions (self)

Removes extensions only at ends. 

RemoveExtension (self, index)

Removes extension based on select object index. 

ResetAllExtensions (self, defaultValue)

Reset all extensions by the supplied defaultValue. 

SetAllIndividualExtensions (self, extensionValues)

Sets all individual extensions. 

SetEndExtensions (self, start, end)

Modifies end extensions only. 

SetIndividualExtensions (self, index, value1, value2)

Modifies extensions based on select object index. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.Annotations.CircleCenterlineBuilder

CircleCenterlineBuilderTypes = CircleCenterlineBuilder.Types

NXOpen.Annotations.CircleCenterlineBuilderTypes is an alias for NXOpen.Annotations.CircleCenterlineBuilder.Types 

## Detailed Description

Builder for creating or editing PMI Bolt Circle Centerline 

To create a new instance of this class, use NXOpen::Annotations::CenterlineCollection::CreatePmiBoltCircleCenterlineBuilder 

Default values. 

Property — Value

FullCircle 

true 

Type 

Through3Points 

Created in NX12.0.0 

## Member Function Documentation

## ◆ AssociatedObjects()

NXOpen.Annotations.PmiBoltCircleCenterlineBuilder.AssociatedObjects
(
self — )

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the associated objects for the center mark. 

Getter License requirements: None.

Created in NX12.0.0 

Returns
AssociatedObjectsBuilder 

## ◆ Plane()

NXOpen.Annotations.PmiBoltCircleCenterlineBuilder.Plane
(
self — )

Getter for property: (NXOpen.Annotations.PlaneBuilder) Plane Returns the plane for the creation of center mark. 

Getter License requirements: None.

Created in NX12.0.0 

Returns
PlaneBuilder 

Copyright 2025 Siemens
