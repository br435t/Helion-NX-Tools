# NXOpen.Annotations.DrawingFormatTitleBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00154.html>

## Classes

class — TitleBlockPositionType

Represent the option of TitleBlockPosition that specifies Type display 

Enumerator — Comment

TopLeft

TopRight

BottomLeft

BottomRight

More...

Copyright 2025 Siemens
