# NXOpen.Annotations.AppendedTextEditorBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11109.html>

Represents a NXOpen::Annotations::AppendedTextEditorBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateAppendedTextEditorBuilder 

More...

Inheritance diagram for NXOpen.Annotations.AppendedTextEditorBuilder:

## Public Member Functions

AppendedTextBuilder (self)

Getter for property: (NXOpen.Annotations.AppendedTextBuilder) AppendedTextBuilder Returns the appended text builder. 

SetDimensions (self, dimensions)

Sets all the dimensions to the builder. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::AppendedTextEditorBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateAppendedTextEditorBuilder 

Created in NX9.0.0 

## Member Function Documentation

## ◆ AppendedTextBuilder()

NXOpen.Annotations.AppendedTextEditorBuilder.AppendedTextBuilder
(
self — )

Getter for property: (NXOpen.Annotations.AppendedTextBuilder) AppendedTextBuilder Returns the appended text builder. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
AppendedTextBuilder 

## ◆ SetDimensions()

NXOpen.Annotations.AppendedTextEditorBuilder.SetDimensions
(
self,

dimensions )

Sets all the dimensions to the builder. 

Created in NX9.0.0 

License requirements: None.

Parameters

dimensions — (List[NXOpen.Annotations.Dimension]) Dimensions Array

Copyright 2025 Siemens
