# NXOpen.Annotations.BillOfMaterialBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00138.html>

## Classes

class — DetailLevelType

The options specify the detail level type. More...

class — FabricationNumberingType

The options specify the fabrication numbering type. More...

class — StockLengthType

The options specify the stock length type. More...

Copyright 2025 Siemens
