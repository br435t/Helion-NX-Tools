# NXOpen.Annotations.PmiEdgeConditionSymbolBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13437.html>

Represents builder for PMI Edge Condition Symbol 

To create a new instance of this class, use NXOpen::Annotations::PmiEdgeConditionSymbolCollection::CreatePmiEdgeConditionSymbolBuilder 

More...

Inheritance diagram for NXOpen.Annotations.PmiEdgeConditionSymbolBuilder:

## Public Member Functions

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the select associated objects. 

Public Member Functions inherited from NXOpen.Annotations.BaseEdgeConditionSymbolBuilder

Inherit (self)

Getter for property: (NXOpen.Annotations.SelectBaseEdgeConditionSymbol) Inherit Returns the inherit. 

InheritProperties (self, ecsTag)

Inheriting properties from the edge condition symbol. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the leader. 

LimitDeviation (self)

Getter for property: (str) LimitDeviation Returns the limit deviation. 

LimitDeviation (self, limitDeviation)

Setter for property: (str) LimitDeviation. 

LimitDeviationA1 (self)

Getter for property: (str) LimitDeviationA1 Returns the limit deviation a1. 

LimitDeviationA1 (self, limitDeviationA1)

Setter for property: (str) LimitDeviationA1. 

LimitDeviationA2 (self)

Getter for property: (str) LimitDeviationA2 Returns the limit deviation a2. 

LimitDeviationA2 (self, limitDeviationA2)

Setter for property: (str) LimitDeviationA2. 

LimitDeviationB1 (self)

Getter for property: (str) LimitDeviationB1 Returns the limit deviation b1. 

LimitDeviationB1 (self, limitDeviationB1)

Setter for property: (str) LimitDeviationB1. 

LimitDeviationB2 (self)

Getter for property: (str) LimitDeviationB2 Returns the limit deviation b2. 

LimitDeviationB2 (self, limitDeviationB2)

Setter for property: (str) LimitDeviationB2. 

LimitDeviationC1 (self)

Getter for property: (str) LimitDeviationC1 Returns the limit deviation c1. 

LimitDeviationC1 (self, limitDeviationC1)

Setter for property: (str) LimitDeviationC1. 

LimitDeviationC2 (self)

Getter for property: (str) LimitDeviationC2 Returns the limit deviation c2. 

LimitDeviationC2 (self, limitDeviationC2)

Setter for property: (str) LimitDeviationC2. 

Method (self)

Getter for property: (NXOpen.Annotations.BaseEdgeConditionSymbolBuilder.MethodType) Method Returns the method. 

Method (self, method)

Setter for property: (NXOpen.Annotations.BaseEdgeConditionSymbolBuilder.MethodType) Method. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

SymbolElement (self)

Getter for property: (NXOpen.Annotations.BaseEdgeConditionSymbolBuilder.SymbolElementEnum) SymbolElement Returns the symbol element. 

SymbolElement (self, symbolElement)

Setter for property: (NXOpen.Annotations.BaseEdgeConditionSymbolBuilder.SymbolElementEnum) SymbolElement. 

Terminator (self)

Getter for property: (NXOpen.Annotations.BaseEdgeConditionSymbolBuilder.TerminatorType) Terminator Returns the terminator type. 

Terminator (self, type)

Setter for property: (NXOpen.Annotations.BaseEdgeConditionSymbolBuilder.TerminatorType) Terminator. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.Annotations.BaseEdgeConditionSymbolBuilder

BaseEdgeConditionSymbolBuilderMethodType = BaseEdgeConditionSymbolBuilder.MethodType

NXOpen.Annotations.BaseEdgeConditionSymbolBuilderMethodType is an alias for NXOpen.Annotations.BaseEdgeConditionSymbolBuilder.MethodType 

BaseEdgeConditionSymbolBuilderSymbolElementEnum = BaseEdgeConditionSymbolBuilder.SymbolElementEnum

NXOpen.Annotations.BaseEdgeConditionSymbolBuilderSymbolElementEnum is an alias for NXOpen.Annotations.BaseEdgeConditionSymbolBuilder.SymbolElementEnum 

BaseEdgeConditionSymbolBuilderTerminatorType = BaseEdgeConditionSymbolBuilder.TerminatorType

NXOpen.Annotations.BaseEdgeConditionSymbolBuilderTerminatorType is an alias for NXOpen.Annotations.BaseEdgeConditionSymbolBuilder.TerminatorType 

## Detailed Description

Represents builder for PMI Edge Condition Symbol 

To create a new instance of this class, use NXOpen::Annotations::PmiEdgeConditionSymbolCollection::CreatePmiEdgeConditionSymbolBuilder 

Created in NX2007.0.0 

## Member Function Documentation

## ◆ AssociatedObjects()

NXOpen.Annotations.PmiEdgeConditionSymbolBuilder.AssociatedObjects
(
self — )

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the select associated objects. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
AssociatedObjectsBuilder 

Copyright 2025 Siemens
