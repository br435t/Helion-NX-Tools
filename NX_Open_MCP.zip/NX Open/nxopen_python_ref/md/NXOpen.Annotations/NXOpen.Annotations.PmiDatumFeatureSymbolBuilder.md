# NXOpen.Annotations.PmiDatumFeatureSymbolBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13405.html>

datum feature symbol builder 

To create a new instance of this class, use NXOpen::Annotations::GdtDatumCollection::CreatePmiDatumFeatureSymbolBuilder 

More...

Inheritance diagram for NXOpen.Annotations.PmiDatumFeatureSymbolBuilder:

## Public Member Functions

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the datum feature associated object. 

Public Member Functions inherited from NXOpen.Annotations.DatumFeatureSymbolBuilder

InheritFrom (self, inheritTag)

The datum feature symbol is inherited form the given datum feature symbol. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Letter (self)

Getter for property: (str) Letter Returns the datum feature string. 

Letter (self, datumFeatureLetter)

Setter for property: (str) Letter. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the datum feature symbol origin. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the datum feature style. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

datum feature symbol builder 

To create a new instance of this class, use NXOpen::Annotations::GdtDatumCollection::CreatePmiDatumFeatureSymbolBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ AssociatedObjects()

NXOpen.Annotations.PmiDatumFeatureSymbolBuilder.AssociatedObjects
(
self — )

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the datum feature associated object. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
AssociatedObjectsBuilder 

Copyright 2025 Siemens
