# NXOpen.Annotations.ShipDimensionBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00215.html>

## Classes

class — GroupType

The enum represents group type from concept model 

Enumerator — Comment

MainShipItem — Group type MainShipItem

Decks — Group type Decks

TransversalFrames — Group type Transversal frames

Bulkheads — Group type Bulkheads

LongitudinalFrames — Group type Longitudinal frames

More...

Copyright 2025 Siemens
