# NXOpen.Annotations.PmiAttributeValueIntegerBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13249.html>

Represents a NXOpen::Annotations::PmiAttributeValueInteger builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiAttributeValueIntegerBuilder 

More...

Inheritance diagram for NXOpen.Annotations.PmiAttributeValueIntegerBuilder:

## Public Member Functions

IntegerValue (self)

Getter for property: (int) IntegerValue Returns the integer_value. 

IntegerValue (self, integerValue)

Setter for property: (int) IntegerValue. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::PmiAttributeValueInteger builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiAttributeValueIntegerBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ IntegerValue() [1/2]

NXOpen.Annotations.PmiAttributeValueIntegerBuilder.IntegerValue
(
self — )

Getter for property: (int) IntegerValue Returns the integer_value. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
int 

## ◆ IntegerValue() [2/2]

NXOpen.Annotations.PmiAttributeValueIntegerBuilder.IntegerValue
(
self,

integerValue )

Setter for property: (int) IntegerValue. 

Sets the integer_value

Setter License requirements: None.

Created in NX6.0.0 

Copyright 2025 Siemens
