# NXOpen.Annotations.OrdinateDimensionBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13049.html>

Represents a NXOpen::Annotations::OrdinateDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateOrdinateDimensionBuilder 

More...

Inheritance diagram for NXOpen.Annotations.OrdinateDimensionBuilder:

## Public Member Functions

Driving (self)

Getter for property: (NXOpen.Annotations.DrivingValueBuilder) Driving Returns the driving. 

ForeshorteningSymbol (self)

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Public Member Functions inherited from NXOpen.Annotations.BaseOrdinateDimensionBuilder

ActiveHorizontalMargin (self)

Getter for property: (NXOpen.Annotations.OrdinateMargin) ActiveHorizontalMargin Returns the active horizontal margin(defined or inferred) where horizontal dimension will be automatically placed. 

ActiveHorizontalMargin (self, margin)

Setter for property: (NXOpen.Annotations.OrdinateMargin) ActiveHorizontalMargin. 

ActiveVerticalMargin (self)

Getter for property: (NXOpen.Annotations.OrdinateMargin) ActiveVerticalMargin Returns the active vertical margin(defined or inferred) where horizontal dimension will be automatically placed. 

ActiveVerticalMargin (self, margin)

Setter for property: (NXOpen.Annotations.OrdinateMargin) ActiveVerticalMargin. 

AllowDuplicates (self)

Getter for property: (bool) AllowDuplicates Returns the allow duplicates. 

AllowDuplicates (self, allowDuplicates)

Setter for property: (bool) AllowDuplicates. 

AppendedText (self)

Getter for property: (NXOpen.Annotations.AppendedTextBuilder) AppendedText Returns the appended text. 

AutoAssociativities (self)

Getter for property: (NXOpen.SelectDisplayableObjectList) AutoAssociativities Returns the auto ordinate associativities. 

Baseline (self)

Getter for property: (NXOpen.Annotations.OrdinateBaselineBuilder) Baseline Returns the baseline. 

HorizontalInferredMarginLocation (self)

Getter for property: (NXOpen.Point3d) HorizontalInferredMarginLocation Returns the horizontal inferred margin location. 

HorizontalInferredMarginLocation (self, location)

Setter for property: (NXOpen.Point3d) HorizontalInferredMarginLocation. 

Inherit (self)

Getter for property: (NXOpen.SelectDisplayableObject) Inherit Returns the inherit. 

OrdinateOrigin (self)

Getter for property: (NXOpen.SelectDisplayableObject) OrdinateOrigin Returns the ordinate origin. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

RepositionExisting (self)

Getter for property: (bool) RepositionExisting Returns the reposition existing. 

RepositionExisting (self, repositionExisting)

Setter for property: (bool) RepositionExisting. 

SecondAssociativities (self)

Getter for property: (NXOpen.SelectDisplayableObject) SecondAssociativities Returns the second associativities. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

Type (self)

Getter for property: (NXOpen.Annotations.BaseOrdinateDimensionBuilder.Types) Type Returns the type. 

Type (self, type)

Setter for property: (NXOpen.Annotations.BaseOrdinateDimensionBuilder.Types) Type. 

VerticalInferredMarginLocation (self)

Getter for property: (NXOpen.Point3d) VerticalInferredMarginLocation Returns the vertical inferred margin location. 

VerticalInferredMarginLocation (self, location)

Setter for property: (NXOpen.Point3d) VerticalInferredMarginLocation. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.Annotations.BaseOrdinateDimensionBuilder

BaseOrdinateDimensionBuilderTypes = BaseOrdinateDimensionBuilder.Types

NXOpen.Annotations.BaseOrdinateDimensionBuilderTypes is an alias for NXOpen.Annotations.BaseOrdinateDimensionBuilder.Types 

## Detailed Description

Represents a NXOpen::Annotations::OrdinateDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateOrdinateDimensionBuilder 

Created in NX9.0.0 

## Member Function Documentation

## ◆ Driving()

NXOpen.Annotations.OrdinateDimensionBuilder.Driving
(
self — )

Getter for property: (NXOpen.Annotations.DrivingValueBuilder) Driving Returns the driving. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
DrivingValueBuilder 

## ◆ ForeshorteningSymbol()

NXOpen.Annotations.OrdinateDimensionBuilder.ForeshorteningSymbol
(
self — )

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
ForeshorteningSymbolBuilder 

Copyright 2025 Siemens
