# NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a14377.html>

Represents a NXOpen::Annotations::ShipDraftingFramebarGeneralBuilder 

This is a sub-builder class and cannot be directly instantiated 

More...

Inheritance diagram for NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder:

## Public Member Functions

DecimalPlaces (self)

Getter for property: (int) DecimalPlaces Returns the decimal places. 

DecimalPlaces (self, decimalPlaces)

Setter for property: (int) DecimalPlaces. 

MainLine (self)

Getter for property: (bool) MainLine Returns the main line. 

MainLine (self, mainLine)

Setter for property: (bool) MainLine. 

MainLineColor (self)

Getter for property: (NXOpen.NXColor) MainLineColor Returns the main line color. 

MainLineColor (self, mainLineColor)

Setter for property: (NXOpen.NXColor) MainLineColor. 

MainLineFont (self)

Getter for property: (NXOpen.DisplayableObject.ObjectFont) MainLineFont Returns the main line font. 

MainLineFont (self, mainLineFont)

Setter for property: (NXOpen.DisplayableObject.ObjectFont) MainLineFont. 

MainLineWidth (self)

Getter for property: (NXOpen.Annotations.LineWidth) MainLineWidth Returns the main line width. 

MainLineWidth (self, mainLineWidth)

Setter for property: (NXOpen.Annotations.LineWidth) MainLineWidth. 

TicDirection (self)

Getter for property: (NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.TicDirectionTypes) TicDirection Returns the tic direction. 

TicDirection (self, ticDirection)

Setter for property: (NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.TicDirectionTypes) TicDirection. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

ShipDraftingFramebarGeneralBuilderTicDirectionTypes = ShipDraftingFramebarGeneralBuilder.TicDirectionTypes

NXOpen.Annotations.ShipDraftingFramebarGeneralBuilderTicDirectionTypes is an alias for NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.TicDirectionTypes 

## Detailed Description

Represents a NXOpen::Annotations::ShipDraftingFramebarGeneralBuilder 

This is a sub-builder class and cannot be directly instantiated 

Created in NX9.0.0 

## Member Function Documentation

## ◆ DecimalPlaces() [1/2]

NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.DecimalPlaces
(
self — )

Getter for property: (int) DecimalPlaces Returns the decimal places. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
int 

## ◆ DecimalPlaces() [2/2]

NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.DecimalPlaces
(
self,

decimalPlaces )

Setter for property: (int) DecimalPlaces. 

Sets the decimal places

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX9.0.0 

## ◆ MainLine() [1/2]

NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.MainLine
(
self — )

Getter for property: (bool) MainLine Returns the main line. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
bool 

## ◆ MainLine() [2/2]

NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.MainLine
(
self,

mainLine )

Setter for property: (bool) MainLine. 

Sets the main line

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX2007.0.0 

## ◆ MainLineColor() [1/2]

NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.MainLineColor
(
self — )

Getter for property: (NXOpen.NXColor) MainLineColor Returns the main line color. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
NXOpen.NXColor 

## ◆ MainLineColor() [2/2]

NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.MainLineColor
(
self,

mainLineColor )

Setter for property: (NXOpen.NXColor) MainLineColor. 

Sets the main line color

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX2007.0.0 

## ◆ MainLineFont() [1/2]

NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.MainLineFont
(
self — )

Getter for property: (NXOpen.DisplayableObject.ObjectFont) MainLineFont Returns the main line font. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
NXOpen.DisplayableObject.ObjectFont 

## ◆ MainLineFont() [2/2]

NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.MainLineFont
(
self,

mainLineFont )

Setter for property: (NXOpen.DisplayableObject.ObjectFont) MainLineFont. 

Sets the main line font

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX2007.0.0 

## ◆ MainLineWidth() [1/2]

NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.MainLineWidth
(
self — )

Getter for property: (NXOpen.Annotations.LineWidth) MainLineWidth Returns the main line width. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
LineWidth 

## ◆ MainLineWidth() [2/2]

NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.MainLineWidth
(
self,

mainLineWidth )

Setter for property: (NXOpen.Annotations.LineWidth) MainLineWidth. 

Sets the main line width

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX2007.0.0 

## ◆ TicDirection() [1/2]

NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.TicDirection
(
self — )

Getter for property: (NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.TicDirectionTypes) TicDirection Returns the tic direction. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
ShipDraftingFramebarGeneralBuilder.TicDirectionTypes 

## ◆ TicDirection() [2/2]

NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.TicDirection
(
self,

ticDirection )

Setter for property: (NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.TicDirectionTypes) TicDirection. 

Sets the tic direction

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX9.0.0 

## Member Data Documentation

## ◆ ShipDraftingFramebarGeneralBuilderTicDirectionTypes

NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.ShipDraftingFramebarGeneralBuilderTicDirectionTypes = ShipDraftingFramebarGeneralBuilder.TicDirectionTypes

NXOpen.Annotations.ShipDraftingFramebarGeneralBuilderTicDirectionTypes is an alias for NXOpen.Annotations.ShipDraftingFramebarGeneralBuilder.TicDirectionTypes 

Copyright 2025 Siemens
