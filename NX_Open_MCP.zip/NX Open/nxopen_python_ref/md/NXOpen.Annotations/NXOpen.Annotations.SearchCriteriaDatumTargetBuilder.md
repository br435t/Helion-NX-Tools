# NXOpen.Annotations.SearchCriteriaDatumTargetBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00208.html>

## Classes

class — DatumTargetMovableOptions

Represents the search pmi movable datum target type 

Enumerator — Comment

No — Datum Target

Yes — Movable Datum Target

More...

class — DatumTargetTypes

Lists the search pmi datum target type 

Enumerator — Comment

Point — point type

Line — line type

Rectangular — rectangular type

Circular — circular type

Annular — annular type

Spherical — spherical type

Cylindrical — cylindrical type

Arbitrary — arbitray type

More...

Copyright 2025 Siemens
