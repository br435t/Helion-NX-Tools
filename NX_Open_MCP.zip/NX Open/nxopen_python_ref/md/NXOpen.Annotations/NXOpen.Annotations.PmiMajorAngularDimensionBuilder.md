# NXOpen.Annotations.PmiMajorAngularDimensionBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13653.html>

Represents a NXOpen::Annotations::AngularDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreatePmiMajorAngularDimensionBuilder 

More...

Inheritance diagram for NXOpen.Annotations.PmiMajorAngularDimensionBuilder:

## Additional Inherited Members

Public Member Functions inherited from NXOpen.Annotations.PmiAngularDimensionBuilder

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the associated objects. 

AssociatedObjectsSets (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsSetsBuilder) AssociatedObjectsSets Returns the associated objects sets. 

Public Member Functions inherited from NXOpen.Annotations.BaseAngularDimensionBuilder

AlternateAngle (self)

Alternate angle. 

AppendedText (self)

Getter for property: (NXOpen.Annotations.AppendedTextBuilder) AppendedText Returns the appended text. 

FirstAssociativity (self)

Getter for property: (NXOpen.SelectDisplayableObject) FirstAssociativity Returns the first associativity. 

FirstVector (self)

Getter for property: (NXOpen.Direction) FirstVector Returns the first vector. 

FirstVector (self, firstVector)

Setter for property: (NXOpen.Direction) FirstVector. 

FirstVectorView (self)

Getter for property: (NXOpen.View) FirstVectorView Returns the first vector view. 

FirstVectorView (self, firstVectorView)

Setter for property: (NXOpen.View) FirstVectorView. 

GetFirstAssociativityVectorFlipped (self)

First associativity vector flipped. 

GetSecondAssociativityVectorFlipped (self)

Second associativity vector flipped. 

Inherit (self)

Getter for property: (NXOpen.Annotations.SelectDimension) Inherit Returns the inherit. 

MeasurementType (self)

Getter for property: (NXOpen.Annotations.Dimension.MeasurementTypes) MeasurementType Returns the measurement type. 

MeasurementType (self, measurementType)

Setter for property: (NXOpen.Annotations.Dimension.MeasurementTypes) MeasurementType. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

SecondAssociativity (self)

Getter for property: (NXOpen.SelectDisplayableObject) SecondAssociativity Returns the second associativity. 

SecondVector (self)

Getter for property: (NXOpen.Direction) SecondVector Returns the second vector. 

SecondVector (self, secondVector)

Setter for property: (NXOpen.Direction) SecondVector. 

SecondVectorView (self)

Getter for property: (NXOpen.View) SecondVectorView Returns the second vector view. 

SecondVectorView (self, firstVectorView)

Setter for property: (NXOpen.View) SecondVectorView. 

SetFirstAssociativityVectorFlipped (self, firstVectorFlipped)

First associativity vector flipped. 

SetNthAssociativityEdited (self, index, edited)

Set nth associativity edited flag in the builder. 

SetSecondAssociativityVectorFlipped (self, secondVectorFlipped)

Second associativity vector flipped. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::AngularDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreatePmiMajorAngularDimensionBuilder 

Created in NX9.0.0 

Copyright 2025 Siemens
