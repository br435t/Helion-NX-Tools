# NXOpen.Annotations.DimensionSetBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11941.html>

Represents a NXOpen::Annotations::DimensionSetBuilder 

This is a sub-builder class and cannot be directly instantiated 

More...

Inheritance diagram for NXOpen.Annotations.DimensionSetBuilder:

## Public Member Functions

DimensionOrSet (self)

Getter for property: (NXOpen.Annotations.SelectAnnotation) DimensionOrSet Returns the dimension or dimension set object. 

Method (self)

Getter for property: (NXOpen.Annotations.DimensionSetBuilder.DimensionSetMethod) Method Returns the dimension set method. 

Method (self, method)

Setter for property: (NXOpen.Annotations.DimensionSetBuilder.DimensionSetMethod) Method. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

DimensionSetBuilderDimensionSetMethod = DimensionSetBuilder.DimensionSetMethod

NXOpen.Annotations.DimensionSetBuilderDimensionSetMethod is an alias for NXOpen.Annotations.DimensionSetBuilder.DimensionSetMethod 

## Detailed Description

Represents a NXOpen::Annotations::DimensionSetBuilder 

This is a sub-builder class and cannot be directly instantiated 

Created in NX9.0.0 

## Member Function Documentation

## ◆ DimensionOrSet()

NXOpen.Annotations.DimensionSetBuilder.DimensionOrSet
(
self — )

Getter for property: (NXOpen.Annotations.SelectAnnotation) DimensionOrSet Returns the dimension or dimension set object. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
SelectAnnotation 

## ◆ Method() [1/2]

NXOpen.Annotations.DimensionSetBuilder.Method
(
self — )

Getter for property: (NXOpen.Annotations.DimensionSetBuilder.DimensionSetMethod) Method Returns the dimension set method. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
DimensionSetBuilder.DimensionSetMethod 

## ◆ Method() [2/2]

NXOpen.Annotations.DimensionSetBuilder.Method
(
self,

method )

Setter for property: (NXOpen.Annotations.DimensionSetBuilder.DimensionSetMethod) Method. 

Sets the dimension set method

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") OR solid_modeling ("SOLIDS MODELING")

Created in NX9.0.0 

## Member Data Documentation

## ◆ DimensionSetBuilderDimensionSetMethod

NXOpen.Annotations.DimensionSetBuilder.DimensionSetBuilderDimensionSetMethod = DimensionSetBuilder.DimensionSetMethod

NXOpen.Annotations.DimensionSetBuilderDimensionSetMethod is an alias for NXOpen.Annotations.DimensionSetBuilder.DimensionSetMethod 

Copyright 2025 Siemens
