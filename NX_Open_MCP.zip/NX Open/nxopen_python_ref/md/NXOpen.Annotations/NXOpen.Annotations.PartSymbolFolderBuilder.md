# NXOpen.Annotations.PartSymbolFolderBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13193.html>

Represents a NXOpen::Annotations::PartSymbolFolderBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.PartSymbolFolderBuilder:

## Public Member Functions

GetChildren (self)

Returns children of current folder. 

GetCurrentFolder (self)

Returns current folder. 

GetFolderCount (self)

Returns number of child folders of current folder. 

GetFolderName (self)

Returns the folder name. 

GetParent (self)

Returns parent of current folder provided current folder is not root folder. 

GetPartSymbolCount (self)

Returns number of part symbols of current folder. 

GetPartSymbols (self)

Returns part symbols of current folder. 

GetRootFolder (self)

Get the root part symbol folder. 

IsRootFolder (self)

Checks whether the given folder is root folder or not. 

SetFolderName (self, folderName)

Sets folder name provided current folder is not root folder. 

SetParent (self, parentfolder)

Sets parent of current folder provided current folder is not root folder. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::PartSymbolFolderBuilder . 

To create a new instance of this class, use NXOpen::Annotations::PartSymbolFolderCollection::CreatePartSymbolFolderBuilder 

Created in NX7.5.0 

## Member Function Documentation

## ◆ GetChildren()

NXOpen.Annotations.PartSymbolFolderBuilder.GetChildren
(
self — )

Returns children of current folder. 

Returns
children (List[NXOpen.Annotations.PartSymbolFolder]): array of sub folders.

Created in NX7.5.0 

License requirements: None. 

## ◆ GetCurrentFolder()

NXOpen.Annotations.PartSymbolFolderBuilder.GetCurrentFolder
(
self — )

Returns current folder. 

Returns
folder (NXOpen.Annotations.PartSymbolFolder): current folder.

Created in NX7.5.0 

License requirements: None. 

## ◆ GetFolderCount()

NXOpen.Annotations.PartSymbolFolderBuilder.GetFolderCount
(
self — )

Returns number of child folders of current folder. 

Returns
count (int): number of child folders.

Created in NX7.5.0 

License requirements: None. 

## ◆ GetFolderName()

NXOpen.Annotations.PartSymbolFolderBuilder.GetFolderName
(
self — )

Returns the folder name. 

Returns
folderName (str): folder name.

Created in NX7.5.0 

License requirements: None. 

## ◆ GetParent()

NXOpen.Annotations.PartSymbolFolderBuilder.GetParent
(
self — )

Returns parent of current folder provided current folder is not root folder. 

Returns
parentfolder (NXOpen.Annotations.PartSymbolFolder): parent part symbol folder.

Created in NX7.5.0 

License requirements: None. 

## ◆ GetPartSymbolCount()

NXOpen.Annotations.PartSymbolFolderBuilder.GetPartSymbolCount
(
self — )

Returns number of part symbols of current folder. 

Returns
count (int): number of part symbols.

Created in NX7.5.0 

License requirements: None. 

## ◆ GetPartSymbols()

NXOpen.Annotations.PartSymbolFolderBuilder.GetPartSymbols
(
self — )

Returns part symbols of current folder. 

Returns
masterSymbols (List[NXOpen.Annotations.MasterSymbol]): array of part symbols.

Created in NX7.5.0 

License requirements: None. 

## ◆ GetRootFolder()

NXOpen.Annotations.PartSymbolFolderBuilder.GetRootFolder
(
self — )

Get the root part symbol folder. 

Returns
rootFolder (NXOpen.Annotations.PartSymbolFolder): root part symbol folder.

Created in NX7.5.0 

License requirements: None. 

## ◆ IsRootFolder()

NXOpen.Annotations.PartSymbolFolderBuilder.IsRootFolder
(
self — )

Checks whether the given folder is root folder or not. 

Returns
isRootFolder (bool): returns true if root folder .

Created in NX7.5.0 

License requirements: None. 

## ◆ SetFolderName()

NXOpen.Annotations.PartSymbolFolderBuilder.SetFolderName
(
self,

folderName )

Sets folder name provided current folder is not root folder. 

Created in NX7.5.0 

License requirements: drafting ("DRAFTING")

Parameters

folderName — (str) folder name

## ◆ SetParent()

NXOpen.Annotations.PartSymbolFolderBuilder.SetParent
(
self,

parentfolder )

Sets parent of current folder provided current folder is not root folder. 

Created in NX7.5.0 

License requirements: drafting ("DRAFTING")

Parameters

parentfolder — (NXOpen.Annotations.PartSymbolFolder) parent part symbol folder

Copyright 2025 Siemens
