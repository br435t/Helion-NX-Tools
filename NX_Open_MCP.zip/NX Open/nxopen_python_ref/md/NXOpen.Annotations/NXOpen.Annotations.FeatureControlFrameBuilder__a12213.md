# NXOpen.Annotations.FeatureControlFrameBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12213.html>

Represents a NXOpen::Annotations::FeatureControlFrameBuilder 

This is an abstract class, and cannot be instantiated. 
More...

Inheritance diagram for NXOpen.Annotations.FeatureControlFrameBuilder:

## Public Member Functions

Characteristic (self)

Getter for property: (NXOpen.Annotations.FeatureControlFrameBuilder.FcfCharacteristic) Characteristic Returns the characteristic. 

Characteristic (self, characteristic)

Setter for property: (NXOpen.Annotations.FeatureControlFrameBuilder.FcfCharacteristic) Characteristic. 

FeatureControlFrameData (self)

The feature control frame data list. 

FeatureControlFrameDataList (self)

Getter for property: (NXOpen.Annotations.FeatureControlFrameDataBuilderList) FeatureControlFrameDataList Returns the feature control frame data list. 

FrameStyle (self)

Getter for property: (NXOpen.Annotations.FeatureControlFrameBuilder.FcfFrameStyle) FrameStyle Returns the frame style. 

FrameStyle (self, frameStyle)

Setter for property: (NXOpen.Annotations.FeatureControlFrameBuilder.FcfFrameStyle) FrameStyle. 

InheritFrom (self, inheritTag)

The feature control frame is inherited form existing feature control frame. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the NXOpen::Annotations::OriginBuilder for the annotation. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

Text (self)

Getter for property: (NXOpen.Annotations.TextWithSymbolsBuilder) Text Returns the text. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

FeatureControlFrameBuilderFcfCharacteristic = FeatureControlFrameBuilder.FcfCharacteristic

NXOpen.Annotations.FeatureControlFrameBuilderFcfCharacteristic is an alias for NXOpen.Annotations.FeatureControlFrameBuilder.FcfCharacteristic 

FeatureControlFrameBuilderFcfFrameStyle = FeatureControlFrameBuilder.FcfFrameStyle

NXOpen.Annotations.FeatureControlFrameBuilderFcfFrameStyle is an alias for NXOpen.Annotations.FeatureControlFrameBuilder.FcfFrameStyle 

## Detailed Description

Represents a NXOpen::Annotations::FeatureControlFrameBuilder 

This is an abstract class, and cannot be instantiated. 

Default values. 

Property — Value

Text.CustomSymbolScale 

1.0 

Text.SymbolAspectRatio 

1.0 

Text.SymbolHeight 

25.4 (millimeters part), 1.0 (inches part) 

Text.SymbolLength 

25.4 (millimeters part), 1.0 (inches part) 

Text.SymbolPreferences 

UseCurrent 

Text.SymbolScale 

1.0 

Text.SymbolSizeMethod 

ScaleAndAspectRatio 

Created in NX6.0.0 

## Member Function Documentation

## ◆ Characteristic() [1/2]

NXOpen.Annotations.FeatureControlFrameBuilder.Characteristic
(
self — )

Getter for property: (NXOpen.Annotations.FeatureControlFrameBuilder.FcfCharacteristic) Characteristic Returns the characteristic. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
FeatureControlFrameBuilder.FcfCharacteristic 

## ◆ Characteristic() [2/2]

NXOpen.Annotations.FeatureControlFrameBuilder.Characteristic
(
self,

characteristic )

Setter for property: (NXOpen.Annotations.FeatureControlFrameBuilder.FcfCharacteristic) Characteristic. 

Sets the characteristic

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ FeatureControlFrameData()

NXOpen.Annotations.FeatureControlFrameBuilder.FeatureControlFrameData
(
self — )

The feature control frame data list. 

this method will always return at least two frames. for single feature control frames (frame type is single frame type) only the first frame is used. 
Returns
featureControlFrameDataBuilders (List[NXOpen.Annotations.FeatureControlFrameDataBuilder]): feature control frame data builders .

Created in NX6.0.0 

License requirements: None. 

## ◆ FeatureControlFrameDataList()

NXOpen.Annotations.FeatureControlFrameBuilder.FeatureControlFrameDataList
(
self — )

Getter for property: (NXOpen.Annotations.FeatureControlFrameDataBuilderList) FeatureControlFrameDataList Returns the feature control frame data list. 

this method will always return at least two frames. for single feature control frames (frame type is single frame type) only the first frame is used.

Getter License requirements: None.

Created in NX6.0.0 

Returns
FeatureControlFrameDataBuilderList 

## ◆ FrameStyle() [1/2]

NXOpen.Annotations.FeatureControlFrameBuilder.FrameStyle
(
self — )

Getter for property: (NXOpen.Annotations.FeatureControlFrameBuilder.FcfFrameStyle) FrameStyle Returns the frame style. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
FeatureControlFrameBuilder.FcfFrameStyle 

## ◆ FrameStyle() [2/2]

NXOpen.Annotations.FeatureControlFrameBuilder.FrameStyle
(
self,

frameStyle )

Setter for property: (NXOpen.Annotations.FeatureControlFrameBuilder.FcfFrameStyle) FrameStyle. 

Sets the frame style

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ InheritFrom()

NXOpen.Annotations.FeatureControlFrameBuilder.InheritFrom
(
self,

inheritTag )

The feature control frame is inherited form existing feature control frame. 

Created in NX8.5.0 

License requirements: None.

Parameters

inheritTag — (NXOpen.Annotations.BaseFcf)

## ◆ Leader()

NXOpen.Annotations.FeatureControlFrameBuilder.Leader
(
self — )

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LeaderBuilder 

## ◆ Origin()

NXOpen.Annotations.FeatureControlFrameBuilder.Origin
(
self — )

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the NXOpen::Annotations::OriginBuilder for the annotation. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
OriginBuilder 

## ◆ Style()

NXOpen.Annotations.FeatureControlFrameBuilder.Style
(
self — )

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
StyleBuilder 

## ◆ Text()

NXOpen.Annotations.FeatureControlFrameBuilder.Text
(
self — )

Getter for property: (NXOpen.Annotations.TextWithSymbolsBuilder) Text Returns the text. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
TextWithSymbolsBuilder 

## Member Data Documentation

## ◆ FeatureControlFrameBuilderFcfCharacteristic

NXOpen.Annotations.FeatureControlFrameBuilder.FeatureControlFrameBuilderFcfCharacteristic = FeatureControlFrameBuilder.FcfCharacteristic

NXOpen.Annotations.FeatureControlFrameBuilderFcfCharacteristic is an alias for NXOpen.Annotations.FeatureControlFrameBuilder.FcfCharacteristic 

## ◆ FeatureControlFrameBuilderFcfFrameStyle

NXOpen.Annotations.FeatureControlFrameBuilder.FeatureControlFrameBuilderFcfFrameStyle = FeatureControlFrameBuilder.FcfFrameStyle

NXOpen.Annotations.FeatureControlFrameBuilderFcfFrameStyle is an alias for NXOpen.Annotations.FeatureControlFrameBuilder.FcfFrameStyle 

Copyright 2025 Siemens
