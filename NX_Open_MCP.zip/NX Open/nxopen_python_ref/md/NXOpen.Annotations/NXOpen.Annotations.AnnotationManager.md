# NXOpen.Annotations.AnnotationManager Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11089.html>

Represents an object that manages annotation and PMI (Product and Manufacturing Information) display instance objects. 
More...

Inheritance diagram for NXOpen.Annotations.AnnotationManager:

## Public Member Functions

BendTables ()

Bend Table collection. 

BusinessModifiers ()

BusinessModifier collection. 

Centerlines ()

Centerlines collection. 

ConvertToGdt (self, drafting_aid, keep_drafting_aid, leader)

Converts a simple drafting aid into a GDT by creating a new GDT using the text, origin, and preferences from the drafting aid. 

ConvertToIdSymbol (self, drafting_aid, keep_drafting_aid, leader)

Converts a simple drafting aid into an ID symbol by creating a new ID symbol using the text, origin, and preferences from the drafting aid. 

ConvertToLabel (self, drafting_aid, keep_drafting_aid, leader)

Converts a simple drafting aid into a label by creating a new label using the text, origin, and preferences from the drafting aid. 

ConvertToLineWeld (self, drafting_aid, keep_drafting_aid, leader)

Converts a simple drafting aid into a line weld by creating a new line weld using the text, origin, and preferences from the drafting aid. 

ConvertToNote (self, drafting_aid, keep_drafting_aid)

Converts a simple drafting aid into a note by creating a new note using the text, origin, and preferences from the drafting aid. 

CreateAssociateDimensionBuilder (self, dimension)

Creates the Dimension Associativity builder. 

CreateAssociativeText (self)

Creates a NXOpen::Annotations::AssociativeText . 

CreateAssociativityBuilder (self, dimension, assocIndex)

Creates the Dimension Associativity builder. 

CreateComponentData (self, annotationTag)

Creates a NXOpen::Annotations::ComponentData for an annotation. 

CreateCompoundDatumReferenceBuilder (self)

Creates a new compound datum dialog. 

CreateDatumReferenceBuilder (self, datumReference)

Creates a NXOpen::Annotations::DatumReferenceBuilder. 

CreateDraftingDatumTargetBuilder (self, datumTarget)

Creates a NXOpen::Annotations::DraftingDatumTargetBuilder. 

CreateDraftingFeatureControlFrameBuilder (self, fcf)

Creates a NXOpen::Annotations::DraftingFeatureControlFrameBuilder. 

CreateDraftingNoteBuilder (self, annotation)

Creates a NXOpen::Annotations::DraftingNoteBuilder. 

CreateEditLeaderBuilder (self, tableTag)

Creates a NXOpen::Annotations::EditLeaderBuilder. 

CreateEmptyDatumReferenceBuilder (self)

Creates a new empty datum reference builder. 

CreateFeatureControlFrameDataBuilder (self, frame)

Creates a NXOpen::Annotations::FeatureControlFrameDataBuilder. 

CreateFeatureControlFrameIndicatorBuilder (self)

Creates a NXOpen::Annotations::FeatureControlFrameIndicatorBuilder. 

CreateGdt (self, text_lines, origin, lettering_preferences, user_symbol_preferences, line_arrow_preferences, always_vertical, leader)

Creates a GDT symbol. 

CreateLabel (self, text_lines, origin, lettering_preferences, user_symbol_preferences, line_arrow_preferences, leader)

Creates a label. 

CreateLeaderData (self)

Creates a NXOpen::Annotations::LeaderData. 

CreateNote (self, text_lines, origin, orientation, lettering_preferences, user_symbol_preferences)

Creates a note. 

CreatePmiDatumTargetBuilder (self, datumTarget)

Creates a NXOpen::Annotations::PmiDatumTargetBuilder. 

CreatePmiFeatureControlFrameBuilder (self, fcf)

Creates a NXOpen::Annotations::PmiFeatureControlFrameBuilder. 

CreatePmiNoteBuilder (self, annotation)

Creates a NXOpen::Annotations::PmiNoteBuilder. 

CreatePmiTrackingPropertiesBuilder (self)

Creates a NXOpen::Annotations::PmiTrackingPropertiesBuilder . 

CreateQueryPmiBuilder (self)

Creates the Query PMI builder. 

CreateQueryView (self, pmi_symbols)

Creates a model view displaying the given PMI symbols. 

CreateTextEditorBuilder (self, text)

Creates a NXOpen::Annotations::TextEditorBuilder. 

CurrentSbfFile (self)

Getter for property: (str) CurrentSbfFile Returns the symbol font definition file. 

CurrentSbfFile (self, file_name)

Setter for property: (str) CurrentSbfFile. 

CustomSymbols ()

CustomSymbol collection. 

Datums ()

Datum collection. 

DatumTargets ()

DatumTarget collection. 

DimensionSets ()

DimensionSet collection. 

DraftingDatumTargets ()

DraftingDatumTarget collection. 

DraftingImages ()

Drafting Image collection. 

DraftingSurfaceFinishSymbol ()

Drafting Surface Finish Symbol collection. 

DraftingSurfaceFinishSymbols ()

Drafting surface finish collection. 

EdgeConditionSymbol ()

Edge Condition Symbol collection. 

EditText ()

Edit Text. 

Fcfs ()

Fcf collection. 

FrameBars ()

Frame bar collection. 

GetDefaultAnnotationPlane (self, ja_default_plane)

Returns the default annotation plane for the specified part. 

GetStandardSymbolTextFont (self)

Returns the font to use for displaying symbols with standard fonts. 

Hatches ()

Hatch collection. 

HoleTables ()

Hole Table collection. 

IdSymbols ()

IdSymbol collection. 

InferLeaderSide (self, ann)

Infers the leader stub side based on current origin location. 

IntersectionSymbols ()

IntersectionSymbol collection. 

LoadSymbolFontFromSbfFile (self, symbol_name)

Loads a symbol font from the current symbol font definition file. 

MakePmi (self, annotation)

Flag the annotation as PMI object. 

MakeStubPerpendicular (self, makeStubPerpendicular, annotations)

Sets leader stub perpendicular setting on first leader of each input annotation. 

NewAppendedText (self)

Creates a new AppendedText object. 

NewAssociativity (self)

Creates a new Associativity object. 

NewDatumReference (self)

Creates a new DatumReference object. 

NewDimensionData (self)

Creates new DimensionData object. 

NewFcfFrame (self)

Creates a new FcfFrame object. 

NewFcfFrameData (self)

Creates a new Fcf Frame Data object. 

NewLeaderBundle (self)

Constructs a new LeaderBundle object. 

NewMasterCustomSymbolData (self)

Creates a new MasterCustomSymbolData object. 

NewPmiData (self)

Creates a new PmiData object. 

NewUserSymbolPreferences (self, type, length_or_scale, height_or_aspect_ratio)

Constructs a new UserSymbolPreferences object. 

OffsetCenterPoints ()

OffsetCenterPoint collection. 

OrdinateMargins ()

OrdinateMargin collection. 

PartFamilyTables ()

Part Family Table collection. 

PartsLists ()

Parts list collection. 

PartSymbolFolders ()

Part Symbol Folder collection. 

PmiEdgeConditionSymbol ()

PMI Edge Condition Symbol collection. 

PmiFilters ()

PmiFilter collection. 

PmiSurfaceFinishSymbol ()

PMI Surface Finish Symbol collection. 

PmiTableSections ()

PMI Table collection. 

Preferences ()

Global annotation preferences. 

ProductGrids ()

Product Grid collection. 

QueryPmiFromGeometry (self, geom)

Finds all PMI symbols that reference the given geometry as an associated object. 

ReadAllSymbolNamesFromSbfFile (self)

Reads the names of all symbol fonts in the current symbol font definition file. 

RemovePmi (self, annotation)

Remove PMI flag from annotation. 

SaveUserSymbolPart (self, sym_data)

Save a new master Custom Symbol file. 

SetMasterSymbolNameInQaf (self)

This method writes master custom symbol name to the predefined quick access folder and saves the part. 

SetParallelToScreen (self, parallelToScreen, annotations)

Sets the parallel to screen status on each input annotation. 

SetStandardSymbolTextFont (self, symbolTextFontName)

Created in NX8.5.0 

SymbolFiles ()

Library Symbol collection. 

Tables ()

Table collection. 

TableSections ()

Table section collection. 

TargetPoints ()

TargetPoint collection. 

Welds ()

Weld collection. 

WeldStandard (self)

Getter for property: (NXOpen.Annotations.WeldStandard) WeldStandard Returns the weld standard for the part file. 

WeldStandard (self, standard)

Setter for property: (NXOpen.Annotations.WeldStandard) WeldStandard. 

## Detailed Description

Represents an object that manages annotation and PMI (Product and Manufacturing Information) display instance objects. 

This class contains the collection objects for creating and iterating over annotations and PMI display instances. 

To obtain an instance of this class, refer to NXOpen::BasePart 

Created in NX3.0.0 

## Member Function Documentation

## ◆ BendTables()

NXOpen.Annotations.AnnotationManager.BendTables
(
)

Bend Table collection. 

Created in NX9.0.0 

NXOpen.Annotations.BendTableCollection 

## ◆ BusinessModifiers()

NXOpen.Annotations.AnnotationManager.BusinessModifiers
(
)

BusinessModifier collection. 

Created in NX3.0.0 

NXOpen.Annotations.BusinessModifierCollection 

## ◆ Centerlines()

NXOpen.Annotations.AnnotationManager.Centerlines
(
)

Centerlines collection. 

Created in NX3.0.0 

NXOpen.Annotations.CenterlineCollection 

## ◆ ConvertToGdt()

NXOpen.Annotations.AnnotationManager.ConvertToGdt
(
self,

drafting_aid,

keep_drafting_aid,

leader )

Converts a simple drafting aid into a GDT by creating a new GDT using the text, origin, and preferences from the drafting aid. 

If there are other annotations that are dependent on the drafting aid, (for example, a label that has a leader attached to the drafting aid), those dependencies will NOT be copied over. 
Returns
gdt (NXOpen.Annotations.Gdt): the new GDT .

Created in NX3.0.0 

License requirements: drafting ("DRAFTING")

Parameters

drafting_aid — (NXOpen.Annotations.SimpleDraftingAid) the drafting aid to convert

keep_drafting_aid — (bool) whether to keep the drafting aid. If false, the drafting aid will be deleted

leader — (NXOpen.Annotations.LeaderBundle) specifies the leaders for the new GDT

## ◆ ConvertToIdSymbol()

NXOpen.Annotations.AnnotationManager.ConvertToIdSymbol
(
self,

drafting_aid,

keep_drafting_aid,

leader )

Converts a simple drafting aid into an ID symbol by creating a new ID symbol using the text, origin, and preferences from the drafting aid. 

If there are other annotations that are dependent on the drafting aid, (for example, a label that has a leader attached to the drafting aid), those dependencies will NOT be copied over. 
Returns
id_symbol (NXOpen.Annotations.SimpleDraftingAid): the new ID Symbol .

Created in NX4.0.0 

License requirements: drafting ("DRAFTING")

Parameters

drafting_aid — (NXOpen.Annotations.SimpleDraftingAid) the drafting aid to convert

keep_drafting_aid — (bool) whether to keep the drafting aid. If false, the drafting aid will be deleted

leader — (NXOpen.Annotations.LeaderBundle) specifies the leaders for the new ID Symbol

## ◆ ConvertToLabel()

NXOpen.Annotations.AnnotationManager.ConvertToLabel
(
self,

drafting_aid,

keep_drafting_aid,

leader )

Converts a simple drafting aid into a label by creating a new label using the text, origin, and preferences from the drafting aid. 

If there are other annotations that are dependent on the drafting aid, (for example, a label that has a leader attached to the drafting aid), those dependencies will NOT be copied over. 
Returns
label (NXOpen.Annotations.Label): the new label .

Created in NX3.0.0 

License requirements: drafting ("DRAFTING")

Parameters

drafting_aid — (NXOpen.Annotations.SimpleDraftingAid) the drafting aid to convert

keep_drafting_aid — (bool) whether to keep the drafting aid. If false, the drafting aid will be deleted

leader — (NXOpen.Annotations.LeaderBundle) specifies the leaders for the new label. The leader type must be Plain, Around, PlainAligned, or AroundAligned. To use any other type of leader, you must create a GDT instead.

## ◆ ConvertToLineWeld()

NXOpen.Annotations.AnnotationManager.ConvertToLineWeld
(
self,

drafting_aid,

keep_drafting_aid,

leader )

Converts a simple drafting aid into a line weld by creating a new line weld using the text, origin, and preferences from the drafting aid. 

If there are other annotations that are dependent on the drafting aid, (for example, a line weld that has a leader attached to the drafting aid), those dependencies will NOT be copied over. 
Returns
label (NXOpen.Annotations.LineWeld): the new line weld .

Created in NX3.0.0 

License requirements: drafting ("DRAFTING")

Parameters

drafting_aid — (NXOpen.Annotations.LineWeld) the drafting aid to convert

keep_drafting_aid — (bool) whether to keep the drafting aid. If false, the drafting aid will be deleted

leader — (NXOpen.Annotations.LeaderBundle) specifies the leaders for the new label. The leader type must be Plain, Around, PlainAligned, or AroundAligned. To use any other type of leader, you must create a GDT instead.

## ◆ ConvertToNote()

NXOpen.Annotations.AnnotationManager.ConvertToNote
(
self,

drafting_aid,

keep_drafting_aid )

Converts a simple drafting aid into a note by creating a new note using the text, origin, and preferences from the drafting aid. 

If there are other annotations that are dependent on the drafting aid, (for example, a label that has a leader attached to the drafting aid), those dependencies will NOT be copied over. 
Returns
note (NXOpen.Annotations.Note): the new note .

Created in NX3.0.0 

License requirements: drafting ("DRAFTING")

Parameters

drafting_aid — (NXOpen.Annotations.SimpleDraftingAid) the drafting aid to convert

keep_drafting_aid — (bool) whether to keep the drafting aid. If false, the drafting aid will be deleted

## ◆ CreateAssociateDimensionBuilder()

NXOpen.Annotations.AnnotationManager.CreateAssociateDimensionBuilder
(
self,

dimension )

Creates the Dimension Associativity builder. 

Returns
builder (NXOpen.Annotations.AssociateDimensionBuilder): AssociateDimensionBuilder object .

Created in NX5.0.0 

License requirements: None.

Parameters

dimension — (NXOpen.Annotations.Dimension) NXOpen::Annotations::Dimension to be edited

## ◆ CreateAssociativeText()

NXOpen.Annotations.AnnotationManager.CreateAssociativeText
(
self — )

Creates a NXOpen::Annotations::AssociativeText . 

The NXOpen::Annotations::AssociativeText instance must be deleted after its use. 

Returns
text (NXOpen.Annotations.AssociativeText): .

Created in NX8.0.0 

License requirements: None. 

## ◆ CreateAssociativityBuilder()

NXOpen.Annotations.AnnotationManager.CreateAssociativityBuilder
(
self,

dimension,

assocIndex )

Creates the Dimension Associativity builder. 

Returns
builder (NXOpen.Annotations.AssociativityBuilder): AssociateDimensionBuilder object .

Created in NX5.0.0 

License requirements: None.

Parameters

dimension — (NXOpen.Annotations.Dimension) NXOpen::Annotations::Dimension to be edited

assocIndex — (int) Associativity index

## ◆ CreateComponentData()

NXOpen.Annotations.AnnotationManager.CreateComponentData
(
self,

annotationTag )

Creates a NXOpen::Annotations::ComponentData for an annotation. 

Returns
componentData (NXOpen.Annotations.ComponentData): .

Created in NX6.0.2 

License requirements: None.

Parameters

annotationTag — (NXOpen.Annotations.Annotation) the annotation whose component data will be available with this object

## ◆ CreateCompoundDatumReferenceBuilder()

NXOpen.Annotations.AnnotationManager.CreateCompoundDatumReferenceBuilder
(
self — )

Creates a new compound datum dialog. 

Returns
builder (NXOpen.Annotations.CompoundDatumReferenceBuilder): .

Created in NX5.0.0 

License requirements: geometric_tol ("GDT") 

## ◆ CreateDatumReferenceBuilder()

NXOpen.Annotations.AnnotationManager.CreateDatumReferenceBuilder
(
self,

datumReference )

Creates a NXOpen::Annotations::DatumReferenceBuilder. 

Returns
builder (NXOpen.Annotations.DatumReferenceBuilder): .

Created in NX6.0.0 

License requirements: None.

Parameters

datumReference — (NXOpen.Annotations.FcfDatumReference) the datum reference to be edited, if NULL, then create an fcf symbol

## ◆ CreateDraftingDatumTargetBuilder()

NXOpen.Annotations.AnnotationManager.CreateDraftingDatumTargetBuilder
(
self,

datumTarget )

Creates a NXOpen::Annotations::DraftingDatumTargetBuilder. 

Returns
builder (NXOpen.Annotations.DraftingDatumTargetBuilder): .

Created in NX6.0.0 

License requirements: None.

Parameters

datumTarget — (NXOpen.Annotations.DraftingDatumTarget) Datum to edit

## ◆ CreateDraftingFeatureControlFrameBuilder()

NXOpen.Annotations.AnnotationManager.CreateDraftingFeatureControlFrameBuilder
(
self,

fcf )

Creates a NXOpen::Annotations::DraftingFeatureControlFrameBuilder. 

Returns
builder (NXOpen.Annotations.DraftingFeatureControlFrameBuilder): .

Created in NX6.0.0 

License requirements: None.

Parameters

fcf — (NXOpen.Annotations.Gdt) the fcf symbol to be edited, if NULL, then create an fcf symbol

## ◆ CreateDraftingNoteBuilder()

NXOpen.Annotations.AnnotationManager.CreateDraftingNoteBuilder
(
self,

annotation )

Creates a NXOpen::Annotations::DraftingNoteBuilder. 

Returns
builder (NXOpen.Annotations.DraftingNoteBuilder): .

Created in NX6.0.0 

License requirements: None.

Parameters

annotation — (NXOpen.Annotations.SimpleDraftingAid) NXOpen::Annotations::SimpleDraftingAid to be edited

## ◆ CreateEditLeaderBuilder()

NXOpen.Annotations.AnnotationManager.CreateEditLeaderBuilder
(
self,

tableTag )

Creates a NXOpen::Annotations::EditLeaderBuilder. 

Returns
builder (NXOpen.Annotations.EditLeaderBuilder): .

Created in NX6.0.1 

License requirements: drafting ("DRAFTING") OR nx_2d_edit (" NX 2D Edit")

Parameters

tableTag — (NXOpen.DisplayableObject) the table object to edit

## ◆ CreateEmptyDatumReferenceBuilder()

NXOpen.Annotations.AnnotationManager.CreateEmptyDatumReferenceBuilder
(
self — )

Creates a new empty datum reference builder. 

Returns
builder (NXOpen.Annotations.DatumReferenceBuilder): .

Created in NX9.0.0 

License requirements: None. 

## ◆ CreateFeatureControlFrameDataBuilder()

NXOpen.Annotations.AnnotationManager.CreateFeatureControlFrameDataBuilder
(
self,

frame )

Creates a NXOpen::Annotations::FeatureControlFrameDataBuilder. 

Returns
builder (NXOpen.Annotations.FeatureControlFrameDataBuilder): .

Created in NX6.0.0 

License requirements: None.

Parameters

frame — (NXOpen.Annotations.FeatureControlFrameData) the fcf symbol to be edited, if NULL, then create an fcf symbol

## ◆ CreateFeatureControlFrameIndicatorBuilder()

NXOpen.Annotations.AnnotationManager.CreateFeatureControlFrameIndicatorBuilder
(
self — )

Creates a NXOpen::Annotations::FeatureControlFrameIndicatorBuilder. 

Returns
builder (NXOpen.Annotations.FeatureControlFrameIndicatorBuilder): .

Created in NX12.0.0 

License requirements: None. 

## ◆ CreateGdt()

NXOpen.Annotations.AnnotationManager.CreateGdt
(
self,

text_lines,

origin,

lettering_preferences,

user_symbol_preferences,

line_arrow_preferences,

always_vertical,

leader )

Creates a GDT symbol. 

Returns
gdt (NXOpen.Annotations.Gdt): the new GDT .

Created in NX3.0.0 

License requirements: drafting ("DRAFTING")

Parameters

text_lines — (List[str]) text for the GDT

origin — (NXOpen.Point3d) origin for the GDT

lettering_preferences — (NXOpen.Annotations.LetteringPreferences) lettering preferences. If NULL, the global lettering preferences will be used

user_symbol_preferences — (NXOpen.Annotations.UserSymbolPreferences) user symbol preferences. If NULL, the scale and aspect ratio will be set to 1.0

line_arrow_preferences — (NXOpen.Annotations.LineAndArrowPreferences) line and arrow preferences. If NULL, the global line and arrow preferences will be used

always_vertical — (bool)

leader — (NXOpen.Annotations.LeaderBundle) specifies the leaders for the GDT. The following leader types are not valid for GDT symbols: PlainNostub and AlignedNostub

## ◆ CreateLabel()

NXOpen.Annotations.AnnotationManager.CreateLabel
(
self,

text_lines,

origin,

lettering_preferences,

user_symbol_preferences,

line_arrow_preferences,

leader )

Creates a label. 

The leader type must be Plain, Around, PlainAligned, or AroundAligned. To use any other type of leader, you must create a GDT instead. 
Returns
label (NXOpen.Annotations.Label): the new label .

Created in NX3.0.0 

License requirements: drafting ("DRAFTING")

Parameters

text_lines — (List[str]) text for the label

origin — (NXOpen.Point3d) origin for the label

lettering_preferences — (NXOpen.Annotations.LetteringPreferences) lettering preferences. If NULL, the global lettering preferences will be used

user_symbol_preferences — (NXOpen.Annotations.UserSymbolPreferences) user symbol preferences. If NULL, the scale and aspect ratio will be set to 1.0

line_arrow_preferences — (NXOpen.Annotations.LineAndArrowPreferences) line and arrow preferences. If NULL, the global line and arrow preferences will be used

leader — (NXOpen.Annotations.LeaderBundle) specifies the leaders for the label

## ◆ CreateLeaderData()

NXOpen.Annotations.AnnotationManager.CreateLeaderData
(
self — )

Creates a NXOpen::Annotations::LeaderData. 

Returns
builder (NXOpen.Annotations.LeaderData): .

Created in NX6.0.0 

License requirements: None. 

## ◆ CreateNote()

NXOpen.Annotations.AnnotationManager.CreateNote
(
self,

text_lines,

origin,

orientation,

lettering_preferences,

user_symbol_preferences )

Creates a note. 

Returns
note (NXOpen.Annotations.Note): the new note .

Created in NX3.0.0 

License requirements: drafting ("DRAFTING") OR nx_2d_edit (" NX 2D Edit")

Parameters

text_lines — (List[str]) text for the note

origin — (NXOpen.Point3d) origin for the note

orientation — (NXOpen.AxisOrientation) determines whether the note will be horizontal or vertical

lettering_preferences — (NXOpen.Annotations.LetteringPreferences) lettering preferences. If NULL, the global lettering preferences will be used

user_symbol_preferences — (NXOpen.Annotations.UserSymbolPreferences) user symbol preferences. If NULL, the scale and aspect ratio will be set to 1.0

## ◆ CreatePmiDatumTargetBuilder()

NXOpen.Annotations.AnnotationManager.CreatePmiDatumTargetBuilder
(
self,

datumTarget )

Creates a NXOpen::Annotations::PmiDatumTargetBuilder. 

Returns
builder (NXOpen.Annotations.PmiDatumTargetBuilder): .

Created in NX6.0.0 

License requirements: None.

Parameters

datumTarget — (NXOpen.Annotations.DatumTarget) Datum to edit

## ◆ CreatePmiFeatureControlFrameBuilder()

NXOpen.Annotations.AnnotationManager.CreatePmiFeatureControlFrameBuilder
(
self,

fcf )

Creates a NXOpen::Annotations::PmiFeatureControlFrameBuilder. 

Returns
builder (NXOpen.Annotations.PmiFeatureControlFrameBuilder): .

Created in NX6.0.0 

License requirements: None.

Parameters

fcf — (NXOpen.Annotations.Fcf) the fcf symbol to be edited, if NULL, then create an fcf symbol

## ◆ CreatePmiNoteBuilder()

NXOpen.Annotations.AnnotationManager.CreatePmiNoteBuilder
(
self,

annotation )

Creates a NXOpen::Annotations::PmiNoteBuilder. 

Returns
builder (NXOpen.Annotations.PmiNoteBuilder): .

Created in NX6.0.0 

License requirements: None.

Parameters

annotation — (NXOpen.Annotations.SimpleDraftingAid) NXOpen::Annotations::SimpleDraftingAid to be edited

## ◆ CreatePmiTrackingPropertiesBuilder()

NXOpen.Annotations.AnnotationManager.CreatePmiTrackingPropertiesBuilder
(
self — )

Creates a NXOpen::Annotations::PmiTrackingPropertiesBuilder . 

Returns
builder (NXOpen.Annotations.PmiTrackingPropertiesBuilder): PmiTrackingPropertiesBuilder object .

Created in NX10.0.0 

License requirements: drafting ("DRAFTING") 

## ◆ CreateQueryPmiBuilder()

NXOpen.Annotations.AnnotationManager.CreateQueryPmiBuilder
(
self — )

Creates the Query PMI builder. 

Returns
builder (NXOpen.Annotations.QueryPmiBuilder): .

Created in NX5.0.0 

License requirements: geometric_tol ("GDT") 

## ◆ CreateQueryView()

NXOpen.Annotations.AnnotationManager.CreateQueryView
(
self,

pmi_symbols )

Creates a model view displaying the given PMI symbols. 

This method would ordinarily be invoked with the PMI symbols resulting from a call to NXOpen::Annotations::AnnotationManager::QueryPmiFromGeometry . 
Returns
query_view (NXOpen.ModelingView): Model view displaying the given PMI symbols .

Created in NX5.0.0 

License requirements: geometric_tol ("GDT")

Parameters

pmi_symbols — (List[NXOpen.Annotations.Annotation]) List of PMI symbols, ordinarily from a geometry query

## ◆ CreateTextEditorBuilder()

NXOpen.Annotations.AnnotationManager.CreateTextEditorBuilder
(
self,

text )

Creates a NXOpen::Annotations::TextEditorBuilder. 

Returns
builder (NXOpen.Annotations.TextEditorBuilder): Text editor builder.

Created in NX2007.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

text — (List[str]) text lines

## ◆ CurrentSbfFile() [1/2]

NXOpen.Annotations.AnnotationManager.CurrentSbfFile
(
self — )

Getter for property: (str) CurrentSbfFile Returns the symbol font definition file. 

LoadSymbolFontFromSbfFile will read from this file

Getter License requirements: None.

Created in NX3.0.0 

Returns
str 

## ◆ CurrentSbfFile() [2/2]

NXOpen.Annotations.AnnotationManager.CurrentSbfFile
(
self,

file_name )

Setter for property: (str) CurrentSbfFile. 

Sets the symbol font definition file. LoadSymbolFontFromSbfFile will read from this file

Setter License requirements: None.

Created in NX3.0.0 

## ◆ CustomSymbols()

NXOpen.Annotations.AnnotationManager.CustomSymbols
(
)

CustomSymbol collection. 

Created in NX3.0.0 

NXOpen.Annotations.CustomSymbolCollection 

## ◆ Datums()

NXOpen.Annotations.AnnotationManager.Datums
(
)

Datum collection. 

Created in NX3.0.0 

NXOpen.Annotations.GdtDatumCollection 

## ◆ DatumTargets()

NXOpen.Annotations.AnnotationManager.DatumTargets
(
)

DatumTarget collection. 

Created in NX3.0.0 

NXOpen.Annotations.DatumTargetCollection 

## ◆ DimensionSets()

NXOpen.Annotations.AnnotationManager.DimensionSets
(
)

DimensionSet collection. 

Created in NX3.0.0 

NXOpen.Annotations.DimensionSetCollection 

## ◆ DraftingDatumTargets()

NXOpen.Annotations.AnnotationManager.DraftingDatumTargets
(
)

DraftingDatumTarget collection. 

Created in NX8.0.1 

NXOpen.Annotations.DraftingDatumTargetCollection 

## ◆ DraftingImages()

NXOpen.Annotations.AnnotationManager.DraftingImages
(
)

Drafting Image collection. 

Created in NX9.0.0 

NXOpen.Annotations.DraftingImageCollection 

## ◆ DraftingSurfaceFinishSymbol()

NXOpen.Annotations.AnnotationManager.DraftingSurfaceFinishSymbol
(
)

Drafting Surface Finish Symbol collection. 

Created in NX2212.0.0 

NXOpen.Annotations.DraftingSurfaceFinishSymbolCollection 

## ◆ DraftingSurfaceFinishSymbols()

NXOpen.Annotations.AnnotationManager.DraftingSurfaceFinishSymbols
(
)

Drafting surface finish collection. 

Created in NX7.5.0 

NXOpen.Annotations.DraftingSurfaceFinishCollection 

## ◆ EdgeConditionSymbol()

NXOpen.Annotations.AnnotationManager.EdgeConditionSymbol
(
)

Edge Condition Symbol collection. 

Created in NX2007.0.0 

NXOpen.Annotations.EdgeConditionSymbolCollection 

## ◆ EditText()

NXOpen.Annotations.AnnotationManager.EditText
(
)

Edit Text. 

Created in NX2206.0.0 

NXOpen.Annotations.EditText 

## ◆ Fcfs()

NXOpen.Annotations.AnnotationManager.Fcfs
(
)

Fcf collection. 

Created in NX3.0.0 

NXOpen.Annotations.FcfCollection 

## ◆ FrameBars()

NXOpen.Annotations.AnnotationManager.FrameBars
(
)

Frame bar collection. 

Created in NX8.0.0 

NXOpen.Annotations.FrameBarCollection 

## ◆ GetDefaultAnnotationPlane()

NXOpen.Annotations.AnnotationManager.GetDefaultAnnotationPlane
(
self,

ja_default_plane )

Returns the default annotation plane for the specified part. 

Returns
default_plane (NXOpen.Xform): .

Created in NX4.0.0 

License requirements: None.

Parameters

ja_default_plane — (NXOpen.Annotations.PmiDefaultPlane)

## ◆ GetStandardSymbolTextFont()

NXOpen.Annotations.AnnotationManager.GetStandardSymbolTextFont
(
self — )

Returns the font to use for displaying symbols with standard fonts. 

Returns
symbolTextFontName (str): The name of the text font to use for displaying a symbol when using a standard font. .

Created in NX8.5.0 

License requirements: None. 

## ◆ Hatches()

NXOpen.Annotations.AnnotationManager.Hatches
(
)

Hatch collection. 

Created in NX3.0.0 

NXOpen.Annotations.HatchCollection 

## ◆ HoleTables()

NXOpen.Annotations.AnnotationManager.HoleTables
(
)

Hole Table collection. 

Created in NX9.0.0 

NXOpen.Annotations.HoleTableCollection 

## ◆ IdSymbols()

NXOpen.Annotations.AnnotationManager.IdSymbols
(
)

IdSymbol collection. 

Created in NX3.0.0 

NXOpen.Annotations.IdSymbolCollection 

## ◆ InferLeaderSide()

NXOpen.Annotations.AnnotationManager.InferLeaderSide
(
self,

ann )

Infers the leader stub side based on current origin location. 

This API is only supported for the Plain, All Around and All Over leader types. This method should be followed by a subsequent call to NXOpen::Update::DoUpdate .

Returns
isLeaderInferred (bool): Inferred leader value .

Created in NX2506.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

ann — (NXOpen.Annotations.Annotation) leader annotation

## ◆ IntersectionSymbols()

NXOpen.Annotations.AnnotationManager.IntersectionSymbols
(
)

IntersectionSymbol collection. 

Created in NX3.0.0 

NXOpen.Annotations.IntersectionSymbolCollection 

## ◆ LoadSymbolFontFromSbfFile()

NXOpen.Annotations.AnnotationManager.LoadSymbolFontFromSbfFile
(
self,

symbol_name )

Loads a symbol font from the current symbol font definition file. 

Returns
A tuple consisting of (symbol_font, symbol_width, symbol_height).
symbol_font is: NXOpen.SymbolFont. .

symbol_width is: float. .

symbol_height is: float. .

Created in NX3.0.0 

License requirements: None.

Parameters

symbol_name — (str) name of the symbol

## ◆ MakePmi()

NXOpen.Annotations.AnnotationManager.MakePmi
(
self,

annotation )

Flag the annotation as PMI object. 

Once flagged, the annotation particiaptes in all PMI specific behaviors, so you can manage it from Part Navigator, inherit on a drawing view, control its display in different model views etc..

Created in NX6.0.0 

License requirements: solid_modeling ("SOLIDS MODELING") OR geometric_tol ("GDT")

Parameters

annotation — (NXOpen.Annotations.Annotation) NXOpen::Annotations::Annotation to be edited

## ◆ MakeStubPerpendicular()

NXOpen.Annotations.AnnotationManager.MakeStubPerpendicular
(
self,

makeStubPerpendicular,

annotations )

Sets leader stub perpendicular setting on first leader of each input annotation. 

Created in NX2506.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

makeStubPerpendicular — (bool) Stub Perpendicular Setting

annotations — (List[NXOpen.Annotations.Annotation]) Annotations to be set

## ◆ NewAppendedText()

NXOpen.Annotations.AnnotationManager.NewAppendedText
(
self — )

Creates a new AppendedText object. 

Returns
appended_text (NXOpen.Annotations.AppendedText): New AppendedText object .

Created in NX4.0.0 

License requirements: None. 

## ◆ NewAssociativity()

NXOpen.Annotations.AnnotationManager.NewAssociativity
(
self — )

Creates a new Associativity object. 

Returns
associativty (NXOpen.Annotations.Associativity): New Associativity object .

Created in NX4.0.0 

License requirements: None. 

## ◆ NewDatumReference()

NXOpen.Annotations.AnnotationManager.NewDatumReference
(
self — )

Creates a new DatumReference object. 

Returns
datum_reference (NXOpen.Annotations.DatumReference): New DatumReference object .

Created in NX4.0.0 

License requirements: None. 

## ◆ NewDimensionData()

NXOpen.Annotations.AnnotationManager.NewDimensionData
(
self — )

Creates new DimensionData object. 

Returns
dimension_data (NXOpen.Annotations.DimensionData): New DimensionData object .

Created in NX4.0.0 

License requirements: None. 

## ◆ NewFcfFrame()

NXOpen.Annotations.AnnotationManager.NewFcfFrame
(
self — )

Creates a new FcfFrame object. 

Returns
fcf_frame (NXOpen.Annotations.FcfFrame): New FcfFrame object .

Created in NX4.0.0 

License requirements: None. 

## ◆ NewFcfFrameData()

NXOpen.Annotations.AnnotationManager.NewFcfFrameData
(
self — )

Creates a new Fcf Frame Data object. 

Returns
fcf_frame_data (NXOpen.Annotations.FcfFrameData): New Fcf Frame Data object .

Created in NX5.0.0 

License requirements: None. 

## ◆ NewLeaderBundle()

NXOpen.Annotations.AnnotationManager.NewLeaderBundle
(
self — )

Constructs a new LeaderBundle object. 

Returns
leader (NXOpen.Annotations.LeaderBundle): .

Created in NX3.0.0 

License requirements: None. 

## ◆ NewMasterCustomSymbolData()

NXOpen.Annotations.AnnotationManager.NewMasterCustomSymbolData
(
self — )

Creates a new MasterCustomSymbolData object. 

Returns
master_sym (NXOpen.Annotations.MasterCustomSymbolData): New MasterCustomSymbolData object .

Created in NX6.0.0 

Deprecated
Deprecated in NX9.0.0. Use NXOpen::Annotations::MasterSymbolBuilder instead. 

License requirements: None. 

## ◆ NewPmiData()

NXOpen.Annotations.AnnotationManager.NewPmiData
(
self — )

Creates a new PmiData object. 

Returns
pmi_data (NXOpen.Annotations.PmiData): New PMIData object .

Created in NX4.0.0 

License requirements: None. 

## ◆ NewUserSymbolPreferences()

NXOpen.Annotations.AnnotationManager.NewUserSymbolPreferences
(
self,

type,

length_or_scale,

height_or_aspect_ratio )

Constructs a new UserSymbolPreferences object. 

Returns
user_symbol_preferences (NXOpen.Annotations.UserSymbolPreferences): the new object .

Created in NX3.0.0 

License requirements: None.

Parameters

type — (NXOpen.Annotations.UserSymbolPreferences.SizeType) Whether to use length and height or scale and aspect ratio

length_or_scale — (float) Length or scale

height_or_aspect_ratio — (float) Height or aspect ratio

## ◆ OffsetCenterPoints()

NXOpen.Annotations.AnnotationManager.OffsetCenterPoints
(
)

OffsetCenterPoint collection. 

Created in NX3.0.0 

NXOpen.Annotations.OffsetCenterPointCollection 

## ◆ OrdinateMargins()

NXOpen.Annotations.AnnotationManager.OrdinateMargins
(
)

OrdinateMargin collection. 

Created in NX3.0.0 

NXOpen.Annotations.OrdinateMarginCollection 

## ◆ PartFamilyTables()

NXOpen.Annotations.AnnotationManager.PartFamilyTables
(
)

Part Family Table collection. 

Created in NX1980.0.0 

NXOpen.Annotations.PartFamilyTableCollection 

## ◆ PartsLists()

NXOpen.Annotations.AnnotationManager.PartsLists
(
)

Parts list collection. 

Created in NX1847.0.0 

NXOpen.Annotations.PartsListCollection 

## ◆ PartSymbolFolders()

NXOpen.Annotations.AnnotationManager.PartSymbolFolders
(
)

Part Symbol Folder collection. 

Created in NX7.5.0 

NXOpen.Annotations.PartSymbolFolderCollection 

## ◆ PmiEdgeConditionSymbol()

NXOpen.Annotations.AnnotationManager.PmiEdgeConditionSymbol
(
)

PMI Edge Condition Symbol collection. 

Created in NX2007.0.0 

NXOpen.Annotations.PmiEdgeConditionSymbolCollection 

## ◆ PmiFilters()

NXOpen.Annotations.AnnotationManager.PmiFilters
(
)

PmiFilter collection. 

Created in NX3.0.0 

NXOpen.Annotations.PmiFilterCollection 

## ◆ PmiSurfaceFinishSymbol()

NXOpen.Annotations.AnnotationManager.PmiSurfaceFinishSymbol
(
)

PMI Surface Finish Symbol collection. 

Created in NX2212.0.0 

NXOpen.Annotations.PmiSurfaceFinishSymbolCollection 

## ◆ PmiTableSections()

NXOpen.Annotations.AnnotationManager.PmiTableSections
(
)

PMI Table collection. 

Created in NX12.0.0 

NXOpen.Annotations.PmiTableSectionCollection 

## ◆ Preferences()

NXOpen.Annotations.AnnotationManager.Preferences
(
)

Global annotation preferences. 

Created in NX3.0.0 

NXOpen.Preferences.AnnotationPreferences 

## ◆ ProductGrids()

NXOpen.Annotations.AnnotationManager.ProductGrids
(
)

Product Grid collection. 

Created in NX1980.0.0 

NXOpen.Annotations.ProductGridCollection 

## ◆ QueryPmiFromGeometry()

NXOpen.Annotations.AnnotationManager.QueryPmiFromGeometry
(
self,

geom )

Finds all PMI symbols that reference the given geometry as an associated object. 

The geometry types supported are limited to those supported by NXOpen::Annotations::AssociatedObject . 
Returns
pmi_symbols (List[NXOpen.Annotations.Annotation]): PMI symbols that reference the geometry .

Created in NX5.0.0 

License requirements: geometric_tol ("GDT")

Parameters

geom — (List[NXOpen.DisplayableObject]) Geometry to be searched

## ◆ ReadAllSymbolNamesFromSbfFile()

NXOpen.Annotations.AnnotationManager.ReadAllSymbolNamesFromSbfFile
(
self — )

Reads the names of all symbol fonts in the current symbol font definition file. 

Returns
symbol_names (List[str]): array of names of all symbol fonts in the file .

Created in NX3.0.0 

License requirements: None. 

## ◆ RemovePmi()

NXOpen.Annotations.AnnotationManager.RemovePmi
(
self,

annotation )

Remove PMI flag from annotation. 

After the flag is removed, the annotation can't be managed as PMI. However it retains all its properties.

Created in NX6.0.0 

License requirements: solid_modeling ("SOLIDS MODELING") OR geometric_tol ("GDT")

Parameters

annotation — (NXOpen.Annotations.Annotation) NXOpen::Annotations::Annotation to be edited

## ◆ SaveUserSymbolPart()

NXOpen.Annotations.AnnotationManager.SaveUserSymbolPart
(
self,

sym_data )

Save a new master Custom Symbol file. 

Use builder class NXOpen::Annotations::MasterSymbolBuilder methods instead of this method.

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.2. Use NXOpen::Annotations::MasterSymbolBuilder instead. 

License requirements: None.

Parameters

sym_data — (NXOpen.Annotations.MasterCustomSymbolData) New master part data

## ◆ SetMasterSymbolNameInQaf()

NXOpen.Annotations.AnnotationManager.SetMasterSymbolNameInQaf
(
self — )

This method writes master custom symbol name to the predefined quick access folder and saves the part. 

The given part should correspond to the part file of native symbol part file otherwise error will be raised.

Created in NX7.5.0 

License requirements: drafting ("DRAFTING") 

## ◆ SetParallelToScreen()

NXOpen.Annotations.AnnotationManager.SetParallelToScreen
(
self,

parallelToScreen,

annotations )

Sets the parallel to screen status on each input annotation. 

Created in NX11.0.1 

License requirements: geometric_tol ("GDT")

Parameters

parallelToScreen — (bool) Parallel to Screen Setting

annotations — (List[NXOpen.Annotations.Annotation]) Annotations to be set

## ◆ SetStandardSymbolTextFont()

NXOpen.Annotations.AnnotationManager.SetStandardSymbolTextFont
(
self,

symbolTextFontName )

Created in NX8.5.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

symbolTextFontName — (str) The name of the text font to use for displaying a symbol when using a standard font.

## ◆ SymbolFiles()

NXOpen.Annotations.AnnotationManager.SymbolFiles
(
)

Library Symbol collection. 

Created in NX8.0.0 

NXOpen.Annotations.SymbolFileCollection 

## ◆ Tables()

NXOpen.Annotations.AnnotationManager.Tables
(
)

Table collection. 

Created in NX8.0.0 

NXOpen.Annotations.TableCollection 

## ◆ TableSections()

NXOpen.Annotations.AnnotationManager.TableSections
(
)

Table section collection. 

Created in NX8.0.0 

NXOpen.Annotations.TableSectionCollection 

## ◆ TargetPoints()

NXOpen.Annotations.AnnotationManager.TargetPoints
(
)

TargetPoint collection. 

Created in NX3.0.0 

NXOpen.Annotations.TargetPointCollection 

## ◆ Welds()

NXOpen.Annotations.AnnotationManager.Welds
(
)

Weld collection. 

Created in NX3.0.0 

NXOpen.Annotations.WeldCollection 

## ◆ WeldStandard() [1/2]

NXOpen.Annotations.AnnotationManager.WeldStandard
(
self — )

Getter for property: (NXOpen.Annotations.WeldStandard) WeldStandard Returns the weld standard for the part file. 

Getter License requirements: None.

Created in NX7.5.4 

Returns
WeldStandard 

## ◆ WeldStandard() [2/2]

NXOpen.Annotations.AnnotationManager.WeldStandard
(
self,

standard )

Setter for property: (NXOpen.Annotations.WeldStandard) WeldStandard. 

Sets the weld standard for the part file.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX7.5.4 

Copyright 2025 Siemens
