# NXOpen.Annotations.EditSymbolDisplayBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00156.html>

## Classes

class — FontTypes

The Enum represent font types. More...

class — WidthTypes

The Enum represent width types NXOpen::Annotations::EditSymbolDisplayBuilder::Width and NXOpen::Annotations::EditSymbolDisplayBuilder::SetWidth will set this width type at builder side and will be used to apply the same on the selected contents after commit 

Enumerator — Comment

Thin — Thin

Normal — Normal

Thick — Thick

ThicknessOne — Width One

ThicknessTwo — Width Two

ThicknessThree — Width Three

ThicknessFour — Width Four

ThicknessFive — Width Five

ThicknessSix — Width Six

ThicknessSeven — Width Seven

ThicknessEight — Width Eight

ThicknessNine — Width Nine

More...

Copyright 2025 Siemens
