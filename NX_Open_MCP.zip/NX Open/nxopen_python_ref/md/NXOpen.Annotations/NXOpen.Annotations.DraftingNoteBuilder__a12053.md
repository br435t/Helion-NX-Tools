# NXOpen.Annotations.DraftingNoteBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12053.html>

Represents a NXOpen::Annotations::Note builder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateDraftingNoteBuilder 

Default values. 
More...

Inheritance diagram for NXOpen.Annotations.DraftingNoteBuilder:

## Public Member Functions

ForeshorteningSymbol (self)

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Inherit (self)

Getter for property: (NXOpen.SelectDisplayableObject) Inherit Returns the note from which the properties are inherited. 

InheritProperties (self, annotation, recordNumber)

Inheriting properties from the note. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style builder. 

Text (self)

Getter for property: (NXOpen.Annotations.TextWithEditControlsBuilder) Text Returns the text. 

TextAlignment (self)

Getter for property: (NXOpen.Annotations.DraftingNoteBuilder.TextAlign) TextAlignment Returns the text alignment. 

TextAlignment (self, textAlignment)

Setter for property: (NXOpen.Annotations.DraftingNoteBuilder.TextAlign) TextAlignment. 

VerticalText (self)

Getter for property: (bool) VerticalText Returns the vertical text for text. 

VerticalText (self, verticalText)

Setter for property: (bool) VerticalText. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

DraftingNoteBuilderTextAlign = DraftingNoteBuilder.TextAlign

NXOpen.Annotations.DraftingNoteBuilderTextAlign is an alias for NXOpen.Annotations.DraftingNoteBuilder.TextAlign 

DraftingNoteBuilderThicknessTypes = DraftingNoteBuilder.ThicknessTypes

NXOpen.Annotations.DraftingNoteBuilderThicknessTypes is an alias for NXOpen.Annotations.DraftingNoteBuilder.ThicknessTypes 

## Detailed Description

Represents a NXOpen::Annotations::Note builder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateDraftingNoteBuilder 

Default values. 

Property — Value

Text.TextBlock.CustomSymbolScale 

1.0 

Text.TextBlock.SymbolAspectRatio 

1.0 

Text.TextBlock.SymbolHeight 

25.4 (millimeters part), 1.0 (inches part) 

Text.TextBlock.SymbolLength 

25.4 (millimeters part), 1.0 (inches part) 

Text.TextBlock.SymbolPreferences 

UseCurrent 

Text.TextBlock.SymbolScale 

1.0 

Text.TextBlock.SymbolSizeMethod 

ScaleAndAspectRatio 

Created in NX6.0.0 

## Member Function Documentation

## ◆ ForeshorteningSymbol()

NXOpen.Annotations.DraftingNoteBuilder.ForeshorteningSymbol
(
self — )

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
ForeshorteningSymbolBuilder 

## ◆ Inherit()

NXOpen.Annotations.DraftingNoteBuilder.Inherit
(
self — )

Getter for property: (NXOpen.SelectDisplayableObject) Inherit Returns the note from which the properties are inherited. 

Getter License requirements: None.

Created in NX7.5.2 

Returns
NXOpen.SelectDisplayableObject 

## ◆ InheritProperties()

NXOpen.Annotations.DraftingNoteBuilder.InheritProperties
(
self,

annotation,

recordNumber )

Inheriting properties from the note. 

Created in NX7.5.2 

License requirements: None.

Parameters

annotation — (NXOpen.Annotations.SimpleDraftingAid)

recordNumber — (int)

## ◆ Leader()

NXOpen.Annotations.DraftingNoteBuilder.Leader
(
self — )

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LeaderBuilder 

## ◆ Origin()

NXOpen.Annotations.DraftingNoteBuilder.Origin
(
self — )

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
OriginBuilder 

## ◆ Style()

NXOpen.Annotations.DraftingNoteBuilder.Style
(
self — )

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style builder. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
StyleBuilder 

## ◆ Text()

NXOpen.Annotations.DraftingNoteBuilder.Text
(
self — )

Getter for property: (NXOpen.Annotations.TextWithEditControlsBuilder) Text Returns the text. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
TextWithEditControlsBuilder 

## ◆ TextAlignment() [1/2]

NXOpen.Annotations.DraftingNoteBuilder.TextAlignment
(
self — )

Getter for property: (NXOpen.Annotations.DraftingNoteBuilder.TextAlign) TextAlignment Returns the text alignment. 

Getter License requirements: drafting ("DRAFTING") OR cam_base ("CAM BASE") OR insp_programming ("INSPECTION PROGRAMMING") OR nx_2d_edit (" NX 2D Edit")

Created in NX6.0.0 

Returns
DraftingNoteBuilder.TextAlign 

## ◆ TextAlignment() [2/2]

NXOpen.Annotations.DraftingNoteBuilder.TextAlignment
(
self,

textAlignment )

Setter for property: (NXOpen.Annotations.DraftingNoteBuilder.TextAlign) TextAlignment. 

Sets the text alignment

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT") OR cam_base ("CAM BASE") OR insp_programming ("INSPECTION PROGRAMMING") OR nx_2d_edit (" NX 2D Edit")

Created in NX6.0.0 

## ◆ VerticalText() [1/2]

NXOpen.Annotations.DraftingNoteBuilder.VerticalText
(
self — )

Getter for property: (bool) VerticalText Returns the vertical text for text. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ VerticalText() [2/2]

NXOpen.Annotations.DraftingNoteBuilder.VerticalText
(
self,

verticalText )

Setter for property: (bool) VerticalText. 

Sets the vertical text for text

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT") OR cam_base ("CAM BASE") OR insp_programming ("INSPECTION PROGRAMMING") OR nx_2d_edit (" NX 2D Edit")

Created in NX6.0.0 

## Member Data Documentation

## ◆ DraftingNoteBuilderTextAlign

NXOpen.Annotations.DraftingNoteBuilder.DraftingNoteBuilderTextAlign = DraftingNoteBuilder.TextAlign

NXOpen.Annotations.DraftingNoteBuilderTextAlign is an alias for NXOpen.Annotations.DraftingNoteBuilder.TextAlign 

## ◆ DraftingNoteBuilderThicknessTypes

NXOpen.Annotations.DraftingNoteBuilder.DraftingNoteBuilderThicknessTypes = DraftingNoteBuilder.ThicknessTypes

NXOpen.Annotations.DraftingNoteBuilderThicknessTypes is an alias for NXOpen.Annotations.DraftingNoteBuilder.ThicknessTypes 

Copyright 2025 Siemens
