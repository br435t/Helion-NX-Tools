# NXOpen.Annotations.PmiCenterMarkBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13337.html>

Builder for creating PMI Center Mark. 
More...

Inheritance diagram for NXOpen.Annotations.PmiCenterMarkBuilder:

## Public Member Functions

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the associated objects for the center mark. 

Plane (self)

Getter for property: (NXOpen.Annotations.PlaneBuilder) Plane Returns the plane for the creation of center mark. 

Public Member Functions inherited from NXOpen.Annotations.BaseCenterMarkBuilder

Locations (self)

Getter for property: (NXOpen.SelectNXObjectList) Locations Returns the location object. 

MultipleCenterMarks (self)

Getter for property: (bool) MultipleCenterMarks Returns the multiple center marks option, applicable only for creation. 

MultipleCenterMarks (self, multipleCenterlines)

Setter for property: (bool) MultipleCenterMarks. 

RemoveLocation (self, index)

Removes location object for a given index from the Select Object List. 

Settings (self)

Getter for property: (NXOpen.Annotations.CenterMarkSettingsBuilder) Settings Returns the center mark settings builder. 

Public Member Functions inherited from NXOpen.Annotations.CenterlineBuilder

AddEndExtensions (self, start, end)

Adds extensions only at ends. 

AddExtension (self, index, defaultValue)

Adds extension based on select object index. 

GetAllExtensions (self)

Returns all extensions. 

GetAllIndividualExtensions (self)

Returns individual extensions. 

GetEndExtensions (self)

Returns end extensions only. 

RemoveEndExtensions (self)

Removes extensions only at ends. 

RemoveExtension (self, index)

Removes extension based on select object index. 

ResetAllExtensions (self, defaultValue)

Reset all extensions by the supplied defaultValue. 

SetAllIndividualExtensions (self, extensionValues)

Sets all individual extensions. 

SetEndExtensions (self, start, end)

Modifies end extensions only. 

SetIndividualExtensions (self, index, value1, value2)

Modifies extensions based on select object index. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Builder for creating PMI Center Mark. 

It creates or edits PMI Center Marks 

To create a new instance of this class, use NXOpen::Annotations::CenterlineCollection::CreatePmiCenterMarkBuilder 

Default values. 

Property — Value

MultipleCenterMarks 

false 

Created in NX7.5.0 

## Member Function Documentation

## ◆ AssociatedObjects()

NXOpen.Annotations.PmiCenterMarkBuilder.AssociatedObjects
(
self — )

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the associated objects for the center mark. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
AssociatedObjectsBuilder 

## ◆ Plane()

NXOpen.Annotations.PmiCenterMarkBuilder.Plane
(
self — )

Getter for property: (NXOpen.Annotations.PlaneBuilder) Plane Returns the plane for the creation of center mark. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
PlaneBuilder 

Copyright 2025 Siemens
