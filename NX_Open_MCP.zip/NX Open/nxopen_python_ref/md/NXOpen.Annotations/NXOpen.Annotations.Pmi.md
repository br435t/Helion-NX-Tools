# NXOpen.Annotations.Pmi Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00189.html>

## Classes

class — PmiType

The PMI type for an PMI object. More...

Copyright 2025 Siemens
