# NXOpen.Annotations.PmiGeneralSetupDisplayBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00196.html>

## Classes

class — AnnotationPlaneDisplayType

the display values which determines whether or not Annotation planes will be displayed while creating and editing PMI. More...

class — AnnotationPlaneType

the plane values which specify the annotation plane that will be used to display PMI. More...

class — ResizeSettingsType

the resize values which specify the method used to resize PMI. More...

Copyright 2025 Siemens
