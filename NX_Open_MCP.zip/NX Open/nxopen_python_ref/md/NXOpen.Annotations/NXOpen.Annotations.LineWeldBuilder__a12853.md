# NXOpen.Annotations.LineWeldBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12853.html>

Represents a NXOpen::Annotations::LineWeldBuilder 

To create a new instance of this class, use NXOpen::Annotations::WeldCollection::CreateLineWeldBuilder 

Default values. 
More...

Inheritance diagram for NXOpen.Annotations.LineWeldBuilder:

## Public Member Functions

ArrowSideWeldData (self)

Getter for property: (NXOpen.Annotations.LineWeldDataBuilder) ArrowSideWeldData Returns the NXOpen::Annotations::LineWeldDataBuilder for the arrow side of the weld symbol. 

FieldWeld (self)

Getter for property: (NXOpen.Annotations.LineWeldBuilder.FieldWeldType) FieldWeld Returns the field indicating the weld is done at the field site. 

FieldWeld (self, fieldWeld)

Setter for property: (NXOpen.Annotations.LineWeldBuilder.FieldWeldType) FieldWeld. 

FlipDirection (self)

Getter for property: (bool) FlipDirection Returns the flip direction for top seam. 

FlipDirection (self, flipDirection)

Setter for property: (bool) FlipDirection. 

FlipHorizontal (self)

Getter for property: (bool) FlipHorizontal Returns the flip horizontal direction for side seam. 

FlipHorizontal (self, flipHorizontal)

Setter for property: (bool) FlipHorizontal. 

FlipVertical (self)

Getter for property: (bool) FlipVertical Returns the flip vertical direction for side seam. 

FlipVertical (self, flipVertical)

Setter for property: (bool) FlipVertical. 

ForeshorteningSymbol (self)

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

GetReference (self)

Returns the reference or specification text. 

IdLine (self)

Getter for property: (NXOpen.Annotations.LineWeldBuilder.IdLineType) IdLine Returns the identification or reference line. 

IdLine (self, idLine)

Setter for property: (NXOpen.Annotations.LineWeldBuilder.IdLineType) IdLine. 

Inherit (self)

Getter for property: (NXOpen.SelectDisplayableObject) Inherit Returns the weld symbol from which the style properties are inherited. 

InheritProperties (self, annotation)

This inherits the properties from the existing weld symbol. 

InheritPropertiesFromWeldFeature (self, feature)

This inherits the properties from the existing weld feature. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for weld symbol. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the NXOpen::Annotations::OriginBuilder for the weld symbol. 

OtherSideWeldData (self)

Getter for property: (NXOpen.Annotations.LineWeldDataBuilder) OtherSideWeldData Returns the NXOpen::Annotations::LineWeldDataBuilder for the other side of the weld symbol. 

Scale (self)

Getter for property: (float) Scale Returns the scaling factor for the welding symbol. 

Scale (self, scale)

Setter for property: (float) Scale. 

SetReference (self, reference)

Sets the reference or specification text. 

SideSeamObjects (self)

Getter for property: (NXOpen.SelectDisplayableObjectList) SideSeamObjects Returns the side seam object. 

SpaceFactor (self)

Getter for property: (float) SpaceFactor Returns the space factor for the welding symbol. 

SpaceFactor (self, spaceFactor)

Setter for property: (float) SpaceFactor. 

StaggeredWeld (self)

Getter for property: (NXOpen.Annotations.LineWeldBuilder.StaggeredWeldType) StaggeredWeld Returns the staggered weld. 

StaggeredWeld (self, staggeredWeld)

Setter for property: (NXOpen.Annotations.LineWeldBuilder.StaggeredWeldType) StaggeredWeld. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the NXOpen::Annotations::StyleBuilder for the weld symbol. 

Tail (self)

Getter for property: (NXOpen.Annotations.LineWeldBuilder.TailType) Tail Returns the weld tail. 

Tail (self, tail)

Setter for property: (NXOpen.Annotations.LineWeldBuilder.TailType) Tail. 

TopSeamObject (self)

Getter for property: (NXOpen.SelectDisplayableObject) TopSeamObject Returns the top seam object. 

WeldAlongContour (self)

Getter for property: (NXOpen.Annotations.LineWeldBuilder.WeldSymbolWeldAlongContourType) WeldAlongContour Returns the weld along contour option. 

WeldAlongContour (self, alongContour)

Setter for property: (NXOpen.Annotations.LineWeldBuilder.WeldSymbolWeldAlongContourType) WeldAlongContour. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

LineWeldBuilderFieldWeldType = LineWeldBuilder.FieldWeldType

NXOpen.Annotations.LineWeldBuilderFieldWeldType is an alias for NXOpen.Annotations.LineWeldBuilder.FieldWeldType 

LineWeldBuilderIdLineType = LineWeldBuilder.IdLineType

NXOpen.Annotations.LineWeldBuilderIdLineType is an alias for NXOpen.Annotations.LineWeldBuilder.IdLineType 

LineWeldBuilderStaggeredWeldType = LineWeldBuilder.StaggeredWeldType

NXOpen.Annotations.LineWeldBuilderStaggeredWeldType is an alias for NXOpen.Annotations.LineWeldBuilder.StaggeredWeldType 

LineWeldBuilderTailType = LineWeldBuilder.TailType

NXOpen.Annotations.LineWeldBuilderTailType is an alias for NXOpen.Annotations.LineWeldBuilder.TailType 

LineWeldBuilderWeldSymbolWeldAlongContourType = LineWeldBuilder.WeldSymbolWeldAlongContourType

NXOpen.Annotations.LineWeldBuilderWeldSymbolWeldAlongContourType is an alias for NXOpen.Annotations.LineWeldBuilder.WeldSymbolWeldAlongContourType 

## Detailed Description

Represents a NXOpen::Annotations::LineWeldBuilder 

To create a new instance of this class, use NXOpen::Annotations::WeldCollection::CreateLineWeldBuilder 

Default values. 

Property — Value

ArrowSideWeldData.ContourSymbol 

None 

ArrowSideWeldData.FinishSymbol 

None 

ArrowSideWeldData.WeldSizeCode 

None 

ArrowSideWeldData.WeldSymbol 

None 

FieldWeld 

Plain 

FlipDirection 

False 

FlipHorizontal 

False 

FlipVertical 

False 

IdLine 

Plain 

Scale 

1 

StaggeredWeld 

NoStaggeredSymbol 

Tail 

NoTail 

WeldAlongContour 

None 

Created in NX6.0.0 

## Member Function Documentation

## ◆ ArrowSideWeldData()

NXOpen.Annotations.LineWeldBuilder.ArrowSideWeldData
(
self — )

Getter for property: (NXOpen.Annotations.LineWeldDataBuilder) ArrowSideWeldData Returns the NXOpen::Annotations::LineWeldDataBuilder for the arrow side of the weld symbol. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWeldDataBuilder 

## ◆ FieldWeld() [1/2]

NXOpen.Annotations.LineWeldBuilder.FieldWeld
(
self — )

Getter for property: (NXOpen.Annotations.LineWeldBuilder.FieldWeldType) FieldWeld Returns the field indicating the weld is done at the field site. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWeldBuilder.FieldWeldType 

## ◆ FieldWeld() [2/2]

NXOpen.Annotations.LineWeldBuilder.FieldWeld
(
self,

fieldWeld )

Setter for property: (NXOpen.Annotations.LineWeldBuilder.FieldWeldType) FieldWeld. 

Sets the field indicating the weld is done at the field site

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ FlipDirection() [1/2]

NXOpen.Annotations.LineWeldBuilder.FlipDirection
(
self — )

Getter for property: (bool) FlipDirection Returns the flip direction for top seam. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ FlipDirection() [2/2]

NXOpen.Annotations.LineWeldBuilder.FlipDirection
(
self,

flipDirection )

Setter for property: (bool) FlipDirection. 

Sets the flip direction for top seam

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ FlipHorizontal() [1/2]

NXOpen.Annotations.LineWeldBuilder.FlipHorizontal
(
self — )

Getter for property: (bool) FlipHorizontal Returns the flip horizontal direction for side seam. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ FlipHorizontal() [2/2]

NXOpen.Annotations.LineWeldBuilder.FlipHorizontal
(
self,

flipHorizontal )

Setter for property: (bool) FlipHorizontal. 

Sets the flip horizontal direction for side seam

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ FlipVertical() [1/2]

NXOpen.Annotations.LineWeldBuilder.FlipVertical
(
self — )

Getter for property: (bool) FlipVertical Returns the flip vertical direction for side seam. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ FlipVertical() [2/2]

NXOpen.Annotations.LineWeldBuilder.FlipVertical
(
self,

flipVertical )

Setter for property: (bool) FlipVertical. 

Sets the flip vertical direction for side seam

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ ForeshorteningSymbol()

NXOpen.Annotations.LineWeldBuilder.ForeshorteningSymbol
(
self — )

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
ForeshorteningSymbolBuilder 

## ◆ GetReference()

NXOpen.Annotations.LineWeldBuilder.GetReference
(
self — )

Returns the reference or specification text. 

Returns
reference (List[str]): .

Created in NX6.0.0 

License requirements: None. 

## ◆ IdLine() [1/2]

NXOpen.Annotations.LineWeldBuilder.IdLine
(
self — )

Getter for property: (NXOpen.Annotations.LineWeldBuilder.IdLineType) IdLine Returns the identification or reference line. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWeldBuilder.IdLineType 

## ◆ IdLine() [2/2]

NXOpen.Annotations.LineWeldBuilder.IdLine
(
self,

idLine )

Setter for property: (NXOpen.Annotations.LineWeldBuilder.IdLineType) IdLine. 

Sets the identification or reference line

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ Inherit()

NXOpen.Annotations.LineWeldBuilder.Inherit
(
self — )

Getter for property: (NXOpen.SelectDisplayableObject) Inherit Returns the weld symbol from which the style properties are inherited. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectDisplayableObject 

## ◆ InheritProperties()

NXOpen.Annotations.LineWeldBuilder.InheritProperties
(
self,

annotation )

This inherits the properties from the existing weld symbol. 

Created in NX8.0.0 

License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Parameters

annotation — (NXOpen.Annotations.Weld)

## ◆ InheritPropertiesFromWeldFeature()

NXOpen.Annotations.LineWeldBuilder.InheritPropertiesFromWeldFeature
(
self,

feature )

This inherits the properties from the existing weld feature. 

Created in NX8.0.0 

License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Parameters

feature — (NXOpen.DisplayableObject)

## ◆ Leader()

NXOpen.Annotations.LineWeldBuilder.Leader
(
self — )

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for weld symbol. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LeaderBuilder 

## ◆ Origin()

NXOpen.Annotations.LineWeldBuilder.Origin
(
self — )

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the NXOpen::Annotations::OriginBuilder for the weld symbol. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
OriginBuilder 

## ◆ OtherSideWeldData()

NXOpen.Annotations.LineWeldBuilder.OtherSideWeldData
(
self — )

Getter for property: (NXOpen.Annotations.LineWeldDataBuilder) OtherSideWeldData Returns the NXOpen::Annotations::LineWeldDataBuilder for the other side of the weld symbol. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWeldDataBuilder 

## ◆ Scale() [1/2]

NXOpen.Annotations.LineWeldBuilder.Scale
(
self — )

Getter for property: (float) Scale Returns the scaling factor for the welding symbol. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ Scale() [2/2]

NXOpen.Annotations.LineWeldBuilder.Scale
(
self,

scale )

Setter for property: (float) Scale. 

Sets the scaling factor for the welding symbol

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ SetReference()

NXOpen.Annotations.LineWeldBuilder.SetReference
(
self,

reference )

Sets the reference or specification text. 

Created in NX6.0.0 

License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Parameters

reference — (List[str])

## ◆ SideSeamObjects()

NXOpen.Annotations.LineWeldBuilder.SideSeamObjects
(
self — )

Getter for property: (NXOpen.SelectDisplayableObjectList) SideSeamObjects Returns the side seam object. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectDisplayableObjectList 

## ◆ SpaceFactor() [1/2]

NXOpen.Annotations.LineWeldBuilder.SpaceFactor
(
self — )

Getter for property: (float) SpaceFactor Returns the space factor for the welding symbol. 

Getter License requirements: None.

Created in NX7.0.0 

Returns
float 

## ◆ SpaceFactor() [2/2]

NXOpen.Annotations.LineWeldBuilder.SpaceFactor
(
self,

spaceFactor )

Setter for property: (float) SpaceFactor. 

Sets the space factor for the welding symbol

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX7.0.0 

## ◆ StaggeredWeld() [1/2]

NXOpen.Annotations.LineWeldBuilder.StaggeredWeld
(
self — )

Getter for property: (NXOpen.Annotations.LineWeldBuilder.StaggeredWeldType) StaggeredWeld Returns the staggered weld. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWeldBuilder.StaggeredWeldType 

## ◆ StaggeredWeld() [2/2]

NXOpen.Annotations.LineWeldBuilder.StaggeredWeld
(
self,

staggeredWeld )

Setter for property: (NXOpen.Annotations.LineWeldBuilder.StaggeredWeldType) StaggeredWeld. 

Sets the staggered weld

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ Style()

NXOpen.Annotations.LineWeldBuilder.Style
(
self — )

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the NXOpen::Annotations::StyleBuilder for the weld symbol. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
StyleBuilder 

## ◆ Tail() [1/2]

NXOpen.Annotations.LineWeldBuilder.Tail
(
self — )

Getter for property: (NXOpen.Annotations.LineWeldBuilder.TailType) Tail Returns the weld tail. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWeldBuilder.TailType 

## ◆ Tail() [2/2]

NXOpen.Annotations.LineWeldBuilder.Tail
(
self,

tail )

Setter for property: (NXOpen.Annotations.LineWeldBuilder.TailType) Tail. 

Sets the weld tail

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## ◆ TopSeamObject()

NXOpen.Annotations.LineWeldBuilder.TopSeamObject
(
self — )

Getter for property: (NXOpen.SelectDisplayableObject) TopSeamObject Returns the top seam object. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectDisplayableObject 

## ◆ WeldAlongContour() [1/2]

NXOpen.Annotations.LineWeldBuilder.WeldAlongContour
(
self — )

Getter for property: (NXOpen.Annotations.LineWeldBuilder.WeldSymbolWeldAlongContourType) WeldAlongContour Returns the weld along contour option. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWeldBuilder.WeldSymbolWeldAlongContourType 

## ◆ WeldAlongContour() [2/2]

NXOpen.Annotations.LineWeldBuilder.WeldAlongContour
(
self,

alongContour )

Setter for property: (NXOpen.Annotations.LineWeldBuilder.WeldSymbolWeldAlongContourType) WeldAlongContour. 

Sets the weld along contour option

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

## Member Data Documentation

## ◆ LineWeldBuilderFieldWeldType

NXOpen.Annotations.LineWeldBuilder.LineWeldBuilderFieldWeldType = LineWeldBuilder.FieldWeldType

NXOpen.Annotations.LineWeldBuilderFieldWeldType is an alias for NXOpen.Annotations.LineWeldBuilder.FieldWeldType 

## ◆ LineWeldBuilderIdLineType

NXOpen.Annotations.LineWeldBuilder.LineWeldBuilderIdLineType = LineWeldBuilder.IdLineType

NXOpen.Annotations.LineWeldBuilderIdLineType is an alias for NXOpen.Annotations.LineWeldBuilder.IdLineType 

## ◆ LineWeldBuilderStaggeredWeldType

NXOpen.Annotations.LineWeldBuilder.LineWeldBuilderStaggeredWeldType = LineWeldBuilder.StaggeredWeldType

NXOpen.Annotations.LineWeldBuilderStaggeredWeldType is an alias for NXOpen.Annotations.LineWeldBuilder.StaggeredWeldType 

## ◆ LineWeldBuilderTailType

NXOpen.Annotations.LineWeldBuilder.LineWeldBuilderTailType = LineWeldBuilder.TailType

NXOpen.Annotations.LineWeldBuilderTailType is an alias for NXOpen.Annotations.LineWeldBuilder.TailType 

## ◆ LineWeldBuilderWeldSymbolWeldAlongContourType

NXOpen.Annotations.LineWeldBuilder.LineWeldBuilderWeldSymbolWeldAlongContourType = LineWeldBuilder.WeldSymbolWeldAlongContourType

NXOpen.Annotations.LineWeldBuilderWeldSymbolWeldAlongContourType is an alias for NXOpen.Annotations.LineWeldBuilder.WeldSymbolWeldAlongContourType 

Copyright 2025 Siemens
