# NXOpen.Annotations.LeaderData Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00174.html>

## Classes

class — ArrowheadType

the set of arrowhead types used to define a leader arrowhead 

Enumerator — Comment

ClosedArrow — Closed arrowhead type

ClosedSolidArrow — Closed solid arrowhead type

OpenArrow — Open arrowhead type

FilledArrow — Filled arrowhead type

ClosedDoubleArrow — Closed double arrowhead type

ClosedDoubleSolidArrow — Closed double solid arrowhead type

OpenDoubleArrow — Open double arrowhead type

FilledDoubleArrow — Filled double arrowhead type

NotSet — No terminating symbol

Origin — Origin symbol

Cross — Cross symbol

Integral — Integral symbol

Dot — Dot symbol

FilledDot — Filled dot symbol

Square — Square symbol

FilledSquare — Filled square symbol

Datum — Datum symbol

FilledDatum — Filled datum symbol

TopOpenArrow — Top open arrowhead

BottomOpenArrow — bottom open arrowhead

TopFilledArrow — top filled arrowhead

BottomFilledArrow — bottom filled arrowhead

More...

class — LeaderType

the set of datatypes used to define the types of leaders that can be applied to an annotation 

Enumerator — Comment

Plain — Plain leader style

AllAround — Plain leader style with all around symbol

PlainWithoutStub — Plain leader style with no stub

Flag — Flag style

Datum — Datum feature symbol style

DotTerminated — Datum feature on stub of dot terminated style

Extension — Id symbol extension style leader

AllOver

More...

Copyright 2025 Siemens
