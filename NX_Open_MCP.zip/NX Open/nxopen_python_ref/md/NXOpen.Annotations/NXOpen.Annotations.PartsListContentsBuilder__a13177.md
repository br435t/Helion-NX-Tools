# NXOpen.Annotations.PartsListContentsBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13177.html>

Represents a Annotations::PartsListContentsBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.PartsListContentsBuilder:

## Public Member Functions

AddMember (self, member, selectSubassemblies)

Adds member to parts list. 

Arrangement (self)

Getter for property: (NXOpen.Assemblies.ArrangementsBuilder) Arrangement Returns the arrangement. 

IncludeSubOrdinateDesignElements (self)

Getter for property: (bool) IncludeSubOrdinateDesignElements Returns the Include Subordinate Design Elements for Parts list in 4GD mode. 

IncludeSubOrdinateDesignElements (self, includeSubOrdinateDesignElements)

Setter for property: (bool) IncludeSubOrdinateDesignElements. 

RemoveMember (self, member, removeSubassemblies)

Removes member from parts list. 

Scope (self)

Getter for property: (NXOpen.Annotations.PartsListContentsBuilder.ScopeType) Scope Returns the scope specifies the configuration type for parts list. 

Scope (self, scope)

Setter for property: (NXOpen.Annotations.PartsListContentsBuilder.ScopeType) Scope. 

TopLevelAssembly (self)

Getter for property: (NXOpen.Annotations.PartsListContentsBuilder.TopLevelAssemblyType) TopLevelAssembly Returns the top level assembly type for parts list. 

TopLevelAssembly (self, topLevelAssembly)

Setter for property: (NXOpen.Annotations.PartsListContentsBuilder.TopLevelAssemblyType) TopLevelAssembly. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

PartsListContentsBuilderScopeType = PartsListContentsBuilder.ScopeType

NXOpen.Annotations.PartsListContentsBuilderScopeType is an alias for NXOpen.Annotations.PartsListContentsBuilder.ScopeType 

PartsListContentsBuilderTopLevelAssemblyType = PartsListContentsBuilder.TopLevelAssemblyType

NXOpen.Annotations.PartsListContentsBuilderTopLevelAssemblyType is an alias for NXOpen.Annotations.PartsListContentsBuilder.TopLevelAssemblyType 

## Detailed Description

Represents a Annotations::PartsListContentsBuilder . 

This is a sub-builder class and cannot be directly instantiated 

Created in NX1847.0.0 

## Member Function Documentation

## ◆ AddMember()

NXOpen.Annotations.PartsListContentsBuilder.AddMember
(
self,

member,

selectSubassemblies )

Adds member to parts list. 

If 'Select Subassemblies flag' is true then child components of input assembly will also be added to parts list. If 'Select Subassemblies flag' is false, then only input member will be added to parts list.

Created in NX1847.0.0 

License requirements: None.

Parameters

member — (NXOpen.TaggedObject) Object of the member to add.

selectSubassemblies — (bool) Select subassemblies flag

## ◆ Arrangement()

NXOpen.Annotations.PartsListContentsBuilder.Arrangement
(
self — )

Getter for property: (NXOpen.Assemblies.ArrangementsBuilder) Arrangement Returns the arrangement. 

Getter License requirements: None.

Created in NX1899.0.0 

Returns
NXOpen.Assemblies.ArrangementsBuilder 

## ◆ IncludeSubOrdinateDesignElements() [1/2]

NXOpen.Annotations.PartsListContentsBuilder.IncludeSubOrdinateDesignElements
(
self — )

Getter for property: (bool) IncludeSubOrdinateDesignElements Returns the Include Subordinate Design Elements for Parts list in 4GD mode. 

Getter License requirements: None.

Created in NX1847.0.0 

Returns
bool 

## ◆ IncludeSubOrdinateDesignElements() [2/2]

NXOpen.Annotations.PartsListContentsBuilder.IncludeSubOrdinateDesignElements
(
self,

includeSubOrdinateDesignElements )

Setter for property: (bool) IncludeSubOrdinateDesignElements. 

Sets the Include Subordinate Design Elements for Parts list in 4GD mode

Setter License requirements: None.

Created in NX1847.0.0 

## ◆ RemoveMember()

NXOpen.Annotations.PartsListContentsBuilder.RemoveMember
(
self,

member,

removeSubassemblies )

Removes member from parts list. 

If 'Remove subassemblies flag' is true then child components of input assembly will also be removed from parts list. If 'Remove subassemblies flag' is false, then only input member will be removed from parts list.

Created in NX1847.0.0 

License requirements: None.

Parameters

member — (NXOpen.TaggedObject) Object of the member to remove.

removeSubassemblies — (bool) Remove subassemblies flag

## ◆ Scope() [1/2]

NXOpen.Annotations.PartsListContentsBuilder.Scope
(
self — )

Getter for property: (NXOpen.Annotations.PartsListContentsBuilder.ScopeType) Scope Returns the scope specifies the configuration type for parts list. 

Getter License requirements: None.

Created in NX1847.0.0 

Returns
PartsListContentsBuilder.ScopeType 

## ◆ Scope() [2/2]

NXOpen.Annotations.PartsListContentsBuilder.Scope
(
self,

scope )

Setter for property: (NXOpen.Annotations.PartsListContentsBuilder.ScopeType) Scope. 

Sets the scope specifies the configuration type for parts list

Setter License requirements: None.

Created in NX1847.0.0 

## ◆ TopLevelAssembly() [1/2]

NXOpen.Annotations.PartsListContentsBuilder.TopLevelAssembly
(
self — )

Getter for property: (NXOpen.Annotations.PartsListContentsBuilder.TopLevelAssemblyType) TopLevelAssembly Returns the top level assembly type for parts list. 

Getter License requirements: None.

Created in NX1847.0.0 

Returns
PartsListContentsBuilder.TopLevelAssemblyType 

## ◆ TopLevelAssembly() [2/2]

NXOpen.Annotations.PartsListContentsBuilder.TopLevelAssembly
(
self,

topLevelAssembly )

Setter for property: (NXOpen.Annotations.PartsListContentsBuilder.TopLevelAssemblyType) TopLevelAssembly. 

Sets the top level assembly type for parts list

Setter License requirements: None.

Created in NX1847.0.0 

## Member Data Documentation

## ◆ PartsListContentsBuilderScopeType

NXOpen.Annotations.PartsListContentsBuilder.PartsListContentsBuilderScopeType = PartsListContentsBuilder.ScopeType

NXOpen.Annotations.PartsListContentsBuilderScopeType is an alias for NXOpen.Annotations.PartsListContentsBuilder.ScopeType 

## ◆ PartsListContentsBuilderTopLevelAssemblyType

NXOpen.Annotations.PartsListContentsBuilder.PartsListContentsBuilderTopLevelAssemblyType = PartsListContentsBuilder.TopLevelAssemblyType

NXOpen.Annotations.PartsListContentsBuilderTopLevelAssemblyType is an alias for NXOpen.Annotations.PartsListContentsBuilder.TopLevelAssemblyType 

Copyright 2025 Siemens
