# NXOpen.Annotations.IntersectionSymbolBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00173.html>

## Classes

class — Thickness

the types of intersection symbol thickness 

Enumerator — Comment

Thin — Thin

Normal — Normal

Thick — Thick

One — Width One

Two — Width Two

Three — Width Three

Four — Width Four

Five — Width Five

Six — Width Six

Seven — Width Seven

Eight — Width Eight

Nine — Width Nine

More...

Copyright 2025 Siemens
