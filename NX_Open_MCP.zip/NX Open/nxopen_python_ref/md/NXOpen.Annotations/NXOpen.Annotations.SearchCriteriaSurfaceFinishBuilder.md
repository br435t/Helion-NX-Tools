# NXOpen.Annotations.SearchCriteriaSurfaceFinishBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00211.html>

## Classes

class — SurfaceFinishTypes

Lists the search pmi surface finish type 

Enumerator — Comment

Open — open

OpenAndModifier — open and modifier

OpenAndModifierAndAllAround — opem and modifier and all around

Required — required

RequiredAndModifier — required and modifier

RequiredAndModifierAndAllAround — required and modifier and all around

Prohibited — prohibited

ProhibitedAndModifier — prohibiter and modifier

ProhibitedAndModifierAndAllAround — prohibiter and modifier and all around

More...

class — ToleranceTypeOptions

Lists the Tolerance type of surface finish value 

Enumerator — Comment

NoTolerance — no tolerance

EqualBilateral — equal bilateral

Bilateral — bilateral

UnilateralPlus — unilateral +

UnilateralMinus — unilateral -

PlusLimit2Lines — + limit 2 lines

MinusLimit2Lines

More...

Copyright 2025 Siemens
