# NXOpen.Annotations.HoleTableBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12529.html>

Represents a NXOpen::Annotations::HoleTableBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.HoleTableBuilder:

## Public Member Functions

Baseline (self)

Getter for property: (NXOpen.Annotations.OrdinateBaselineBuilder) Baseline Returns the ordinate baseline. 

Inherit (self)

Getter for property: (NXOpen.SelectDisplayableObject) Inherit Returns the inherit hole table. 

OrdinateOrigin (self)

Getter for property: (NXOpen.SelectDisplayableObject) OrdinateOrigin Returns the Ordinate Origin of the hole table. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the hole table origin. 

ResetHoletableOrdinateOrigin (self)

Reset the Ordinate Origin of the hole table. 

ResetLabelPosition (self)

Reset all the hole label's position of hole table. 

SelectedObjects (self)

Getter for property: (NXOpen.SelectNXObjectList) SelectedObjects Returns the list of selected objects. 

Style (self)

Getter for property: (NXOpen.Annotations.TableStyleBuilder) Style Returns the hole table style. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::HoleTableBuilder . 

This class queries and sets settings specific to holes when creating or editing hole table. 

To create a new instance of this class, use NXOpen::Annotations::HoleTableCollection::CreateHoleTableBuilder 

Created in NX9.0.0 

## Member Function Documentation

## ◆ Baseline()

NXOpen.Annotations.HoleTableBuilder.Baseline
(
self — )

Getter for property: (NXOpen.Annotations.OrdinateBaselineBuilder) Baseline Returns the ordinate baseline. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
OrdinateBaselineBuilder 

## ◆ Inherit()

NXOpen.Annotations.HoleTableBuilder.Inherit
(
self — )

Getter for property: (NXOpen.SelectDisplayableObject) Inherit Returns the inherit hole table. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
NXOpen.SelectDisplayableObject 

## ◆ OrdinateOrigin()

NXOpen.Annotations.HoleTableBuilder.OrdinateOrigin
(
self — )

Getter for property: (NXOpen.SelectDisplayableObject) OrdinateOrigin Returns the Ordinate Origin of the hole table. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
NXOpen.SelectDisplayableObject 

## ◆ Origin()

NXOpen.Annotations.HoleTableBuilder.Origin
(
self — )

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the hole table origin. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
OriginBuilder 

## ◆ ResetHoletableOrdinateOrigin()

NXOpen.Annotations.HoleTableBuilder.ResetHoletableOrdinateOrigin
(
self — )

Reset the Ordinate Origin of the hole table. 

Created in NX9.0.0 

License requirements: None. 

## ◆ ResetLabelPosition()

NXOpen.Annotations.HoleTableBuilder.ResetLabelPosition
(
self — )

Reset all the hole label's position of hole table. 

Created in NX9.0.0 

License requirements: None. 

## ◆ SelectedObjects()

NXOpen.Annotations.HoleTableBuilder.SelectedObjects
(
self — )

Getter for property: (NXOpen.SelectNXObjectList) SelectedObjects Returns the list of selected objects. 

These object can be of type view, solid_body and/or holes

Getter License requirements: None.

Created in NX9.0.0 

Returns
NXOpen.SelectNXObjectList 

## ◆ Style()

NXOpen.Annotations.HoleTableBuilder.Style
(
self — )

Getter for property: (NXOpen.Annotations.TableStyleBuilder) Style Returns the hole table style. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
TableStyleBuilder 

Copyright 2025 Siemens
