# NXOpen.Annotations.OriginBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00184.html>

## Classes

class — AlignmentPosition

alignment position on the annotation 

Enumerator — Comment

TopLeft — Top left position

TopCenter — Top center position

TopRight — Top right position

MidLeft — Mid left position

MidCenter — Mid center position

MidRight — Mid right position

BottomLeft — Bottom left position

BottomCenter — Bottom center position

BottomRight — Bottom right position

More...

Copyright 2025 Siemens
