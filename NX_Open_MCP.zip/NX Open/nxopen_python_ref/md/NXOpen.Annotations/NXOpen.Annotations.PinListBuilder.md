# NXOpen.Annotations.PinListBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00187.html>

## Classes

class — FilterType

The options specify the filter type. More...

Copyright 2025 Siemens
