# NXOpen.Annotations.LineWeld Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00176.html>

## Classes

class — AutoWeldType

the Auto Weld Type enum 

Enumerator — Comment

OtherSideGrooveCountersinkAngle

ArrowSideGrooveCountersinkAngle

OtherSideNumberRootDepth

ArrowSideNumberRootDepth

OtherSideWeldSize

ArrowSideWeldSize

OtherSideCompoundWeldSize

ArrowSideCompoundWeldSize

OtherSideLengthPitch

ArrowSideLengthPitch

OtherSideWeldSizeCode

ArrowSideWeldSizeCode

OtherSideCompoundWeldSizeCode

ArrowSideCompoundWeldSizeCode

FieldWeldType

More...

Copyright 2025 Siemens
