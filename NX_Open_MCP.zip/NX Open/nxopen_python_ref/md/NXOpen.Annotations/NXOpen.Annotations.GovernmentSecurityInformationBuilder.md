# NXOpen.Annotations.GovernmentSecurityInformationBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12465.html>

Represents a NXOpen::Annotations::GovernmentSecurityInformation builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateGovernmentSecurityInformationBuilder 

More...

Inheritance diagram for NXOpen.Annotations.GovernmentSecurityInformationBuilder:

## Public Member Functions

GetStringText (self)

Returns the str text. 

Identifier (self)

Getter for property: (str) Identifier Returns the identifier. 

Identifier (self, identifier)

Setter for property: (str) Identifier. 

SetStringText (self, stringText)

Sets the str text. 

Title (self)

Getter for property: (str) Title Returns the str title. 

Title (self, title)

Setter for property: (str) Title. 

Public Member Functions inherited from NXOpen.Annotations.PmiAttributeBuilder

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the NXOpen::Annotations::AssociatedObjectsBuilder for the annotation. 

Attribute (self)

Getter for property: (NXOpen.Annotations.Pmi) Attribute Returns the NXOpen::Annotations::Pmi for this annotation. 

Attribute (self, attribute)

Setter for property: (NXOpen.Annotations.Pmi) Attribute. 

BusinessModifier (self)

Getter for property: (NXOpen.NXObject) BusinessModifier Returns the business modifier. 

BusinessModifier (self, businessModifier)

Setter for property: (NXOpen.NXObject) BusinessModifier. 

GetAttributeValues (self)

Returns the attribute values. 

KnowledgeFusionClassName (self)

Getter for property: (str) KnowledgeFusionClassName Returns the knowledge fusion class name file, the default class is UG provided pmi KF class. 

KnowledgeFusionClassName (self, knowledgeFusionClassName)

Setter for property: (str) KnowledgeFusionClassName. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the NXOpen::Annotations::OriginBuilder for the annotation. 

SetAttributeValues (self, attributeValues)

Sets the attribute values. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the NXOpen::Annotations::StyleBuilder for the annotation. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::GovernmentSecurityInformation builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateGovernmentSecurityInformationBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ GetStringText()

NXOpen.Annotations.GovernmentSecurityInformationBuilder.GetStringText
(
self — )

Returns the str text. 

Returns
stringText (List[str]): .

Created in NX6.0.0 

License requirements: None. 

## ◆ Identifier() [1/2]

NXOpen.Annotations.GovernmentSecurityInformationBuilder.Identifier
(
self — )

Getter for property: (str) Identifier Returns the identifier. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Identifier() [2/2]

NXOpen.Annotations.GovernmentSecurityInformationBuilder.Identifier
(
self,

identifier )

Setter for property: (str) Identifier. 

Sets the identifier

Setter License requirements: None.

Created in NX6.0.0 

## ◆ SetStringText()

NXOpen.Annotations.GovernmentSecurityInformationBuilder.SetStringText
(
self,

stringText )

Sets the str text. 

Created in NX6.0.0 

License requirements: None.

Parameters

stringText — (List[str])

## ◆ Title() [1/2]

NXOpen.Annotations.GovernmentSecurityInformationBuilder.Title
(
self — )

Getter for property: (str) Title Returns the str title. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Title() [2/2]

NXOpen.Annotations.GovernmentSecurityInformationBuilder.Title
(
self,

title )

Setter for property: (str) Title. 

Sets the str title

Setter License requirements: None.

Created in NX6.0.0 

Copyright 2025 Siemens
