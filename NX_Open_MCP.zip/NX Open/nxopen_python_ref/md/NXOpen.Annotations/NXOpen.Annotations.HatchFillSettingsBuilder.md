# NXOpen.Annotations.HatchFillSettingsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00164.html>

## Classes

class — AnnotationTypes

the valid types of hatch objects 

Enumerator — Comment

Crosshatch — Crosshatch

AreaFill — Area Fill

More...

Copyright 2025 Siemens
