# NXOpen.Annotations.LeaderData Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12769.html>

Represents a NXOpen::Annotations::LeaderData . 
More...

Inheritance diagram for NXOpen.Annotations.LeaderData:

## Public Member Functions

Arrowhead (self)

Getter for property: (NXOpen.Annotations.LeaderData.ArrowheadType) Arrowhead Returns the arrowhead. 

Arrowhead (self, arrowhead)

Setter for property: (NXOpen.Annotations.LeaderData.ArrowheadType) Arrowhead. 

DatumOnDotTerminatedArrowhead (self)

Getter for property: (NXOpen.Annotations.LeaderData.ArrowheadType) DatumOnDotTerminatedArrowhead Returns the datum arrowhead type for the datum portion of a datum on dot terminated leader. 

DatumOnDotTerminatedArrowhead (self, arrowhead)

Setter for property: (NXOpen.Annotations.LeaderData.ArrowheadType) DatumOnDotTerminatedArrowhead. 

DatumOnDotTerminatedEndPoint (self)

Getter for property: (NXOpen.Point3d) DatumOnDotTerminatedEndPoint Returns the datum end point for the leader segment of the datum portion of a datum on dot terminated leadet. 

DatumOnDotTerminatedEndPoint (self, endpoint)

Setter for property: (NXOpen.Point3d) DatumOnDotTerminatedEndPoint. 

DatumOnDotTerminatedStartPoint (self)

Getter for property: (NXOpen.Point3d) DatumOnDotTerminatedStartPoint Returns the datum start point for the leader segment of the datum portion of a datum on dot terminated leader. 

DatumOnDotTerminatedStartPoint (self, startpoint)

Setter for property: (NXOpen.Point3d) DatumOnDotTerminatedStartPoint. 

GetStubEndPoint (self)

Returns the end point of the leader. 

GetStubStartPoint (self)

Returns the start point of the leader. 

HasStub (self)

Returns the stub status of the defined leader. 

Jogs (self)

Getter for property: (NXOpen.SelectDisplayableObjectList) Jogs Returns the jogs. 

Leader (self)

Getter for property: (NXOpen.SelectDisplayableObject) Leader Returns the leader. 

LeaderPerpendicular (self)

Getter for property: (bool) LeaderPerpendicular Returns the perpendicular relationship between the first segment and attachement object. 

LeaderPerpendicular (self, isLeaderPerpendicular)

Setter for property: (bool) LeaderPerpendicular. 

Perpendicular (self)

Getter for property: (bool) Perpendicular Returns the perpendicular relationship between the first segment and stub. 

Perpendicular (self, isPerpendicular)

Setter for property: (bool) Perpendicular. 

StubSide (self)

Getter for property: (NXOpen.Annotations.LeaderSide) StubSide Returns the stub side. 

StubSide (self, stub_side)

Setter for property: (NXOpen.Annotations.LeaderSide) StubSide. 

StubSize (self)

Getter for property: (float) StubSize Returns the stub size. 

StubSize (self, stubSize)

Setter for property: (float) StubSize. 

TerminatorType (self)

Getter for property: (NXOpen.Annotations.LeaderData.LeaderType) TerminatorType Returns the terminator type. 

TerminatorType (self, terminatorType)

Setter for property: (NXOpen.Annotations.LeaderData.LeaderType) TerminatorType. 

VerticalAttachment (self)

Getter for property: (NXOpen.Annotations.LeaderVerticalAttachment) VerticalAttachment Returns the vertical attachment. 

VerticalAttachment (self, vertical_attachment)

Setter for property: (NXOpen.Annotations.LeaderVerticalAttachment) VerticalAttachment. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

LeaderDataArrowheadType = LeaderData.ArrowheadType

NXOpen.Annotations.LeaderDataArrowheadType is an alias for NXOpen.Annotations.LeaderData.ArrowheadType 

LeaderDataLeaderType = LeaderData.LeaderType

NXOpen.Annotations.LeaderDataLeaderType is an alias for NXOpen.Annotations.LeaderData.LeaderType 

## Detailed Description

Represents a NXOpen::Annotations::LeaderData . 

This class is used to construct the definition for a single leader object. 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateLeaderData 

Created in NX6.0.0 

## Member Function Documentation

## ◆ Arrowhead() [1/2]

NXOpen.Annotations.LeaderData.Arrowhead
(
self — )

Getter for property: (NXOpen.Annotations.LeaderData.ArrowheadType) Arrowhead Returns the arrowhead. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LeaderData.ArrowheadType 

## ◆ Arrowhead() [2/2]

NXOpen.Annotations.LeaderData.Arrowhead
(
self,

arrowhead )

Setter for property: (NXOpen.Annotations.LeaderData.ArrowheadType) Arrowhead. 

Sets the arrowhead

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DatumOnDotTerminatedArrowhead() [1/2]

NXOpen.Annotations.LeaderData.DatumOnDotTerminatedArrowhead
(
self — )

Getter for property: (NXOpen.Annotations.LeaderData.ArrowheadType) DatumOnDotTerminatedArrowhead Returns the datum arrowhead type for the datum portion of a datum on dot terminated leader. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
LeaderData.ArrowheadType 

## ◆ DatumOnDotTerminatedArrowhead() [2/2]

NXOpen.Annotations.LeaderData.DatumOnDotTerminatedArrowhead
(
self,

arrowhead )

Setter for property: (NXOpen.Annotations.LeaderData.ArrowheadType) DatumOnDotTerminatedArrowhead. 

Sets the datum arrowhead type for the datum portion of a datum on dot terminated leader

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ DatumOnDotTerminatedEndPoint() [1/2]

NXOpen.Annotations.LeaderData.DatumOnDotTerminatedEndPoint
(
self — )

Getter for property: (NXOpen.Point3d) DatumOnDotTerminatedEndPoint Returns the datum end point for the leader segment of the datum portion of a datum on dot terminated leadet. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
NXOpen.Point3d 

## ◆ DatumOnDotTerminatedEndPoint() [2/2]

NXOpen.Annotations.LeaderData.DatumOnDotTerminatedEndPoint
(
self,

endpoint )

Setter for property: (NXOpen.Point3d) DatumOnDotTerminatedEndPoint. 

Sets the datum end point for the leader segment of the datum portion of a datum on dot terminated leadet

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ DatumOnDotTerminatedStartPoint() [1/2]

NXOpen.Annotations.LeaderData.DatumOnDotTerminatedStartPoint
(
self — )

Getter for property: (NXOpen.Point3d) DatumOnDotTerminatedStartPoint Returns the datum start point for the leader segment of the datum portion of a datum on dot terminated leader. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
NXOpen.Point3d 

## ◆ DatumOnDotTerminatedStartPoint() [2/2]

NXOpen.Annotations.LeaderData.DatumOnDotTerminatedStartPoint
(
self,

startpoint )

Setter for property: (NXOpen.Point3d) DatumOnDotTerminatedStartPoint. 

Sets the datum start point for the leader segment of the datum portion of a datum on dot terminated leader

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ GetStubEndPoint()

NXOpen.Annotations.LeaderData.GetStubEndPoint
(
self — )

Returns the end point of the leader. 

Returns
endPoint (NXOpen.Point3d): .

Created in NX11.0.0 

License requirements: None. 

## ◆ GetStubStartPoint()

NXOpen.Annotations.LeaderData.GetStubStartPoint
(
self — )

Returns the start point of the leader. 

Returns
startPoint (NXOpen.Point3d): .

Created in NX11.0.0 

License requirements: None. 

## ◆ HasStub()

NXOpen.Annotations.LeaderData.HasStub
(
self — )

Returns the stub status of the defined leader. 

Returns
hasStub (bool): .

Created in NX11.0.0 

License requirements: None. 

## ◆ Jogs()

NXOpen.Annotations.LeaderData.Jogs
(
self — )

Getter for property: (NXOpen.SelectDisplayableObjectList) Jogs Returns the jogs. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectDisplayableObjectList 

## ◆ Leader()

NXOpen.Annotations.LeaderData.Leader
(
self — )

Getter for property: (NXOpen.SelectDisplayableObject) Leader Returns the leader. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectDisplayableObject 

## ◆ LeaderPerpendicular() [1/2]

NXOpen.Annotations.LeaderData.LeaderPerpendicular
(
self — )

Getter for property: (bool) LeaderPerpendicular Returns the perpendicular relationship between the first segment and attachement object. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
bool 

## ◆ LeaderPerpendicular() [2/2]

NXOpen.Annotations.LeaderData.LeaderPerpendicular
(
self,

isLeaderPerpendicular )

Setter for property: (bool) LeaderPerpendicular. 

Sets the perpendicular relationship between the first segment and attachement object

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ Perpendicular() [1/2]

NXOpen.Annotations.LeaderData.Perpendicular
(
self — )

Getter for property: (bool) Perpendicular Returns the perpendicular relationship between the first segment and stub. 

Getter License requirements: None.

Created in NX7.0.0 

Returns
bool 

## ◆ Perpendicular() [2/2]

NXOpen.Annotations.LeaderData.Perpendicular
(
self,

isPerpendicular )

Setter for property: (bool) Perpendicular. 

Sets the perpendicular relationship between the first segment and stub

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX7.0.0 

## ◆ StubSide() [1/2]

NXOpen.Annotations.LeaderData.StubSide
(
self — )

Getter for property: (NXOpen.Annotations.LeaderSide) StubSide Returns the stub side. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LeaderSide 

## ◆ StubSide() [2/2]

NXOpen.Annotations.LeaderData.StubSide
(
self,

stub_side )

Setter for property: (NXOpen.Annotations.LeaderSide) StubSide. 

Sets the stub side

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ StubSize() [1/2]

NXOpen.Annotations.LeaderData.StubSize
(
self — )

Getter for property: (float) StubSize Returns the stub size. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ StubSize() [2/2]

NXOpen.Annotations.LeaderData.StubSize
(
self,

stubSize )

Setter for property: (float) StubSize. 

Sets the stub size

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ TerminatorType() [1/2]

NXOpen.Annotations.LeaderData.TerminatorType
(
self — )

Getter for property: (NXOpen.Annotations.LeaderData.LeaderType) TerminatorType Returns the terminator type. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LeaderData.LeaderType 

## ◆ TerminatorType() [2/2]

NXOpen.Annotations.LeaderData.TerminatorType
(
self,

terminatorType )

Setter for property: (NXOpen.Annotations.LeaderData.LeaderType) TerminatorType. 

Sets the terminator type

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ VerticalAttachment() [1/2]

NXOpen.Annotations.LeaderData.VerticalAttachment
(
self — )

Getter for property: (NXOpen.Annotations.LeaderVerticalAttachment) VerticalAttachment Returns the vertical attachment. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
LeaderVerticalAttachment 

## ◆ VerticalAttachment() [2/2]

NXOpen.Annotations.LeaderData.VerticalAttachment
(
self,

vertical_attachment )

Setter for property: (NXOpen.Annotations.LeaderVerticalAttachment) VerticalAttachment. 

Sets the vertical attachment

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX10.0.0 

## Member Data Documentation

## ◆ LeaderDataArrowheadType

NXOpen.Annotations.LeaderData.LeaderDataArrowheadType = LeaderData.ArrowheadType

NXOpen.Annotations.LeaderDataArrowheadType is an alias for NXOpen.Annotations.LeaderData.ArrowheadType 

## ◆ LeaderDataLeaderType

NXOpen.Annotations.LeaderData.LeaderDataLeaderType = LeaderData.LeaderType

NXOpen.Annotations.LeaderDataLeaderType is an alias for NXOpen.Annotations.LeaderData.LeaderType 

Copyright 2025 Siemens
