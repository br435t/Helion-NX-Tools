# NXOpen.Annotations.FeatureControlFrameBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00158.html>

## Classes

class — FcfCharacteristic

Specifies the characteristitic of the feature control frame 

Enumerator — Comment

Straightness — straightness

Flatness — flatness

Circularity — circularity

Cylindricity — cylindricity

ProfileOfALine — profile of a line

ProfileOfASurface — profile of a sufrace

Angularity — angularity

Perpendicularity — perpendicularity

Parallelism — parallelism

Position — position

Concentricity — concentricity

Symmetry — symmetry

CircularRunout — circular runout

TotalRunout — total runout

AxisIntersection — axis intersection

More...

class — FcfFrameStyle

Specifies whether the feature control frame is a single frame or composite 

Enumerator — Comment

SingleFrame — single frame

CompositeFrame — composite frame

More...

Copyright 2025 Siemens
