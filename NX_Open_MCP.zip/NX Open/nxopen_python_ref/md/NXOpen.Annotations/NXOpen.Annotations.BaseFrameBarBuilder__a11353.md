# NXOpen.Annotations.BaseFrameBarBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11353.html>

Represents a NXOpen::Annotations::BaseFrameBarBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.BaseFrameBarBuilder:

## Public Member Functions

AftPerpendicular (self)

Getter for property: (bool) AftPerpendicular Returns the aft perpendicular. 

AftPerpendicular (self, aftPerpendicular)

Setter for property: (bool) AftPerpendicular. 

Axis (self)

Getter for property: (NXOpen.Annotations.BaseFrameBarBuilder.AxisType) Axis Returns the axis. 

Axis (self, axis)

Setter for property: (NXOpen.Annotations.BaseFrameBarBuilder.AxisType) Axis. 

Baseline (self)

Getter for property: (bool) Baseline Returns the baseline. 

Baseline (self, baseline)

Setter for property: (bool) Baseline. 

BulkHeads (self)

Getter for property: (bool) BulkHeads Returns the bulk heads. 

BulkHeads (self, bulkHeads)

Setter for property: (bool) BulkHeads. 

Centerline (self)

Getter for property: (bool) Centerline Returns the centerline. 

Centerline (self, centerline)

Setter for property: (bool) Centerline. 

CreateFrameBarObject (self)

Creates frame bar object. 

Decks (self)

Getter for property: (bool) Decks Returns the decks. 

Decks (self, decks)

Setter for property: (bool) Decks. 

DeleteFrameBarObject (self)

This function is used to delete frame bar. 

ForwardPerpendicular (self)

Getter for property: (bool) ForwardPerpendicular Returns the forward perpendicular. 

ForwardPerpendicular (self, forwardPerpendicular)

Setter for property: (bool) ForwardPerpendicular. 

GetFramebar (self)

The frame bar. 

HorizontalDistance (self)

Getter for property: (float) HorizontalDistance Returns the horizontal distance. 

HorizontalDistance (self, horizontalDistance)

Setter for property: (float) HorizontalDistance. 

HorizontalPosition (self)

Getter for property: (NXOpen.Annotations.BaseFrameBarBuilder.HorizontalPositionType) HorizontalPosition Returns the horizontal position. 

HorizontalPosition (self, horizontalPosition)

Setter for property: (NXOpen.Annotations.BaseFrameBarBuilder.HorizontalPositionType) HorizontalPosition. 

InterTransverseFrames (self)

Getter for property: (bool) InterTransverseFrames Returns the inter transverse frames. 

InterTransverseFrames (self, interTransverseFrames)

Setter for property: (bool) InterTransverseFrames. 

LongitudinalBulkheads (self)

Getter for property: (bool) LongitudinalBulkheads Returns the longitudinal bulkheads. 

LongitudinalBulkheads (self, longitudinalBulkheads)

Setter for property: (bool) LongitudinalBulkheads. 

LongitudinalYFrames (self)

Getter for property: (bool) LongitudinalYFrames Returns the longitudinal yframes. 

LongitudinalYFrames (self, longitudinalYFrames)

Setter for property: (bool) LongitudinalYFrames. 

LongitudinalYInsertFrames (self)

Getter for property: (bool) LongitudinalYInsertFrames Returns the longitudinal Y insert frames. 

LongitudinalYInsertFrames (self, longitudinalYInsertFrames)

Setter for property: (bool) LongitudinalYInsertFrames. 

LongitudinalZFrames (self)

Getter for property: (bool) LongitudinalZFrames Returns the longitudinal zframes. 

LongitudinalZFrames (self, longitudinalZFrames)

Setter for property: (bool) LongitudinalZFrames. 

LongitudinalZInsertFrames (self)

Getter for property: (bool) LongitudinalZInsertFrames Returns the longitudinal Z insert frames. 

LongitudinalZInsertFrames (self, longitudinalZInsertFrames)

Setter for property: (bool) LongitudinalZInsertFrames. 

MainLine (self)

Getter for property: (bool) MainLine Returns the create main line. 

MainLine (self, mainLine)

Setter for property: (bool) MainLine. 

MainLineColor (self)

Getter for property: (NXOpen.NXColor) MainLineColor Returnsthe color of the framebar main line. 

MainLineColor (self, color)

Setter for property: (NXOpen.NXColor) MainLineColor. 

MainLineFont (self)

Getter for property: (NXOpen.DisplayableObject.ObjectFont) MainLineFont Returns the font of the framebar main line. 

MainLineFont (self, font)

Setter for property: (NXOpen.DisplayableObject.ObjectFont) MainLineFont. 

MainLineWidth (self)

Getter for property: (NXOpen.Annotations.LineWidth) MainLineWidth Returnsthe width of the framebar main line. 

MainLineWidth (self, width)

Setter for property: (NXOpen.Annotations.LineWidth) MainLineWidth. 

Midship (self)

Getter for property: (bool) Midship Returns the mid ship. 

Midship (self, midship)

Setter for property: (bool) Midship. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

OriginType (self)

Getter for property: (NXOpen.Annotations.BaseFrameBarBuilder.OriginOption) OriginType Returns the origin type. 

OriginType (self, originType)

Setter for property: (NXOpen.Annotations.BaseFrameBarBuilder.OriginOption) OriginType. 

ReverseAlongHullSide (self)

This function is used to reverse along hull side. 

ReverseTics (self)

This function is used to reverse tics on the framebar. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

TransveralInsertArea (self)

Getter for property: (bool) TransveralInsertArea Returns the transveral insert area. 

TransveralInsertArea (self, transveralInsertArea)

Setter for property: (bool) TransveralInsertArea. 

TransverseFrames (self)

Getter for property: (bool) TransverseFrames Returns the transverse frames. 

TransverseFrames (self, transverseFrames)

Setter for property: (bool) TransverseFrames. 

UpdateFrameBarFromStyle (self)

Updates frame bar object as per style. 

UpdateFromConceptModel (self)

This function is used to update framebar from Concept model. 

VerticalDistance (self)

Getter for property: (float) VerticalDistance Returns the vertical distance. 

VerticalDistance (self, verticalDistance)

Setter for property: (float) VerticalDistance. 

VerticalPosition (self)

Getter for property: (NXOpen.Annotations.BaseFrameBarBuilder.VerticalPositionType) VerticalPosition Returns the vertical position. 

VerticalPosition (self, verticalPosition)

Setter for property: (NXOpen.Annotations.BaseFrameBarBuilder.VerticalPositionType) VerticalPosition. 

View (self)

Getter for property: (NXOpen.Drawings.SelectDraftingView) View Returns the select view. 

Waterline (self)

Getter for property: (bool) Waterline Returns the waterline. 

Waterline (self, waterline)

Setter for property: (bool) Waterline. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

BaseFrameBarBuilderAxisType = BaseFrameBarBuilder.AxisType

NXOpen.Annotations.BaseFrameBarBuilderAxisType is an alias for NXOpen.Annotations.BaseFrameBarBuilder.AxisType 

BaseFrameBarBuilderHorizontalPositionType = BaseFrameBarBuilder.HorizontalPositionType

NXOpen.Annotations.BaseFrameBarBuilderHorizontalPositionType is an alias for NXOpen.Annotations.BaseFrameBarBuilder.HorizontalPositionType 

BaseFrameBarBuilderOriginOption = BaseFrameBarBuilder.OriginOption

NXOpen.Annotations.BaseFrameBarBuilderOriginOption is an alias for NXOpen.Annotations.BaseFrameBarBuilder.OriginOption 

BaseFrameBarBuilderVerticalPositionType = BaseFrameBarBuilder.VerticalPositionType

NXOpen.Annotations.BaseFrameBarBuilderVerticalPositionType is an alias for NXOpen.Annotations.BaseFrameBarBuilder.VerticalPositionType 

## Detailed Description

Represents a NXOpen::Annotations::BaseFrameBarBuilder . 

This class allows to create frame bar annotation 

This is an abstract class, and cannot be instantiated. 

Created in NX8.0.0 

## Member Function Documentation

## ◆ AftPerpendicular() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.AftPerpendicular
(
self — )

Getter for property: (bool) AftPerpendicular Returns the aft perpendicular. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
bool 

## ◆ AftPerpendicular() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.AftPerpendicular
(
self,

aftPerpendicular )

Setter for property: (bool) AftPerpendicular. 

Sets the aft perpendicular

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX8.0.0 

## ◆ Axis() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.Axis
(
self — )

Getter for property: (NXOpen.Annotations.BaseFrameBarBuilder.AxisType) Axis Returns the axis. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
BaseFrameBarBuilder.AxisType 

## ◆ Axis() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.Axis
(
self,

axis )

Setter for property: (NXOpen.Annotations.BaseFrameBarBuilder.AxisType) Axis. 

Sets the axis

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX8.0.0 

## ◆ Baseline() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.Baseline
(
self — )

Getter for property: (bool) Baseline Returns the baseline. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
bool 

## ◆ Baseline() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.Baseline
(
self,

baseline )

Setter for property: (bool) Baseline. 

Sets the baseline

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX8.0.0 

## ◆ BulkHeads() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.BulkHeads
(
self — )

Getter for property: (bool) BulkHeads Returns the bulk heads. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
bool 

## ◆ BulkHeads() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.BulkHeads
(
self,

bulkHeads )

Setter for property: (bool) BulkHeads. 

Sets the bulk heads

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX8.0.0 

## ◆ Centerline() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.Centerline
(
self — )

Getter for property: (bool) Centerline Returns the centerline. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
bool 

## ◆ Centerline() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.Centerline
(
self,

centerline )

Setter for property: (bool) Centerline. 

Sets the centerline

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX8.0.0 

## ◆ CreateFrameBarObject()

NXOpen.Annotations.BaseFrameBarBuilder.CreateFrameBarObject
(
self — )

Creates frame bar object. 

Created in NX8.0.0 

License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") 

## ◆ Decks() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.Decks
(
self — )

Getter for property: (bool) Decks Returns the decks. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
bool 

## ◆ Decks() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.Decks
(
self,

decks )

Setter for property: (bool) Decks. 

Sets the decks

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX8.0.0 

## ◆ DeleteFrameBarObject()

NXOpen.Annotations.BaseFrameBarBuilder.DeleteFrameBarObject
(
self — )

This function is used to delete frame bar. 

Created in NX1899.0.0 

License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") 

## ◆ ForwardPerpendicular() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.ForwardPerpendicular
(
self — )

Getter for property: (bool) ForwardPerpendicular Returns the forward perpendicular. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
bool 

## ◆ ForwardPerpendicular() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.ForwardPerpendicular
(
self,

forwardPerpendicular )

Setter for property: (bool) ForwardPerpendicular. 

Sets the forward perpendicular

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX8.0.0 

## ◆ GetFramebar()

NXOpen.Annotations.BaseFrameBarBuilder.GetFramebar
(
self — )

The frame bar. 

Returns
frameBar (NXOpen.Annotations.BaseFrameBar): The frame bar .

Created in NX8.0.0 

License requirements: None. 

## ◆ HorizontalDistance() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.HorizontalDistance
(
self — )

Getter for property: (float) HorizontalDistance Returns the horizontal distance. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
float 

## ◆ HorizontalDistance() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.HorizontalDistance
(
self,

horizontalDistance )

Setter for property: (float) HorizontalDistance. 

Sets the horizontal distance

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX1980.0.0 

## ◆ HorizontalPosition() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.HorizontalPosition
(
self — )

Getter for property: (NXOpen.Annotations.BaseFrameBarBuilder.HorizontalPositionType) HorizontalPosition Returns the horizontal position. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
BaseFrameBarBuilder.HorizontalPositionType 

## ◆ HorizontalPosition() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.HorizontalPosition
(
self,

horizontalPosition )

Setter for property: (NXOpen.Annotations.BaseFrameBarBuilder.HorizontalPositionType) HorizontalPosition. 

Sets the horizontal position

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX1980.0.0 

## ◆ InterTransverseFrames() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.InterTransverseFrames
(
self — )

Getter for property: (bool) InterTransverseFrames Returns the inter transverse frames. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
bool 

## ◆ InterTransverseFrames() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.InterTransverseFrames
(
self,

interTransverseFrames )

Setter for property: (bool) InterTransverseFrames. 

Sets the inter transverse frames

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX8.0.0 

## ◆ LongitudinalBulkheads() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.LongitudinalBulkheads
(
self — )

Getter for property: (bool) LongitudinalBulkheads Returns the longitudinal bulkheads. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
bool 

## ◆ LongitudinalBulkheads() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.LongitudinalBulkheads
(
self,

longitudinalBulkheads )

Setter for property: (bool) LongitudinalBulkheads. 

Sets the longitudinal bulkheads

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX2007.0.0 

## ◆ LongitudinalYFrames() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.LongitudinalYFrames
(
self — )

Getter for property: (bool) LongitudinalYFrames Returns the longitudinal yframes. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
bool 

## ◆ LongitudinalYFrames() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.LongitudinalYFrames
(
self,

longitudinalYFrames )

Setter for property: (bool) LongitudinalYFrames. 

Sets the longitudinal yframes

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX8.0.0 

## ◆ LongitudinalYInsertFrames() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.LongitudinalYInsertFrames
(
self — )

Getter for property: (bool) LongitudinalYInsertFrames Returns the longitudinal Y insert frames. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
bool 

## ◆ LongitudinalYInsertFrames() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.LongitudinalYInsertFrames
(
self,

longitudinalYInsertFrames )

Setter for property: (bool) LongitudinalYInsertFrames. 

Sets the longitudinal Y insert frames

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX2007.0.0 

## ◆ LongitudinalZFrames() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.LongitudinalZFrames
(
self — )

Getter for property: (bool) LongitudinalZFrames Returns the longitudinal zframes. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
bool 

## ◆ LongitudinalZFrames() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.LongitudinalZFrames
(
self,

longitudinalZFrames )

Setter for property: (bool) LongitudinalZFrames. 

Sets the longitudinal zframes

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX8.0.0 

## ◆ LongitudinalZInsertFrames() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.LongitudinalZInsertFrames
(
self — )

Getter for property: (bool) LongitudinalZInsertFrames Returns the longitudinal Z insert frames. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
bool 

## ◆ LongitudinalZInsertFrames() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.LongitudinalZInsertFrames
(
self,

longitudinalZInsertFrames )

Setter for property: (bool) LongitudinalZInsertFrames. 

Sets the longitudinal Z insert frames

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX2007.0.0 

## ◆ MainLine() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.MainLine
(
self — )

Getter for property: (bool) MainLine Returns the create main line. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
bool 

## ◆ MainLine() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.MainLine
(
self,

mainLine )

Setter for property: (bool) MainLine. 

Sets the create main line

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX2007.0.0 

## ◆ MainLineColor() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.MainLineColor
(
self — )

Getter for property: (NXOpen.NXColor) MainLineColor Returnsthe color of the framebar main line. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
NXOpen.NXColor 

## ◆ MainLineColor() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.MainLineColor
(
self,

color )

Setter for property: (NXOpen.NXColor) MainLineColor. 

Setsthe color of the framebar main line

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX2007.0.0 

## ◆ MainLineFont() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.MainLineFont
(
self — )

Getter for property: (NXOpen.DisplayableObject.ObjectFont) MainLineFont Returns the font of the framebar main line. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
NXOpen.DisplayableObject.ObjectFont 

## ◆ MainLineFont() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.MainLineFont
(
self,

font )

Setter for property: (NXOpen.DisplayableObject.ObjectFont) MainLineFont. 

Sets the font of the framebar main line

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX2007.0.0 

## ◆ MainLineWidth() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.MainLineWidth
(
self — )

Getter for property: (NXOpen.Annotations.LineWidth) MainLineWidth Returnsthe width of the framebar main line. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
LineWidth 

## ◆ MainLineWidth() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.MainLineWidth
(
self,

width )

Setter for property: (NXOpen.Annotations.LineWidth) MainLineWidth. 

Setsthe width of the framebar main line

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX2007.0.0 

## ◆ Midship() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.Midship
(
self — )

Getter for property: (bool) Midship Returns the mid ship. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ Midship() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.Midship
(
self,

midship )

Setter for property: (bool) Midship. 

Sets the mid ship

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX2206.0.0 

## ◆ Origin()

NXOpen.Annotations.BaseFrameBarBuilder.Origin
(
self — )

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
OriginBuilder 

## ◆ OriginType() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.OriginType
(
self — )

Getter for property: (NXOpen.Annotations.BaseFrameBarBuilder.OriginOption) OriginType Returns the origin type. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
BaseFrameBarBuilder.OriginOption 

## ◆ OriginType() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.OriginType
(
self,

originType )

Setter for property: (NXOpen.Annotations.BaseFrameBarBuilder.OriginOption) OriginType. 

Sets the origin type

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX1980.0.0 

## ◆ ReverseAlongHullSide()

NXOpen.Annotations.BaseFrameBarBuilder.ReverseAlongHullSide
(
self — )

This function is used to reverse along hull side. 

Created in NX1899.0.0 

License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") 

## ◆ ReverseTics()

NXOpen.Annotations.BaseFrameBarBuilder.ReverseTics
(
self — )

This function is used to reverse tics on the framebar. 

Created in NX8.0.0 

License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") 

## ◆ Style()

NXOpen.Annotations.BaseFrameBarBuilder.Style
(
self — )

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
StyleBuilder 

## ◆ TransveralInsertArea() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.TransveralInsertArea
(
self — )

Getter for property: (bool) TransveralInsertArea Returns the transveral insert area. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
bool 

## ◆ TransveralInsertArea() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.TransveralInsertArea
(
self,

transveralInsertArea )

Setter for property: (bool) TransveralInsertArea. 

Sets the transveral insert area

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX8.0.0 

## ◆ TransverseFrames() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.TransverseFrames
(
self — )

Getter for property: (bool) TransverseFrames Returns the transverse frames. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
bool 

## ◆ TransverseFrames() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.TransverseFrames
(
self,

transverseFrames )

Setter for property: (bool) TransverseFrames. 

Sets the transverse frames

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX8.0.0 

## ◆ UpdateFrameBarFromStyle()

NXOpen.Annotations.BaseFrameBarBuilder.UpdateFrameBarFromStyle
(
self — )

Updates frame bar object as per style. 

Created in NX8.0.0 

License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") 

## ◆ UpdateFromConceptModel()

NXOpen.Annotations.BaseFrameBarBuilder.UpdateFromConceptModel
(
self — )

This function is used to update framebar from Concept model. 

Created in NX8.0.0 

License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") 

## ◆ VerticalDistance() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.VerticalDistance
(
self — )

Getter for property: (float) VerticalDistance Returns the vertical distance. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
float 

## ◆ VerticalDistance() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.VerticalDistance
(
self,

verticalDistance )

Setter for property: (float) VerticalDistance. 

Sets the vertical distance

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX1980.0.0 

## ◆ VerticalPosition() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.VerticalPosition
(
self — )

Getter for property: (NXOpen.Annotations.BaseFrameBarBuilder.VerticalPositionType) VerticalPosition Returns the vertical position. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
BaseFrameBarBuilder.VerticalPositionType 

## ◆ VerticalPosition() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.VerticalPosition
(
self,

verticalPosition )

Setter for property: (NXOpen.Annotations.BaseFrameBarBuilder.VerticalPositionType) VerticalPosition. 

Sets the vertical position

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX1980.0.0 

## ◆ View()

NXOpen.Annotations.BaseFrameBarBuilder.View
(
self — )

Getter for property: (NXOpen.Drawings.SelectDraftingView) View Returns the select view. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
NXOpen.Drawings.SelectDraftingView 

## ◆ Waterline() [1/2]

NXOpen.Annotations.BaseFrameBarBuilder.Waterline
(
self — )

Getter for property: (bool) Waterline Returns the waterline. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
bool 

## ◆ Waterline() [2/2]

NXOpen.Annotations.BaseFrameBarBuilder.Waterline
(
self,

waterline )

Setter for property: (bool) Waterline. 

Sets the waterline

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Created in NX8.0.0 

## Member Data Documentation

## ◆ BaseFrameBarBuilderAxisType

NXOpen.Annotations.BaseFrameBarBuilder.BaseFrameBarBuilderAxisType = BaseFrameBarBuilder.AxisType

NXOpen.Annotations.BaseFrameBarBuilderAxisType is an alias for NXOpen.Annotations.BaseFrameBarBuilder.AxisType 

## ◆ BaseFrameBarBuilderHorizontalPositionType

NXOpen.Annotations.BaseFrameBarBuilder.BaseFrameBarBuilderHorizontalPositionType = BaseFrameBarBuilder.HorizontalPositionType

NXOpen.Annotations.BaseFrameBarBuilderHorizontalPositionType is an alias for NXOpen.Annotations.BaseFrameBarBuilder.HorizontalPositionType 

## ◆ BaseFrameBarBuilderOriginOption

NXOpen.Annotations.BaseFrameBarBuilder.BaseFrameBarBuilderOriginOption = BaseFrameBarBuilder.OriginOption

NXOpen.Annotations.BaseFrameBarBuilderOriginOption is an alias for NXOpen.Annotations.BaseFrameBarBuilder.OriginOption 

## ◆ BaseFrameBarBuilderVerticalPositionType

NXOpen.Annotations.BaseFrameBarBuilder.BaseFrameBarBuilderVerticalPositionType = BaseFrameBarBuilder.VerticalPositionType

NXOpen.Annotations.BaseFrameBarBuilderVerticalPositionType is an alias for NXOpen.Annotations.BaseFrameBarBuilder.VerticalPositionType 

Copyright 2025 Siemens
