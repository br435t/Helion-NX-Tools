# NXOpen.Annotations.Annotation.AssociativeOriginData Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11101.html>

Describes the geometry that an annotation's origin is associated with NXOpen.Annotations.AnnotationAssociativeOriginData_Struct is an alias for NXOpen.Annotations.Annotation.AssociativeOriginData. 
More...

## Public Member Functions

AlignedAnnotation (self)

Getter for property :(NXOpen.AECDesign.NXOpen.Annotations.Annotation) AlignedAnnotation Alignment annotation. 

AlignedAnnotation (self, NXOpen.AECDesign.NXOpen.Annotations.Annotation value)

Setter for property :(NXOpen.AECDesign.NXOpen.Annotations.Annotation) AlignedAnnotation. 

AssociatedPoint (self)

Getter for property :(NXOpen.Features.NXOpen.Point) AssociatedPoint Origin location of annotation. 

AssociatedPoint (self, NXOpen.Features.NXOpen.Point value)

Setter for property :(NXOpen.Features.NXOpen.Point) AssociatedPoint. 

AssociatedView (self)

Getter for property :(NXOpen.View) AssociatedView The member view in which the absolute model point lies. 

AssociatedView (self, NXOpen.View value)

Setter for property :(NXOpen.View) AssociatedView. 

DimensionLine (self)

Getter for property :(int) DimensionLine 1 for dimension line 1, 2 for dimension line 2. 

DimensionLine (self, int value)

Setter for property :(int) DimensionLine. 

HorizAlignmentPosition (self)

Getter for property :(NXOpen.Annotations.AlignmentPosition) HorizAlignmentPosition Alignment position on horiz_annotation to align to. 

HorizAlignmentPosition (self, AlignmentPosition value)

Setter for property :(NXOpen.Annotations.AlignmentPosition) HorizAlignmentPosition. 

HorizAnnotation (self)

Getter for property :(NXOpen.AECDesign.NXOpen.Annotations.Annotation) HorizAnnotation Annotation to align with. 

HorizAnnotation (self, NXOpen.AECDesign.NXOpen.Annotations.Annotation value)

Setter for property :(NXOpen.AECDesign.NXOpen.Annotations.Annotation) HorizAnnotation. 

OffsetAlignmentPosition (self)

Getter for property :(NXOpen.Annotations.AlignmentPosition) OffsetAlignmentPosition Alignment position on annotation to align with. 

OffsetAlignmentPosition (self, AlignmentPosition value)

Setter for property :(NXOpen.Annotations.AlignmentPosition) OffsetAlignmentPosition. 

OffsetAnnotation (self)

Getter for property :(NXOpen.AECDesign.NXOpen.Annotations.Annotation) OffsetAnnotation Annotation to align to. 

OffsetAnnotation (self, NXOpen.AECDesign.NXOpen.Annotations.Annotation value)

Setter for property :(NXOpen.AECDesign.NXOpen.Annotations.Annotation) OffsetAnnotation. 

OriginType (self)

Getter for property :(NXOpen.Annotations.AssociativeOriginType) OriginType Type of associativity. 

OriginType (self, AssociativeOriginType value)

Setter for property :(NXOpen.Annotations.AssociativeOriginType) OriginType. 

PointOnGeometry (self)

Getter for property :(NXOpen.Features.NXOpen.Point) PointOnGeometry Absolute point in absolute space the annotation is associated with. 

PointOnGeometry (self, NXOpen.Features.NXOpen.Point value)

Setter for property :(NXOpen.Features.NXOpen.Point) PointOnGeometry. 

StackAlignmentPosition (self)

Getter for property :(NXOpen.Annotations.StackAlignmentPosition) StackAlignmentPosition. 

StackAlignmentPosition (self, StackAlignmentPosition value)

Setter for property :(NXOpen.Annotations.StackAlignmentPosition) StackAlignmentPosition. 

VertAlignmentPosition (self)

Getter for property :(NXOpen.Annotations.AlignmentPosition) VertAlignmentPosition Alignment position on vert_annotation to align to. 

VertAlignmentPosition (self, AlignmentPosition value)

Setter for property :(NXOpen.Annotations.AlignmentPosition) VertAlignmentPosition. 

VertAnnotation (self)

Getter for property :(NXOpen.AECDesign.NXOpen.Annotations.Annotation) VertAnnotation Annotation to align with. 

VertAnnotation (self, NXOpen.AECDesign.NXOpen.Annotations.Annotation value)

Setter for property :(NXOpen.AECDesign.NXOpen.Annotations.Annotation) VertAnnotation. 

View (self)

Getter for property :(NXOpen.View) View View of associativity for the annotation. 

View (self, NXOpen.View value)

Setter for property :(NXOpen.View) View. 

ViewOfGeometry (self)

Getter for property :(NXOpen.View) ViewOfGeometry The member view in which the absolute model point lies. 

ViewOfGeometry (self, NXOpen.View value)

Setter for property :(NXOpen.View) ViewOfGeometry. 

XOffsetFactor (self)

Getter for property :(float) XOffsetFactor X Offset factor from associated point. 

XOffsetFactor (self, float value)

Setter for property :(float) XOffsetFactor. 

YOffsetFactor (self)

Getter for property :(float) YOffsetFactor Y Offset factor from associated point. 

YOffsetFactor (self, float value)

Setter for property :(float) YOffsetFactor. 

## Detailed Description

Describes the geometry that an annotation's origin is associated with NXOpen.Annotations.AnnotationAssociativeOriginData_Struct is an alias for NXOpen.Annotations.Annotation.AssociativeOriginData. 

## Member Function Documentation

## ◆ AlignedAnnotation() [1/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.AlignedAnnotation
(
self — )

Getter for property :(NXOpen.AECDesign.NXOpen.Annotations.Annotation) AlignedAnnotation Alignment annotation. 

Returns
NXOpen.AECDesign.NXOpen.Annotations.Annotation 

## ◆ AlignedAnnotation() [2/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.AlignedAnnotation
(
self,

NXOpen.AECDesign.NXOpen.Annotations.Annotation — value )

Setter for property :(NXOpen.AECDesign.NXOpen.Annotations.Annotation) AlignedAnnotation. 

## ◆ AssociatedPoint() [1/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.AssociatedPoint
(
self — )

Getter for property :(NXOpen.Features.NXOpen.Point) AssociatedPoint Origin location of annotation. 

Returns
NXOpen.Features.NXOpen.Point 

## ◆ AssociatedPoint() [2/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.AssociatedPoint
(
self,

NXOpen.Features.NXOpen.Point — value )

Setter for property :(NXOpen.Features.NXOpen.Point) AssociatedPoint. 

## ◆ AssociatedView() [1/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.AssociatedView
(
self — )

Getter for property :(NXOpen.View) AssociatedView The member view in which the absolute model point lies. 

Returns
NXOpen.View 

## ◆ AssociatedView() [2/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.AssociatedView
(
self,

NXOpen.View — value )

Setter for property :(NXOpen.View) AssociatedView. 

## ◆ DimensionLine() [1/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.DimensionLine
(
self — )

Getter for property :(int) DimensionLine 1 for dimension line 1, 2 for dimension line 2. 

Returns
int 

## ◆ DimensionLine() [2/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.DimensionLine
(
self,

int — value )

Setter for property :(int) DimensionLine. 

## ◆ HorizAlignmentPosition() [1/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.HorizAlignmentPosition
(
self — )

Getter for property :(NXOpen.Annotations.AlignmentPosition) HorizAlignmentPosition Alignment position on horiz_annotation to align to. 

Returns
NXOpen.Annotations.AlignmentPosition 

## ◆ HorizAlignmentPosition() [2/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.HorizAlignmentPosition
(
self,

AlignmentPosition — value )

Setter for property :(NXOpen.Annotations.AlignmentPosition) HorizAlignmentPosition. 

## ◆ HorizAnnotation() [1/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.HorizAnnotation
(
self — )

Getter for property :(NXOpen.AECDesign.NXOpen.Annotations.Annotation) HorizAnnotation Annotation to align with. 

Returns
NXOpen.AECDesign.NXOpen.Annotations.Annotation 

## ◆ HorizAnnotation() [2/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.HorizAnnotation
(
self,

NXOpen.AECDesign.NXOpen.Annotations.Annotation — value )

Setter for property :(NXOpen.AECDesign.NXOpen.Annotations.Annotation) HorizAnnotation. 

## ◆ OffsetAlignmentPosition() [1/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.OffsetAlignmentPosition
(
self — )

Getter for property :(NXOpen.Annotations.AlignmentPosition) OffsetAlignmentPosition Alignment position on annotation to align with. 

Returns
NXOpen.Annotations.AlignmentPosition 

## ◆ OffsetAlignmentPosition() [2/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.OffsetAlignmentPosition
(
self,

AlignmentPosition — value )

Setter for property :(NXOpen.Annotations.AlignmentPosition) OffsetAlignmentPosition. 

## ◆ OffsetAnnotation() [1/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.OffsetAnnotation
(
self — )

Getter for property :(NXOpen.AECDesign.NXOpen.Annotations.Annotation) OffsetAnnotation Annotation to align to. 

Returns
NXOpen.AECDesign.NXOpen.Annotations.Annotation 

## ◆ OffsetAnnotation() [2/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.OffsetAnnotation
(
self,

NXOpen.AECDesign.NXOpen.Annotations.Annotation — value )

Setter for property :(NXOpen.AECDesign.NXOpen.Annotations.Annotation) OffsetAnnotation. 

## ◆ OriginType() [1/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.OriginType
(
self — )

Getter for property :(NXOpen.Annotations.AssociativeOriginType) OriginType Type of associativity. 

Returns
NXOpen.Annotations.AssociativeOriginType 

## ◆ OriginType() [2/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.OriginType
(
self,

AssociativeOriginType — value )

Setter for property :(NXOpen.Annotations.AssociativeOriginType) OriginType. 

## ◆ PointOnGeometry() [1/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.PointOnGeometry
(
self — )

Getter for property :(NXOpen.Features.NXOpen.Point) PointOnGeometry Absolute point in absolute space the annotation is associated with. 

Returns
NXOpen.Features.NXOpen.Point 

## ◆ PointOnGeometry() [2/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.PointOnGeometry
(
self,

NXOpen.Features.NXOpen.Point — value )

Setter for property :(NXOpen.Features.NXOpen.Point) PointOnGeometry. 

## ◆ StackAlignmentPosition() [1/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.StackAlignmentPosition
(
self — )

Getter for property :(NXOpen.Annotations.StackAlignmentPosition) StackAlignmentPosition. 

Returns
NXOpen.Annotations.StackAlignmentPosition 

## ◆ StackAlignmentPosition() [2/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.StackAlignmentPosition
(
self,

StackAlignmentPosition — value )

Setter for property :(NXOpen.Annotations.StackAlignmentPosition) StackAlignmentPosition. 

## ◆ VertAlignmentPosition() [1/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.VertAlignmentPosition
(
self — )

Getter for property :(NXOpen.Annotations.AlignmentPosition) VertAlignmentPosition Alignment position on vert_annotation to align to. 

Returns
NXOpen.Annotations.AlignmentPosition 

## ◆ VertAlignmentPosition() [2/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.VertAlignmentPosition
(
self,

AlignmentPosition — value )

Setter for property :(NXOpen.Annotations.AlignmentPosition) VertAlignmentPosition. 

## ◆ VertAnnotation() [1/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.VertAnnotation
(
self — )

Getter for property :(NXOpen.AECDesign.NXOpen.Annotations.Annotation) VertAnnotation Annotation to align with. 

Returns
NXOpen.AECDesign.NXOpen.Annotations.Annotation 

## ◆ VertAnnotation() [2/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.VertAnnotation
(
self,

NXOpen.AECDesign.NXOpen.Annotations.Annotation — value )

Setter for property :(NXOpen.AECDesign.NXOpen.Annotations.Annotation) VertAnnotation. 

## ◆ View() [1/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.View
(
self — )

Getter for property :(NXOpen.View) View View of associativity for the annotation. 

Returns
NXOpen.View 

## ◆ View() [2/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.View
(
self,

NXOpen.View — value )

Setter for property :(NXOpen.View) View. 

## ◆ ViewOfGeometry() [1/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.ViewOfGeometry
(
self — )

Getter for property :(NXOpen.View) ViewOfGeometry The member view in which the absolute model point lies. 

Returns
NXOpen.View 

## ◆ ViewOfGeometry() [2/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.ViewOfGeometry
(
self,

NXOpen.View — value )

Setter for property :(NXOpen.View) ViewOfGeometry. 

## ◆ XOffsetFactor() [1/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.XOffsetFactor
(
self — )

Getter for property :(float) XOffsetFactor X Offset factor from associated point. 

Returns
float 

## ◆ XOffsetFactor() [2/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.XOffsetFactor
(
self,

float — value )

Setter for property :(float) XOffsetFactor. 

## ◆ YOffsetFactor() [1/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.YOffsetFactor
(
self — )

Getter for property :(float) YOffsetFactor Y Offset factor from associated point. 

Returns
float 

## ◆ YOffsetFactor() [2/2]

NXOpen.Annotations.Annotation.AssociativeOriginData.YOffsetFactor
(
self,

float — value )

Setter for property :(float) YOffsetFactor. 

Copyright 2025 Siemens
