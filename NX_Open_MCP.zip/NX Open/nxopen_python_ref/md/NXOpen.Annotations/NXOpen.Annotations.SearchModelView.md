# NXOpen.Annotations.SearchModelView Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a14261.html>

Represents a search model view 

To create or edit an instance of this class, use NXOpen::Annotations::SearchModelViewBuilder 

More...

Inheritance diagram for NXOpen.Annotations.SearchModelView:

## Additional Inherited Members

Public Member Functions inherited from NXOpen.ModelingView

ActiveDynamicSection (self)

Getter for property: (NXOpen.Display.DynamicSection) ActiveDynamicSection Returns the active dynamic section object in the modeling view. 

ActiveDynamicSection (self, dynamicSection)

Setter for property: (NXOpen.Display.DynamicSection) ActiveDynamicSection. 

DisplaySectioningToggle (self)

Getter for property: (bool) DisplaySectioningToggle Returns the toggle between enabling or disabling the Dynamic Sectioning viewing. 

DisplaySectioningToggle (self, current_state)

Setter for property: (bool) DisplaySectioningToggle. 

ExpandCollapseNode (self, expand)

Expand or collapse the node for the specified Model View in the Part Navigator. 

HiqhQualityImage ()

Returns the High Quality Image instance belonging to a view. 

IsDynamicSectionVisible (self, dynamicSection)

Returns if the specified dynamic section object is visible in this view. 

IsMirrored (self)

Getter for property: (bool) IsMirrored Returns a flag indicating whether the model view is mirrored. 

SetDynamicSectionVisible (self, dynamicSection, visible)

Sets the specified dynamic section object is visible/invisible in this view. 

UseDefaultLights (self)

Changes the set of lights used in the given view to the "Default" set, which for now is the Scene Ambient, Scene Left Top and Scene Right Top lights. 

UseSceneLights (self)

Changes the set of lights used in the given view to the "Scene" set, which for now includes the eight predefined scene lights (including the Scene Ambient light). 

Public Member Functions inherited from NXOpen.View

AbsoluteOrigin (self)

Getter for property: (NXOpen.Point3d) AbsoluteOrigin Returns the view origin in absolute space. 

AskVisibleObjects (self)

Returns an array of objects visible in a view. 

ChangePerspective (self, changeViewToPerspective)

Changes a view from an orthographic view to a perspective view, or from a perspective view to an orthographic view. 

Concatenate (self, center_of_rotation, rotation_axis, angle)

Concatenates the given rotation with the previous viewing transformation of the specified view. 

Concatenate (self, scale)

Concatenates the given scale with the previous viewing transformation of the specified view. 

Concatenate (self, scale, center_of_rotation, rotation_axis, angle)

Concatenates the given scale and rotation with the previous viewing transformation of the specified view. 

Concatenate (self, translation)

Concatenates the given translation with the previous viewing transformation of the specified view. 

Concatenate (self, translation, center_of_rotation, rotation_axis, angle)

Concatenates the given translation and rotation with the previous viewing transformation of the specified view. 

Concatenate (self, translation, scale)

Concatenates the given translation and scale with the previous viewing transformation of the specified view. 

Concatenate (self, translation, scale, center_of_rotation, rotation_axis, angle)

Concatenates the given translation, scale and rotation with the previous viewing transformation of the specified view. 

DependentDisplay ()

Returns an object to perform all view dependent display operations. 

DisclosurePurpose (self)

Getter for property: (str) DisclosurePurpose Returns the Disclosure Purpose. 

DisclosurePurpose (self, disclosurePurpose)

Setter for property: (str) DisclosurePurpose. 

DisplayStyle (self)

Getter for property: (NXOpen.View.DisplayStyleType) DisplayStyle Returns the display style of the view. 

DisplayStyle (self, display_style)

Setter for property: (NXOpen.View.DisplayStyleType) DisplayStyle. 

DynamicHiddenEdges (self)

Getter for property: (NXOpen.View.HiddenEdgesType) DynamicHiddenEdges Returns the dynamic hidden edges property of the view. 

DynamicHiddenEdges (self, hidden_edges)

Setter for property: (NXOpen.View.HiddenEdgesType) DynamicHiddenEdges. 

EnableNavigationFlyThrough (self, isEnable)

Enables Fly-through by virtually placing you as a first-person observer in the view. 

Expand (self)

Expands the specified view to fill as much of the layout which contains the view as possible, without changing the aspect ratio of the view. 

Fit (self)

Adjusts the bounds of a given view so that it fully encompasses the extents of the model geometry. 

FitAfterShowOrHide (self, type)

Adjusts the bounds of a given view conditionally so that it fully encompasses the extents of the model geometry. 

FitToObjects (self, objects)

Adjusts the bounds of a given view so that it fully encompasses the extents of the given objects. 

FlyToObjects (self, objects)

Fly to the given objects. 

GetAxis (self, x_y_z_axis)

Returns one of the view axes. 

GetExpandedScale (self)

Returns the view scale, including any expansion factor. 

HasPreview (self)

Returns whether or not the given view has a preview. 

IsDisclosed (self)

Getter for property: (bool) IsDisclosed Returns the disclosure status of the view. 

IsNavigationFlyThroughEnabled (self)

Returns whether or not Fly-through is enabled. 

LockRotations (self)

Getter for property: (bool) LockRotations Returns the "Lock Rotations" toggle state of a view. 

LockRotations (self, curr_toggle_state)

Setter for property: (bool) LockRotations. 

MakeWork (self)

Makes the given view the work view. 

Matrix (self)

Getter for property: (NXOpen.Matrix3x3) Matrix Returns the view matrix. 

NavigationFlyThrough (self, startPoint, startEnd)

In Fly-through, fly from start point and ends at end point. 

NavigationFlyThroughWithScale (self, relativeScale)

In Fly-through, fly use relative scale. 

Orient (self, matrix)

Changes the view orientation relative to the specified absolute coordinate system. 

Orient (self, view_name, view_scale)

Changes the view orientation to a specified canned view. 

Orient (self, view_name, view_scale)

Changes the view orientation to a specified view. 

Origin (self)

Getter for property: (NXOpen.Point3d) Origin Returns the view origin. 

PanToObjects (self, objects)

Pans and centers the view to the given objects. 

Regenerate (self)

Regenerates the display of given view. 

RenderingStyle (self)

Getter for property: (NXOpen.View.RenderingStyleType) RenderingStyle Returns the rendering style of the view. 

RenderingStyle (self, rendering_style)

Setter for property: (NXOpen.View.RenderingStyleType) RenderingStyle. 

Restore (self)

Restores a view to its last remembered rotation, scale and translation. 

RestoreNavigationHomeView (self)

Restore and transitions from the current view to the home view. 

Rotate (self, matrix)

Rotates the view by concatenating the given matrix to the existing rotation matrix of the view. 

Rotate (self, origin, vector, angle)

Rotates the specified view using the specified origin of rotation and about the specified axis. 

SaveNavigationHomeView (self)

Save the current view as the home view. 

SaveViewWithViewName (self, replacementChar)

Increment the name of given view with replacement character. 

Scale (self)

Getter for property: (float) Scale Returns the view scale. 

SetOrigin (self, origin)

Moves the given position to the center of the view. 

SetRotationTranslationScale (self, rot_matrix, translation, scale)

Sets the rotation, translation and scale of the specified view. 

SetScale (self, scale)

Sets the scale of the specified view to the desired scale factor. 

ShadedDisplayType (self)

Getter for property: (NXOpen.View.ShadedDisplayModeType) ShadedDisplayType Returns. 

ShadedDisplayType (self, shaded_display_type)

Setter for property: (NXOpen.View.ShadedDisplayModeType) ShadedDisplayType. 

SnapToClosestCannedOrientation (self)

Changes the orientation of the given view to the orientation of the canned view whose orientation is the closest to that of the given view. 

SnapToVariantCannedOrientation (self)

Similar to NXOpen::View::SnapToClosestCannedOrientation except it changes the orientation of the given view to the orientation of some canned view "variant" based on I-deas's 'snapview' logic whose orientation is the closest to one of the six orthographic and eight flavors of trimetric views. 

StaticHiddenEdges (self)

Getter for property: (NXOpen.View.HiddenEdgesType) StaticHiddenEdges Returns the static hidden edges property of the view. 

StaticHiddenEdges (self, hidden_edges)

Setter for property: (NXOpen.View.HiddenEdgesType) StaticHiddenEdges. 

SyncViews (self)

Getter for property: (bool) SyncViews Returns the "Synchronized Views" toggle state of a view. 

SyncViews (self, curr_toggle_state)

Setter for property: (bool) SyncViews. 

TriadVisibility (self)

Getter for property: (bool) TriadVisibility Returns the visibility of the view triad in the view. 

TriadVisibility (self, triad_visibility)

Setter for property: (bool) TriadVisibility. 

UpdateCustomSymbols (self)

Updates custom symbol in a drawing member view or drawing sheet. 

UpdateDisplay (self)

Updates the display of given view, as needed. 

VisualizationSpecialEffectsPreferences ()

Returns an object to perform all visualization Special Effects related preferences settings. 

VisualizationVisualPreferences ()

Returns an object to perform all visualization related preferences settings. 

WcsVisibility (self)

Getter for property: (bool) WcsVisibility Returns the visibility of the WCS in the view. 

WcsVisibility (self, is_visible)

Setter for property: (bool) WcsVisibility. 

Zoom (self, scale_factor)

Scales the specified view to a desired relative scale. 

ZoomAboutPoint (self, relative_scale, scale_about_point, view_center)

Scales the specified view such that the given scale_about_point does not move. 

ZoomByRectangle (self, corner_1, corner_2)

Scales the specified view such that the specified rectangle is as large as possible while being fully contained within the viewport. 

Public Member Functions inherited from NXOpen.NXObject

CreateAttributeIterator (self)

Create an attribute iterator. 

DeleteAllAttributesByType (self, type)

Deletes all attributes of a specific type. 

DeleteAllAttributesByType (self, type, option)

Deletes all attributes of a specific type with the option to update or not. 

DeleteAttributeByTypeAndTitle (self, type, title)

Deletes an attribute by type and title. 

DeleteAttributeByTypeAndTitle (self, type, title, option)

Deletes an attribute by type and title with the option to update or not. 

DeleteUserAttribute (self, type, title, delete_entire_array, option)

Deletes the first attribute encountered with the given Type, Title. 

DeleteUserAttributes (self, iterator, option)

Deletes the attributes on the object, if any, that satisfy the given iterator. 

DeleteUserAttributes (self, type, option)

Deletes the attributes encountered with the given Type with option to update or not. 

GetAttributeTitlesByType (self, type)

Gets all the attribute titles of a specific type. 

GetBooleanUserAttribute (self, title, index)

Gets a boolean attribute by Title and array Index. 

GetComputationalTimeUserAttribute (self, title, index)

Gets a time attribute by Title and array Index. 

GetIntegerAttribute (self, title)

Gets an integer attribute by title. 

GetIntegerUserAttribute (self, title, index)

Gets an integer attribute by Title and array Index. 

GetNextUserAttribute (self, iterator)

Gets the next attribute encountered on the object, if any, that satisfies the given iterator. 

GetPdmReferenceAttributeValue (self, attributeTitle)

Gets the value of PDM Reference attribute for given object. 

GetRealAttribute (self, title)

Gets a real attribute by title. 

GetRealUserAttribute (self, title, index)

Gets a real attribute by Title and array Index. 

GetReferenceAttribute (self, title)

Gets the reference string (not the calculated value) of a string attribute that uses a reference string. 

GetStringAttribute (self, title)

Gets a string attribute value by title. 

GetStringUserAttribute (self, title, index)

Gets a string attribute by Title and array Index. 

GetTimeAttribute (self, format, title)

Gets a time attribute by title. 

GetTimeUserAttribute (self, title, index)

Gets a time attribute by Title and array Index. 

GetUserAttribute (self, title, includeUnset, addStringValues, type)

Gets the first attribute (or attribute array) encountered on the object, if any, with a given Title and Type. 

GetUserAttribute (self, title, type, index)

Gets the first attribute encountered on the object, if any, with a given Title, Type and array Index. 

GetUserAttributeAsString (self, title, type, index)

Gets the first attribute encountered on the object, if any, with a given title, type and array index. 

GetUserAttributeCount (self, iterator)

Gets the count of set attributes on the object, if any, that satisfy the given iterator. 

GetUserAttributeCount (self, iterator, countArrayAsOneAttribute)

Gets the count of set attributes on the object, if any, that satisfy the given iterator. 

GetUserAttributeCount (self, type)

Gets the count of set attributes on the object, if any, of the given type. 

GetUserAttributeCount (self, type, includeUnset, countArrayAsOneAttribute)

Gets the count of attributes on the object, if any, of the given type. 

GetUserAttributeLock (self, title, type)

Determine the lock of the given attribute. 

GetUserAttributes (self)

Gets all the attributes that have been set on the given object. 

GetUserAttributes (self, includeUnset)

Gets all the attributes of the given object. 

GetUserAttributes (self, includeUnset, addStringValues)

Gets all the attributes of the given object. 

GetUserAttributes (self, iterator)

Gets all the attributes that have been set on the given object, if any, that satisfy the given iterator. 

GetUserAttributesAsStrings (self)

Gets all the attributes that have been set on the given object. 

GetUserAttributeSize (self, title, type)

Gets the size of the first attribute encountered on the object, if any, with a given Title and Type. 

GetUserAttributeSourceObjects (self)

Returns an array of objects from which this object presents attributes. 

HasUserAttribute (self, iterator)

Determines if an attribute exists on the object, that satisfies the given iterator. 

HasUserAttribute (self, title, type, index)

Determines if an attribute with the given Title, Type and array Index is present on the object Unset attributes will not be detected by this function, as its purpose is to test for the actual presence of the attribute on the object. 

IsOccurrence (self)

Getter for property: (bool) IsOccurrence Returns whether this object is an occurrence or not. 

JournalIdentifier (self)

Getter for property: (str) JournalIdentifier Returns the identifier that would be recorded in a journal for this object. 

Name (self)

Getter for property: (str) Name Returns the custom name of the object. 

OwningComponent (self)

Getter for property: (NXOpen.Assemblies.Component) OwningComponent Returns the owning component, if this object is an occurrence. 

OwningPart (self)

Getter for property: (NXOpen.BasePart) OwningPart Returns the owning part of this object. 

Prototype (self)

Getter for property: (NXOpen.INXObject) Prototype Returns the prototype of this object if it is an occurrence. 

SetAttribute (self, title)

Creates or modifies a null attribute which is an attribute with a title and no value. 

SetAttribute (self, title, option)

Creates or modifies a null attribute with the option to update or not. 

SetAttribute (self, title, value)

Creates or modifies an integer attribute. 

SetAttribute (self, title, value)

Creates or modifies a real attribute. 

SetAttribute (self, title, value)

Creates or modifies a string attribute. 

SetAttribute (self, title, value, option)

Creates or modifies an integer attribute with the option to update or not. 

SetAttribute (self, title, value, option)

Creates or modifies a real attribute with the option to update or not. 

SetAttribute (self, title, value, option)

Creates or modifies a string attribute with the option to update or not. 

SetBooleanUserAttribute (self, title, index, value, option)

Creates or modifies a boolean attribute with the option to update or not. 

SetPdmReferenceAttribute (self, attributeTitle, attributeValue)

Sets the value of PDM Reference attribute on the object. 

SetReferenceAttribute (self, title, value)

Creates or modifies a string attribute which uses a reference string. 

SetReferenceAttribute (self, title, value, option)

Creates or modifies a string attribute which uses a reference string, with the option to update or not. 

SetTimeAttribute (self, title, value)

Creates or modifies a time attribute. 

SetTimeAttribute (self, title, value, option)

Creates or modifies a time attribute with the option to update or not. 

SetTimeUserAttribute (self, title, index, value, option)

Creates or modifies a time attribute with the option to update or not. 

SetTimeUserAttribute (self, title, index, value, option)

Creates or modifies a time attribute with the option to update or not. 

SetUserAttribute (self, info, option)

Creates or modifies an attribute with the option to update or not. 

SetUserAttribute (self, title, index, option)

Creates or modifies a null attribute with the option to update or not. 

SetUserAttribute (self, title, index, value, option)

Creates or modifies an integer attribute with the option to update or not. 

SetUserAttribute (self, title, index, value, option)

Creates or modifies a real attribute with the option to update or not. 

SetUserAttribute (self, title, index, value, option)

Creates or modifies a string attribute with the option to update or not. 

SetUserAttributeLock (self, title, type, lock)

Lock or unlock the given attribute. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

Public Attributes inherited from NXOpen.View

ViewCanned = View.Canned

NXOpen.ViewCanned is an alias for NXOpen.View.Canned 

ViewDisplayStyleType = View.DisplayStyleType

NXOpen.ViewDisplayStyleType is an alias for NXOpen.View.DisplayStyleType 

ViewHiddenEdgesType = View.HiddenEdgesType

NXOpen.ViewHiddenEdgesType is an alias for NXOpen.View.HiddenEdgesType 

ViewRenderingStyleType = View.RenderingStyleType

NXOpen.ViewRenderingStyleType is an alias for NXOpen.View.RenderingStyleType 

ViewScaleAdjustment = View.ScaleAdjustment

NXOpen.ViewScaleAdjustment is an alias for NXOpen.View.ScaleAdjustment 

ViewScaleFactor = View.ScaleFactor

NXOpen.ViewScaleFactor is an alias for NXOpen.View.ScaleFactor 

ViewShadedDisplayModeType = View.ShadedDisplayModeType

NXOpen.ViewShadedDisplayModeType is an alias for NXOpen.View.ShadedDisplayModeType 

ViewShowOrHideType = View.ShowOrHideType

NXOpen.ViewShowOrHideType is an alias for NXOpen.View.ShowOrHideType 

Public Attributes inherited from NXOpen.NXObject

NXObjectAttributeInformation_Struct = NXObject.AttributeInformation

NXOpen.NXObjectAttributeInformation_Struct is an alias for NXOpen.NXObject.AttributeInformation. 

NXObjectAttributeType = NXObject.AttributeType

NXOpen.NXObjectAttributeType is an alias for NXOpen.NXObject.AttributeType 

NXObjectComputationalTime_Struct = NXObject.ComputationalTime

NXOpen.NXObjectComputationalTime_Struct is an alias for NXOpen.NXObject.ComputationalTime. 

NXObjectDateAndTimeFormat = NXObject.DateAndTimeFormat

NXOpen.NXObjectDateAndTimeFormat is an alias for NXOpen.NXObject.DateAndTimeFormat 

## Detailed Description

Represents a search model view 

To create or edit an instance of this class, use NXOpen::Annotations::SearchModelViewBuilder 

Created in NX7.5.0 

Copyright 2025 Siemens
