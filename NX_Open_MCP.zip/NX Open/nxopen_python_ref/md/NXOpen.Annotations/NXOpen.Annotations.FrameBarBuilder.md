# NXOpen.Annotations.FrameBarBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12333.html>

Represents a NXOpen::Annotations::FrameBarBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.FrameBarBuilder:

## Additional Inherited Members

Public Member Functions inherited from NXOpen.Annotations.BaseFrameBarBuilder

AftPerpendicular (self)

Getter for property: (bool) AftPerpendicular Returns the aft perpendicular. 

AftPerpendicular (self, aftPerpendicular)

Setter for property: (bool) AftPerpendicular. 

Axis (self)

Getter for property: (NXOpen.Annotations.BaseFrameBarBuilder.AxisType) Axis Returns the axis. 

Axis (self, axis)

Setter for property: (NXOpen.Annotations.BaseFrameBarBuilder.AxisType) Axis. 

Baseline (self)

Getter for property: (bool) Baseline Returns the baseline. 

Baseline (self, baseline)

Setter for property: (bool) Baseline. 

BulkHeads (self)

Getter for property: (bool) BulkHeads Returns the bulk heads. 

BulkHeads (self, bulkHeads)

Setter for property: (bool) BulkHeads. 

Centerline (self)

Getter for property: (bool) Centerline Returns the centerline. 

Centerline (self, centerline)

Setter for property: (bool) Centerline. 

CreateFrameBarObject (self)

Creates frame bar object. 

Decks (self)

Getter for property: (bool) Decks Returns the decks. 

Decks (self, decks)

Setter for property: (bool) Decks. 

DeleteFrameBarObject (self)

This function is used to delete frame bar. 

ForwardPerpendicular (self)

Getter for property: (bool) ForwardPerpendicular Returns the forward perpendicular. 

ForwardPerpendicular (self, forwardPerpendicular)

Setter for property: (bool) ForwardPerpendicular. 

GetFramebar (self)

The frame bar. 

HorizontalDistance (self)

Getter for property: (float) HorizontalDistance Returns the horizontal distance. 

HorizontalDistance (self, horizontalDistance)

Setter for property: (float) HorizontalDistance. 

HorizontalPosition (self)

Getter for property: (NXOpen.Annotations.BaseFrameBarBuilder.HorizontalPositionType) HorizontalPosition Returns the horizontal position. 

HorizontalPosition (self, horizontalPosition)

Setter for property: (NXOpen.Annotations.BaseFrameBarBuilder.HorizontalPositionType) HorizontalPosition. 

InterTransverseFrames (self)

Getter for property: (bool) InterTransverseFrames Returns the inter transverse frames. 

InterTransverseFrames (self, interTransverseFrames)

Setter for property: (bool) InterTransverseFrames. 

LongitudinalBulkheads (self)

Getter for property: (bool) LongitudinalBulkheads Returns the longitudinal bulkheads. 

LongitudinalBulkheads (self, longitudinalBulkheads)

Setter for property: (bool) LongitudinalBulkheads. 

LongitudinalYFrames (self)

Getter for property: (bool) LongitudinalYFrames Returns the longitudinal yframes. 

LongitudinalYFrames (self, longitudinalYFrames)

Setter for property: (bool) LongitudinalYFrames. 

LongitudinalYInsertFrames (self)

Getter for property: (bool) LongitudinalYInsertFrames Returns the longitudinal Y insert frames. 

LongitudinalYInsertFrames (self, longitudinalYInsertFrames)

Setter for property: (bool) LongitudinalYInsertFrames. 

LongitudinalZFrames (self)

Getter for property: (bool) LongitudinalZFrames Returns the longitudinal zframes. 

LongitudinalZFrames (self, longitudinalZFrames)

Setter for property: (bool) LongitudinalZFrames. 

LongitudinalZInsertFrames (self)

Getter for property: (bool) LongitudinalZInsertFrames Returns the longitudinal Z insert frames. 

LongitudinalZInsertFrames (self, longitudinalZInsertFrames)

Setter for property: (bool) LongitudinalZInsertFrames. 

MainLine (self)

Getter for property: (bool) MainLine Returns the create main line. 

MainLine (self, mainLine)

Setter for property: (bool) MainLine. 

MainLineColor (self)

Getter for property: (NXOpen.NXColor) MainLineColor Returnsthe color of the framebar main line. 

MainLineColor (self, color)

Setter for property: (NXOpen.NXColor) MainLineColor. 

MainLineFont (self)

Getter for property: (NXOpen.DisplayableObject.ObjectFont) MainLineFont Returns the font of the framebar main line. 

MainLineFont (self, font)

Setter for property: (NXOpen.DisplayableObject.ObjectFont) MainLineFont. 

MainLineWidth (self)

Getter for property: (NXOpen.Annotations.LineWidth) MainLineWidth Returnsthe width of the framebar main line. 

MainLineWidth (self, width)

Setter for property: (NXOpen.Annotations.LineWidth) MainLineWidth. 

Midship (self)

Getter for property: (bool) Midship Returns the mid ship. 

Midship (self, midship)

Setter for property: (bool) Midship. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

OriginType (self)

Getter for property: (NXOpen.Annotations.BaseFrameBarBuilder.OriginOption) OriginType Returns the origin type. 

OriginType (self, originType)

Setter for property: (NXOpen.Annotations.BaseFrameBarBuilder.OriginOption) OriginType. 

ReverseAlongHullSide (self)

This function is used to reverse along hull side. 

ReverseTics (self)

This function is used to reverse tics on the framebar. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

TransveralInsertArea (self)

Getter for property: (bool) TransveralInsertArea Returns the transveral insert area. 

TransveralInsertArea (self, transveralInsertArea)

Setter for property: (bool) TransveralInsertArea. 

TransverseFrames (self)

Getter for property: (bool) TransverseFrames Returns the transverse frames. 

TransverseFrames (self, transverseFrames)

Setter for property: (bool) TransverseFrames. 

UpdateFrameBarFromStyle (self)

Updates frame bar object as per style. 

UpdateFromConceptModel (self)

This function is used to update framebar from Concept model. 

VerticalDistance (self)

Getter for property: (float) VerticalDistance Returns the vertical distance. 

VerticalDistance (self, verticalDistance)

Setter for property: (float) VerticalDistance. 

VerticalPosition (self)

Getter for property: (NXOpen.Annotations.BaseFrameBarBuilder.VerticalPositionType) VerticalPosition Returns the vertical position. 

VerticalPosition (self, verticalPosition)

Setter for property: (NXOpen.Annotations.BaseFrameBarBuilder.VerticalPositionType) VerticalPosition. 

View (self)

Getter for property: (NXOpen.Drawings.SelectDraftingView) View Returns the select view. 

Waterline (self)

Getter for property: (bool) Waterline Returns the waterline. 

Waterline (self, waterline)

Setter for property: (bool) Waterline. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

Public Attributes inherited from NXOpen.Annotations.BaseFrameBarBuilder

BaseFrameBarBuilderAxisType = BaseFrameBarBuilder.AxisType

NXOpen.Annotations.BaseFrameBarBuilderAxisType is an alias for NXOpen.Annotations.BaseFrameBarBuilder.AxisType 

BaseFrameBarBuilderHorizontalPositionType = BaseFrameBarBuilder.HorizontalPositionType

NXOpen.Annotations.BaseFrameBarBuilderHorizontalPositionType is an alias for NXOpen.Annotations.BaseFrameBarBuilder.HorizontalPositionType 

BaseFrameBarBuilderOriginOption = BaseFrameBarBuilder.OriginOption

NXOpen.Annotations.BaseFrameBarBuilderOriginOption is an alias for NXOpen.Annotations.BaseFrameBarBuilder.OriginOption 

BaseFrameBarBuilderVerticalPositionType = BaseFrameBarBuilder.VerticalPositionType

NXOpen.Annotations.BaseFrameBarBuilderVerticalPositionType is an alias for NXOpen.Annotations.BaseFrameBarBuilder.VerticalPositionType 

## Detailed Description

Represents a NXOpen::Annotations::FrameBarBuilder . 

This class allows to create frame bar annotation 

To create a new instance of this class, use NXOpen::Annotations::FrameBarCollection::CreateFrameBarBuilder 

Default values. 

Property — Value

AftPerpendicular 

0 

Axis 

X 

Baseline 

0 

BulkHeads 

0 

Centerline 

0 

Decks 

0 

ForwardPerpendicular 

0 

InterTransverseFrames 

0 

LongitudinalYFrames 

0 

LongitudinalZFrames 

0 

TransveralInsertArea 

0 

TransverseFrames 

0 

Waterline 

0 

Created in NX8.0.0 

Copyright 2025 Siemens
