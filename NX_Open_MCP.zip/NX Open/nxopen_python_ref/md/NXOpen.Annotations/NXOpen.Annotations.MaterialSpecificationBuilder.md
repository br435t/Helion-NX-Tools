# NXOpen.Annotations.MaterialSpecificationBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12973.html>

Represents a NXOpen::Annotations::MaterialSpecification builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateMaterialSpecificationBuilder 

More...

Inheritance diagram for NXOpen.Annotations.MaterialSpecificationBuilder:

## Public Member Functions

AvailableMaterial (self)

Getter for property: (str) AvailableMaterial Returns the revision. 

AvailableMaterial (self, availableMaterial)

Setter for property: (str) AvailableMaterial. 

Category (self)

Getter for property: (str) Category Returns the category. 

Category (self, category)

Setter for property: (str) Category. 

GetMaterialProperties (self)

Returns the material properties. 

GetNomenclature (self)

Returns the nomenclature. 

GetOpenField (self)

Returns the open field. 

MaterialType (self)

Getter for property: (str) MaterialType Returns the material type. 

MaterialType (self, materialType)

Setter for property: (str) MaterialType. 

Revision (self)

Getter for property: (str) Revision Returns the revision. 

Revision (self, revision)

Setter for property: (str) Revision. 

SetMaterialProperties (self, materialProperties)

Sets the material properties. 

SetNomenclature (self, nomenclature)

Sets the nomenclature. 

SetOpenField (self, openField)

Sets the open field. 

Title (self)

Getter for property: (str) Title Returns the str title. 

Title (self, title)

Setter for property: (str) Title. 

Public Member Functions inherited from NXOpen.Annotations.PmiAttributeBuilder

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the NXOpen::Annotations::AssociatedObjectsBuilder for the annotation. 

Attribute (self)

Getter for property: (NXOpen.Annotations.Pmi) Attribute Returns the NXOpen::Annotations::Pmi for this annotation. 

Attribute (self, attribute)

Setter for property: (NXOpen.Annotations.Pmi) Attribute. 

BusinessModifier (self)

Getter for property: (NXOpen.NXObject) BusinessModifier Returns the business modifier. 

BusinessModifier (self, businessModifier)

Setter for property: (NXOpen.NXObject) BusinessModifier. 

GetAttributeValues (self)

Returns the attribute values. 

KnowledgeFusionClassName (self)

Getter for property: (str) KnowledgeFusionClassName Returns the knowledge fusion class name file, the default class is UG provided pmi KF class. 

KnowledgeFusionClassName (self, knowledgeFusionClassName)

Setter for property: (str) KnowledgeFusionClassName. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the NXOpen::Annotations::OriginBuilder for the annotation. 

SetAttributeValues (self, attributeValues)

Sets the attribute values. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the NXOpen::Annotations::StyleBuilder for the annotation. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::MaterialSpecification builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateMaterialSpecificationBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ AvailableMaterial() [1/2]

NXOpen.Annotations.MaterialSpecificationBuilder.AvailableMaterial
(
self — )

Getter for property: (str) AvailableMaterial Returns the revision. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ AvailableMaterial() [2/2]

NXOpen.Annotations.MaterialSpecificationBuilder.AvailableMaterial
(
self,

availableMaterial )

Setter for property: (str) AvailableMaterial. 

Sets the revision

Setter License requirements: None.

Created in NX6.0.0 

## ◆ Category() [1/2]

NXOpen.Annotations.MaterialSpecificationBuilder.Category
(
self — )

Getter for property: (str) Category Returns the category. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Category() [2/2]

NXOpen.Annotations.MaterialSpecificationBuilder.Category
(
self,

category )

Setter for property: (str) Category. 

Sets the category

Setter License requirements: None.

Created in NX6.0.0 

## ◆ GetMaterialProperties()

NXOpen.Annotations.MaterialSpecificationBuilder.GetMaterialProperties
(
self — )

Returns the material properties. 

Returns
materialProperties (List[str]): .

Created in NX6.0.0 

License requirements: None. 

## ◆ GetNomenclature()

NXOpen.Annotations.MaterialSpecificationBuilder.GetNomenclature
(
self — )

Returns the nomenclature. 

Returns
nomenclature (List[str]): .

Created in NX6.0.0 

License requirements: None. 

## ◆ GetOpenField()

NXOpen.Annotations.MaterialSpecificationBuilder.GetOpenField
(
self — )

Returns the open field. 

Returns
openField (List[str]): .

Created in NX6.0.0 

License requirements: None. 

## ◆ MaterialType() [1/2]

NXOpen.Annotations.MaterialSpecificationBuilder.MaterialType
(
self — )

Getter for property: (str) MaterialType Returns the material type. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ MaterialType() [2/2]

NXOpen.Annotations.MaterialSpecificationBuilder.MaterialType
(
self,

materialType )

Setter for property: (str) MaterialType. 

Sets the material type

Setter License requirements: None.

Created in NX6.0.0 

## ◆ Revision() [1/2]

NXOpen.Annotations.MaterialSpecificationBuilder.Revision
(
self — )

Getter for property: (str) Revision Returns the revision. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Revision() [2/2]

NXOpen.Annotations.MaterialSpecificationBuilder.Revision
(
self,

revision )

Setter for property: (str) Revision. 

Sets the revision

Setter License requirements: None.

Created in NX6.0.0 

## ◆ SetMaterialProperties()

NXOpen.Annotations.MaterialSpecificationBuilder.SetMaterialProperties
(
self,

materialProperties )

Sets the material properties. 

Created in NX6.0.0 

License requirements: None.

Parameters

materialProperties — (List[str])

## ◆ SetNomenclature()

NXOpen.Annotations.MaterialSpecificationBuilder.SetNomenclature
(
self,

nomenclature )

Sets the nomenclature. 

Created in NX6.0.0 

License requirements: None.

Parameters

nomenclature — (List[str])

## ◆ SetOpenField()

NXOpen.Annotations.MaterialSpecificationBuilder.SetOpenField
(
self,

openField )

Sets the open field. 

Created in NX6.0.0 

License requirements: None.

Parameters

openField — (List[str])

## ◆ Title() [1/2]

NXOpen.Annotations.MaterialSpecificationBuilder.Title
(
self — )

Getter for property: (str) Title Returns the str title. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Title() [2/2]

NXOpen.Annotations.MaterialSpecificationBuilder.Title
(
self,

title )

Setter for property: (str) Title. 

Sets the str title

Setter License requirements: None.

Created in NX6.0.0 

Copyright 2025 Siemens
