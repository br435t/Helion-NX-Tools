# NXOpen.Annotations.IdSymbolBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12637.html>

Represents a NXOpen::Annotations::IdSymbol builder 

To create a new instance of this class, use NXOpen::Annotations::IdSymbolCollection::CreateIdSymbolBuilder 

Default values. 
More...

Inheritance diagram for NXOpen.Annotations.IdSymbolBuilder:

## Public Member Functions

ForeshorteningSymbol (self)

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Placement (self)

Getter for property: (NXOpen.Annotations.AnnotationPlacement) Placement Returns an annotation placement object. 

SetPreviewObject (self, symbol)

Sets the preview object for dialog creation of id symbols. 

Type (self)

Getter for property: (NXOpen.Annotations.IdSymbolBuilder.SymbolTypes) Type Returns the symbol type. 

Type (self, type)

Setter for property: (NXOpen.Annotations.IdSymbolBuilder.SymbolTypes) Type. 

Public Member Functions inherited from NXOpen.Annotations.BaseIdSymbolBuilder

BalloonType (self)

Getter for property: (NXOpen.Annotations.BalloonTypes) BalloonType Returns the balloon type. 

BalloonType (self, type)

Setter for property: (NXOpen.Annotations.BalloonTypes) BalloonType. 

Inherit (self)

Getter for property: (NXOpen.Annotations.SelectIdSymbol) Inherit Returns the inherit The id symbol from which the style properties are inherited. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

LowerText (self)

Getter for property: (str) LowerText Returns the lower text The text displayed in the lower portion of the divided symbol In case Quadrant Circle symbol, the lower text is placed in the lower right quadrant just above the horizontal dividing line. 

LowerText (self, lowerText)

Setter for property: (str) LowerText. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin, where the symbol is going to be displayed. 

Size (self)

Getter for property: (float) Size Returns the size The circle symbols are measured by diameter, the rounded box is measured by length, and all other symbols are measured by a circumscribed circle. 

Size (self, size)

Setter for property: (float) Size. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

UpperText (self)

Getter for property: (str) UpperText Returns the upper text The text displayed in the upper portion of the divided symbol In case Quadrant Circle symbol, the upper text is placed in the upper left quadrant just above the horizontal dividing line. 

UpperText (self, upperText)

Setter for property: (str) UpperText. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

IdSymbolBuilderSymbolTypes = IdSymbolBuilder.SymbolTypes

NXOpen.Annotations.IdSymbolBuilderSymbolTypes is an alias for NXOpen.Annotations.IdSymbolBuilder.SymbolTypes 

## Detailed Description

Represents a NXOpen::Annotations::IdSymbol builder 

To create a new instance of this class, use NXOpen::Annotations::IdSymbolCollection::CreateIdSymbolBuilder 

Default values. 

Property — Value

Size 

0 

Created in NX5.0.0 

## Member Function Documentation

## ◆ ForeshorteningSymbol()

NXOpen.Annotations.IdSymbolBuilder.ForeshorteningSymbol
(
self — )

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
ForeshorteningSymbolBuilder 

## ◆ Placement()

NXOpen.Annotations.IdSymbolBuilder.Placement
(
self — )

Getter for property: (NXOpen.Annotations.AnnotationPlacement) Placement Returns an annotation placement object. 

Getter License requirements: None.

Created in NX5.0.0 

Deprecated
Deprecated in NX6.0.0. This functionality is no longer supported. 

Returns
AnnotationPlacement 

## ◆ SetPreviewObject()

NXOpen.Annotations.IdSymbolBuilder.SetPreviewObject
(
self,

symbol )

Sets the preview object for dialog creation of id symbols. 

Created in NX5.0.0 

Deprecated
Deprecated in NX6.0.0. This functionality is no longer supported. 

License requirements: None.

Parameters

symbol — (NXOpen.Annotations.IdSymbol) rubberbanding symbol

## ◆ Type() [1/2]

NXOpen.Annotations.IdSymbolBuilder.Type
(
self — )

Getter for property: (NXOpen.Annotations.IdSymbolBuilder.SymbolTypes) Type Returns the symbol type. 

Getter License requirements: None.

Created in NX6.0.0 

Deprecated
Deprecated in NX12.0.2. Use NXOpen::Annotations::BaseIdSymbolBuilder::BalloonType instead. 

Returns
IdSymbolBuilder.SymbolTypes 

## ◆ Type() [2/2]

NXOpen.Annotations.IdSymbolBuilder.Type
(
self,

type )

Setter for property: (NXOpen.Annotations.IdSymbolBuilder.SymbolTypes) Type. 

Sets the symbol type

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX6.0.0 

Deprecated
Deprecated in NX12.0.2. Use NXOpen::Annotations::BaseIdSymbolBuilder::SetBalloonType instead. 

## Member Data Documentation

## ◆ IdSymbolBuilderSymbolTypes

NXOpen.Annotations.IdSymbolBuilder.IdSymbolBuilderSymbolTypes = IdSymbolBuilder.SymbolTypes

NXOpen.Annotations.IdSymbolBuilderSymbolTypes is an alias for NXOpen.Annotations.IdSymbolBuilder.SymbolTypes 

Copyright 2025 Siemens
