# NXOpen.Annotations.LinearDimensionBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12825.html>

Represents a NXOpen::Annotations::Dimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateLinearDimensionBuilder 

More...

Inheritance diagram for NXOpen.Annotations.LinearDimensionBuilder:

## Public Member Functions

Driving (self)

Getter for property: (NXOpen.Annotations.DrivingValueBuilder) Driving Returns the driving. 

ForeshorteningSymbol (self)

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Public Member Functions inherited from NXOpen.Annotations.BaseLinearDimensionBuilder

AppendedText (self)

Getter for property: (NXOpen.Annotations.AppendedTextBuilder) AppendedText Returns the appended text. 

DimensionSet (self)

Getter for property: (NXOpen.Annotations.DimensionSetBuilder) DimensionSet Returns the dimension set. 

FirstAssociativity (self)

Getter for property: (NXOpen.SelectNXObject) FirstAssociativity Returns the first associativity. 

GetNthSecondaryArrowheadOrientation (self, nth)

The arrowhead orientation for nth secondary dimensions. 

GetNthSecondaryOrigin (self, nth)

The origin for nth secondary dimensions. 

GetSecondaryCallouts (self)

The secondary callouts. 

Inherit (self)

Getter for property: (NXOpen.SelectDisplayableObject) Inherit Returns the inherit. 

IsAutoplaced (self)

Getter for property: (bool) IsAutoplaced Returns a flag to indicate if auto placement turned on. 

IsAutoplaced (self, isAutoplaced)

Setter for property: (bool) IsAutoplaced. 

Measurement (self)

Getter for property: (NXOpen.Annotations.DimensionMeasurementBuilder) Measurement Returns the measurement. 

MeasurementType (self)

Getter for property: (NXOpen.Annotations.Dimension.MeasurementTypes) MeasurementType Returns the measurement type. 

MeasurementType (self, measurementType)

Setter for property: (NXOpen.Annotations.Dimension.MeasurementTypes) MeasurementType. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

SecondAssociativity (self)

Getter for property: (NXOpen.SelectNXObject) SecondAssociativity Returns the second associativity. 

SetNthSecondaryArrowheadOrientation (self, nth, secondaryArrowheadOrientation)

The arrowhead orientation for nth secondary dimensions. 

SetNthSecondaryOrigin (self, nth, secondaryOrigin)

The origin for nth secondary dimensions. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

UseBaseline (self)

Getter for property: (bool) UseBaseline Returns a treat first associativity as a baseline. 

UseBaseline (self, useBaseline)

Setter for property: (bool) UseBaseline. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::Dimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateLinearDimensionBuilder 

Created in NX9.0.0 

## Member Function Documentation

## ◆ Driving()

NXOpen.Annotations.LinearDimensionBuilder.Driving
(
self — )

Getter for property: (NXOpen.Annotations.DrivingValueBuilder) Driving Returns the driving. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
DrivingValueBuilder 

## ◆ ForeshorteningSymbol()

NXOpen.Annotations.LinearDimensionBuilder.ForeshorteningSymbol
(
self — )

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
ForeshorteningSymbolBuilder 

Copyright 2025 Siemens
