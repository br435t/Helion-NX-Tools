# NXOpen.Annotations.DimensionMeasurementBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00149.html>

## Classes

class — MeasurementMethod

measurement method for the dimensions 

Enumerator — Comment

Inferred — Inferred measurement direction (UI Only)

Horizontal — Horizontal measurement direction

Vertical — Vertical measurement direction

PointToPoint — Point to point measurement direction

Perpendicular — Perpendicular measurement direction

Cylindrical — Linear measurement method representing a diameter

Angular — Angular measurement type

Radial — Radial measurement type

Diametral — Diametral measurement type

HoleCallout — Hole Callout based measurement

More...

Copyright 2025 Siemens
