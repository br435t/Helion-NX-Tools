# NXOpen.Annotations.DraftingNoteBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00152.html>

## Classes

class — TextAlign

text over leader types for text 

Enumerator — Comment

Top — Align top

Middle — Align middle

Bottom — Align bottom

BelowbottomExtToMax — Align below bottom extension to maximum

BelowbottomExtToMaxUnderline — Align below bottom extension to maximum and underline

Belowbottom — Align below bottom

BelowbottomUnderline — Align below bottom and underline

BelowTopExtToMax — Align below top extension to maximum

BelowTopExtToMaxUnderline — Align below top extension to maximum and underline

BelowTop — Align below top

BelowTopUnderline — Align below top and underline

More...

class — ThicknessTypes

thickness types for text 

Enumerator — Comment

Medium — Medium thickness type

Thick — Thick thickness type

More...

Copyright 2025 Siemens
