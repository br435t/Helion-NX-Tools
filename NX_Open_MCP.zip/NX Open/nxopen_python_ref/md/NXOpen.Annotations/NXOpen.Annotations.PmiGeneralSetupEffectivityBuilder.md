# NXOpen.Annotations.PmiGeneralSetupEffectivityBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00197.html>

## Classes

class — PrimaryGeometryType

the enum values which provides additional control over the display of PMI associated to primary geometry when Effectivity is being inferred 

Enumerator — Comment

IfAllAssociatedOccurrencesareLoaded — the value which represents 'If All Associated Occurrences are Loaded' type for primary geometry

IfAnyAssociatedOccurrencesareLoaded — the value which represents 'If Any Associated Occurrences are Loaded' type for primary geometry

More...

class — ReferenceGeometryType

the enum values which provides additional control over the display of PMI associated to reference geometry when Effectivity is being inferred 

Enumerator — Comment

IfAllAssociatedOccurrencesareLoaded — the value which represents 'If All Associated Occurrences are Loaded' type for reference geometry

IfAnyAssociatedOccurrencesareLoaded — the value which represents 'If Any Associated Occurrences are Loaded' type for reference geometry

More...

Copyright 2025 Siemens
