# NXOpen.Annotations.RadialDimensionBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a14001.html>

Represents a NXOpen::Annotations::Dimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateRadialDimensionBuilder 

More...

Inheritance diagram for NXOpen.Annotations.RadialDimensionBuilder:

## Public Member Functions

Driving (self)

Getter for property: (NXOpen.Annotations.DrivingValueBuilder) Driving Returns the driving. 

ForeshorteningSymbol (self)

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

GetNthSecondaryArrowheadOrientation (self, nth)

The arrowhead orientation for nth secondary dimensions. 

GetNthSecondaryOrigin (self, nth)

The origins for secondary dimensions. 

GetSecondaryCallouts (self)

The secondary callouts. 

IsAutoplaced (self)

Getter for property: (bool) IsAutoplaced Returns a flag to indicate if auto placement turned on. 

IsAutoplaced (self, isAutoplaced)

Setter for property: (bool) IsAutoplaced. 

SetNthSecondaryArrowheadOrientation (self, nth, secondaryArrowheadOrientation)

The arrowhead orientation for nth secondary dimensions. 

SetNthSecondaryOrigin (self, nth, secondaryOrigin)

The origins for secondary dimensions. 

Public Member Functions inherited from NXOpen.Annotations.BaseRadialDimensionBuilder

AppendedText (self)

Getter for property: (NXOpen.Annotations.AppendedTextBuilder) AppendedText Returns the appended text. 

DiameterDimensionDimLineAngle (self)

Getter for property: (float) DiameterDimensionDimLineAngle Returns the diameter dimension's dimension-line-angle. 

DiameterDimensionDimLineAngle (self, dimLineAngle)

Setter for property: (float) DiameterDimensionDimLineAngle. 

FirstAssociativity (self)

Getter for property: (NXOpen.SelectNXObject) FirstAssociativity Returns the first associativity. 

FoldLocation (self)

Getter for property: (NXOpen.SelectDisplayableObject) FoldLocation Returns the fold location. 

Inherit (self)

Getter for property: (NXOpen.SelectDisplayableObject) Inherit Returns the inherit. 

IsFoldedRadius (self)

Getter for property: (bool) IsFoldedRadius Returns the is folded radius. 

IsFoldedRadius (self, isFoldedRadius)

Setter for property: (bool) IsFoldedRadius. 

IsHoleStyle (self)

Getter for property: (bool) IsHoleStyle Returns the is hole style dimension. 

IsHoleStyle (self, isArrowsOutDia)

Setter for property: (bool) IsHoleStyle. 

IsRadiusToCenter (self)

Getter for property: (bool) IsRadiusToCenter Returns the is radius to center. 

IsRadiusToCenter (self, isRadiusToCenter)

Setter for property: (bool) IsRadiusToCenter. 

Measurement (self)

Getter for property: (NXOpen.Annotations.DimensionMeasurementBuilder) Measurement Returns the measurement. 

OffsetCenterPoint (self)

Getter for property: (NXOpen.SelectDisplayableObject) OffsetCenterPoint Returns the offset center point. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::Dimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateRadialDimensionBuilder 

Created in NX9.0.0 

## Member Function Documentation

## ◆ Driving()

NXOpen.Annotations.RadialDimensionBuilder.Driving
(
self — )

Getter for property: (NXOpen.Annotations.DrivingValueBuilder) Driving Returns the driving. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
DrivingValueBuilder 

## ◆ ForeshorteningSymbol()

NXOpen.Annotations.RadialDimensionBuilder.ForeshorteningSymbol
(
self — )

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
ForeshorteningSymbolBuilder 

## ◆ GetNthSecondaryArrowheadOrientation()

NXOpen.Annotations.RadialDimensionBuilder.GetNthSecondaryArrowheadOrientation
(
self,

nth )

The arrowhead orientation for nth secondary dimensions. 

Returns
secondaryArrowheadOrientation (NXOpen.Annotations.TextPlacement): .

Created in NX11.0.0 

License requirements: None.

Parameters

nth — (int)

## ◆ GetNthSecondaryOrigin()

NXOpen.Annotations.RadialDimensionBuilder.GetNthSecondaryOrigin
(
self,

nth )

The origins for secondary dimensions. 

Returns
secondaryOrigin (NXOpen.Point3d): .

Created in NX11.0.0 

License requirements: None.

Parameters

nth — (int)

## ◆ GetSecondaryCallouts()

NXOpen.Annotations.RadialDimensionBuilder.GetSecondaryCallouts
(
self — )

The secondary callouts. 

Returns
secondaryCallouts (List[NXOpen.Annotations.Dimension]): .

Created in NX11.0.0 

License requirements: None. 

## ◆ IsAutoplaced() [1/2]

NXOpen.Annotations.RadialDimensionBuilder.IsAutoplaced
(
self — )

Getter for property: (bool) IsAutoplaced Returns a flag to indicate if auto placement turned on. 

This is used to compute origins for secondary dimensions

Getter License requirements: None.

Created in NX11.0.0 

Returns
bool 

## ◆ IsAutoplaced() [2/2]

NXOpen.Annotations.RadialDimensionBuilder.IsAutoplaced
(
self,

isAutoplaced )

Setter for property: (bool) IsAutoplaced. 

Sets a flag to indicate if auto placement turned on. This is used to compute origins for secondary dimensions

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") OR nx_2d_edit (" NX 2D Edit")

Created in NX11.0.0 

## ◆ SetNthSecondaryArrowheadOrientation()

NXOpen.Annotations.RadialDimensionBuilder.SetNthSecondaryArrowheadOrientation
(
self,

nth,

secondaryArrowheadOrientation )

The arrowhead orientation for nth secondary dimensions. 

Created in NX11.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") OR nx_2d_edit (" NX 2D Edit")

Parameters

nth — (int)

secondaryArrowheadOrientation — (NXOpen.Annotations.TextPlacement)

## ◆ SetNthSecondaryOrigin()

NXOpen.Annotations.RadialDimensionBuilder.SetNthSecondaryOrigin
(
self,

nth,

secondaryOrigin )

The origins for secondary dimensions. 

Created in NX11.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") OR nx_2d_edit (" NX 2D Edit")

Parameters

nth — (int)

secondaryOrigin — (NXOpen.Point3d)

Copyright 2025 Siemens
