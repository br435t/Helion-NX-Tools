# NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00204.html>

## Classes

class — GridLabelLocation

The location of a grid label relative to its grid value 

Enumerator — Comment

Before

After

Above

Below

More...

class — HorizontalLabelDisplay

The display of grid labels for the horizontal axis of a product grid 

Enumerator — Comment

Before

After

BeforeAfter

NotSet

More...

class — VerticalLabelDisplay

The display of grid labels for the vertical axis of a product grid 

Enumerator — Comment

Below

Above

AboveBelow

NotSet

More...

Copyright 2025 Siemens
