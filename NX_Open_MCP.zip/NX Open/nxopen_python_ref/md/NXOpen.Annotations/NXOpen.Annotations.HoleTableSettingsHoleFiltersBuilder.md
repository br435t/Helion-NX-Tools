# NXOpen.Annotations.HoleTableSettingsHoleFiltersBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00168.html>

## Classes

class — ScopeType

the Scope enum 

Enumerator — Comment

OneSidedHoles — One-sided Holes

TwoSidedHoles — Two-sided Holes

More...

Copyright 2025 Siemens
