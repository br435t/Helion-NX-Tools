# NXOpen.Annotations.PmiManager Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00199.html>

## Classes

class — ComponentPmiDisplayStatus

the display status for the PMIs inside a component of an assembly part 

Enumerator — Comment

DoDisplay — PMIs are displayed in the component

DoNotDisplay — PMIs are not displayed in the component

Unknown — PMIs' display status is unknown in the component

More...

Copyright 2025 Siemens
