# NXOpen.Annotations.PmiSectionViewViewBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00203.html>

## Classes

class — CrosshatchPatternBy

the crosshatch pattern type 

Enumerator — Comment

User — Specified by user

Material — Determined by material

More...

Copyright 2025 Siemens
