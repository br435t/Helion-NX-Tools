# NXOpen.Annotations.PmiTableBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13873.html>

Represents a NXOpen::Annotations::PmiTableSection builder 

To create a new instance of this class, use NXOpen::Annotations::PmiTableSectionCollection::CreatePmiTableBuilder 

Default values. 
More...

Inheritance diagram for NXOpen.Annotations.PmiTableBuilder:

## Public Member Functions

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the NXOpen::Annotations::AssociatedObjectsBuilder for PMI Table. 

Public Member Functions inherited from NXOpen.Annotations.TableSectionBuilder

ColumnWidth (self)

Getter for property: (float) ColumnWidth Returns the column width. 

ColumnWidth (self, columnWidth)

Setter for property: (float) ColumnWidth. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

NumberOfColumns (self)

Getter for property: (int) NumberOfColumns Returns the number of columns, input for tabulr note column numbers. 

NumberOfColumns (self, numberOfColumns)

Setter for property: (int) NumberOfColumns. 

NumberOfRows (self)

Getter for property: (int) NumberOfRows Returns the number of rows. 

NumberOfRows (self, numberOfRows)

Setter for property: (int) NumberOfRows. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin, where the symbol is going to be displayed. 

RowHeight (self)

Getter for property: (float) RowHeight Returns the row height. 

RowHeight (self, rowHeight)

Setter for property: (float) RowHeight. 

Style (self)

Getter for property: (NXOpen.Annotations.TableStyleBuilder) Style Returns the style. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::PmiTableSection builder 

To create a new instance of this class, use NXOpen::Annotations::PmiTableSectionCollection::CreatePmiTableBuilder 

Default values. 

Property — Value

ColumnWidth 

50 (millimeters part), 2 (inches part) 

NumberOfColumns 

5 

NumberOfRows 

5 

RowHeight 

8 (millimeters part), 0.25 (inches part) 

Created in NX12.0.0 

## Member Function Documentation

## ◆ AssociatedObjects()

NXOpen.Annotations.PmiTableBuilder.AssociatedObjects
(
self — )

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the NXOpen::Annotations::AssociatedObjectsBuilder for PMI Table. 

Getter License requirements: None.

Created in NX12.0.0 

Returns
AssociatedObjectsBuilder 

Copyright 2025 Siemens
