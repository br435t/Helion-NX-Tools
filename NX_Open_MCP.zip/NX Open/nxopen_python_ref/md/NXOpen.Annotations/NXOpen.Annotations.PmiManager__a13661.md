# NXOpen.Annotations.PmiManager Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13661.html>

Represents an object that manages PMI objects. 
More...

Inheritance diagram for NXOpen.Annotations.PmiManager:

## Public Member Functions

ApplyModelViewOrder (self, savedOrderName)

Applies a saved explicit order. 

CopyDisplayInstanceObjects (self, input_objects, view)

Creates copies of input PMI Display Instance objects in the part. 

CopyObjects (self, input_objects)

Creates copies of input PMI objects in the part. 

CreateArbitraryAreaSeedBuilder (self)

Creates a NXOpen::Annotations::ArbitraryAreaSeedBuilder. 

CreateConvertPmiBuilder (self)

Creates a NXOpen::Annotations::ConvertPmiBuilder. 

CreateEditAnnotationPlaneBuilder (self)

Creates a NXOpen::Annotations::EditAnnotationPlaneBuilder. 

CreateExplicitOrderBuilder (self)

Creates a NXOpen::Annotations::PMIExplicitOrderBuilder. 

CreateSuppressPmibuilder (self)

Creates a NXOpen::Annotations::SuppressPMIBuilder. 

CutDisplayInstanceObjects (self, input_objects, cut_views, view_of_paste)

Cuts the input PMI Display Instance objects in the part. 

DeleteReplaceAnnotation (self, old_annotation, new_annotation)

Deletes or replaces one annotation with another. 

GetDisplayInstanceParent (self, display_instance)

Returns the PMI Display Instance parent. 

GetInheritParent (self, inherited_pmi)

Returns the inherited PMI parent. 

HasPmiInView (self, view)

Returns whether model view is having any PMI or not. 

IsDisplayInstance (self, annotation)

Returns whether or not the given annotation is a PMI Display Instance. 

IsEffectivityFiltered (self, objectValue)

The flag indicates whether the PMI is an effectivity filtered PMI because of assembly component configuration from managed environment. 

IsInheritedPmi (self, objectValue)

The flag indicating whether the annotation is an inherited PMI on the drawing sheet/view. 

LoadComponentPmi (self)

Loads Component PMI for the displayed assembly. 

LoadMonolithicJtPmi (self)

Loads PMI for the top monolithic Jt part. 

PmiAttributes ()

PmiAttribute collection. 

PmiLightweightSections ()

Lightweight Section View collection. 

PmiRegions ()

Region collection. 

Pmis ()

Pmi collection. 

PmiWave ()

WAVE collection. 

Position (self, view)

Position all the PMIs in given view. 

ResetSize (self)

Resets the size of all the PMI displayed in the part. 

Resize (self)

Resizes all PMI symbols displayed in the active view. 

RestoreUnpastedObjects (self)

Restores the unpasted PMI objects in the part. 

SaveModelViewOrder (self, orderList, saveName)

Saves an explicit order defined by the user. 

SearchModelViews ()

PMI search view collection. 

## Public Attributes

PmiManagerComponentPmiDisplayStatus = PmiManager.ComponentPmiDisplayStatus

NXOpen.Annotations.PmiManagerComponentPmiDisplayStatus is an alias for NXOpen.Annotations.PmiManager.ComponentPmiDisplayStatus 

## Detailed Description

Represents an object that manages PMI objects. 

To obtain an instance of this class, refer to NXOpen::Part 

Created in NX5.0.0 

## Member Function Documentation

## ◆ ApplyModelViewOrder()

NXOpen.Annotations.PmiManager.ApplyModelViewOrder
(
self,

savedOrderName )

Applies a saved explicit order. 

Created in NX9.0.0 

License requirements: geometric_tol ("GDT")

Parameters

savedOrderName — (str)

## ◆ CopyDisplayInstanceObjects()

NXOpen.Annotations.PmiManager.CopyDisplayInstanceObjects
(
self,

input_objects,

view )

Creates copies of input PMI Display Instance objects in the part. 

Only PMI Display Instance objects which can be copied in the NX user interface will be copied. 

Client must perform update NXOpen::Update::DoUpdate () after calling this method. 

Returns
output_objects (List[NXOpen.Annotations.Annotation]): Copies of PMI Display Instance objects .

Created in NX5.0.0 

License requirements: None.

Parameters

input_objects — (List[NXOpen.Annotations.Annotation]) PMI Display Instance objects to be copied

view — (NXOpen.View) View in which PMI Display Instance are copied.

## ◆ CopyObjects()

NXOpen.Annotations.PmiManager.CopyObjects
(
self,

input_objects )

Creates copies of input PMI objects in the part. 

Only PMI objects which can be copied in the NX user interface will be copied. 

Client must perform update NXOpen::Update::DoUpdate after calling this method. 

Returns
output_objects (List[NXOpen.Annotations.Pmi]): Copies of PMI objects .

Created in NX5.0.0 

License requirements: None.

Parameters

input_objects — (List[NXOpen.Annotations.Pmi]) PMI objects to be copied

## ◆ CreateArbitraryAreaSeedBuilder()

NXOpen.Annotations.PmiManager.CreateArbitraryAreaSeedBuilder
(
self — )

Creates a NXOpen::Annotations::ArbitraryAreaSeedBuilder. 

Returns
builder (NXOpen.Annotations.ArbitraryAreaSeedBuilder): .

Created in NX6.0.0 

License requirements: None. 

## ◆ CreateConvertPmiBuilder()

NXOpen.Annotations.PmiManager.CreateConvertPmiBuilder
(
self — )

Creates a NXOpen::Annotations::ConvertPmiBuilder. 

Returns
builder (NXOpen.Annotations.ConvertPmiBuilder): .

Created in NX2007.0.0 

License requirements: geometric_tol ("GDT") 

## ◆ CreateEditAnnotationPlaneBuilder()

NXOpen.Annotations.PmiManager.CreateEditAnnotationPlaneBuilder
(
self — )

Creates a NXOpen::Annotations::EditAnnotationPlaneBuilder. 

Returns
builder (NXOpen.Annotations.EditAnnotationPlaneBuilder): .

Created in NX2506.0.0 

License requirements: None. 

## ◆ CreateExplicitOrderBuilder()

NXOpen.Annotations.PmiManager.CreateExplicitOrderBuilder
(
self — )

Creates a NXOpen::Annotations::PMIExplicitOrderBuilder. 

Returns
builder (NXOpen.Annotations.PMIExplicitOrderBuilder): .

Created in NX9.0.0 

License requirements: None. 

## ◆ CreateSuppressPmibuilder()

NXOpen.Annotations.PmiManager.CreateSuppressPmibuilder
(
self — )

Creates a NXOpen::Annotations::SuppressPMIBuilder. 

Returns
builder (NXOpen.Annotations.SuppressPMIBuilder): .

Created in NX12.0.0 

License requirements: None. 

## ◆ CutDisplayInstanceObjects()

NXOpen.Annotations.PmiManager.CutDisplayInstanceObjects
(
self,

input_objects,

cut_views,

view_of_paste )

Cuts the input PMI Display Instance objects in the part. 

Cut operation makes the PMI Display Instance object invisible in the view of cut and makes it visible in the view of paste. Only PMI Display Instance objects which can be cut in the NX user interface will be copied. 

Client must perform update NXOpen::Update::DoUpdate () after calling this method. 

Created in NX5.0.0 

License requirements: None.

Parameters

input_objects — (List[NXOpen.Annotations.Annotation]) PMI Display Instance objects to be cut

cut_views — (List[NXOpen.View]) List of cut views. Each PMI Display Instance object is cut from the corresponding view in the list.

view_of_paste — (NXOpen.View) View in which PMI Display Instances are pasted.

## ◆ DeleteReplaceAnnotation()

NXOpen.Annotations.PmiManager.DeleteReplaceAnnotation
(
self,

old_annotation,

new_annotation )

Deletes or replaces one annotation with another. 

This will adjust the requirements ID of the annotation if one annotation replaces another. This method may be used in NX generated automation programs but it is not intended to be used in a customer written automation program. 

Created in NX6.0.0 

License requirements: None.

Parameters

old_annotation — (NXOpen.Annotations.Annotation) NXOpen::Annotations::Annotation Annotation or Dimension Set to be deleted

new_annotation — (NXOpen.Annotations.Annotation) NXOpen::Annotations::Annotation to replace the deleted annootation, can be NULL

## ◆ GetDisplayInstanceParent()

NXOpen.Annotations.PmiManager.GetDisplayInstanceParent
(
self,

display_instance )

Returns the PMI Display Instance parent. 

The parent is the PMI Object. 
Returns
parent (NXOpen.Annotations.Pmi): Parent PMI object .

Created in NX5.0.0 

License requirements: None.

Parameters

display_instance — (NXOpen.Annotations.Annotation) PMI Display Instance

## ◆ GetInheritParent()

NXOpen.Annotations.PmiManager.GetInheritParent
(
self,

inherited_pmi )

Returns the inherited PMI parent. 

The parent is the PMI Display Instance in modeling. 
Returns
pmi_display_instance (NXOpen.Annotations.Annotation): Parent PMI Display Instance .

Created in NX5.0.0 

License requirements: None.

Parameters

inherited_pmi — (NXOpen.Annotations.Annotation) Inherited PMI

## ◆ HasPmiInView()

NXOpen.Annotations.PmiManager.HasPmiInView
(
self,

view )

Returns whether model view is having any PMI or not. 

Returns
hasPmi (bool): 

True - Model view is having PMI 

False - Model view is not having any PMI 

.

Created in NX2206.0.0 

License requirements: None.

Parameters

view — (NXOpen.View) The model view to query for PMI content

## ◆ IsDisplayInstance()

NXOpen.Annotations.PmiManager.IsDisplayInstance
(
self,

annotation )

Returns whether or not the given annotation is a PMI Display Instance. 

Returns
isDisplayInstance (bool): .

Created in NX2212.0.0 

License requirements: None.

Parameters

annotation — (NXOpen.Annotations.Annotation) Annotation

## ◆ IsEffectivityFiltered()

NXOpen.Annotations.PmiManager.IsEffectivityFiltered
(
self,

objectValue )

The flag indicates whether the PMI is an effectivity filtered PMI because of assembly component configuration from managed environment. 

Returns
isEffectivityFiltered (bool): .

Created in NX8.5.1 

License requirements: None.

Parameters

objectValue — (NXOpen.Annotations.Pmi) PMI object to examine

## ◆ IsInheritedPmi()

NXOpen.Annotations.PmiManager.IsInheritedPmi
(
self,

objectValue )

The flag indicating whether the annotation is an inherited PMI on the drawing sheet/view. 

Inherited PMI is the associative copy of the PMI display instance in modeling. 
Returns
inherited (bool): .

Created in NX5.0.0 

License requirements: None.

Parameters

objectValue — (NXOpen.Annotations.Annotation) Annotation to examine

## ◆ LoadComponentPmi()

NXOpen.Annotations.PmiManager.LoadComponentPmi
(
self — )

Loads Component PMI for the displayed assembly. 

Created in NX2007.0.0 

License requirements: None. 

## ◆ LoadMonolithicJtPmi()

NXOpen.Annotations.PmiManager.LoadMonolithicJtPmi
(
self — )

Loads PMI for the top monolithic Jt part. 

Created in NX2506.0.0 

License requirements: None. 

## ◆ PmiAttributes()

NXOpen.Annotations.PmiManager.PmiAttributes
(
)

PmiAttribute collection. 

Created in NX3.0.0 

NXOpen.Annotations.PmiAttributeCollection 

## ◆ PmiLightweightSections()

NXOpen.Annotations.PmiManager.PmiLightweightSections
(
)

Lightweight Section View collection. 

Created in NX7.5.0 

NXOpen.Annotations.PmiLightweightSectionCollection 

## ◆ PmiRegions()

NXOpen.Annotations.PmiManager.PmiRegions
(
)

Region collection. 

Created in NX6.0.2 

NXOpen.Annotations.PmiRegionCollection 

## ◆ Pmis()

NXOpen.Annotations.PmiManager.Pmis
(
)

Pmi collection. 

Created in NX3.0.0 

NXOpen.Annotations.PmiCollection 

## ◆ PmiWave()

NXOpen.Annotations.PmiManager.PmiWave
(
)

WAVE collection. 

Created in NX8.0.0 

NXOpen.Annotations.PmiWaveCollection 

## ◆ Position()

NXOpen.Annotations.PmiManager.Position
(
self,

view )

Position all the PMIs in given view. 

Created in NX1980.0.0 

License requirements: geometric_tol ("GDT")

Parameters

view — (NXOpen.View)

## ◆ ResetSize()

NXOpen.Annotations.PmiManager.ResetSize
(
self — )

Resets the size of all the PMI displayed in the part. 

This will restore the size of the PMI to the part default. 

Created in NX11.0.0 

License requirements: geometric_tol ("GDT") 

## ◆ Resize()

NXOpen.Annotations.PmiManager.Resize
(
self — )

Resizes all PMI symbols displayed in the active view. 

Created in NX8.0.0 

License requirements: geometric_tol ("GDT") 

## ◆ RestoreUnpastedObjects()

NXOpen.Annotations.PmiManager.RestoreUnpastedObjects
(
self — )

Restores the unpasted PMI objects in the part. 

This method is used by NX user interface to restore PMI objects that were cut but not pasted. If called by an automation program, this method can cause unexpected results. 

Created in NX5.0.0 

License requirements: None. 

## ◆ SaveModelViewOrder()

NXOpen.Annotations.PmiManager.SaveModelViewOrder
(
self,

orderList,

saveName )

Saves an explicit order defined by the user. 

Created in NX9.0.0 

License requirements: geometric_tol ("GDT")

Parameters

orderList — (List[str])

saveName — (str)

## ◆ SearchModelViews()

NXOpen.Annotations.PmiManager.SearchModelViews
(
)

PMI search view collection. 

Created in NX7.5.0 

NXOpen.Annotations.SearchModelViewCollection 

## Member Data Documentation

## ◆ PmiManagerComponentPmiDisplayStatus

NXOpen.Annotations.PmiManager.PmiManagerComponentPmiDisplayStatus = PmiManager.ComponentPmiDisplayStatus

NXOpen.Annotations.PmiManagerComponentPmiDisplayStatus is an alias for NXOpen.Annotations.PmiManager.ComponentPmiDisplayStatus 

Copyright 2025 Siemens
