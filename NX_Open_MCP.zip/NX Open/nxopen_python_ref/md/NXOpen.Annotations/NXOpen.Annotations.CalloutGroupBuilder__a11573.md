# NXOpen.Annotations.CalloutGroupBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11573.html>

Represents a NXOpen::Annotations::CalloutGroupBuilder 

To create a new instance of this class, use NXOpen::Annotations::IdSymbolCollection::CreateCalloutGroupBuilder 

More...

Inheritance diagram for NXOpen.Annotations.CalloutGroupBuilder:

## Public Member Functions

CalloutModeType (self)

Getter for property: (NXOpen.Annotations.CalloutGroupBuilder.Mode) CalloutModeType Returns the mode. 

CalloutModeType (self, mode)

Setter for property: (NXOpen.Annotations.CalloutGroupBuilder.Mode) CalloutModeType. 

GetGroupSymbols (self)

Gets the symbols which are grouped. 

LayoutType (self)

Getter for property: (NXOpen.Annotations.CalloutGroupBuilder.Layout) LayoutType Returns the layout type. 

LayoutType (self, layout)

Setter for property: (NXOpen.Annotations.CalloutGroupBuilder.Layout) LayoutType. 

SelectCallout (self)

Getter for property: (NXOpen.SelectDisplayableObjectList) SelectCallout Returns the selected callout. 

SetGroupSymbols (self, symbols)

Groups or UnGroups the symbols based on NXOpen::Annotations::CalloutGroupBuilder::Mode . 

VerticalLeaderAttachment (self)

Getter for property: (NXOpen.Annotations.CalloutGroupBuilder.VerticalGroupLeaderAttachment) VerticalLeaderAttachment Returns the leader attachment to vertical callout groups. 

VerticalLeaderAttachment (self, position)

Setter for property: (NXOpen.Annotations.CalloutGroupBuilder.VerticalGroupLeaderAttachment) VerticalLeaderAttachment. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

CalloutGroupBuilderLayout = CalloutGroupBuilder.Layout

NXOpen.Annotations.CalloutGroupBuilderLayout is an alias for NXOpen.Annotations.CalloutGroupBuilder.Layout 

CalloutGroupBuilderMode = CalloutGroupBuilder.Mode

NXOpen.Annotations.CalloutGroupBuilderMode is an alias for NXOpen.Annotations.CalloutGroupBuilder.Mode 

CalloutGroupBuilderVerticalGroupLeaderAttachment = CalloutGroupBuilder.VerticalGroupLeaderAttachment

NXOpen.Annotations.CalloutGroupBuilderVerticalGroupLeaderAttachment is an alias for NXOpen.Annotations.CalloutGroupBuilder.VerticalGroupLeaderAttachment 

## Detailed Description

Represents a NXOpen::Annotations::CalloutGroupBuilder 

To create a new instance of this class, use NXOpen::Annotations::IdSymbolCollection::CreateCalloutGroupBuilder 

Created in NX7.5.0 

## Member Function Documentation

## ◆ CalloutModeType() [1/2]

NXOpen.Annotations.CalloutGroupBuilder.CalloutModeType
(
self — )

Getter for property: (NXOpen.Annotations.CalloutGroupBuilder.Mode) CalloutModeType Returns the mode. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
CalloutGroupBuilder.Mode 

## ◆ CalloutModeType() [2/2]

NXOpen.Annotations.CalloutGroupBuilder.CalloutModeType
(
self,

mode )

Setter for property: (NXOpen.Annotations.CalloutGroupBuilder.Mode) CalloutModeType. 

Sets the mode

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ GetGroupSymbols()

NXOpen.Annotations.CalloutGroupBuilder.GetGroupSymbols
(
self — )

Gets the symbols which are grouped. 

Returns
symbols (List[NXOpen.Annotations.IdSymbol]): .

Created in NX7.5.0 

License requirements: None. 

## ◆ LayoutType() [1/2]

NXOpen.Annotations.CalloutGroupBuilder.LayoutType
(
self — )

Getter for property: (NXOpen.Annotations.CalloutGroupBuilder.Layout) LayoutType Returns the layout type. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
CalloutGroupBuilder.Layout 

## ◆ LayoutType() [2/2]

NXOpen.Annotations.CalloutGroupBuilder.LayoutType
(
self,

layout )

Setter for property: (NXOpen.Annotations.CalloutGroupBuilder.Layout) LayoutType. 

Sets the layout type

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ SelectCallout()

NXOpen.Annotations.CalloutGroupBuilder.SelectCallout
(
self — )

Getter for property: (NXOpen.SelectDisplayableObjectList) SelectCallout Returns the selected callout. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
NXOpen.SelectDisplayableObjectList 

## ◆ SetGroupSymbols()

NXOpen.Annotations.CalloutGroupBuilder.SetGroupSymbols
(
self,

symbols )

Groups or UnGroups the symbols based on NXOpen::Annotations::CalloutGroupBuilder::Mode . 

Created in NX7.5.0 

License requirements: drafting ("DRAFTING")

Parameters

symbols — (List[NXOpen.Annotations.IdSymbol])

## ◆ VerticalLeaderAttachment() [1/2]

NXOpen.Annotations.CalloutGroupBuilder.VerticalLeaderAttachment
(
self — )

Getter for property: (NXOpen.Annotations.CalloutGroupBuilder.VerticalGroupLeaderAttachment) VerticalLeaderAttachment Returns the leader attachment to vertical callout groups. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
CalloutGroupBuilder.VerticalGroupLeaderAttachment 

## ◆ VerticalLeaderAttachment() [2/2]

NXOpen.Annotations.CalloutGroupBuilder.VerticalLeaderAttachment
(
self,

position )

Setter for property: (NXOpen.Annotations.CalloutGroupBuilder.VerticalGroupLeaderAttachment) VerticalLeaderAttachment. 

Sets the leader attachment to vertical callout groups

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## Member Data Documentation

## ◆ CalloutGroupBuilderLayout

NXOpen.Annotations.CalloutGroupBuilder.CalloutGroupBuilderLayout = CalloutGroupBuilder.Layout

NXOpen.Annotations.CalloutGroupBuilderLayout is an alias for NXOpen.Annotations.CalloutGroupBuilder.Layout 

## ◆ CalloutGroupBuilderMode

NXOpen.Annotations.CalloutGroupBuilder.CalloutGroupBuilderMode = CalloutGroupBuilder.Mode

NXOpen.Annotations.CalloutGroupBuilderMode is an alias for NXOpen.Annotations.CalloutGroupBuilder.Mode 

## ◆ CalloutGroupBuilderVerticalGroupLeaderAttachment

NXOpen.Annotations.CalloutGroupBuilder.CalloutGroupBuilderVerticalGroupLeaderAttachment = CalloutGroupBuilder.VerticalGroupLeaderAttachment

NXOpen.Annotations.CalloutGroupBuilderVerticalGroupLeaderAttachment is an alias for NXOpen.Annotations.CalloutGroupBuilder.VerticalGroupLeaderAttachment 

Copyright 2025 Siemens
