# NXOpen.Annotations.EnterpriseIdentificationBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12169.html>

Represents a NXOpen::Annotations::EnterpriseIdentification builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateEnterpriseIdentificationBuilder 

More...

Inheritance diagram for NXOpen.Annotations.EnterpriseIdentificationBuilder:

## Public Member Functions

CageCode (self)

Getter for property: (str) CageCode Returns the cage code. 

CageCode (self, cageCode)

Setter for property: (str) CageCode. 

CompanyName (self)

Getter for property: (str) CompanyName Returns the company name. 

CompanyName (self, companyName)

Setter for property: (str) CompanyName. 

Division (self)

Getter for property: (str) Division Returns the division. 

Division (self, division)

Setter for property: (str) Division. 

GetCompanyAddress (self)

Returns the company address. 

SetCompanyAddress (self, companyAddress)

Sets the company address. 

Title (self)

Getter for property: (str) Title Returns the str title. 

Title (self, title)

Setter for property: (str) Title. 

Public Member Functions inherited from NXOpen.Annotations.PmiAttributeBuilder

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the NXOpen::Annotations::AssociatedObjectsBuilder for the annotation. 

Attribute (self)

Getter for property: (NXOpen.Annotations.Pmi) Attribute Returns the NXOpen::Annotations::Pmi for this annotation. 

Attribute (self, attribute)

Setter for property: (NXOpen.Annotations.Pmi) Attribute. 

BusinessModifier (self)

Getter for property: (NXOpen.NXObject) BusinessModifier Returns the business modifier. 

BusinessModifier (self, businessModifier)

Setter for property: (NXOpen.NXObject) BusinessModifier. 

GetAttributeValues (self)

Returns the attribute values. 

KnowledgeFusionClassName (self)

Getter for property: (str) KnowledgeFusionClassName Returns the knowledge fusion class name file, the default class is UG provided pmi KF class. 

KnowledgeFusionClassName (self, knowledgeFusionClassName)

Setter for property: (str) KnowledgeFusionClassName. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the NXOpen::Annotations::OriginBuilder for the annotation. 

SetAttributeValues (self, attributeValues)

Sets the attribute values. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the NXOpen::Annotations::StyleBuilder for the annotation. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::EnterpriseIdentification builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateEnterpriseIdentificationBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ CageCode() [1/2]

NXOpen.Annotations.EnterpriseIdentificationBuilder.CageCode
(
self — )

Getter for property: (str) CageCode Returns the cage code. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ CageCode() [2/2]

NXOpen.Annotations.EnterpriseIdentificationBuilder.CageCode
(
self,

cageCode )

Setter for property: (str) CageCode. 

Sets the cage code

Setter License requirements: None.

Created in NX6.0.0 

## ◆ CompanyName() [1/2]

NXOpen.Annotations.EnterpriseIdentificationBuilder.CompanyName
(
self — )

Getter for property: (str) CompanyName Returns the company name. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ CompanyName() [2/2]

NXOpen.Annotations.EnterpriseIdentificationBuilder.CompanyName
(
self,

companyName )

Setter for property: (str) CompanyName. 

Sets the company name

Setter License requirements: None.

Created in NX6.0.0 

## ◆ Division() [1/2]

NXOpen.Annotations.EnterpriseIdentificationBuilder.Division
(
self — )

Getter for property: (str) Division Returns the division. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Division() [2/2]

NXOpen.Annotations.EnterpriseIdentificationBuilder.Division
(
self,

division )

Setter for property: (str) Division. 

Sets the division

Setter License requirements: None.

Created in NX6.0.0 

## ◆ GetCompanyAddress()

NXOpen.Annotations.EnterpriseIdentificationBuilder.GetCompanyAddress
(
self — )

Returns the company address. 

Returns
companyAddress (List[str]): .

Created in NX6.0.0 

License requirements: None. 

## ◆ SetCompanyAddress()

NXOpen.Annotations.EnterpriseIdentificationBuilder.SetCompanyAddress
(
self,

companyAddress )

Sets the company address. 

Created in NX6.0.0 

License requirements: None.

Parameters

companyAddress — (List[str])

## ◆ Title() [1/2]

NXOpen.Annotations.EnterpriseIdentificationBuilder.Title
(
self — )

Getter for property: (str) Title Returns the str title. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Title() [2/2]

NXOpen.Annotations.EnterpriseIdentificationBuilder.Title
(
self,

title )

Setter for property: (str) Title. 

Sets the str title

Setter License requirements: None.

Created in NX6.0.0 

Copyright 2025 Siemens
