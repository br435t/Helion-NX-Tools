# NXOpen.Annotations.MasterSymbolBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00179.html>

## Classes

class — LeaderAttachmentType

The Enum for Attachment options 

Enumerator — Comment

Left — Left Attachment

Right — Right Attachment

More...

Copyright 2025 Siemens
