# NXOpen.Annotations.PartFamilyTableSettingsBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13129.html>

Represents a NXOpen::Annotations::PartFamilyTableSettingsBuilder. 
More...

Inheritance diagram for NXOpen.Annotations.PartFamilyTableSettingsBuilder:

## Public Member Functions

AllowManualColumns (self)

Getter for property: (bool) AllowManualColumns Returns the allow manual columns option. 

AllowManualColumns (self, allowManualColumns)

Setter for property: (bool) AllowManualColumns. 

AllowManualRows (self)

Getter for property: (bool) AllowManualRows Returns the allow manual rows option. 

AllowManualRows (self, allowManualRows)

Setter for property: (bool) AllowManualRows. 

SetColumnVisibility (self, columnIndex, columnVisibility)

Sets the visibility of the table columns. 

SetRowVisibility (self, rowIndex, rowVisibility)

Sets the visibility of the table rows. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::PartFamilyTableSettingsBuilder. 

Created in NX1980.0.0 

## Member Function Documentation

## ◆ AllowManualColumns() [1/2]

NXOpen.Annotations.PartFamilyTableSettingsBuilder.AllowManualColumns
(
self — )

Getter for property: (bool) AllowManualColumns Returns the allow manual columns option. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
bool 

## ◆ AllowManualColumns() [2/2]

NXOpen.Annotations.PartFamilyTableSettingsBuilder.AllowManualColumns
(
self,

allowManualColumns )

Setter for property: (bool) AllowManualColumns. 

Sets the allow manual columns option

Setter License requirements: None.

Created in NX1980.0.0 

## ◆ AllowManualRows() [1/2]

NXOpen.Annotations.PartFamilyTableSettingsBuilder.AllowManualRows
(
self — )

Getter for property: (bool) AllowManualRows Returns the allow manual rows option. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
bool 

## ◆ AllowManualRows() [2/2]

NXOpen.Annotations.PartFamilyTableSettingsBuilder.AllowManualRows
(
self,

allowManualRows )

Setter for property: (bool) AllowManualRows. 

Sets the allow manual rows option

Setter License requirements: None.

Created in NX1980.0.0 

## ◆ SetColumnVisibility()

NXOpen.Annotations.PartFamilyTableSettingsBuilder.SetColumnVisibility
(
self,

columnIndex,

columnVisibility )

Sets the visibility of the table columns. 

Created in NX1980.0.0 

License requirements: None.

Parameters

columnIndex — (int) index of the column in the Columns list

columnVisibility — (bool) the visibility of the column

## ◆ SetRowVisibility()

NXOpen.Annotations.PartFamilyTableSettingsBuilder.SetRowVisibility
(
self,

rowIndex,

rowVisibility )

Sets the visibility of the table rows. 

Created in NX1980.0.0 

License requirements: None.

Parameters

rowIndex — (int) index of the row in the Hidden Rows list

rowVisibility — (bool) the visibility of the row

Copyright 2025 Siemens
