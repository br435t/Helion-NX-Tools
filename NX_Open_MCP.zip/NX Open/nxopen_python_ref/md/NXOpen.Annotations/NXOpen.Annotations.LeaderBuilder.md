# NXOpen.Annotations.LeaderBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12757.html>

Represents a NXOpen::Annotations::LeaderBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.LeaderBuilder:

## Public Member Functions

Leaders (self)

Getter for property: (NXOpen.Annotations.LeaderDataList) Leaders Returns the leaders to attach to the annotation. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::LeaderBuilder . 

This class is used to construct a leader for an annotation object. 

This is a sub-builder class and cannot be directly instantiated 

Created in NX6.0.0 

## Member Function Documentation

## ◆ Leaders()

NXOpen.Annotations.LeaderBuilder.Leaders
(
self — )

Getter for property: (NXOpen.Annotations.LeaderDataList) Leaders Returns the leaders to attach to the annotation. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LeaderDataList 

Copyright 2025 Siemens
