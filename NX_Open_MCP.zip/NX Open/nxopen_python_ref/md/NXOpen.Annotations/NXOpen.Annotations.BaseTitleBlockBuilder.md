# NXOpen.Annotations.BaseTitleBlockBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11501.html>

Represents a NXOpen::Annotations::BaseTitleBlockBuilder builder. 
More...

Inheritance diagram for NXOpen.Annotations.BaseTitleBlockBuilder:

## Public Member Functions

Cells (self)

Getter for property: (NXOpen.Annotations.TitleBlockCellBuilderList) Cells Returns the cells. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::BaseTitleBlockBuilder builder. 

This an abstract class and can not be instantiated. Methods of this class can be invoked by using the objects of derived classes NXOpen::Annotations::EditTitleBlockBuilder , NXOpen::Annotations::DefineTitleBlockBuilder . 

This is an abstract class, and cannot be instantiated. 

Created in NX8.0.0 

## Member Function Documentation

## ◆ Cells()

NXOpen.Annotations.BaseTitleBlockBuilder.Cells
(
self — )

Getter for property: (NXOpen.Annotations.TitleBlockCellBuilderList) Cells Returns the cells. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
TitleBlockCellBuilderList 

Copyright 2025 Siemens
