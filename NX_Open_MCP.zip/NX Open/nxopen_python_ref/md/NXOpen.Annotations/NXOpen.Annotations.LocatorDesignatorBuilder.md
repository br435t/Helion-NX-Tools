# NXOpen.Annotations.LocatorDesignatorBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12921.html>

Represents a NXOpen::Annotations::LocatorDesignator builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateLocatorDesignatorBuilder 

More...

Inheritance diagram for NXOpen.Annotations.LocatorDesignatorBuilder:

## Public Member Functions

CoordinatePlane (self)

Getter for property: (str) CoordinatePlane Returns the coordinateplane. 

CoordinatePlane (self, coordinatePlane)

Setter for property: (str) CoordinatePlane. 

HotSpot (self)

Getter for property: (NXOpen.Point) HotSpot Returns the hot spot. 

HotSpot (self, hotSpot)

Setter for property: (NXOpen.Point) HotSpot. 

HotSpotText (self)

Getter for property: (str) HotSpotText Returns the hot spot text. 

HotSpotText (self, hotSpotText)

Setter for property: (str) HotSpotText. 

LocatorLetter (self)

Getter for property: (str) LocatorLetter Returns the locatorletter. 

LocatorLetter (self, locatorLetter)

Setter for property: (str) LocatorLetter. 

LocatorType (self)

Getter for property: (str) LocatorType Returns the locatortype. 

LocatorType (self, locatorType)

Setter for property: (str) LocatorType. 

NormalDirection (self)

Getter for property: (NXOpen.Direction) NormalDirection Returns the normal direction. 

NormalDirection (self, normalDirection)

Setter for property: (NXOpen.Direction) NormalDirection. 

NoteText (self)

Getter for property: (str) NoteText Returns the notetext. 

NoteText (self, noteText)

Setter for property: (str) NoteText. 

PinDirection (self)

Getter for property: (NXOpen.Direction) PinDirection Returns the pin direction. 

PinDirection (self, pinDirection)

Setter for property: (NXOpen.Direction) PinDirection. 

PunchDirection (self)

Getter for property: (NXOpen.Direction) PunchDirection Returns the punch direction. 

PunchDirection (self, punchDirection)

Setter for property: (NXOpen.Direction) PunchDirection. 

Subscript (self)

Getter for property: (str) Subscript Returns the subscript. 

Subscript (self, subscript)

Setter for property: (str) Subscript. 

Title (self)

Getter for property: (str) Title Returns the str title. 

Title (self, title)

Setter for property: (str) Title. 

Public Member Functions inherited from NXOpen.Annotations.PmiAttributeBuilder

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the NXOpen::Annotations::AssociatedObjectsBuilder for the annotation. 

Attribute (self)

Getter for property: (NXOpen.Annotations.Pmi) Attribute Returns the NXOpen::Annotations::Pmi for this annotation. 

Attribute (self, attribute)

Setter for property: (NXOpen.Annotations.Pmi) Attribute. 

BusinessModifier (self)

Getter for property: (NXOpen.NXObject) BusinessModifier Returns the business modifier. 

BusinessModifier (self, businessModifier)

Setter for property: (NXOpen.NXObject) BusinessModifier. 

GetAttributeValues (self)

Returns the attribute values. 

KnowledgeFusionClassName (self)

Getter for property: (str) KnowledgeFusionClassName Returns the knowledge fusion class name file, the default class is UG provided pmi KF class. 

KnowledgeFusionClassName (self, knowledgeFusionClassName)

Setter for property: (str) KnowledgeFusionClassName. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the NXOpen::Annotations::OriginBuilder for the annotation. 

SetAttributeValues (self, attributeValues)

Sets the attribute values. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the NXOpen::Annotations::StyleBuilder for the annotation. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::LocatorDesignator builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateLocatorDesignatorBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ CoordinatePlane() [1/2]

NXOpen.Annotations.LocatorDesignatorBuilder.CoordinatePlane
(
self — )

Getter for property: (str) CoordinatePlane Returns the coordinateplane. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ CoordinatePlane() [2/2]

NXOpen.Annotations.LocatorDesignatorBuilder.CoordinatePlane
(
self,

coordinatePlane )

Setter for property: (str) CoordinatePlane. 

Sets the coordinateplane

Setter License requirements: None.

Created in NX6.0.0 

## ◆ HotSpot() [1/2]

NXOpen.Annotations.LocatorDesignatorBuilder.HotSpot
(
self — )

Getter for property: (NXOpen.Point) HotSpot Returns the hot spot. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.Point 

## ◆ HotSpot() [2/2]

NXOpen.Annotations.LocatorDesignatorBuilder.HotSpot
(
self,

hotSpot )

Setter for property: (NXOpen.Point) HotSpot. 

Sets the hot spot

Setter License requirements: None.

Created in NX6.0.0 

## ◆ HotSpotText() [1/2]

NXOpen.Annotations.LocatorDesignatorBuilder.HotSpotText
(
self — )

Getter for property: (str) HotSpotText Returns the hot spot text. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ HotSpotText() [2/2]

NXOpen.Annotations.LocatorDesignatorBuilder.HotSpotText
(
self,

hotSpotText )

Setter for property: (str) HotSpotText. 

Sets the hot spot text

Setter License requirements: None.

Created in NX6.0.0 

## ◆ LocatorLetter() [1/2]

NXOpen.Annotations.LocatorDesignatorBuilder.LocatorLetter
(
self — )

Getter for property: (str) LocatorLetter Returns the locatorletter. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ LocatorLetter() [2/2]

NXOpen.Annotations.LocatorDesignatorBuilder.LocatorLetter
(
self,

locatorLetter )

Setter for property: (str) LocatorLetter. 

Sets the locatorletter

Setter License requirements: None.

Created in NX6.0.0 

## ◆ LocatorType() [1/2]

NXOpen.Annotations.LocatorDesignatorBuilder.LocatorType
(
self — )

Getter for property: (str) LocatorType Returns the locatortype. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ LocatorType() [2/2]

NXOpen.Annotations.LocatorDesignatorBuilder.LocatorType
(
self,

locatorType )

Setter for property: (str) LocatorType. 

Sets the locatortype

Setter License requirements: None.

Created in NX6.0.0 

## ◆ NormalDirection() [1/2]

NXOpen.Annotations.LocatorDesignatorBuilder.NormalDirection
(
self — )

Getter for property: (NXOpen.Direction) NormalDirection Returns the normal direction. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.Direction 

## ◆ NormalDirection() [2/2]

NXOpen.Annotations.LocatorDesignatorBuilder.NormalDirection
(
self,

normalDirection )

Setter for property: (NXOpen.Direction) NormalDirection. 

Sets the normal direction

Setter License requirements: None.

Created in NX6.0.0 

## ◆ NoteText() [1/2]

NXOpen.Annotations.LocatorDesignatorBuilder.NoteText
(
self — )

Getter for property: (str) NoteText Returns the notetext. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ NoteText() [2/2]

NXOpen.Annotations.LocatorDesignatorBuilder.NoteText
(
self,

noteText )

Setter for property: (str) NoteText. 

Sets the notetext

Setter License requirements: None.

Created in NX6.0.0 

## ◆ PinDirection() [1/2]

NXOpen.Annotations.LocatorDesignatorBuilder.PinDirection
(
self — )

Getter for property: (NXOpen.Direction) PinDirection Returns the pin direction. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.Direction 

## ◆ PinDirection() [2/2]

NXOpen.Annotations.LocatorDesignatorBuilder.PinDirection
(
self,

pinDirection )

Setter for property: (NXOpen.Direction) PinDirection. 

Sets the pin direction

Setter License requirements: None.

Created in NX6.0.0 

## ◆ PunchDirection() [1/2]

NXOpen.Annotations.LocatorDesignatorBuilder.PunchDirection
(
self — )

Getter for property: (NXOpen.Direction) PunchDirection Returns the punch direction. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.Direction 

## ◆ PunchDirection() [2/2]

NXOpen.Annotations.LocatorDesignatorBuilder.PunchDirection
(
self,

punchDirection )

Setter for property: (NXOpen.Direction) PunchDirection. 

Sets the punch direction

Setter License requirements: None.

Created in NX6.0.0 

## ◆ Subscript() [1/2]

NXOpen.Annotations.LocatorDesignatorBuilder.Subscript
(
self — )

Getter for property: (str) Subscript Returns the subscript. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Subscript() [2/2]

NXOpen.Annotations.LocatorDesignatorBuilder.Subscript
(
self,

subscript )

Setter for property: (str) Subscript. 

Sets the subscript

Setter License requirements: None.

Created in NX6.0.0 

## ◆ Title() [1/2]

NXOpen.Annotations.LocatorDesignatorBuilder.Title
(
self — )

Getter for property: (str) Title Returns the str title. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Title() [2/2]

NXOpen.Annotations.LocatorDesignatorBuilder.Title
(
self,

title )

Setter for property: (str) Title. 

Sets the str title

Setter License requirements: None.

Created in NX6.0.0 

Copyright 2025 Siemens
