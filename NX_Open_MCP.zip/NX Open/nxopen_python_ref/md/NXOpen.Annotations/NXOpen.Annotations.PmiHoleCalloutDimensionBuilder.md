# NXOpen.Annotations.PmiHoleCalloutDimensionBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13569.html>

Represents a NXOpen::Annotations::PmiHoleCalloutDimensionBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreatePmiHoleCalloutDimensionBuilder 

More...

Inheritance diagram for NXOpen.Annotations.PmiHoleCalloutDimensionBuilder:

## Public Member Functions

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the associated objects. 

Public Member Functions inherited from NXOpen.Annotations.BaseHoleCalloutDimensionBuilder

AppendedText (self)

Getter for property: (NXOpen.Annotations.AppendedTextBuilder) AppendedText Returns the appended text. 

CanReverseFeatureDirection (self)

Determines whether the direction of the current feature can be reversed. 

FirstAssociativity (self)

Getter for property: (NXOpen.SelectNXObject) FirstAssociativity Returns the first associativity. 

GetNthSecondaryArrowheadOrientation (self, nth)

The arrowhead orientation for nth secondary dimensions. 

GetNthSecondaryOrigin (self, nth)

The origin for nth secondary dimensions. 

GetSecondaryCallouts (self)

The secondary callouts. 

Inherit (self)

Getter for property: (NXOpen.SelectDisplayableObject) Inherit Returns the hole dimension from which the properties are inherited. 

IsAutoplaced (self)

Getter for property: (bool) IsAutoplaced Returns the flag to indicate if auto placement turned on. 

IsAutoplaced (self, isAutoplaced)

Setter for property: (bool) IsAutoplaced. 

IsHoleStyle (self)

Getter for property: (bool) IsHoleStyle Returns the flag to indicate if dimension is of hole style. 

IsHoleStyle (self, isArrowsOutDia)

Setter for property: (bool) IsHoleStyle. 

Measurement (self)

Getter for property: (NXOpen.Annotations.DimensionMeasurementBuilder) Measurement Returns the measurement parameters. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

ReverseFeatureDirection (self)

Reverses the direction of the current feature. 

SecondAssociativity (self)

Getter for property: (NXOpen.SelectNXObject) SecondAssociativity Returns the second associativity. 

SetNthSecondaryArrowheadOrientation (self, nth, secondaryArrowheadOrientation)

The arrowhead orientation for nth secondary dimensions. 

SetNthSecondaryOrigin (self, nth, secondaryOrigin)

The origin for nth secondary dimensions. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

Type (self)

Getter for property: (NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.HolecalloutType) Type Returns the hole callout type. 

Type (self, type)

Setter for property: (NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.HolecalloutType) Type. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.Annotations.BaseHoleCalloutDimensionBuilder

BaseHoleCalloutDimensionBuilderHolecalloutType = BaseHoleCalloutDimensionBuilder.HolecalloutType

NXOpen.Annotations.BaseHoleCalloutDimensionBuilderHolecalloutType is an alias for NXOpen.Annotations.BaseHoleCalloutDimensionBuilder.HolecalloutType 

## Detailed Description

Represents a NXOpen::Annotations::PmiHoleCalloutDimensionBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreatePmiHoleCalloutDimensionBuilder 

Created in NX2206.0.0 

## Member Function Documentation

## ◆ AssociatedObjects()

NXOpen.Annotations.PmiHoleCalloutDimensionBuilder.AssociatedObjects
(
self — )

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the associated objects. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
AssociatedObjectsBuilder 

Copyright 2025 Siemens
