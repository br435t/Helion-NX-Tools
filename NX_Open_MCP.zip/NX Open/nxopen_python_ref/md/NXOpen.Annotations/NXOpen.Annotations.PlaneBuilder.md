# NXOpen.Annotations.PlaneBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00188.html>

## Classes

class — PlaneMethodType

method used to compute the annotation plane 

Enumerator — Comment

XyPlane — XY of the WCS

XzPlane — XZ of the WCS

YzPlane — YZ of the WCS

ModelView — Model view plane

UserDefined — User define plane

More...

Copyright 2025 Siemens
