# NXOpen.Annotations.DraftingCustomSymbolBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12001.html>

Represents builder for Drafting Custom Symbol 

To create a new instance of this class, use NXOpen::Annotations::CustomSymbolCollection::CreateDraftingCustomSymbolBuilder 

More...

Inheritance diagram for NXOpen.Annotations.DraftingCustomSymbolBuilder:

## Public Member Functions

ForeshorteningSymbol (self)

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Public Member Functions inherited from NXOpen.Annotations.BaseCustomSymbolBuilder

Angle (self)

Getter for property: (NXOpen.Expression) Angle Returns the angle. 

AnnotationPreference (self)

Getter for property: (NXOpen.Annotations.BaseCustomSymbolBuilder.AnnotationPreferences) AnnotationPreference Returns the enum annot pref. 

AnnotationPreference (self, enumAnnotPref)

Setter for property: (NXOpen.Annotations.BaseCustomSymbolBuilder.AnnotationPreferences) AnnotationPreference. 

ControlledNoteTitle (self)

Getter for property: (int) ControlledNoteTitle Returns the controlled note title. 

ControlledNoteTitle (self, controlledNoteTitle)

Setter for property: (int) ControlledNoteTitle. 

GeometryPreference (self)

Getter for property: (NXOpen.Annotations.BaseCustomSymbolBuilder.GeometryPreferences) GeometryPreference Returns the enum geom pref. 

GeometryPreference (self, enumGeomPref)

Setter for property: (NXOpen.Annotations.BaseCustomSymbolBuilder.GeometryPreferences) GeometryPreference. 

GetArbitraryNoteTitle (self)

Returns the arbitrary note value in an array. 

GetSymbol (self)

Returns the custom symbol. 

HorizontalFlip (self)

Getter for property: (bool) HorizontalFlip Returns the horizontal flip. 

HorizontalFlip (self, horizontalFlip)

Setter for property: (bool) HorizontalFlip. 

Integer (self)

Getter for property: (int) Integer Returns the integer value of selected text. 

Integer (self, integer)

Setter for property: (int) Integer. 

IsPartSymbol (self)

Getter for property: (bool) IsPartSymbol Returns the is part symbol. 

IsPartSymbol (self, isPartSymbol)

Setter for property: (bool) IsPartSymbol. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

LockStatus (self)

Getter for property: (bool) LockStatus Returns the get symbol lock property. 

LockStatus (self, lockUpdate)

Setter for property: (bool) LockStatus. 

MasterSymbolName (self)

Getter for property: (str) MasterSymbolName Returns the master symbol Name. 

MasterSymbolName (self, masterSymbolName)

Setter for property: (str) MasterSymbolName. 

MasterSymbolPath (self)

Getter for property: (str) MasterSymbolPath Returns the master symbol path. 

MasterSymbolPath (self, masterSymbolPath)

Setter for property: (str) MasterSymbolPath. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

PartiallyControlledNoteTitle (self)

Getter for property: (str) PartiallyControlledNoteTitle Returns the partially controlled note title. 

PartiallyControlledNoteTitle (self, partiallyControlledNoteTitle)

Setter for property: (str) PartiallyControlledNoteTitle. 

Real (self)

Getter for property: (float) Real Returns the real value of selected text. 

Real (self, real)

Setter for property: (float) Real. 

Scale (self)

Getter for property: (NXOpen.Expression) Scale Returns the scale. 

SelectPartSymbol (self, name, path)

Selects part custom symbol. 

SelectSymbol (self, name)

Selects custom symbol. 

SelectText (self, index)

Selects the node index of custom symbol text. 

SetArbitraryNoteTitle (self, arbitraryNoteTitle)

Sets the arbitrary note value. 

SmashSymbol (self)

Getter for property: (bool) SmashSymbol Returns the smash symbol. 

SmashSymbol (self, smashSymbol)

Setter for property: (bool) SmashSymbol. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style builder. 

Texts (self)

Getter for property: (NXOpen.Annotations.MasterSymbolListItemBuilderList) Texts Returns the texts. 

VerticalFlip (self)

Getter for property: (bool) VerticalFlip Returns the vertical flip. 

VerticalFlip (self, verticalFlip)

Setter for property: (bool) VerticalFlip. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.Annotations.BaseCustomSymbolBuilder

BaseCustomSymbolBuilderAnnotationPreferences = BaseCustomSymbolBuilder.AnnotationPreferences

NXOpen.Annotations.BaseCustomSymbolBuilderAnnotationPreferences is an alias for NXOpen.Annotations.BaseCustomSymbolBuilder.AnnotationPreferences 

BaseCustomSymbolBuilderGeometryPreferences = BaseCustomSymbolBuilder.GeometryPreferences

NXOpen.Annotations.BaseCustomSymbolBuilderGeometryPreferences is an alias for NXOpen.Annotations.BaseCustomSymbolBuilder.GeometryPreferences 

## Detailed Description

Represents builder for Drafting Custom Symbol 

To create a new instance of this class, use NXOpen::Annotations::CustomSymbolCollection::CreateDraftingCustomSymbolBuilder 

Created in NX7.5.0 

## Member Function Documentation

## ◆ ForeshorteningSymbol()

NXOpen.Annotations.DraftingCustomSymbolBuilder.ForeshorteningSymbol
(
self — )

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
ForeshorteningSymbolBuilder 

Copyright 2025 Siemens
