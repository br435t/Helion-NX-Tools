# NXOpen.Annotations.OrdinateDimension.DoglegPreferences Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13061.html>

Specifies the ordinate dogleg preferences NXOpen.Annotations.OrdinateDimensionDoglegPreferences_Struct is an alias for NXOpen.Annotations.OrdinateDimension.DoglegPreferences. 
More...

## Public Member Functions

Angle (self)

Getter for property :(float) Angle. 

Angle (self, float value)

Setter for property :(float) Angle. 

DoglegOption (self)

Getter for property :(NXOpen.Annotations.OrdinateDoglegCreationOption) DoglegOption. 

DoglegOption (self, OrdinateDoglegCreationOption value)

Setter for property :(NXOpen.Annotations.OrdinateDoglegCreationOption) DoglegOption. 

DoglegSetting (self)

Getter for property :(NXOpen.Annotations.OrdinateDoglegDefinition) DoglegSetting. 

DoglegSetting (self, OrdinateDoglegDefinition value)

Setter for property :(NXOpen.Annotations.OrdinateDoglegDefinition) DoglegSetting. 

EndOffset (self)

Getter for property :(float) EndOffset. 

EndOffset (self, float value)

Setter for property :(float) EndOffset. 

StartOffset (self)

Getter for property :(float) StartOffset. 

StartOffset (self, float value)

Setter for property :(float) StartOffset. 

## Detailed Description

Specifies the ordinate dogleg preferences NXOpen.Annotations.OrdinateDimensionDoglegPreferences_Struct is an alias for NXOpen.Annotations.OrdinateDimension.DoglegPreferences. 

## Member Function Documentation

## ◆ Angle() [1/2]

NXOpen.Annotations.OrdinateDimension.DoglegPreferences.Angle
(
self — )

Getter for property :(float) Angle. 

Returns
float 

## ◆ Angle() [2/2]

NXOpen.Annotations.OrdinateDimension.DoglegPreferences.Angle
(
self,

float — value )

Setter for property :(float) Angle. 

## ◆ DoglegOption() [1/2]

NXOpen.Annotations.OrdinateDimension.DoglegPreferences.DoglegOption
(
self — )

Getter for property :(NXOpen.Annotations.OrdinateDoglegCreationOption) DoglegOption. 

Returns
NXOpen.Annotations.OrdinateDoglegCreationOption 

## ◆ DoglegOption() [2/2]

NXOpen.Annotations.OrdinateDimension.DoglegPreferences.DoglegOption
(
self,

OrdinateDoglegCreationOption — value )

Setter for property :(NXOpen.Annotations.OrdinateDoglegCreationOption) DoglegOption. 

## ◆ DoglegSetting() [1/2]

NXOpen.Annotations.OrdinateDimension.DoglegPreferences.DoglegSetting
(
self — )

Getter for property :(NXOpen.Annotations.OrdinateDoglegDefinition) DoglegSetting. 

Returns
NXOpen.Annotations.OrdinateDoglegDefinition 

## ◆ DoglegSetting() [2/2]

NXOpen.Annotations.OrdinateDimension.DoglegPreferences.DoglegSetting
(
self,

OrdinateDoglegDefinition — value )

Setter for property :(NXOpen.Annotations.OrdinateDoglegDefinition) DoglegSetting. 

## ◆ EndOffset() [1/2]

NXOpen.Annotations.OrdinateDimension.DoglegPreferences.EndOffset
(
self — )

Getter for property :(float) EndOffset. 

Returns
float 

## ◆ EndOffset() [2/2]

NXOpen.Annotations.OrdinateDimension.DoglegPreferences.EndOffset
(
self,

float — value )

Setter for property :(float) EndOffset. 

## ◆ StartOffset() [1/2]

NXOpen.Annotations.OrdinateDimension.DoglegPreferences.StartOffset
(
self — )

Getter for property :(float) StartOffset. 

Returns
float 

## ◆ StartOffset() [2/2]

NXOpen.Annotations.OrdinateDimension.DoglegPreferences.StartOffset
(
self,

float — value )

Setter for property :(float) StartOffset. 

Copyright 2025 Siemens
