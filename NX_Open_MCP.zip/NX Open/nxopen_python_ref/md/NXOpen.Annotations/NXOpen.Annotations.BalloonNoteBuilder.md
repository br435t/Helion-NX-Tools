# NXOpen.Annotations.BalloonNoteBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11217.html>

Represents a NXOpen::Annotations::BalloonNote builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateBalloonNoteBuilder 

More...

Inheritance diagram for NXOpen.Annotations.BalloonNoteBuilder:

## Public Member Functions

BalloonText (self)

Getter for property: (str) BalloonText Returns the balloon text. 

BalloonText (self, balloonText)

Setter for property: (str) BalloonText. 

Category (self)

Getter for property: (str) Category Returns the category. 

Category (self, category)

Setter for property: (str) Category. 

GetText (self)

Returns the text. 

Identifier (self)

Getter for property: (str) Identifier Returns the identifier. 

Identifier (self, identifier)

Setter for property: (str) Identifier. 

Revision (self)

Getter for property: (str) Revision Returns the revision. 

Revision (self, revision)

Setter for property: (str) Revision. 

Scale (self)

Getter for property: (float) Scale Returns the scale. 

Scale (self, scale)

Setter for property: (float) Scale. 

SetText (self, text)

Sets the text. 

Title (self)

Getter for property: (str) Title Returns the title. 

Title (self, title)

Setter for property: (str) Title. 

Public Member Functions inherited from NXOpen.Annotations.PmiAttributeBuilder

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the NXOpen::Annotations::AssociatedObjectsBuilder for the annotation. 

Attribute (self)

Getter for property: (NXOpen.Annotations.Pmi) Attribute Returns the NXOpen::Annotations::Pmi for this annotation. 

Attribute (self, attribute)

Setter for property: (NXOpen.Annotations.Pmi) Attribute. 

BusinessModifier (self)

Getter for property: (NXOpen.NXObject) BusinessModifier Returns the business modifier. 

BusinessModifier (self, businessModifier)

Setter for property: (NXOpen.NXObject) BusinessModifier. 

GetAttributeValues (self)

Returns the attribute values. 

KnowledgeFusionClassName (self)

Getter for property: (str) KnowledgeFusionClassName Returns the knowledge fusion class name file, the default class is UG provided pmi KF class. 

KnowledgeFusionClassName (self, knowledgeFusionClassName)

Setter for property: (str) KnowledgeFusionClassName. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the NXOpen::Annotations::OriginBuilder for the annotation. 

SetAttributeValues (self, attributeValues)

Sets the attribute values. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the NXOpen::Annotations::StyleBuilder for the annotation. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::BalloonNote builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateBalloonNoteBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ BalloonText() [1/2]

NXOpen.Annotations.BalloonNoteBuilder.BalloonText
(
self — )

Getter for property: (str) BalloonText Returns the balloon text. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ BalloonText() [2/2]

NXOpen.Annotations.BalloonNoteBuilder.BalloonText
(
self,

balloonText )

Setter for property: (str) BalloonText. 

Sets the balloon text

Setter License requirements: None.

Created in NX6.0.0 

## ◆ Category() [1/2]

NXOpen.Annotations.BalloonNoteBuilder.Category
(
self — )

Getter for property: (str) Category Returns the category. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Category() [2/2]

NXOpen.Annotations.BalloonNoteBuilder.Category
(
self,

category )

Setter for property: (str) Category. 

Sets the category

Setter License requirements: None.

Created in NX6.0.0 

## ◆ GetText()

NXOpen.Annotations.BalloonNoteBuilder.GetText
(
self — )

Returns the text. 

Returns
text (List[str]): .

Created in NX6.0.0 

License requirements: None. 

## ◆ Identifier() [1/2]

NXOpen.Annotations.BalloonNoteBuilder.Identifier
(
self — )

Getter for property: (str) Identifier Returns the identifier. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Identifier() [2/2]

NXOpen.Annotations.BalloonNoteBuilder.Identifier
(
self,

identifier )

Setter for property: (str) Identifier. 

Sets the identifier

Setter License requirements: None.

Created in NX6.0.0 

## ◆ Revision() [1/2]

NXOpen.Annotations.BalloonNoteBuilder.Revision
(
self — )

Getter for property: (str) Revision Returns the revision. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Revision() [2/2]

NXOpen.Annotations.BalloonNoteBuilder.Revision
(
self,

revision )

Setter for property: (str) Revision. 

Sets the revision

Setter License requirements: None.

Created in NX6.0.0 

## ◆ Scale() [1/2]

NXOpen.Annotations.BalloonNoteBuilder.Scale
(
self — )

Getter for property: (float) Scale Returns the scale. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ Scale() [2/2]

NXOpen.Annotations.BalloonNoteBuilder.Scale
(
self,

scale )

Setter for property: (float) Scale. 

Sets the scale

Setter License requirements: None.

Created in NX6.0.0 

## ◆ SetText()

NXOpen.Annotations.BalloonNoteBuilder.SetText
(
self,

text )

Sets the text. 

Created in NX6.0.0 

License requirements: None.

Parameters

text — (List[str])

## ◆ Title() [1/2]

NXOpen.Annotations.BalloonNoteBuilder.Title
(
self — )

Getter for property: (str) Title Returns the title. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Title() [2/2]

NXOpen.Annotations.BalloonNoteBuilder.Title
(
self,

title )

Setter for property: (str) Title. 

Sets the title

Setter License requirements: None.

Created in NX6.0.0 

Copyright 2025 Siemens
