# NXOpen.Annotations.DefineTitleBlockBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11897.html>

Represents a NXOpen::Annotations::DefineTitleBlockBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.DefineTitleBlockBuilder:

## Public Member Functions

Components (self)

Getter for property: (NXOpen.Annotations.SelectTableSectionList) Components Returns the components, i. 

Origin (self)

Getter for property: (NXOpen.Point3d) Origin Returns the origin of the title block. 

Origin (self, origin)

Setter for property: (NXOpen.Point3d) Origin. 

UpdateCells (self)

Update the title block cell information when user edits the tables. 

Public Member Functions inherited from NXOpen.Annotations.BaseTitleBlockBuilder

Cells (self)

Getter for property: (NXOpen.Annotations.TitleBlockCellBuilderList) Cells Returns the cells. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::DefineTitleBlockBuilder . 

To create a new instance of this class, use NXOpen::Annotations::TitleBlockCollection::CreateDefineTitleBlockBuilder 

Created in NX8.0.0 

## Member Function Documentation

## ◆ Components()

NXOpen.Annotations.DefineTitleBlockBuilder.Components
(
self — )

Getter for property: (NXOpen.Annotations.SelectTableSectionList) Components Returns the components, i. 

e. tags of selected entities such as tabular notes

Getter License requirements: None.

Created in NX8.0.0 

Returns
SelectTableSectionList 

## ◆ Origin() [1/2]

NXOpen.Annotations.DefineTitleBlockBuilder.Origin
(
self — )

Getter for property: (NXOpen.Point3d) Origin Returns the origin of the title block. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
NXOpen.Point3d 

## ◆ Origin() [2/2]

NXOpen.Annotations.DefineTitleBlockBuilder.Origin
(
self,

origin )

Setter for property: (NXOpen.Point3d) Origin. 

Sets the origin of the title block.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ UpdateCells()

NXOpen.Annotations.DefineTitleBlockBuilder.UpdateCells
(
self — )

Update the title block cell information when user edits the tables. 

Created in NX12.0.1 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") 

Copyright 2025 Siemens
