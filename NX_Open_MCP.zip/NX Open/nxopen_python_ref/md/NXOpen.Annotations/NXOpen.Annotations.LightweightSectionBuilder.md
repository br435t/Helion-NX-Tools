# NXOpen.Annotations.LightweightSectionBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12809.html>

Represents a NXOpen::Annotations::LightweightSection builder 

To create a new instance of this class, use NXOpen::Annotations::PmiLightweightSectionCollection::CreateLightweightSectionBuilder 

Default values. 
More...

Inheritance diagram for NXOpen.Annotations.LightweightSectionBuilder:

## Public Member Functions

AssemblyCrosshatching (self)

Getter for property: (bool) AssemblyCrosshatching Returns the assembly crosshatch option. 

AssemblyCrosshatching (self, assemblyCrosshatchingOption)

Setter for property: (bool) AssemblyCrosshatching. 

BoundingBoxComponents (self)

Getter for property: (NXOpen.SelectDisplayableObjectList) BoundingBoxComponents Returns the objects to define the box section type bounding extents. 

ClipCoplanarObjects (self)

Getter for property: (bool) ClipCoplanarObjects Returns the clip coplanar objects. 

ClipCoplanarObjects (self, clipCoplanarObjectsOption)

Setter for property: (bool) ClipCoplanarObjects. 

ClipWireframeObjects (self)

Getter for property: (bool) ClipWireframeObjects Returns the clip wireframe objects. 

ClipWireframeObjects (self, clipWireframeObjectsOption)

Setter for property: (bool) ClipWireframeObjects. 

CrosshatchSettings (self)

Getter for property: (NXOpen.Annotations.HatchFillSettingsBuilder) CrosshatchSettings Returns the crosshatch settings. 

CuttingPlaneSymbol (self)

Getter for property: (NXOpen.Annotations.CuttingPlaneSymbolBuilder) CuttingPlaneSymbol Returns the cutting plane symbol. 

DisplayCrosshatch (self)

Getter for property: (bool) DisplayCrosshatch Returns the display crosshatch option. 

DisplayCrosshatch (self, displayCrosshatchOption)

Setter for property: (bool) DisplayCrosshatch. 

GetSectionCurves (self)

Returns the lightweight section view curves. 

ObjectsToSection (self)

Getter for property: (NXOpen.SelectDisplayableObjectList) ObjectsToSection Returns the objects to section. 

PatternDefinedBy (self)

Getter for property: (int) PatternDefinedBy Returns the crosshatch pattern defined by. 

PatternDefinedBy (self, patternDefinedBy)

Setter for property: (int) PatternDefinedBy. 

RestrictCrosshatch (self)

Getter for property: (bool) RestrictCrosshatch Returns the restrict crosshatch angle to 45 degree option. 

RestrictCrosshatch (self, restrictCrosshatchOption)

Setter for property: (bool) RestrictCrosshatch. 

SaveAssociativeCurves (self)

Getter for property: (bool) SaveAssociativeCurves Returns the save associative curves toggle value. 

SaveAssociativeCurves (self, saveAssociativeCurvesToggle)

Setter for property: (bool) SaveAssociativeCurves. 

Settings (self)

Getter for property: (NXOpen.Annotations.PmiSectionViewSettingsBuilder) Settings Returns the view settings. 

ToleranceCrosshatch (self)

Getter for property: (float) ToleranceCrosshatch Returns the crosshatch adjacency tolerance. 

ToleranceCrosshatch (self, crosshatchAdjacencyTolerance)

Setter for property: (float) ToleranceCrosshatch. 

ViewName (self)

Getter for property: (str) ViewName Returns the name of the lightweight section view. 

ViewName (self, viewName)

Setter for property: (str) ViewName. 

Public Member Functions inherited from NXOpen.Display.DynamicSectionBuilder

AlternatePlane (self)

Cycle through planes that are 90 degrees aligned to the current section plane. 

BoxExtentDelayUpdate (self)

Getter for property: (bool) BoxExtentDelayUpdate Returns the delay box extent update. 

BoxExtentDelayUpdate (self, delayUpdate)

Setter for property: (bool) BoxExtentDelayUpdate. 

BoxExtentMargin (self)

Getter for property: (float) BoxExtentMargin Returns the margin for box section extents 

Use Display::DynamicSectionBuilder::BoxExtentSupported to determine if extent construction is supported before querying or setting extent attributes. 

BoxExtentMargin (self, margin)

Setter for property: (float) BoxExtentMargin. 

BoxExtentObjects (self)

Getter for property: (NXOpen.SelectINXObjectList) BoxExtentObjects Returns the objects that define the extents for box section. 

BoxExtentSupported (self)

Getter for property: (bool) BoxExtentSupported Returns the box extent support. 

CapColor (self)

Getter for property: (NXOpen.NXColor) CapColor Returns the cap color. 

CapColor (self, capColor)

Setter for property: (NXOpen.NXColor) CapColor. 

CapColorOption (self)

Getter for property: (NXOpen.Display.DynamicSectionTypes.CapColorOption) CapColorOption Returns the cap color option. 

CapColorOption (self, capColorOption)

Setter for property: (NXOpen.Display.DynamicSectionTypes.CapColorOption) CapColorOption. 

ClipType (self)

Getter for property: (NXOpen.Display.DynamicSectionTypes.Clip) ClipType Returns the clip type. 

ClipType (self, clipType)

Setter for property: (NXOpen.Display.DynamicSectionTypes.Clip) ClipType. 

CreateDatumPlane (self)

Creates a datum plane from the active section plane. 

CsysType (self)

Getter for property: (NXOpen.Display.DynamicSectionTypes.CoordinateSystem) CsysType Returns the coordinate system used for creating section plane along X, Y or Z principal planes. 

CsysType (self, csys)

Setter for property: (NXOpen.Display.DynamicSectionTypes.CoordinateSystem) CsysType. 

CurveColor (self)

Getter for property: (NXOpen.NXColor) CurveColor Returns the curve color. 

CurveColor (self, curveColor)

Setter for property: (NXOpen.NXColor) CurveColor. 

CurveColorOption (self)

Getter for property: (NXOpen.Display.DynamicSectionTypes.CurveColorOption) CurveColorOption Returns the curve color option. 

CurveColorOption (self, curveColorOption)

Setter for property: (NXOpen.Display.DynamicSectionTypes.CurveColorOption) CurveColorOption. 

CurveFont (self)

Getter for property: (NXOpen.DisplayableObject.ObjectFont) CurveFont Returns the curve font. 

CurveFont (self, curveFont)

Setter for property: (NXOpen.DisplayableObject.ObjectFont) CurveFont. 

CurveWidth (self)

Getter for property: (NXOpen.DisplayableObject.ObjectWidth) CurveWidth Returns the curve width. 

CurveWidth (self, curveWidth)

Setter for property: (NXOpen.DisplayableObject.ObjectWidth) CurveWidth. 

DefaultPlaneAxis (self)

Getter for property: (NXOpen.Display.DynamicSectionTypes.Axis) DefaultPlaneAxis Returns the axis indicating the default plane normal. 

DefaultPlaneAxis (self, planeAxis)

Setter for property: (NXOpen.Display.DynamicSectionTypes.Axis) DefaultPlaneAxis. 

DeferCurveUpdate (self)

Getter for property: (bool) DeferCurveUpdate Returns the defer curve update property. 

DeferCurveUpdate (self, deferCurveUpdate)

Setter for property: (bool) DeferCurveUpdate. 

EditView (self, view)

Edits the section object in the modeling view. 

ExportSectionCurves (self, groupName, fileName)

Exports section curves in the group into a part file. 

GetActivePlane (self)

Gets the active plane in the section. 

GetAllPlanesGeometry (self)

Gets geometry for all planes of the section. 

GetAssociativePlane (self)

The dynamic section associative plane. 

GetBoundingBox (self)

Gets bounding box used by the section. 

GetGridSettings (self)

Creates a grid settings builder from the active section plane. 

GetName (self)

Gets the section name. 

GetNormal (self)

Gets the normal of the section plane. 

GetOffset (self)

Gets the the plane offset. 

GetOffsetLimits (self)

Gets minimum and maximum offset limits. 

GetOrigin (self)

Gets the section origin. 

GetPlaneGeometry (self, axisType, planeType)

Gets geometry of specified plane of the section. 

GetPlaneThickness (self)

Gets the thickness between active plane pair. 

GetRotationAngle (self, rotationAxis)

Gets rotation angle for specified axis. 

GetRotationMatrix (self)

Gets the section rotation matrix. 

InterferenceColor (self)

Getter for property: (NXOpen.NXColor) InterferenceColor Returns the interference color. 

InterferenceColor (self, interferenceColor)

Setter for property: (NXOpen.NXColor) InterferenceColor. 

IsAssociativitySupported (self)

Determines if an associative section plane is supported. 

IsDefaultPlane (self)

Indicates whether the section plane is at the default location. 

LayerSettings (self)

Getter for property: (NXOpen.Display.LayerSettingsBuilder) LayerSettings Returns the layer settings builder. 

LoadAllIntersecting (self)

Loads all components that intersect the current section plane. 

LoadNearIntersecting (self)

Loads components that intersect the current section plane and are near the section plane origin. 

LockPlanes (self)

Getter for property: (bool) LockPlanes Returns the lock planes flag. 

LockPlanes (self, lockPlanes)

Setter for property: (bool) LockPlanes. 

NumberInSeries (self)

Getter for property: (int) NumberInSeries Returns the number of requested section planes in the current section series. 

NumberInSeries (self, numberSectionsRequested)

Setter for property: (int) NumberInSeries. 

OffsetOriginInPlane (self, xOffset, yOffset)

Offsets section origin within current section plane. 

PlaneX (self)

Creates a plane along X direction. 

PlaneY (self)

Creates a plane along Y direction. 

PlaneZ (self)

Creates a plane along Z direction. 

RestoreView (self)

Restores the section to the saved section in the view database. 

ReverseDirection (self)

Reverses the plane direction. 

ReverseSeries (self)

Getter for property: (bool) ReverseSeries Returns the reverse series flag. 

ReverseSeries (self, reverseSeries)

Setter for property: (bool) ReverseSeries. 

SaveCurves (self, group_name)

Creates curves by intersecting all clipping planes of the section with all visible bodies in the scene and adds them to the group created with the specified name. 

SeriesSpacing (self)

Getter for property: (float) SeriesSpacing Returns the section plane spacing in the current section series. 

SeriesSpacing (self, sectionSpacing)

Setter for property: (float) SeriesSpacing. 

SetActivePlane (self, planeAxis, activePlane)

Sets the active plane in the section. 

SetAllPlanesGeometry (self, planeOrigins, planeMetrices)

Sets geometry for all planes of the section. 

SetAssociativePlane (self, planeTag)

Makes dynamic section associative to the specified plane The plane must be a smart plane; otherwise an error will be reported. 

SetBoundingBox (self, minCornerPt, maxCornerPt)

Sets bounding box for the section. 

SetDefaultPlane (self)

Set current section plane to its default definition. 

SetDefaults (self)

Set current section to the default values. 

SetName (self, sectionName)

Sets the section name. 

SetNormal (self, normal)

Sets the normal of the section plane 

Section offset and rotation matrix are updated. 

SetOffset (self, offset)

Sets the the plane offset. 

SetOffsetByPoint (self, point)

This method offsets the active clipping plane such that the plane passes through the specified point. 

SetOrigin (self, origin)

Sets the section origin. 

SetPlane (self, axisOrigin, origin, rotationMatrix)

Sets a section plane to be the specified plane The plane is created at the specified origin with the specified rotation matrix. 

SetPlaneThickness (self, planeThickness)

Sets the thickness between active plane pair. 

SetRotationAngle (self, rotationAxis, angle)

Rotates the section about specified axis by the specified angle. 

SetRotationMatrix (self, rotationAxis, rotationMatrix)

Sets the section rotation matrix 

Specify Display::DynamicSectionTypes::AxisNone if the axis about which rotation was performed is not known. 

ShowCap (self)

Getter for property: (bool) ShowCap Returns the cap on off flag. 

ShowCap (self, showCap)

Setter for property: (bool) ShowCap. 

ShowClip (self)

Getter for property: (bool) ShowClip Returns the clip on off flag. 

ShowClip (self, showClip)

Setter for property: (bool) ShowClip. 

ShowCurvePreview (self, showCurvePreview)

Show/hide curve preview. 

ShowCurves (self)

Getter for property: (bool) ShowCurves Returns the curve on off flag. 

ShowCurves (self, showCurves)

Setter for property: (bool) ShowCurves. 

ShowGrid (self)

Getter for property: (bool) ShowGrid Returns the show grid display flag. 

ShowGrid (self, showGrid)

Setter for property: (bool) ShowGrid. 

ShowInterference (self)

Getter for property: (bool) ShowInterference Returns the interference on off flag. 

ShowInterference (self, showInterference)

Setter for property: (bool) ShowInterference. 

ShowSectionCurves (self, showCurves)

Shows the section curves in the view associated with the builder. 

ShowViewer (self)

Getter for property: (bool) ShowViewer Returns the 2D viewer display flag. 

ShowViewer (self, showViewer)

Setter for property: (bool) ShowViewer. 

Type (self)

Getter for property: (NXOpen.Display.DynamicSectionTypes.Type) Type Returns the section type. 

Type (self, type)

Setter for property: (NXOpen.Display.DynamicSectionTypes.Type) Type. 

UpdateBoxExtents (self)

Update box section display by recomputing the box extents if necessary. 

View (self)

Getter for property: (NXOpen.ModelingView) View Returns the modeling view in which section object edits are being done. 

View (self, view)

Setter for property: (NXOpen.ModelingView) View. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::LightweightSection builder 

To create a new instance of this class, use NXOpen::Annotations::PmiLightweightSectionCollection::CreateLightweightSectionBuilder 

Default values. 

Property — Value

BoxExtentDelayUpdate 

false 

CapColorOption 

Any 

ClipType 

Section 

CurveColorOption 

Any 

CurveFont 

Solid 

CurveWidth 

Two 

LockPlanes 

true 

ShowCap 

true 

ShowClip 

true 

ShowCurves (deprecated) 

false 

ShowGrid 

false 

ShowInterference 

false 

ShowViewer 

false 

Type 

OnePlane 

Created in NX7.5.0 

## Member Function Documentation

## ◆ AssemblyCrosshatching() [1/2]

NXOpen.Annotations.LightweightSectionBuilder.AssemblyCrosshatching
(
self — )

Getter for property: (bool) AssemblyCrosshatching Returns the assembly crosshatch option. 

Getter License requirements: None.

Created in NX9.0.0 

Deprecated
Deprecated in NX2007.0.0. Use instead. 

Returns
bool 

## ◆ AssemblyCrosshatching() [2/2]

NXOpen.Annotations.LightweightSectionBuilder.AssemblyCrosshatching
(
self,

assemblyCrosshatchingOption )

Setter for property: (bool) AssemblyCrosshatching. 

Sets the assembly crosshatch option

Setter License requirements: geometric_tol ("GDT")

Created in NX9.0.0 

Deprecated
Deprecated in NX2007.0.0. Use instead. 

## ◆ BoundingBoxComponents()

NXOpen.Annotations.LightweightSectionBuilder.BoundingBoxComponents
(
self — )

Getter for property: (NXOpen.SelectDisplayableObjectList) BoundingBoxComponents Returns the objects to define the box section type bounding extents. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
NXOpen.SelectDisplayableObjectList 

## ◆ ClipCoplanarObjects() [1/2]

NXOpen.Annotations.LightweightSectionBuilder.ClipCoplanarObjects
(
self — )

Getter for property: (bool) ClipCoplanarObjects Returns the clip coplanar objects. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
bool 

## ◆ ClipCoplanarObjects() [2/2]

NXOpen.Annotations.LightweightSectionBuilder.ClipCoplanarObjects
(
self,

clipCoplanarObjectsOption )

Setter for property: (bool) ClipCoplanarObjects. 

Sets the clip coplanar objects

Setter License requirements: geometric_tol ("GDT")

Created in NX11.0.0 

## ◆ ClipWireframeObjects() [1/2]

NXOpen.Annotations.LightweightSectionBuilder.ClipWireframeObjects
(
self — )

Getter for property: (bool) ClipWireframeObjects Returns the clip wireframe objects. 

Getter License requirements: None.

Created in NX11.0.1 

Returns
bool 

## ◆ ClipWireframeObjects() [2/2]

NXOpen.Annotations.LightweightSectionBuilder.ClipWireframeObjects
(
self,

clipWireframeObjectsOption )

Setter for property: (bool) ClipWireframeObjects. 

Sets the clip wireframe objects

Setter License requirements: geometric_tol ("GDT")

Created in NX11.0.1 

## ◆ CrosshatchSettings()

NXOpen.Annotations.LightweightSectionBuilder.CrosshatchSettings
(
self — )

Getter for property: (NXOpen.Annotations.HatchFillSettingsBuilder) CrosshatchSettings Returns the crosshatch settings. 

Getter License requirements: None.

Created in NX9.0.0 

Deprecated
Deprecated in NX2007.0.0. Use instead. 

Returns
HatchFillSettingsBuilder 

## ◆ CuttingPlaneSymbol()

NXOpen.Annotations.LightweightSectionBuilder.CuttingPlaneSymbol
(
self — )

Getter for property: (NXOpen.Annotations.CuttingPlaneSymbolBuilder) CuttingPlaneSymbol Returns the cutting plane symbol. 

Getter License requirements: None.

Created in NX9.0.0 

Deprecated
Deprecated in NX2007.0.0. Use instead. 

Returns
CuttingPlaneSymbolBuilder 

## ◆ DisplayCrosshatch() [1/2]

NXOpen.Annotations.LightweightSectionBuilder.DisplayCrosshatch
(
self — )

Getter for property: (bool) DisplayCrosshatch Returns the display crosshatch option. 

Getter License requirements: None.

Created in NX9.0.0 

Deprecated
Deprecated in NX2007.0.0. Use instead. 

Returns
bool 

## ◆ DisplayCrosshatch() [2/2]

NXOpen.Annotations.LightweightSectionBuilder.DisplayCrosshatch
(
self,

displayCrosshatchOption )

Setter for property: (bool) DisplayCrosshatch. 

Sets the display crosshatch option

Setter License requirements: geometric_tol ("GDT")

Created in NX9.0.0 

Deprecated
Deprecated in NX2007.0.0. Use instead. 

## ◆ GetSectionCurves()

NXOpen.Annotations.LightweightSectionBuilder.GetSectionCurves
(
self — )

Returns the lightweight section view curves. 

Returns
curves (List[NXOpen.Curve]): Array of lightweight section view curves .

Created in NX7.5.0 

License requirements: None. 

## ◆ ObjectsToSection()

NXOpen.Annotations.LightweightSectionBuilder.ObjectsToSection
(
self — )

Getter for property: (NXOpen.SelectDisplayableObjectList) ObjectsToSection Returns the objects to section. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
NXOpen.SelectDisplayableObjectList 

## ◆ PatternDefinedBy() [1/2]

NXOpen.Annotations.LightweightSectionBuilder.PatternDefinedBy
(
self — )

Getter for property: (int) PatternDefinedBy Returns the crosshatch pattern defined by. 

Getter License requirements: None.

Created in NX9.0.0 

Deprecated
Deprecated in NX2007.0.0. Use instead. 

Returns
int 

## ◆ PatternDefinedBy() [2/2]

NXOpen.Annotations.LightweightSectionBuilder.PatternDefinedBy
(
self,

patternDefinedBy )

Setter for property: (int) PatternDefinedBy. 

Sets the crosshatch pattern defined by

Setter License requirements: geometric_tol ("GDT")

Created in NX9.0.0 

Deprecated
Deprecated in NX2007.0.0. Use instead. 

## ◆ RestrictCrosshatch() [1/2]

NXOpen.Annotations.LightweightSectionBuilder.RestrictCrosshatch
(
self — )

Getter for property: (bool) RestrictCrosshatch Returns the restrict crosshatch angle to 45 degree option. 

Getter License requirements: None.

Created in NX9.0.0 

Deprecated
Deprecated in NX2007.0.0. Use instead. 

Returns
bool 

## ◆ RestrictCrosshatch() [2/2]

NXOpen.Annotations.LightweightSectionBuilder.RestrictCrosshatch
(
self,

restrictCrosshatchOption )

Setter for property: (bool) RestrictCrosshatch. 

Sets the restrict crosshatch angle to 45 degree option

Setter License requirements: geometric_tol ("GDT")

Created in NX9.0.0 

Deprecated
Deprecated in NX2007.0.0. Use instead. 

## ◆ SaveAssociativeCurves() [1/2]

NXOpen.Annotations.LightweightSectionBuilder.SaveAssociativeCurves
(
self — )

Getter for property: (bool) SaveAssociativeCurves Returns the save associative curves toggle value. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
bool 

## ◆ SaveAssociativeCurves() [2/2]

NXOpen.Annotations.LightweightSectionBuilder.SaveAssociativeCurves
(
self,

saveAssociativeCurvesToggle )

Setter for property: (bool) SaveAssociativeCurves. 

Sets the save associative curves toggle value

Setter License requirements: geometric_tol ("GDT")

Created in NX7.5.0 

## ◆ Settings()

NXOpen.Annotations.LightweightSectionBuilder.Settings
(
self — )

Getter for property: (NXOpen.Annotations.PmiSectionViewSettingsBuilder) Settings Returns the view settings. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
PmiSectionViewSettingsBuilder 

## ◆ ToleranceCrosshatch() [1/2]

NXOpen.Annotations.LightweightSectionBuilder.ToleranceCrosshatch
(
self — )

Getter for property: (float) ToleranceCrosshatch Returns the crosshatch adjacency tolerance. 

Getter License requirements: None.

Created in NX9.0.0 

Deprecated
Deprecated in NX2007.0.0. Use instead. 

Returns
float 

## ◆ ToleranceCrosshatch() [2/2]

NXOpen.Annotations.LightweightSectionBuilder.ToleranceCrosshatch
(
self,

crosshatchAdjacencyTolerance )

Setter for property: (float) ToleranceCrosshatch. 

Sets the crosshatch adjacency tolerance

Setter License requirements: geometric_tol ("GDT")

Created in NX9.0.0 

Deprecated
Deprecated in NX2007.0.0. Use instead. 

## ◆ ViewName() [1/2]

NXOpen.Annotations.LightweightSectionBuilder.ViewName
(
self — )

Getter for property: (str) ViewName Returns the name of the lightweight section view. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
str 

## ◆ ViewName() [2/2]

NXOpen.Annotations.LightweightSectionBuilder.ViewName
(
self,

viewName )

Setter for property: (str) ViewName. 

Sets the name of the lightweight section view

Setter License requirements: geometric_tol ("GDT")

Created in NX7.5.0 

Copyright 2025 Siemens
