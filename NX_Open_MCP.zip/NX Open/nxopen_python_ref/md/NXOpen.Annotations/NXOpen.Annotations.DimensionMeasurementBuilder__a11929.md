# NXOpen.Annotations.DimensionMeasurementBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11929.html>

Represents a NXOpen::Annotations::DimensionMeasurementBuilder 

This is a sub-builder class and cannot be directly instantiated 

More...

Inheritance diagram for NXOpen.Annotations.DimensionMeasurementBuilder:

## Public Member Functions

Direction (self)

Getter for property: (NXOpen.Direction) Direction Returns the measurement direction when using NXOpen::Annotations::DimensionMeasurementBuilder::MeasurementMethodPointToPoint (optional) 

Direction (self, direction)

Setter for property: (NXOpen.Direction) Direction. 

DirectionView (self)

Getter for property: (NXOpen.View) DirectionView Returns the measurement direction view when using NXOpen::Annotations::DimensionMeasurementBuilder::MeasurementMethodPointToPoint (optional) 

DirectionView (self, directionView)

Setter for property: (NXOpen.View) DirectionView. 

Method (self)

Getter for property: (NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod) Method Returns the measurement method for the size of the dimension. 

Method (self, method)

Setter for property: (NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod) Method. 

PartOccurrence (self)

Getter for property: (NXOpen.Assemblies.Component) PartOccurrence Returns the measurement part occurrence. 

PartOccurrence (self, partOccurrence)

Setter for property: (NXOpen.Assemblies.Component) PartOccurrence. 

SecondaryCalloutActive (self)

Getter for property: (bool) SecondaryCalloutActive Returns the activation of hole callout secondary dimension. 

SecondaryCalloutActive (self, secondaryCalloutActive)

Setter for property: (bool) SecondaryCalloutActive. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

DimensionMeasurementBuilderMeasurementMethod = DimensionMeasurementBuilder.MeasurementMethod

NXOpen.Annotations.DimensionMeasurementBuilderMeasurementMethod is an alias for NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod 

## Detailed Description

Represents a NXOpen::Annotations::DimensionMeasurementBuilder 

This is a sub-builder class and cannot be directly instantiated 

Created in NX9.0.0 

## Member Function Documentation

## ◆ Direction() [1/2]

NXOpen.Annotations.DimensionMeasurementBuilder.Direction
(
self — )

Getter for property: (NXOpen.Direction) Direction Returns the measurement direction when using NXOpen::Annotations::DimensionMeasurementBuilder::MeasurementMethodPointToPoint (optional) 

Getter License requirements: None.

Created in NX9.0.0 

Returns
NXOpen.Direction 

## ◆ Direction() [2/2]

NXOpen.Annotations.DimensionMeasurementBuilder.Direction
(
self,

direction )

Setter for property: (NXOpen.Direction) Direction. 

Sets the measurement direction when using NXOpen::Annotations::DimensionMeasurementBuilder::MeasurementMethodPointToPoint (optional)

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") OR solid_modeling ("SOLIDS MODELING")

Created in NX9.0.0 

## ◆ DirectionView() [1/2]

NXOpen.Annotations.DimensionMeasurementBuilder.DirectionView
(
self — )

Getter for property: (NXOpen.View) DirectionView Returns the measurement direction view when using NXOpen::Annotations::DimensionMeasurementBuilder::MeasurementMethodPointToPoint (optional) 

Getter License requirements: None.

Created in NX9.0.0 

Returns
NXOpen.View 

## ◆ DirectionView() [2/2]

NXOpen.Annotations.DimensionMeasurementBuilder.DirectionView
(
self,

directionView )

Setter for property: (NXOpen.View) DirectionView. 

Sets the measurement direction view when using NXOpen::Annotations::DimensionMeasurementBuilder::MeasurementMethodPointToPoint (optional)

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") OR solid_modeling ("SOLIDS MODELING")

Created in NX9.0.0 

## ◆ Method() [1/2]

NXOpen.Annotations.DimensionMeasurementBuilder.Method
(
self — )

Getter for property: (NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod) Method Returns the measurement method for the size of the dimension. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
DimensionMeasurementBuilder.MeasurementMethod 

## ◆ Method() [2/2]

NXOpen.Annotations.DimensionMeasurementBuilder.Method
(
self,

method )

Setter for property: (NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod) Method. 

Sets the measurement method for the size of the dimension

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") OR solid_modeling ("SOLIDS MODELING")

Created in NX9.0.0 

## ◆ PartOccurrence() [1/2]

NXOpen.Annotations.DimensionMeasurementBuilder.PartOccurrence
(
self — )

Getter for property: (NXOpen.Assemblies.Component) PartOccurrence Returns the measurement part occurrence. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
NXOpen.Assemblies.Component 

## ◆ PartOccurrence() [2/2]

NXOpen.Annotations.DimensionMeasurementBuilder.PartOccurrence
(
self,

partOccurrence )

Setter for property: (NXOpen.Assemblies.Component) PartOccurrence. 

Sets the measurement part occurrence

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") OR solid_modeling ("SOLIDS MODELING")

Created in NX9.0.0 

## ◆ SecondaryCalloutActive() [1/2]

NXOpen.Annotations.DimensionMeasurementBuilder.SecondaryCalloutActive
(
self — )

Getter for property: (bool) SecondaryCalloutActive Returns the activation of hole callout secondary dimension. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
bool 

## ◆ SecondaryCalloutActive() [2/2]

NXOpen.Annotations.DimensionMeasurementBuilder.SecondaryCalloutActive
(
self,

secondaryCalloutActive )

Setter for property: (bool) SecondaryCalloutActive. 

Sets the activation of hole callout secondary dimension

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") OR solid_modeling ("SOLIDS MODELING")

Created in NX11.0.0 

## Member Data Documentation

## ◆ DimensionMeasurementBuilderMeasurementMethod

NXOpen.Annotations.DimensionMeasurementBuilder.DimensionMeasurementBuilderMeasurementMethod = DimensionMeasurementBuilder.MeasurementMethod

NXOpen.Annotations.DimensionMeasurementBuilderMeasurementMethod is an alias for NXOpen.Annotations.DimensionMeasurementBuilder.MeasurementMethod 

Copyright 2025 Siemens
