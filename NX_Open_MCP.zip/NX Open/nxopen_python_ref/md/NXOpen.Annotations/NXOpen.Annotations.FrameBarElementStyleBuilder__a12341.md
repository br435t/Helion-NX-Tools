# NXOpen.Annotations.FrameBarElementStyleBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12341.html>

Represents a NXOpen::Annotations::FrameBarElementStyleBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.FrameBarElementStyleBuilder:

## Public Member Functions

DisplayPosition (self)

Getter for property: (bool) DisplayPosition Returns the display position. 

DisplayPosition (self, bShow)

Setter for property: (bool) DisplayPosition. 

DisplayThicknessDirection (self)

Getter for property: (bool) DisplayThicknessDirection Returns the display thickness dirction. 

DisplayThicknessDirection (self, bShow)

Setter for property: (bool) DisplayThicknessDirection. 

ExtendedTicBegin (self)

Getter for property: (int) ExtendedTicBegin Returns the extended tic from which display to be started. 

ExtendedTicBegin (self, displayExtendBegin)

Setter for property: (int) ExtendedTicBegin. 

ExtendedTicColor (self)

Getter for property: (int) ExtendedTicColor Returns the extended tic color. 

ExtendedTicColor (self, extendColor)

Setter for property: (int) ExtendedTicColor. 

ExtendedTicFont (self)

Getter for property: (int) ExtendedTicFont Returns the extended tic font. 

ExtendedTicFont (self, extendFont)

Setter for property: (int) ExtendedTicFont. 

ExtendedTicFrequency (self)

Getter for property: (int) ExtendedTicFrequency Returns the extended tic display frequency. 

ExtendedTicFrequency (self, displayExtendFrequency)

Setter for property: (int) ExtendedTicFrequency. 

ExtendedTicLength (self)

Getter for property: (float) ExtendedTicLength Returns the extended tic length. 

ExtendedTicLength (self, extendLength)

Setter for property: (float) ExtendedTicLength. 

ExtendedTicWidth (self)

Getter for property: (int) ExtendedTicWidth Returns the extended tic width. 

ExtendedTicWidth (self, extendWidth)

Setter for property: (int) ExtendedTicWidth. 

LabelColor (self)

Getter for property: (int) LabelColor Returns the label color. 

LabelColor (self, labelColor)

Setter for property: (int) LabelColor. 

LabelFont (self)

Getter for property: (int) LabelFont Returns the label font. 

LabelFont (self, labelFont)

Setter for property: (int) LabelFont. 

LabelItalicized (self)

Getter for property: (bool) LabelItalicized Returns the label font style. 

LabelItalicized (self, italic)

Setter for property: (bool) LabelItalicized. 

LabelName (self)

Getter for property: (int) LabelName Returns the label name. 

LabelName (self, labelName)

Setter for property: (int) LabelName. 

LabelTextAspectRatio (self)

Getter for property: (float) LabelTextAspectRatio Returns the label text aspect ratio. 

LabelTextAspectRatio (self, aspectRatio)

Setter for property: (float) LabelTextAspectRatio. 

LabelTextFontGapFactor (self)

Getter for property: (float) LabelTextFontGapFactor Returns the label text font gap factor. 

LabelTextFontGapFactor (self, gapFactor)

Setter for property: (float) LabelTextFontGapFactor. 

LabelTextHeight (self)

Getter for property: (float) LabelTextHeight Returns the label text height. 

LabelTextHeight (self, height)

Setter for property: (float) LabelTextHeight. 

LabelTextLetteringAngle (self)

Getter for property: (float) LabelTextLetteringAngle Returns the label text lettering angle. 

LabelTextLetteringAngle (self, angle)

Setter for property: (float) LabelTextLetteringAngle. 

LabelWidth (self)

Getter for property: (int) LabelWidth Returns the label width. 

LabelWidth (self, labelWidth)

Setter for property: (int) LabelWidth. 

NumberOfStartFrame (self)

Getter for property: (str) NumberOfStartFrame Returns the number of start farme. 

NumberOfStartFrame (self, strNumberOfStartFrame)

Setter for property: (str) NumberOfStartFrame. 

SkipLabelBegin (self)

Getter for property: (int) SkipLabelBegin Returns the label from which skip to be started. 

SkipLabelBegin (self, skipLabelBegin)

Setter for property: (int) SkipLabelBegin. 

SkipLabelFrequency (self)

Getter for property: (int) SkipLabelFrequency Returns the label skip frequency. 

SkipLabelFrequency (self, skipLabelFrequency)

Setter for property: (int) SkipLabelFrequency. 

SkipTicBegin (self)

Getter for property: (int) SkipTicBegin Returns the tic from which skip to be started. 

SkipTicBegin (self, skipTicBegin)

Setter for property: (int) SkipTicBegin. 

SkipTicFrequency (self)

Getter for property: (int) SkipTicFrequency Returns the tic skip frequency. 

SkipTicFrequency (self, skipTicFrequency)

Setter for property: (int) SkipTicFrequency. 

TicColor (self)

Getter for property: (int) TicColor Returns the tic color. 

TicColor (self, ticColor)

Setter for property: (int) TicColor. 

TicDisplay (self)

Getter for property: (int) TicDisplay Returns the transverse frames tic display type. 

TicDisplay (self, ticDisplay)

Setter for property: (int) TicDisplay. 

TicFont (self)

Getter for property: (int) TicFont Returns the tic font. 

TicFont (self, ticFont)

Setter for property: (int) TicFont. 

TicLabelTextOrientation (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder.LabelTextOrientation) TicLabelTextOrientation Returns the tic label text orientation type. 

TicLabelTextOrientation (self, ticLabelTextOrientation)

Setter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder.LabelTextOrientation) TicLabelTextOrientation. 

TicLength (self)

Getter for property: (float) TicLength Returns the tic length. 

TicLength (self, ticLength)

Setter for property: (float) TicLength. 

TicWidth (self)

Getter for property: (int) TicWidth Returns the tic width. 

TicWidth (self, ticWidth)

Setter for property: (int) TicWidth. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

FrameBarElementStyleBuilderLabelTextOrientation = FrameBarElementStyleBuilder.LabelTextOrientation

NXOpen.Annotations.FrameBarElementStyleBuilderLabelTextOrientation is an alias for NXOpen.Annotations.FrameBarElementStyleBuilder.LabelTextOrientation 

## Detailed Description

Represents a NXOpen::Annotations::FrameBarElementStyleBuilder . 

This class queries and sets FrameBar preferences when creating and editing FrameBar drafting annotations.

Created in NX6.0.0 

## Member Function Documentation

## ◆ DisplayPosition() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.DisplayPosition
(
self — )

Getter for property: (bool) DisplayPosition Returns the display position. 

Getter License requirements: None.

Created in NX1899.0.0 

Returns
bool 

## ◆ DisplayPosition() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.DisplayPosition
(
self,

bShow )

Setter for property: (bool) DisplayPosition. 

Sets the display position

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX1899.0.0 

## ◆ DisplayThicknessDirection() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.DisplayThicknessDirection
(
self — )

Getter for property: (bool) DisplayThicknessDirection Returns the display thickness dirction. 

Getter License requirements: None.

Created in NX1899.0.0 

Returns
bool 

## ◆ DisplayThicknessDirection() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.DisplayThicknessDirection
(
self,

bShow )

Setter for property: (bool) DisplayThicknessDirection. 

Sets the display thickness dirction

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX1899.0.0 

## ◆ ExtendedTicBegin() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.ExtendedTicBegin
(
self — )

Getter for property: (int) ExtendedTicBegin Returns the extended tic from which display to be started. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
int 

## ◆ ExtendedTicBegin() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.ExtendedTicBegin
(
self,

displayExtendBegin )

Setter for property: (int) ExtendedTicBegin. 

Sets the extended tic from which display to be started

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ ExtendedTicColor() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.ExtendedTicColor
(
self — )

Getter for property: (int) ExtendedTicColor Returns the extended tic color. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
int 

## ◆ ExtendedTicColor() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.ExtendedTicColor
(
self,

extendColor )

Setter for property: (int) ExtendedTicColor. 

Sets the extended tic color

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ ExtendedTicFont() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.ExtendedTicFont
(
self — )

Getter for property: (int) ExtendedTicFont Returns the extended tic font. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
int 

## ◆ ExtendedTicFont() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.ExtendedTicFont
(
self,

extendFont )

Setter for property: (int) ExtendedTicFont. 

Sets the extended tic font

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ ExtendedTicFrequency() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.ExtendedTicFrequency
(
self — )

Getter for property: (int) ExtendedTicFrequency Returns the extended tic display frequency. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
int 

## ◆ ExtendedTicFrequency() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.ExtendedTicFrequency
(
self,

displayExtendFrequency )

Setter for property: (int) ExtendedTicFrequency. 

Sets the extended tic display frequency

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ ExtendedTicLength() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.ExtendedTicLength
(
self — )

Getter for property: (float) ExtendedTicLength Returns the extended tic length. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
float 

## ◆ ExtendedTicLength() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.ExtendedTicLength
(
self,

extendLength )

Setter for property: (float) ExtendedTicLength. 

Sets the extended tic length

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ ExtendedTicWidth() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.ExtendedTicWidth
(
self — )

Getter for property: (int) ExtendedTicWidth Returns the extended tic width. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
int 

## ◆ ExtendedTicWidth() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.ExtendedTicWidth
(
self,

extendWidth )

Setter for property: (int) ExtendedTicWidth. 

Sets the extended tic width

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ LabelColor() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelColor
(
self — )

Getter for property: (int) LabelColor Returns the label color. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
int 

## ◆ LabelColor() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelColor
(
self,

labelColor )

Setter for property: (int) LabelColor. 

Sets the label color

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ LabelFont() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelFont
(
self — )

Getter for property: (int) LabelFont Returns the label font. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
int 

## ◆ LabelFont() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelFont
(
self,

labelFont )

Setter for property: (int) LabelFont. 

Sets the label font

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ LabelItalicized() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelItalicized
(
self — )

Getter for property: (bool) LabelItalicized Returns the label font style. 

Getter License requirements: None.

Created in NX8.5.0 

Returns
bool 

## ◆ LabelItalicized() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelItalicized
(
self,

italic )

Setter for property: (bool) LabelItalicized. 

Sets the label font style

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.5.0 

## ◆ LabelName() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelName
(
self — )

Getter for property: (int) LabelName Returns the label name. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
int 

## ◆ LabelName() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelName
(
self,

labelName )

Setter for property: (int) LabelName. 

Sets the label name

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ LabelTextAspectRatio() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelTextAspectRatio
(
self — )

Getter for property: (float) LabelTextAspectRatio Returns the label text aspect ratio. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
float 

## ◆ LabelTextAspectRatio() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelTextAspectRatio
(
self,

aspectRatio )

Setter for property: (float) LabelTextAspectRatio. 

Sets the label text aspect ratio

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ LabelTextFontGapFactor() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelTextFontGapFactor
(
self — )

Getter for property: (float) LabelTextFontGapFactor Returns the label text font gap factor. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
float 

## ◆ LabelTextFontGapFactor() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelTextFontGapFactor
(
self,

gapFactor )

Setter for property: (float) LabelTextFontGapFactor. 

Sets the label text font gap factor

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ LabelTextHeight() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelTextHeight
(
self — )

Getter for property: (float) LabelTextHeight Returns the label text height. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
float 

## ◆ LabelTextHeight() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelTextHeight
(
self,

height )

Setter for property: (float) LabelTextHeight. 

Sets the label text height

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ LabelTextLetteringAngle() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelTextLetteringAngle
(
self — )

Getter for property: (float) LabelTextLetteringAngle Returns the label text lettering angle. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
float 

## ◆ LabelTextLetteringAngle() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelTextLetteringAngle
(
self,

angle )

Setter for property: (float) LabelTextLetteringAngle. 

Sets the label text lettering angle

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ LabelWidth() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelWidth
(
self — )

Getter for property: (int) LabelWidth Returns the label width. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
int 

## ◆ LabelWidth() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.LabelWidth
(
self,

labelWidth )

Setter for property: (int) LabelWidth. 

Sets the label width

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ NumberOfStartFrame() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.NumberOfStartFrame
(
self — )

Getter for property: (str) NumberOfStartFrame Returns the number of start farme. 

Getter License requirements: None.

Created in NX1899.0.0 

Returns
str 

## ◆ NumberOfStartFrame() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.NumberOfStartFrame
(
self,

strNumberOfStartFrame )

Setter for property: (str) NumberOfStartFrame. 

Sets the number of start farme

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX1899.0.0 

## ◆ SkipLabelBegin() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.SkipLabelBegin
(
self — )

Getter for property: (int) SkipLabelBegin Returns the label from which skip to be started. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
int 

## ◆ SkipLabelBegin() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.SkipLabelBegin
(
self,

skipLabelBegin )

Setter for property: (int) SkipLabelBegin. 

Sets the label from which skip to be started

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ SkipLabelFrequency() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.SkipLabelFrequency
(
self — )

Getter for property: (int) SkipLabelFrequency Returns the label skip frequency. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
int 

## ◆ SkipLabelFrequency() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.SkipLabelFrequency
(
self,

skipLabelFrequency )

Setter for property: (int) SkipLabelFrequency. 

Sets the label skip frequency

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ SkipTicBegin() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.SkipTicBegin
(
self — )

Getter for property: (int) SkipTicBegin Returns the tic from which skip to be started. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
int 

## ◆ SkipTicBegin() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.SkipTicBegin
(
self,

skipTicBegin )

Setter for property: (int) SkipTicBegin. 

Sets the tic from which skip to be started

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ SkipTicFrequency() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.SkipTicFrequency
(
self — )

Getter for property: (int) SkipTicFrequency Returns the tic skip frequency. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
int 

## ◆ SkipTicFrequency() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.SkipTicFrequency
(
self,

skipTicFrequency )

Setter for property: (int) SkipTicFrequency. 

Sets the tic skip frequency

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ TicColor() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.TicColor
(
self — )

Getter for property: (int) TicColor Returns the tic color. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
int 

## ◆ TicColor() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.TicColor
(
self,

ticColor )

Setter for property: (int) TicColor. 

Sets the tic color

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ TicDisplay() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.TicDisplay
(
self — )

Getter for property: (int) TicDisplay Returns the transverse frames tic display type. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
int 

## ◆ TicDisplay() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.TicDisplay
(
self,

ticDisplay )

Setter for property: (int) TicDisplay. 

Sets the transverse frames tic display type

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ TicFont() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.TicFont
(
self — )

Getter for property: (int) TicFont Returns the tic font. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
int 

## ◆ TicFont() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.TicFont
(
self,

ticFont )

Setter for property: (int) TicFont. 

Sets the tic font

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ TicLabelTextOrientation() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.TicLabelTextOrientation
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder.LabelTextOrientation) TicLabelTextOrientation Returns the tic label text orientation type. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
FrameBarElementStyleBuilder.LabelTextOrientation 

## ◆ TicLabelTextOrientation() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.TicLabelTextOrientation
(
self,

ticLabelTextOrientation )

Setter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder.LabelTextOrientation) TicLabelTextOrientation. 

Sets the tic label text orientation type

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX11.0.0 

## ◆ TicLength() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.TicLength
(
self — )

Getter for property: (float) TicLength Returns the tic length. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
float 

## ◆ TicLength() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.TicLength
(
self,

ticLength )

Setter for property: (float) TicLength. 

Sets the tic length

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ TicWidth() [1/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.TicWidth
(
self — )

Getter for property: (int) TicWidth Returns the tic width. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
int 

## ◆ TicWidth() [2/2]

NXOpen.Annotations.FrameBarElementStyleBuilder.TicWidth
(
self,

ticWidth )

Setter for property: (int) TicWidth. 

Sets the tic width

Setter License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing") OR drafting ("DRAFTING")

Created in NX8.0.0 

## Member Data Documentation

## ◆ FrameBarElementStyleBuilderLabelTextOrientation

NXOpen.Annotations.FrameBarElementStyleBuilder.FrameBarElementStyleBuilderLabelTextOrientation = FrameBarElementStyleBuilder.LabelTextOrientation

NXOpen.Annotations.FrameBarElementStyleBuilderLabelTextOrientation is an alias for NXOpen.Annotations.FrameBarElementStyleBuilder.LabelTextOrientation 

Copyright 2025 Siemens
