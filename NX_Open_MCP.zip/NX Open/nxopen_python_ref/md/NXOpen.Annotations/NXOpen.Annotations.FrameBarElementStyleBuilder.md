# NXOpen.Annotations.FrameBarElementStyleBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00162.html>

## Classes

class — LabelTextOrientation

the Label text orientation 

Enumerator — Comment

AlongTic — Along Tic

PerpendicularToTic — Perpendicular To Tic

More...

Copyright 2025 Siemens
