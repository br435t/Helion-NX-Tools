# NXOpen.Annotations.BaseApplicationStyleBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11241.html>

Represents a NXOpen::Annotations::BaseApplicationStyleBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.BaseApplicationStyleBuilder:

## Additional Inherited Members

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::BaseApplicationStyleBuilder . 

Created in NX2506.0.0 

Copyright 2025 Siemens
