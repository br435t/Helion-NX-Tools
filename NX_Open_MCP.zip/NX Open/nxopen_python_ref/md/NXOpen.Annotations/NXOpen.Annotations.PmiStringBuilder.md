# NXOpen.Annotations.PmiStringBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13829.html>

Represents a NXOpen::Annotations::PmiString builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiStringBuilder 

More...

Inheritance diagram for NXOpen.Annotations.PmiStringBuilder:

## Public Member Functions

StringValue (self)

Getter for property: (str) StringValue Returns the str value. 

StringValue (self, stringValue)

Setter for property: (str) StringValue. 

Title (self)

Getter for property: (str) Title Returns the str title. 

Title (self, title)

Setter for property: (str) Title. 

Public Member Functions inherited from NXOpen.Annotations.PmiAttributeBuilder

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the NXOpen::Annotations::AssociatedObjectsBuilder for the annotation. 

Attribute (self)

Getter for property: (NXOpen.Annotations.Pmi) Attribute Returns the NXOpen::Annotations::Pmi for this annotation. 

Attribute (self, attribute)

Setter for property: (NXOpen.Annotations.Pmi) Attribute. 

BusinessModifier (self)

Getter for property: (NXOpen.NXObject) BusinessModifier Returns the business modifier. 

BusinessModifier (self, businessModifier)

Setter for property: (NXOpen.NXObject) BusinessModifier. 

GetAttributeValues (self)

Returns the attribute values. 

KnowledgeFusionClassName (self)

Getter for property: (str) KnowledgeFusionClassName Returns the knowledge fusion class name file, the default class is UG provided pmi KF class. 

KnowledgeFusionClassName (self, knowledgeFusionClassName)

Setter for property: (str) KnowledgeFusionClassName. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the NXOpen::Annotations::OriginBuilder for the annotation. 

SetAttributeValues (self, attributeValues)

Sets the attribute values. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the NXOpen::Annotations::StyleBuilder for the annotation. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::PmiString builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiStringBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ StringValue() [1/2]

NXOpen.Annotations.PmiStringBuilder.StringValue
(
self — )

Getter for property: (str) StringValue Returns the str value. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ StringValue() [2/2]

NXOpen.Annotations.PmiStringBuilder.StringValue
(
self,

stringValue )

Setter for property: (str) StringValue. 

Sets the str value

Setter License requirements: None.

Created in NX6.0.0 

## ◆ Title() [1/2]

NXOpen.Annotations.PmiStringBuilder.Title
(
self — )

Getter for property: (str) Title Returns the str title. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Title() [2/2]

NXOpen.Annotations.PmiStringBuilder.Title
(
self,

title )

Setter for property: (str) Title. 

Sets the str title

Setter License requirements: None.

Created in NX6.0.0 

Copyright 2025 Siemens
