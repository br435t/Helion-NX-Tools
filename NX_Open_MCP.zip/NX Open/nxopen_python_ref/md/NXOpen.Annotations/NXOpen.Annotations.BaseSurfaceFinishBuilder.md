# NXOpen.Annotations.BaseSurfaceFinishBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00135.html>

## Classes

class — ParanthesesType

the valid parantheses types. More...

class — ParenthesesType

the valid parentheses types 

Enumerator — Comment

NotSet — None

Left — Left

Right — Right

Both — Both

More...

class — ToleranceOption

the valid surface finish tolerance types 

Enumerator — Comment

NotSet — No tolerance

EqualBilateral — Equal bilateral

Bilateral — Bilateral

UnilateralPlus — Unilateral plus

UnilateralMinus — Unilateral minus

PlusLimitTwoLines — Plus limit two lines

MinusLimitTwoLines — Minus limit two lines

PlusLimitOneLine — Plus limit one line

MinusLimitOneLine — Minus limit one line

More...

Copyright 2025 Siemens
