# NXOpen.Annotations.OffsetCenterPointBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13021.html>

Represents a NXOpen::Annotations::OffsetCenterPoint builder 

To create a new instance of this class, use NXOpen::Annotations::OffsetCenterPointCollection::CreateOffsetCenterPointBuilder 

Default values. 
More...

Inheritance diagram for NXOpen.Annotations.OffsetCenterPointBuilder:

## Public Member Functions

CenterCross (self)

Getter for property: (float) CenterCross Returns the center cross size. 

CenterCross (self, centerCross)

Setter for property: (float) CenterCross. 

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

DisplayStyle (self)

Getter for property: (NXOpen.Annotations.OffsetCenterPointBuilder.Display) DisplayStyle Returns the display style. 

DisplayStyle (self, display)

Setter for property: (NXOpen.Annotations.OffsetCenterPointBuilder.Display) DisplayStyle. 

Distance (self)

Getter for property: (float) Distance Returns the offset distance, valid for all offset method types except those by position. 

Distance (self, distance)

Setter for property: (float) Distance. 

Extension (self)

Getter for property: (float) Extension Returns the extension. 

Extension (self, extension)

Setter for property: (float) Extension. 

Gap (self)

Getter for property: (float) Gap Returns the gap. 

Gap (self, gap)

Setter for property: (float) Gap. 

Inherit (self)

Getter for property: (NXOpen.SelectNXObject) Inherit Returns the inherit. 

Location (self)

Getter for property: (NXOpen.SelectNXObject) Location Returns the location. 

OffsetMethod (self)

Getter for property: (NXOpen.Annotations.OffsetCenterPointBuilder.Offset) OffsetMethod Returns the offset method. 

OffsetMethod (self, offsetMethod)

Setter for property: (NXOpen.Annotations.OffsetCenterPointBuilder.Offset) OffsetMethod. 

OffsetPosition (self)

Getter for property: (NXOpen.Point3d) OffsetPosition Returns the offset position, valid for position offset methods. 

OffsetPosition (self, point)

Setter for property: (NXOpen.Point3d) OffsetPosition. 

Width (self)

Getter for property: (NXOpen.Annotations.OffsetCenterPointBuilder.Thickness) Width Returns the width. 

Width (self, width)

Setter for property: (NXOpen.Annotations.OffsetCenterPointBuilder.Thickness) Width. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

OffsetCenterPointBuilderDisplay = OffsetCenterPointBuilder.Display

NXOpen.Annotations.OffsetCenterPointBuilderDisplay is an alias for NXOpen.Annotations.OffsetCenterPointBuilder.Display 

OffsetCenterPointBuilderOffset = OffsetCenterPointBuilder.Offset

NXOpen.Annotations.OffsetCenterPointBuilderOffset is an alias for NXOpen.Annotations.OffsetCenterPointBuilder.Offset 

OffsetCenterPointBuilderThickness = OffsetCenterPointBuilder.Thickness

NXOpen.Annotations.OffsetCenterPointBuilderThickness is an alias for NXOpen.Annotations.OffsetCenterPointBuilder.Thickness 

## Detailed Description

Represents a NXOpen::Annotations::OffsetCenterPoint builder 

To create a new instance of this class, use NXOpen::Annotations::OffsetCenterPointCollection::CreateOffsetCenterPointBuilder 

Default values. 

Property — Value

CenterCross 

3.175 (millimeters part), 0.125 (inches part) 

DisplayStyle 

CenterPoint 

Distance 

0 

Extension 

6.35 (millimeters part), 0.25 (inches part) 

Gap 

1.5875 (millimeters part), 0.0625 (inches part) 

OffsetMethod 

HorizontalDistanceFromArc 

Width 

Thin 

Created in NX6.0.0 

## Member Function Documentation

## ◆ CenterCross() [1/2]

NXOpen.Annotations.OffsetCenterPointBuilder.CenterCross
(
self — )

Getter for property: (float) CenterCross Returns the center cross size. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ CenterCross() [2/2]

NXOpen.Annotations.OffsetCenterPointBuilder.CenterCross
(
self,

centerCross )

Setter for property: (float) CenterCross. 

Sets the center cross size

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ Color() [1/2]

NXOpen.Annotations.OffsetCenterPointBuilder.Color
(
self — )

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.NXColor 

## ◆ Color() [2/2]

NXOpen.Annotations.OffsetCenterPointBuilder.Color
(
self,

color )

Setter for property: (NXOpen.NXColor) Color. 

Sets the color

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DisplayStyle() [1/2]

NXOpen.Annotations.OffsetCenterPointBuilder.DisplayStyle
(
self — )

Getter for property: (NXOpen.Annotations.OffsetCenterPointBuilder.Display) DisplayStyle Returns the display style. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
OffsetCenterPointBuilder.Display 

## ◆ DisplayStyle() [2/2]

NXOpen.Annotations.OffsetCenterPointBuilder.DisplayStyle
(
self,

display )

Setter for property: (NXOpen.Annotations.OffsetCenterPointBuilder.Display) DisplayStyle. 

Sets the display style

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ Distance() [1/2]

NXOpen.Annotations.OffsetCenterPointBuilder.Distance
(
self — )

Getter for property: (float) Distance Returns the offset distance, valid for all offset method types except those by position. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ Distance() [2/2]

NXOpen.Annotations.OffsetCenterPointBuilder.Distance
(
self,

distance )

Setter for property: (float) Distance. 

Sets the offset distance, valid for all offset method types except those by position

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ Extension() [1/2]

NXOpen.Annotations.OffsetCenterPointBuilder.Extension
(
self — )

Getter for property: (float) Extension Returns the extension. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ Extension() [2/2]

NXOpen.Annotations.OffsetCenterPointBuilder.Extension
(
self,

extension )

Setter for property: (float) Extension. 

Sets the extension

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ Gap() [1/2]

NXOpen.Annotations.OffsetCenterPointBuilder.Gap
(
self — )

Getter for property: (float) Gap Returns the gap. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ Gap() [2/2]

NXOpen.Annotations.OffsetCenterPointBuilder.Gap
(
self,

gap )

Setter for property: (float) Gap. 

Sets the gap

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ Inherit()

NXOpen.Annotations.OffsetCenterPointBuilder.Inherit
(
self — )

Getter for property: (NXOpen.SelectNXObject) Inherit Returns the inherit. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ Location()

NXOpen.Annotations.OffsetCenterPointBuilder.Location
(
self — )

Getter for property: (NXOpen.SelectNXObject) Location Returns the location. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ OffsetMethod() [1/2]

NXOpen.Annotations.OffsetCenterPointBuilder.OffsetMethod
(
self — )

Getter for property: (NXOpen.Annotations.OffsetCenterPointBuilder.Offset) OffsetMethod Returns the offset method. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
OffsetCenterPointBuilder.Offset 

## ◆ OffsetMethod() [2/2]

NXOpen.Annotations.OffsetCenterPointBuilder.OffsetMethod
(
self,

offsetMethod )

Setter for property: (NXOpen.Annotations.OffsetCenterPointBuilder.Offset) OffsetMethod. 

Sets the offset method

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ OffsetPosition() [1/2]

NXOpen.Annotations.OffsetCenterPointBuilder.OffsetPosition
(
self — )

Getter for property: (NXOpen.Point3d) OffsetPosition Returns the offset position, valid for position offset methods. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.Point3d 

## ◆ OffsetPosition() [2/2]

NXOpen.Annotations.OffsetCenterPointBuilder.OffsetPosition
(
self,

point )

Setter for property: (NXOpen.Point3d) OffsetPosition. 

Sets the offset position, valid for position offset methods

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ Width() [1/2]

NXOpen.Annotations.OffsetCenterPointBuilder.Width
(
self — )

Getter for property: (NXOpen.Annotations.OffsetCenterPointBuilder.Thickness) Width Returns the width. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
OffsetCenterPointBuilder.Thickness 

## ◆ Width() [2/2]

NXOpen.Annotations.OffsetCenterPointBuilder.Width
(
self,

width )

Setter for property: (NXOpen.Annotations.OffsetCenterPointBuilder.Thickness) Width. 

Sets the width

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## Member Data Documentation

## ◆ OffsetCenterPointBuilderDisplay

NXOpen.Annotations.OffsetCenterPointBuilder.OffsetCenterPointBuilderDisplay = OffsetCenterPointBuilder.Display

NXOpen.Annotations.OffsetCenterPointBuilderDisplay is an alias for NXOpen.Annotations.OffsetCenterPointBuilder.Display 

## ◆ OffsetCenterPointBuilderOffset

NXOpen.Annotations.OffsetCenterPointBuilder.OffsetCenterPointBuilderOffset = OffsetCenterPointBuilder.Offset

NXOpen.Annotations.OffsetCenterPointBuilderOffset is an alias for NXOpen.Annotations.OffsetCenterPointBuilder.Offset 

## ◆ OffsetCenterPointBuilderThickness

NXOpen.Annotations.OffsetCenterPointBuilder.OffsetCenterPointBuilderThickness = OffsetCenterPointBuilder.Thickness

NXOpen.Annotations.OffsetCenterPointBuilderThickness is an alias for NXOpen.Annotations.OffsetCenterPointBuilder.Thickness 

Copyright 2025 Siemens
