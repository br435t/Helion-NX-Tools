# NXOpen.Annotations.Annotation Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00126.html>

## Classes

class — AssociativeOriginData

Describes the geometry that an annotation's origin is associated with NXOpen.Annotations.AnnotationAssociativeOriginData_Struct is an alias for NXOpen.Annotations.Annotation.AssociativeOriginData. More...

Copyright 2025 Siemens
