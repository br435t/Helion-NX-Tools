# NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00161.html>

## Classes

class — MethodType

Represents foreshortening symbol method type 

Enumerator — Comment

WidthAndAngle

WidthAndHeight

More...

class — SymbolType

Represents foreshortening symbol type 

Enumerator — Comment

Regular

Stretched

More...

Copyright 2025 Siemens
