# NXOpen.Annotations.HoleTableSettingsFormatBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00167.html>

## Classes

class — DeletedHolesDisplayType

Represents Deleted Holes Display options 

Enumerator — Comment

Strikethrough — Strikethrough

HideText — HideText

Remove — Remove

More...

class — DepthMeasurementDatumType

Represents Depth Measurement Datum options 

Enumerator — Comment

TopBottomFace

BaseFace

StepFace

More...

class — ShowColumnsType

Represents Show Columns options 

Enumerator — Comment

Xy — X and Y

Xyz — X, Y and Z

All — All

More...

class — SizeFormatType

Represents Size Format options 

Enumerator — Comment

DisplayInSummaryRows — Display in Summary Rows

DisplayInColumn — Display in Column

More...

Copyright 2025 Siemens
