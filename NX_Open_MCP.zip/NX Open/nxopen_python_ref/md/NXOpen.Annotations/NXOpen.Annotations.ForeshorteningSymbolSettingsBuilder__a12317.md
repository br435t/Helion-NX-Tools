# NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12317.html>

Represents a NXOpen::Annotations::ForeshorteningSymbolSettingsBuilder builder. 
More...

Inheritance diagram for NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder:

## Public Member Functions

Angle (self)

Getter for property: (float) Angle Returns the foreshortening symbol angle. 

Angle (self, foreshorteningSymbolAngle)

Setter for property: (float) Angle. 

ForeshorteningSymbolMethodType (self)

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.MethodType) ForeshorteningSymbolMethodType Returns the foreshortening symbol method. 

ForeshorteningSymbolMethodType (self, foreshorteningSymbolMethod)

Setter for property: (NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.MethodType) ForeshorteningSymbolMethodType. 

ForeshorteningSymbolType (self)

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.SymbolType) ForeshorteningSymbolType Returns the foreshortening symbol type. 

ForeshorteningSymbolType (self, foreshorteningSymbolType)

Setter for property: (NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.SymbolType) ForeshorteningSymbolType. 

Height (self)

Getter for property: (float) Height Returns the foreshortening symbol height. 

Height (self, foreshorteningSymbolHeight)

Setter for property: (float) Height. 

Width (self)

Getter for property: (float) Width Returns the foreshortening symbol width. 

Width (self, foreshorteningSymbolWidth)

Setter for property: (float) Width. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

ForeshorteningSymbolSettingsBuilderMethodType = ForeshorteningSymbolSettingsBuilder.MethodType

NXOpen.Annotations.ForeshorteningSymbolSettingsBuilderMethodType is an alias for NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.MethodType 

ForeshorteningSymbolSettingsBuilderSymbolType = ForeshorteningSymbolSettingsBuilder.SymbolType

NXOpen.Annotations.ForeshorteningSymbolSettingsBuilderSymbolType is an alias for NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.SymbolType 

## Detailed Description

Represents a NXOpen::Annotations::ForeshorteningSymbolSettingsBuilder builder. 

Created in NX10.0.0 

## Member Function Documentation

## ◆ Angle() [1/2]

NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.Angle
(
self — )

Getter for property: (float) Angle Returns the foreshortening symbol angle. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
float 

## ◆ Angle() [2/2]

NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.Angle
(
self,

foreshorteningSymbolAngle )

Setter for property: (float) Angle. 

Sets the foreshortening symbol angle

Setter License requirements: drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ ForeshorteningSymbolMethodType() [1/2]

NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.ForeshorteningSymbolMethodType
(
self — )

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.MethodType) ForeshorteningSymbolMethodType Returns the foreshortening symbol method. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
ForeshorteningSymbolSettingsBuilder.MethodType 

## ◆ ForeshorteningSymbolMethodType() [2/2]

NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.ForeshorteningSymbolMethodType
(
self,

foreshorteningSymbolMethod )

Setter for property: (NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.MethodType) ForeshorteningSymbolMethodType. 

Sets the foreshortening symbol method

Setter License requirements: drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ ForeshorteningSymbolType() [1/2]

NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.ForeshorteningSymbolType
(
self — )

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.SymbolType) ForeshorteningSymbolType Returns the foreshortening symbol type. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
ForeshorteningSymbolSettingsBuilder.SymbolType 

## ◆ ForeshorteningSymbolType() [2/2]

NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.ForeshorteningSymbolType
(
self,

foreshorteningSymbolType )

Setter for property: (NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.SymbolType) ForeshorteningSymbolType. 

Sets the foreshortening symbol type

Setter License requirements: drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ Height() [1/2]

NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.Height
(
self — )

Getter for property: (float) Height Returns the foreshortening symbol height. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
float 

## ◆ Height() [2/2]

NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.Height
(
self,

foreshorteningSymbolHeight )

Setter for property: (float) Height. 

Sets the foreshortening symbol height

Setter License requirements: drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ Width() [1/2]

NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.Width
(
self — )

Getter for property: (float) Width Returns the foreshortening symbol width. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
float 

## ◆ Width() [2/2]

NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.Width
(
self,

foreshorteningSymbolWidth )

Setter for property: (float) Width. 

Sets the foreshortening symbol width

Setter License requirements: drafting ("DRAFTING")

Created in NX10.0.0 

## Member Data Documentation

## ◆ ForeshorteningSymbolSettingsBuilderMethodType

NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.ForeshorteningSymbolSettingsBuilderMethodType = ForeshorteningSymbolSettingsBuilder.MethodType

NXOpen.Annotations.ForeshorteningSymbolSettingsBuilderMethodType is an alias for NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.MethodType 

## ◆ ForeshorteningSymbolSettingsBuilderSymbolType

NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.ForeshorteningSymbolSettingsBuilderSymbolType = ForeshorteningSymbolSettingsBuilder.SymbolType

NXOpen.Annotations.ForeshorteningSymbolSettingsBuilderSymbolType is an alias for NXOpen.Annotations.ForeshorteningSymbolSettingsBuilder.SymbolType 

Copyright 2025 Siemens
