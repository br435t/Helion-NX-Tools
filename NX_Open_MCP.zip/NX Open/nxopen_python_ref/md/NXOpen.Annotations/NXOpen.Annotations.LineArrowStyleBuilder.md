# NXOpen.Annotations.LineArrowStyleBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12829.html>

Represents a NXOpen::Annotations::LineArrowStyleBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.LineArrowStyleBuilder:

## Public Member Functions

AllAroundSymbolSize (self)

Getter for property: (float) AllAroundSymbolSize Returns the size of all around symbol. 

AllAroundSymbolSize (self, allAroundSymbol)

Setter for property: (float) AllAroundSymbolSize. 

ArrowheadIncludedAngle (self)

Getter for property: (float) ArrowheadIncludedAngle Returns the arrowhead included angle. 

ArrowheadIncludedAngle (self, arrowheadIncludedAngle)

Setter for property: (float) ArrowheadIncludedAngle. 

ArrowheadLength (self)

Getter for property: (float) ArrowheadLength Returns the arrowhead length. 

ArrowheadLength (self, arrowheadLength)

Setter for property: (float) ArrowheadLength. 

BalloonLeaderArrowHeadType (self)

Getter for property: (NXOpen.Annotations.ArrowheadType) BalloonLeaderArrowHeadType Returns the balloon arrow head type. 

BalloonLeaderArrowHeadType (self, balloonArrowheadType)

Setter for property: (NXOpen.Annotations.ArrowheadType) BalloonLeaderArrowHeadType. 

ClipOrdinateDimensionLine (self)

Getter for property: (bool) ClipOrdinateDimensionLine Returns the clipping of the dimension line to the ordinate origin at the view border. 

ClipOrdinateDimensionLine (self, clipOrdinateDimLine)

Setter for property: (bool) ClipOrdinateDimensionLine. 

DatumLengthPastArrow (self)

Getter for property: (float) DatumLengthPastArrow Returns the distance from the apex of the datum arrowhead to the end of the extension line. 

DatumLengthPastArrow (self, datumLengthPastArrow)

Setter for property: (float) DatumLengthPastArrow. 

DotArrowheadDiameter (self)

Getter for property: (float) DotArrowheadDiameter Returns the dot arrowhead diameter. 

DotArrowheadDiameter (self, dotArrowheadDiameter)

Setter for property: (float) DotArrowheadDiameter. 

FirstArrowheadColor (self)

Getter for property: (NXOpen.NXColor) FirstArrowheadColor Returns the first arrowhead color. 

FirstArrowheadColor (self, firstArrowheadColor)

Setter for property: (NXOpen.NXColor) FirstArrowheadColor. 

FirstArrowheadFont (self)

Getter for property: (NXOpen.DisplayableObject.ObjectFont) FirstArrowheadFont Returns the first arrowhead font. 

FirstArrowheadFont (self, firstArrowheadFont)

Setter for property: (NXOpen.DisplayableObject.ObjectFont) FirstArrowheadFont. 

FirstArrowheadWidth (self)

Getter for property: (NXOpen.Annotations.LineWidth) FirstArrowheadWidth Returns the first arrowhead width. 

FirstArrowheadWidth (self, firstArrowheadWidth)

Setter for property: (NXOpen.Annotations.LineWidth) FirstArrowheadWidth. 

FirstArrowLineColor (self)

Getter for property: (NXOpen.NXColor) FirstArrowLineColor Returns the first arrow line color. 

FirstArrowLineColor (self, firstArrowLineColor)

Setter for property: (NXOpen.NXColor) FirstArrowLineColor. 

FirstArrowLineFont (self)

Getter for property: (NXOpen.DisplayableObject.ObjectFont) FirstArrowLineFont Returns the first arrow line font. 

FirstArrowLineFont (self, firstArrowLineFont)

Setter for property: (NXOpen.DisplayableObject.ObjectFont) FirstArrowLineFont. 

FirstArrowLineWidth (self)

Getter for property: (NXOpen.Annotations.LineWidth) FirstArrowLineWidth Returns the first arrow line width. 

FirstArrowLineWidth (self, firstArrowLineWidth)

Setter for property: (NXOpen.Annotations.LineWidth) FirstArrowLineWidth. 

FirstArrowType (self)

Getter for property: (NXOpen.Annotations.ArrowheadType) FirstArrowType Returns the first arrowhead type. 

FirstArrowType (self, firstArrowType)

Setter for property: (NXOpen.Annotations.ArrowheadType) FirstArrowType. 

FirstExtensionLineColor (self)

Getter for property: (NXOpen.NXColor) FirstExtensionLineColor Returns the first extension line color. 

FirstExtensionLineColor (self, firstExtensionLineColor)

Setter for property: (NXOpen.NXColor) FirstExtensionLineColor. 

FirstExtensionLineFont (self)

Getter for property: (NXOpen.DisplayableObject.ObjectFont) FirstExtensionLineFont Returns the first extension line font. 

FirstExtensionLineFont (self, firstExtensionLineFont)

Setter for property: (NXOpen.DisplayableObject.ObjectFont) FirstExtensionLineFont. 

FirstExtensionLineWidth (self)

Getter for property: (NXOpen.Annotations.LineWidth) FirstExtensionLineWidth Returns the first extension line width. 

FirstExtensionLineWidth (self, firstExtensionLineWidth)

Setter for property: (NXOpen.Annotations.LineWidth) FirstExtensionLineWidth. 

FirstJogAngle (self)

Getter for property: (float) FirstJogAngle Returns the first jog angle, between the jog and the extension line, in degrees. 

FirstJogAngle (self, jogAngle)

Setter for property: (float) FirstJogAngle. 

FirstJogDisplay (self)

Getter for property: (bool) FirstJogDisplay Returns the first jog's display flag, if true, the first jog will be displayed, false otherwise. 

FirstJogDisplay (self, jogDisplay)

Setter for property: (bool) FirstJogDisplay. 

FirstJogEndOffset (self)

Getter for property: (float) FirstJogEndOffset Returns the first jog end offset from the dimension line. 

FirstJogEndOffset (self, jogEndOffset)

Setter for property: (float) FirstJogEndOffset. 

FirstJogOrientation (self)

Getter for property: (NXOpen.Annotations.JogOrientation) FirstJogOrientation Returns the first jog orientation, can be either IN or OUT. 

FirstJogOrientation (self, jogOrientation)

Setter for property: (NXOpen.Annotations.JogOrientation) FirstJogOrientation. 

FirstJogStartOffset (self)

Getter for property: (float) FirstJogStartOffset Returns the first jog start offset from the dimension line. 

FirstJogStartOffset (self, jogStartOffset)

Setter for property: (float) FirstJogStartOffset. 

FirstPosToExtensionLineDistance (self)

Getter for property: (float) FirstPosToExtensionLineDistance Returns the distance from the position on the object being dimensioned to the end of the first extension line or arc. 

FirstPosToExtensionLineDistance (self, firstPosToExtensionLineDistance)

Setter for property: (float) FirstPosToExtensionLineDistance. 

LeaderLocation (self)

Getter for property: (NXOpen.Annotations.VerticalTextJustification) LeaderLocation Returns the leader location. 

LeaderLocation (self, leaderLocation)

Setter for property: (NXOpen.Annotations.VerticalTextJustification) LeaderLocation. 

LeaderOrientation (self)

Getter for property: (NXOpen.Annotations.LeaderSide) LeaderOrientation Returns the leader orientation. 

LeaderOrientation (self, leaderOrientation)

Setter for property: (NXOpen.Annotations.LeaderSide) LeaderOrientation. 

LinePastArrowDistance (self)

Getter for property: (float) LinePastArrowDistance Returns the distance an extension line or arc extends past the dimension line or arc. 

LinePastArrowDistance (self, linePastArrowDistance)

Setter for property: (float) LinePastArrowDistance. 

LinePastArrowDistance2 (self)

Getter for property: (float) LinePastArrowDistance2 Returns the second distance an extension line or arc extends past the dimension line or arc. 

LinePastArrowDistance2 (self, linePastArrowDistance)

Setter for property: (float) LinePastArrowDistance2. 

ObliqueExtensionLineAngle (self)

Getter for property: (float) ObliqueExtensionLineAngle Returns the extension line angle. 

ObliqueExtensionLineAngle (self, obliqueExtensionLineAngle)

Setter for property: (float) ObliqueExtensionLineAngle. 

SecondArrowheadColor (self)

Getter for property: (NXOpen.NXColor) SecondArrowheadColor Returns the second arrowhead color. 

SecondArrowheadColor (self, secondArrowheadColor)

Setter for property: (NXOpen.NXColor) SecondArrowheadColor. 

SecondArrowheadFont (self)

Getter for property: (NXOpen.DisplayableObject.ObjectFont) SecondArrowheadFont Returns the second arrowhead font. 

SecondArrowheadFont (self, secondArrowheadFont)

Setter for property: (NXOpen.DisplayableObject.ObjectFont) SecondArrowheadFont. 

SecondArrowheadWidth (self)

Getter for property: (NXOpen.Annotations.LineWidth) SecondArrowheadWidth Returns the second arrowhead width. 

SecondArrowheadWidth (self, secondArrowheadWidth)

Setter for property: (NXOpen.Annotations.LineWidth) SecondArrowheadWidth. 

SecondArrowLineColor (self)

Getter for property: (NXOpen.NXColor) SecondArrowLineColor Returns the second arrow line color. 

SecondArrowLineColor (self, secondArrowLineColor)

Setter for property: (NXOpen.NXColor) SecondArrowLineColor. 

SecondArrowLineFont (self)

Getter for property: (NXOpen.DisplayableObject.ObjectFont) SecondArrowLineFont Returns the second arrow line font. 

SecondArrowLineFont (self, secondArrowLineFont)

Setter for property: (NXOpen.DisplayableObject.ObjectFont) SecondArrowLineFont. 

SecondArrowLineWidth (self)

Getter for property: (NXOpen.Annotations.LineWidth) SecondArrowLineWidth Returns the second arrow line width. 

SecondArrowLineWidth (self, secondArrowLineWidth)

Setter for property: (NXOpen.Annotations.LineWidth) SecondArrowLineWidth. 

SecondArrowType (self)

Getter for property: (NXOpen.Annotations.ArrowheadType) SecondArrowType Returns the second arrowhead type. 

SecondArrowType (self, secondArrowType)

Setter for property: (NXOpen.Annotations.ArrowheadType) SecondArrowType. 

SecondExtensionLineColor (self)

Getter for property: (NXOpen.NXColor) SecondExtensionLineColor Returns the second extension line color. 

SecondExtensionLineColor (self, secondExtensionLineColor)

Setter for property: (NXOpen.NXColor) SecondExtensionLineColor. 

SecondExtensionLineFont (self)

Getter for property: (NXOpen.DisplayableObject.ObjectFont) SecondExtensionLineFont Returns the second extension line font. 

SecondExtensionLineFont (self, secondExtensionLineFont)

Setter for property: (NXOpen.DisplayableObject.ObjectFont) SecondExtensionLineFont. 

SecondExtensionLineWidth (self)

Getter for property: (NXOpen.Annotations.LineWidth) SecondExtensionLineWidth Returns the second extension line width. 

SecondExtensionLineWidth (self, secondExtensionLineWidth)

Setter for property: (NXOpen.Annotations.LineWidth) SecondExtensionLineWidth. 

SecondJogAngle (self)

Getter for property: (float) SecondJogAngle Returns the second jog angle, between the jog and the extension line, in degrees. 

SecondJogAngle (self, jogAngle)

Setter for property: (float) SecondJogAngle. 

SecondJogDisplay (self)

Getter for property: (bool) SecondJogDisplay Returns the second jog's display flag, if true, the second jog will be displayed, false otherwise. 

SecondJogDisplay (self, jogDisplay)

Setter for property: (bool) SecondJogDisplay. 

SecondJogEndOffset (self)

Getter for property: (float) SecondJogEndOffset Returns the second jog end offset from the dimension line. 

SecondJogEndOffset (self, jogEndOffset)

Setter for property: (float) SecondJogEndOffset. 

SecondJogOrientation (self)

Getter for property: (NXOpen.Annotations.JogOrientation) SecondJogOrientation Returns the second jog orientation, can be either IN or OUT. 

SecondJogOrientation (self, jogOrientation)

Setter for property: (NXOpen.Annotations.JogOrientation) SecondJogOrientation. 

SecondJogStartOffset (self)

Getter for property: (float) SecondJogStartOffset Returns the second jog start offset from the dimension line. 

SecondJogStartOffset (self, jogStartOffset)

Setter for property: (float) SecondJogStartOffset. 

SecondPosToExtensionLineDistance (self)

Getter for property: (float) SecondPosToExtensionLineDistance Returns the distance from the position on the object being dimensioned to the end of the second extension line. 

SecondPosToExtensionLineDistance (self, secondPosToExtensionLineDistance)

Setter for property: (float) SecondPosToExtensionLineDistance. 

StubLength (self)

Getter for property: (float) StubLength Returns the stub length. 

StubLength (self, stubLength)

Setter for property: (float) StubLength. 

StubSymbolType (self)

Getter for property: (NXOpen.Annotations.StubSymbolType) StubSymbolType Returns the stub symbol type. 

StubSymbolType (self, stubSymbolType)

Setter for property: (NXOpen.Annotations.StubSymbolType) StubSymbolType. 

TextOverLeaderGapFactor (self)

Getter for property: (float) TextOverLeaderGapFactor Returns the character size factor that controls the gap between text and the leader. 

TextOverLeaderGapFactor (self, textOverLeaderGapFactor)

Setter for property: (float) TextOverLeaderGapFactor. 

TextOverStubFactor (self)

Getter for property: (float) TextOverStubFactor Returns the character size factor which controls the distance between the stub and label text when the text displays above the stub line. 

TextOverStubFactor (self, textOverStubFactor)

Setter for property: (float) TextOverStubFactor. 

TextToLineDistance (self)

Getter for property: (float) TextToLineDistance Returns the distance from the text to the dimension line(stub) or arc. 

TextToLineDistance (self, textToLineDistance)

Setter for property: (float) TextToLineDistance. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::LineArrowStyleBuilder . 

This class queries and sets preferences that apply to leaders and arrow and extension lines when creating or editing annotations, including dimensions.

Created in NX6.0.0 

## Member Function Documentation

## ◆ AllAroundSymbolSize() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.AllAroundSymbolSize
(
self — )

Getter for property: (float) AllAroundSymbolSize Returns the size of all around symbol. 

This is also used for inner diameter of all over symbol

Getter License requirements: None.

Created in NX8.5.0 

Returns
float 

## ◆ AllAroundSymbolSize() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.AllAroundSymbolSize
(
self,

allAroundSymbol )

Setter for property: (float) AllAroundSymbolSize. 

Sets the size of all around symbol. This is also used for inner diameter of all over symbol

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX8.5.0 

## ◆ ArrowheadIncludedAngle() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.ArrowheadIncludedAngle
(
self — )

Getter for property: (float) ArrowheadIncludedAngle Returns the arrowhead included angle. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ ArrowheadIncludedAngle() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.ArrowheadIncludedAngle
(
self,

arrowheadIncludedAngle )

Setter for property: (float) ArrowheadIncludedAngle. 

Sets the arrowhead included angle

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ ArrowheadLength() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.ArrowheadLength
(
self — )

Getter for property: (float) ArrowheadLength Returns the arrowhead length. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ ArrowheadLength() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.ArrowheadLength
(
self,

arrowheadLength )

Setter for property: (float) ArrowheadLength. 

Sets the arrowhead length

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ BalloonLeaderArrowHeadType() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.BalloonLeaderArrowHeadType
(
self — )

Getter for property: (NXOpen.Annotations.ArrowheadType) BalloonLeaderArrowHeadType Returns the balloon arrow head type. 

This property should not be used in object settings, instead use NXOpen::Annotations::LineArrowStyleBuilder::FirstArrowType .

Getter License requirements: None.

Created in NX1847.0.0 

Returns
ArrowheadType 

## ◆ BalloonLeaderArrowHeadType() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.BalloonLeaderArrowHeadType
(
self,

balloonArrowheadType )

Setter for property: (NXOpen.Annotations.ArrowheadType) BalloonLeaderArrowHeadType. 

Sets the balloon arrow head type.

This property should not be used in object settings, instead use NXOpen::Annotations::LineArrowStyleBuilder::FirstArrowType .

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX1847.0.0 

## ◆ ClipOrdinateDimensionLine() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.ClipOrdinateDimensionLine
(
self — )

Getter for property: (bool) ClipOrdinateDimensionLine Returns the clipping of the dimension line to the ordinate origin at the view border. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
bool 

## ◆ ClipOrdinateDimensionLine() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.ClipOrdinateDimensionLine
(
self,

clipOrdinateDimLine )

Setter for property: (bool) ClipOrdinateDimensionLine. 

Sets the clipping of the dimension line to the ordinate origin at the view border

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ DatumLengthPastArrow() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.DatumLengthPastArrow
(
self — )

Getter for property: (float) DatumLengthPastArrow Returns the distance from the apex of the datum arrowhead to the end of the extension line. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ DatumLengthPastArrow() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.DatumLengthPastArrow
(
self,

datumLengthPastArrow )

Setter for property: (float) DatumLengthPastArrow. 

Sets the distance from the apex of the datum arrowhead to the end of the extension line

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DotArrowheadDiameter() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.DotArrowheadDiameter
(
self — )

Getter for property: (float) DotArrowheadDiameter Returns the dot arrowhead diameter. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ DotArrowheadDiameter() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.DotArrowheadDiameter
(
self,

dotArrowheadDiameter )

Setter for property: (float) DotArrowheadDiameter. 

Sets the dot arrowhead diameter

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ FirstArrowheadColor() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstArrowheadColor
(
self — )

Getter for property: (NXOpen.NXColor) FirstArrowheadColor Returns the first arrowhead color. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.NXColor 

## ◆ FirstArrowheadColor() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstArrowheadColor
(
self,

firstArrowheadColor )

Setter for property: (NXOpen.NXColor) FirstArrowheadColor. 

Sets the first arrowhead color

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ FirstArrowheadFont() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstArrowheadFont
(
self — )

Getter for property: (NXOpen.DisplayableObject.ObjectFont) FirstArrowheadFont Returns the first arrowhead font. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.DisplayableObject.ObjectFont 

## ◆ FirstArrowheadFont() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstArrowheadFont
(
self,

firstArrowheadFont )

Setter for property: (NXOpen.DisplayableObject.ObjectFont) FirstArrowheadFont. 

Sets the first arrowhead font

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ FirstArrowheadWidth() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstArrowheadWidth
(
self — )

Getter for property: (NXOpen.Annotations.LineWidth) FirstArrowheadWidth Returns the first arrowhead width. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWidth 

## ◆ FirstArrowheadWidth() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstArrowheadWidth
(
self,

firstArrowheadWidth )

Setter for property: (NXOpen.Annotations.LineWidth) FirstArrowheadWidth. 

Sets the first arrowhead width

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ FirstArrowLineColor() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstArrowLineColor
(
self — )

Getter for property: (NXOpen.NXColor) FirstArrowLineColor Returns the first arrow line color. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.NXColor 

## ◆ FirstArrowLineColor() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstArrowLineColor
(
self,

firstArrowLineColor )

Setter for property: (NXOpen.NXColor) FirstArrowLineColor. 

Sets the first arrow line color

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ FirstArrowLineFont() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstArrowLineFont
(
self — )

Getter for property: (NXOpen.DisplayableObject.ObjectFont) FirstArrowLineFont Returns the first arrow line font. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.DisplayableObject.ObjectFont 

## ◆ FirstArrowLineFont() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstArrowLineFont
(
self,

firstArrowLineFont )

Setter for property: (NXOpen.DisplayableObject.ObjectFont) FirstArrowLineFont. 

Sets the first arrow line font

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ FirstArrowLineWidth() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstArrowLineWidth
(
self — )

Getter for property: (NXOpen.Annotations.LineWidth) FirstArrowLineWidth Returns the first arrow line width. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWidth 

## ◆ FirstArrowLineWidth() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstArrowLineWidth
(
self,

firstArrowLineWidth )

Setter for property: (NXOpen.Annotations.LineWidth) FirstArrowLineWidth. 

Sets the first arrow line width

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ FirstArrowType() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstArrowType
(
self — )

Getter for property: (NXOpen.Annotations.ArrowheadType) FirstArrowType Returns the first arrowhead type. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
ArrowheadType 

## ◆ FirstArrowType() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstArrowType
(
self,

firstArrowType )

Setter for property: (NXOpen.Annotations.ArrowheadType) FirstArrowType. 

Sets the first arrowhead type

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ FirstExtensionLineColor() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstExtensionLineColor
(
self — )

Getter for property: (NXOpen.NXColor) FirstExtensionLineColor Returns the first extension line color. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.NXColor 

## ◆ FirstExtensionLineColor() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstExtensionLineColor
(
self,

firstExtensionLineColor )

Setter for property: (NXOpen.NXColor) FirstExtensionLineColor. 

Sets the first extension line color

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ FirstExtensionLineFont() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstExtensionLineFont
(
self — )

Getter for property: (NXOpen.DisplayableObject.ObjectFont) FirstExtensionLineFont Returns the first extension line font. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.DisplayableObject.ObjectFont 

## ◆ FirstExtensionLineFont() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstExtensionLineFont
(
self,

firstExtensionLineFont )

Setter for property: (NXOpen.DisplayableObject.ObjectFont) FirstExtensionLineFont. 

Sets the first extension line font

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ FirstExtensionLineWidth() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstExtensionLineWidth
(
self — )

Getter for property: (NXOpen.Annotations.LineWidth) FirstExtensionLineWidth Returns the first extension line width. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWidth 

## ◆ FirstExtensionLineWidth() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstExtensionLineWidth
(
self,

firstExtensionLineWidth )

Setter for property: (NXOpen.Annotations.LineWidth) FirstExtensionLineWidth. 

Sets the first extension line width

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ FirstJogAngle() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstJogAngle
(
self — )

Getter for property: (float) FirstJogAngle Returns the first jog angle, between the jog and the extension line, in degrees. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
float 

## ◆ FirstJogAngle() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstJogAngle
(
self,

jogAngle )

Setter for property: (float) FirstJogAngle. 

Sets the first jog angle, between the jog and the extension line, in degrees.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ FirstJogDisplay() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstJogDisplay
(
self — )

Getter for property: (bool) FirstJogDisplay Returns the first jog's display flag, if true, the first jog will be displayed, false otherwise. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
bool 

## ◆ FirstJogDisplay() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstJogDisplay
(
self,

jogDisplay )

Setter for property: (bool) FirstJogDisplay. 

Sets the first jog's display flag, if true, the first jog will be displayed, false otherwise

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ FirstJogEndOffset() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstJogEndOffset
(
self — )

Getter for property: (float) FirstJogEndOffset Returns the first jog end offset from the dimension line. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
float 

## ◆ FirstJogEndOffset() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstJogEndOffset
(
self,

jogEndOffset )

Setter for property: (float) FirstJogEndOffset. 

Sets the first jog end offset from the dimension line

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ FirstJogOrientation() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstJogOrientation
(
self — )

Getter for property: (NXOpen.Annotations.JogOrientation) FirstJogOrientation Returns the first jog orientation, can be either IN or OUT. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
JogOrientation 

## ◆ FirstJogOrientation() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstJogOrientation
(
self,

jogOrientation )

Setter for property: (NXOpen.Annotations.JogOrientation) FirstJogOrientation. 

Sets the first jog orientation, can be either IN or OUT

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ FirstJogStartOffset() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstJogStartOffset
(
self — )

Getter for property: (float) FirstJogStartOffset Returns the first jog start offset from the dimension line. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
float 

## ◆ FirstJogStartOffset() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstJogStartOffset
(
self,

jogStartOffset )

Setter for property: (float) FirstJogStartOffset. 

Sets the first jog start offset from the dimension line

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ FirstPosToExtensionLineDistance() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstPosToExtensionLineDistance
(
self — )

Getter for property: (float) FirstPosToExtensionLineDistance Returns the distance from the position on the object being dimensioned to the end of the first extension line or arc. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ FirstPosToExtensionLineDistance() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.FirstPosToExtensionLineDistance
(
self,

firstPosToExtensionLineDistance )

Setter for property: (float) FirstPosToExtensionLineDistance. 

Sets the distance from the position on the object being dimensioned to the end of the first extension line or arc

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ LeaderLocation() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.LeaderLocation
(
self — )

Getter for property: (NXOpen.Annotations.VerticalTextJustification) LeaderLocation Returns the leader location. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
VerticalTextJustification 

## ◆ LeaderLocation() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.LeaderLocation
(
self,

leaderLocation )

Setter for property: (NXOpen.Annotations.VerticalTextJustification) LeaderLocation. 

Sets the leader location

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ LeaderOrientation() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.LeaderOrientation
(
self — )

Getter for property: (NXOpen.Annotations.LeaderSide) LeaderOrientation Returns the leader orientation. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
LeaderSide 

## ◆ LeaderOrientation() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.LeaderOrientation
(
self,

leaderOrientation )

Setter for property: (NXOpen.Annotations.LeaderSide) LeaderOrientation. 

Sets the leader orientation

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ LinePastArrowDistance() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.LinePastArrowDistance
(
self — )

Getter for property: (float) LinePastArrowDistance Returns the distance an extension line or arc extends past the dimension line or arc. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ LinePastArrowDistance() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.LinePastArrowDistance
(
self,

linePastArrowDistance )

Setter for property: (float) LinePastArrowDistance. 

Sets the distance an extension line or arc extends past the dimension line or arc

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ LinePastArrowDistance2() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.LinePastArrowDistance2
(
self — )

Getter for property: (float) LinePastArrowDistance2 Returns the second distance an extension line or arc extends past the dimension line or arc. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
float 

## ◆ LinePastArrowDistance2() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.LinePastArrowDistance2
(
self,

linePastArrowDistance )

Setter for property: (float) LinePastArrowDistance2. 

Sets the second distance an extension line or arc extends past the dimension line or arc

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ ObliqueExtensionLineAngle() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.ObliqueExtensionLineAngle
(
self — )

Getter for property: (float) ObliqueExtensionLineAngle Returns the extension line angle. 

This angle only applies to vertical and horizontal dimensions

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ ObliqueExtensionLineAngle() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.ObliqueExtensionLineAngle
(
self,

obliqueExtensionLineAngle )

Setter for property: (float) ObliqueExtensionLineAngle. 

Sets the extension line angle. This angle only applies to vertical and horizontal dimensions

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SecondArrowheadColor() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondArrowheadColor
(
self — )

Getter for property: (NXOpen.NXColor) SecondArrowheadColor Returns the second arrowhead color. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.NXColor 

## ◆ SecondArrowheadColor() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondArrowheadColor
(
self,

secondArrowheadColor )

Setter for property: (NXOpen.NXColor) SecondArrowheadColor. 

Sets the second arrowhead color

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SecondArrowheadFont() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondArrowheadFont
(
self — )

Getter for property: (NXOpen.DisplayableObject.ObjectFont) SecondArrowheadFont Returns the second arrowhead font. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.DisplayableObject.ObjectFont 

## ◆ SecondArrowheadFont() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondArrowheadFont
(
self,

secondArrowheadFont )

Setter for property: (NXOpen.DisplayableObject.ObjectFont) SecondArrowheadFont. 

Sets the second arrowhead font

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SecondArrowheadWidth() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondArrowheadWidth
(
self — )

Getter for property: (NXOpen.Annotations.LineWidth) SecondArrowheadWidth Returns the second arrowhead width. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWidth 

## ◆ SecondArrowheadWidth() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondArrowheadWidth
(
self,

secondArrowheadWidth )

Setter for property: (NXOpen.Annotations.LineWidth) SecondArrowheadWidth. 

Sets the second arrowhead width

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SecondArrowLineColor() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondArrowLineColor
(
self — )

Getter for property: (NXOpen.NXColor) SecondArrowLineColor Returns the second arrow line color. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.NXColor 

## ◆ SecondArrowLineColor() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondArrowLineColor
(
self,

secondArrowLineColor )

Setter for property: (NXOpen.NXColor) SecondArrowLineColor. 

Sets the second arrow line color

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SecondArrowLineFont() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondArrowLineFont
(
self — )

Getter for property: (NXOpen.DisplayableObject.ObjectFont) SecondArrowLineFont Returns the second arrow line font. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.DisplayableObject.ObjectFont 

## ◆ SecondArrowLineFont() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondArrowLineFont
(
self,

secondArrowLineFont )

Setter for property: (NXOpen.DisplayableObject.ObjectFont) SecondArrowLineFont. 

Sets the second arrow line font

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SecondArrowLineWidth() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondArrowLineWidth
(
self — )

Getter for property: (NXOpen.Annotations.LineWidth) SecondArrowLineWidth Returns the second arrow line width. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWidth 

## ◆ SecondArrowLineWidth() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondArrowLineWidth
(
self,

secondArrowLineWidth )

Setter for property: (NXOpen.Annotations.LineWidth) SecondArrowLineWidth. 

Sets the second arrow line width

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SecondArrowType() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondArrowType
(
self — )

Getter for property: (NXOpen.Annotations.ArrowheadType) SecondArrowType Returns the second arrowhead type. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
ArrowheadType 

## ◆ SecondArrowType() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondArrowType
(
self,

secondArrowType )

Setter for property: (NXOpen.Annotations.ArrowheadType) SecondArrowType. 

Sets the second arrowhead type

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SecondExtensionLineColor() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondExtensionLineColor
(
self — )

Getter for property: (NXOpen.NXColor) SecondExtensionLineColor Returns the second extension line color. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.NXColor 

## ◆ SecondExtensionLineColor() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondExtensionLineColor
(
self,

secondExtensionLineColor )

Setter for property: (NXOpen.NXColor) SecondExtensionLineColor. 

Sets the second extension line color

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SecondExtensionLineFont() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondExtensionLineFont
(
self — )

Getter for property: (NXOpen.DisplayableObject.ObjectFont) SecondExtensionLineFont Returns the second extension line font. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.DisplayableObject.ObjectFont 

## ◆ SecondExtensionLineFont() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondExtensionLineFont
(
self,

secondExtensionLineFont )

Setter for property: (NXOpen.DisplayableObject.ObjectFont) SecondExtensionLineFont. 

Sets the second extension line font

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SecondExtensionLineWidth() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondExtensionLineWidth
(
self — )

Getter for property: (NXOpen.Annotations.LineWidth) SecondExtensionLineWidth Returns the second extension line width. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
LineWidth 

## ◆ SecondExtensionLineWidth() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondExtensionLineWidth
(
self,

secondExtensionLineWidth )

Setter for property: (NXOpen.Annotations.LineWidth) SecondExtensionLineWidth. 

Sets the second extension line width

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SecondJogAngle() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondJogAngle
(
self — )

Getter for property: (float) SecondJogAngle Returns the second jog angle, between the jog and the extension line, in degrees. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
float 

## ◆ SecondJogAngle() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondJogAngle
(
self,

jogAngle )

Setter for property: (float) SecondJogAngle. 

Sets the second jog angle, between the jog and the extension line, in degrees.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ SecondJogDisplay() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondJogDisplay
(
self — )

Getter for property: (bool) SecondJogDisplay Returns the second jog's display flag, if true, the second jog will be displayed, false otherwise. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
bool 

## ◆ SecondJogDisplay() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondJogDisplay
(
self,

jogDisplay )

Setter for property: (bool) SecondJogDisplay. 

Sets the second jog's display flag, if true, the second jog will be displayed, false otherwise

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ SecondJogEndOffset() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondJogEndOffset
(
self — )

Getter for property: (float) SecondJogEndOffset Returns the second jog end offset from the dimension line. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
float 

## ◆ SecondJogEndOffset() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondJogEndOffset
(
self,

jogEndOffset )

Setter for property: (float) SecondJogEndOffset. 

Sets the second jog end offset from the dimension line

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ SecondJogOrientation() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondJogOrientation
(
self — )

Getter for property: (NXOpen.Annotations.JogOrientation) SecondJogOrientation Returns the second jog orientation, can be either IN or OUT. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
JogOrientation 

## ◆ SecondJogOrientation() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondJogOrientation
(
self,

jogOrientation )

Setter for property: (NXOpen.Annotations.JogOrientation) SecondJogOrientation. 

Sets the second jog orientation, can be either IN or OUT

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ SecondJogStartOffset() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondJogStartOffset
(
self — )

Getter for property: (float) SecondJogStartOffset Returns the second jog start offset from the dimension line. 

Getter License requirements: None.

Created in NX10.0.0 

Returns
float 

## ◆ SecondJogStartOffset() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondJogStartOffset
(
self,

jogStartOffset )

Setter for property: (float) SecondJogStartOffset. 

Sets the second jog start offset from the dimension line

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX10.0.0 

## ◆ SecondPosToExtensionLineDistance() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondPosToExtensionLineDistance
(
self — )

Getter for property: (float) SecondPosToExtensionLineDistance Returns the distance from the position on the object being dimensioned to the end of the second extension line. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ SecondPosToExtensionLineDistance() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.SecondPosToExtensionLineDistance
(
self,

secondPosToExtensionLineDistance )

Setter for property: (float) SecondPosToExtensionLineDistance. 

Sets the distance from the position on the object being dimensioned to the end of the second extension line

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ StubLength() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.StubLength
(
self — )

Getter for property: (float) StubLength Returns the stub length. 

This is the size of the dogleg on a label or dimension

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ StubLength() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.StubLength
(
self,

stubLength )

Setter for property: (float) StubLength. 

Sets the stub length. This is the size of the dogleg on a label or dimension

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ StubSymbolType() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.StubSymbolType
(
self — )

Getter for property: (NXOpen.Annotations.StubSymbolType) StubSymbolType Returns the stub symbol type. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
StubSymbolType 

## ◆ StubSymbolType() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.StubSymbolType
(
self,

stubSymbolType )

Setter for property: (NXOpen.Annotations.StubSymbolType) StubSymbolType. 

Sets the stub symbol type

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX11.0.0 

## ◆ TextOverLeaderGapFactor() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.TextOverLeaderGapFactor
(
self — )

Getter for property: (float) TextOverLeaderGapFactor Returns the character size factor that controls the gap between text and the leader. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
float 

## ◆ TextOverLeaderGapFactor() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.TextOverLeaderGapFactor
(
self,

textOverLeaderGapFactor )

Setter for property: (float) TextOverLeaderGapFactor. 

Sets the character size factor that controls the gap between text and the leader

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX8.0.0 

## ◆ TextOverStubFactor() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.TextOverStubFactor
(
self — )

Getter for property: (float) TextOverStubFactor Returns the character size factor which controls the distance between the stub and label text when the text displays above the stub line. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ TextOverStubFactor() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.TextOverStubFactor
(
self,

textOverStubFactor )

Setter for property: (float) TextOverStubFactor. 

Sets the character size factor which controls the distance between the stub and label text when the text displays above the stub line

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ TextToLineDistance() [1/2]

NXOpen.Annotations.LineArrowStyleBuilder.TextToLineDistance
(
self — )

Getter for property: (float) TextToLineDistance Returns the distance from the text to the dimension line(stub) or arc. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ TextToLineDistance() [2/2]

NXOpen.Annotations.LineArrowStyleBuilder.TextToLineDistance
(
self,

textToLineDistance )

Setter for property: (float) TextToLineDistance. 

Sets the distance from the text to the dimension line(stub) or arc

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

Copyright 2025 Siemens
