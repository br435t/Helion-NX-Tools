# NXOpen.Annotations.HatchBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00163.html>

## Classes

class — AnnotationTypes

Represents types of hatch objects. More...

Copyright 2025 Siemens
