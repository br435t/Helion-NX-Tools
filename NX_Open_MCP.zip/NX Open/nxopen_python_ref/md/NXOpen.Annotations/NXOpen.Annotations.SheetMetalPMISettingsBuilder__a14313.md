# NXOpen.Annotations.SheetMetalPMISettingsBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a14313.html>

Represents a NXOpen::Annotations::SheetMetalPMISettingsBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.SheetMetalPMISettingsBuilder:

## Public Member Functions

AngularDecimalPlaces (self)

Getter for property: (int) AngularDecimalPlaces Returns the angular decimal places setting. 

AngularDecimalPlaces (self, angularDecimalPlaces)

Setter for property: (int) AngularDecimalPlaces. 

BlindHoleText (self)

Getter for property: (str) BlindHoleText Returns the text for blind hole in flat pattern hole details label. 

BlindHoleText (self, blindHoleText)

Setter for property: (str) BlindHoleText. 

CreateFlatPatternBendLabel (self)

Getter for property: (bool) CreateFlatPatternBendLabel Returns the create flat pattern bend label setting. 

CreateFlatPatternBendLabel (self, createFlatPatternBendLabel)

Setter for property: (bool) CreateFlatPatternBendLabel. 

CreateFlatPatternHoleDetailsLabel (self)

Getter for property: (bool) CreateFlatPatternHoleDetailsLabel Returns the create flat pattern hole details label setting. 

CreateFlatPatternHoleDetailsLabel (self, createFlatPatternHoleDetailsLabel)

Setter for property: (bool) CreateFlatPatternHoleDetailsLabel. 

CreateFlatPatternJoggleLabel (self)

Getter for property: (bool) CreateFlatPatternJoggleLabel Returns the create flat pattern joggle label setting. 

CreateFlatPatternJoggleLabel (self, createFlatPatternJoggleLabel)

Setter for property: (bool) CreateFlatPatternJoggleLabel. 

CreateFlatPatternLighteningCutoutLabel (self)

Getter for property: (bool) CreateFlatPatternLighteningCutoutLabel Returns the create flat pattern lightening cutout label setting. 

CreateFlatPatternLighteningCutoutLabel (self, createFlatPatternLCutoutLabel)

Setter for property: (bool) CreateFlatPatternLighteningCutoutLabel. 

CreateFlatPatternNote (self)

Getter for property: (bool) CreateFlatPatternNote Returns the create flat pattern note setting. 

CreateFlatPatternNote (self, createFlatPatternNote)

Setter for property: (bool) CreateFlatPatternNote. 

CreateFlatPatternToolIDLabel (self)

Getter for property: (bool) CreateFlatPatternToolIDLabel Returns the create flat pattern tool id label setting. 

CreateFlatPatternToolIDLabel (self, createFlatPatternToolIdLabel)

Setter for property: (bool) CreateFlatPatternToolIDLabel. 

DecimalPlaces (self)

Getter for property: (int) DecimalPlaces Returns the decimal places setting. 

DecimalPlaces (self, decimalPlaces)

Setter for property: (int) DecimalPlaces. 

FlatPatternHoleDetailsPrefix (self)

Getter for property: (str) FlatPatternHoleDetailsPrefix Returns the prefix characters for flat pattern hole details label. 

FlatPatternHoleDetailsPrefix (self, prefix)

Setter for property: (str) FlatPatternHoleDetailsPrefix. 

FlatPatternHoleDetailsSuffix (self)

Getter for property: (str) FlatPatternHoleDetailsSuffix Returns the suffix characters for flat pattern hole details label. 

FlatPatternHoleDetailsSuffix (self, suffix)

Setter for property: (str) FlatPatternHoleDetailsSuffix. 

FlatPatternToolIDPrefix (self)

Getter for property: (str) FlatPatternToolIDPrefix Returns the prefix characters for flat pattern tool ID label. 

FlatPatternToolIDPrefix (self, prefix)

Setter for property: (str) FlatPatternToolIDPrefix. 

FlatPatternToolIDSuffix (self)

Getter for property: (str) FlatPatternToolIDSuffix Returns the suffix characters for flat pattern tool ID label. 

FlatPatternToolIDSuffix (self, suffix)

Setter for property: (str) FlatPatternToolIDSuffix. 

GetFlatPatternBendParameters (self)

Returns flat pattern bend labels. 

GetFlatPatternPropertiesNote (self)

Returns flat pattern properties note. 

GetPrefixForBendParameterType (self, parameterType)

Gets prefix for bend parameter type. 

GetPrefixForBodyParameterType (self, parameterType)

Gets prefix for body parameter type. 

GetPrefixForFlatPatternBendDataType (self, parameterType)

Gets prefix for flat pattern bend data type. 

GetPrefixForFlatPatternJogggleParameterType (self, parameterType)

Gets prefix for flat pattern joggle parameter type. 

GetPrefixForFlatPatternLighteningCutoutParameterType (self, parameterType)

Gets prefix for flat pattern lightening cutout parameter type. 

GetPrefixForFlatPatternNotePropertiesType (self, parameterType)

Gets prefix for flat pattern note properties type. 

GetSuffixForBendParameterType (self, parameterType)

Gets suffix for bend parameter type. 

GetSuffixForBodyParameterType (self, parameterType)

Gets suffix for body parameter type. 

GetSuffixForFlatPatternBendDataType (self, parameterType)

Gets suffix for flat pattern bend data type. 

GetSuffixForFlatPatternJogggleParameterType (self, parameterType)

Gets suffix for flat pattern joggle parameter type. 

GetSuffixForFlatPatternLighteningCutoutParameterType (self, parameterType)

Gets suffix for flat pattern lightening cutout parameter type. 

GetSuffixForFlatPatternNotePropertiesType (self, parameterType)

Gets suffix for flat pattern note properties type. 

IncludeBendAngle (self)

Getter for property: (bool) IncludeBendAngle Returns the include bend angle setting. 

IncludeBendAngle (self, includeBendAngle)

Setter for property: (bool) IncludeBendAngle. 

IncludeBendAngleInFlatPatternLabel (self)

Getter for property: (bool) IncludeBendAngleInFlatPatternLabel Returns the include bend angle in flat pattern bend label setting. 

IncludeBendAngleInFlatPatternLabel (self, includeBendAngle)

Setter for property: (bool) IncludeBendAngleInFlatPatternLabel. 

IncludeBendDirectionInFlatPatternLabel (self)

Getter for property: (bool) IncludeBendDirectionInFlatPatternLabel Returns the include bend direction in flat pattern bend label setting. 

IncludeBendDirectionInFlatPatternLabel (self, includeBendDirection)

Setter for property: (bool) IncludeBendDirectionInFlatPatternLabel. 

IncludeBendNameInFlatPatternLabel (self)

Getter for property: (bool) IncludeBendNameInFlatPatternLabel Returns the include bend name in flat pattern bend label setting. 

IncludeBendNameInFlatPatternLabel (self, includeBendName)

Setter for property: (bool) IncludeBendNameInFlatPatternLabel. 

IncludeBendRadius (self)

Getter for property: (bool) IncludeBendRadius Returns the include bend radius setting. 

IncludeBendRadius (self, includeBendRadius)

Setter for property: (bool) IncludeBendRadius. 

IncludeBendRadiusInFlatPatternLabel (self)

Getter for property: (bool) IncludeBendRadiusInFlatPatternLabel Returns the include bend radius in flat pattern bend label setting. 

IncludeBendRadiusInFlatPatternLabel (self, includeBendRadius)

Setter for property: (bool) IncludeBendRadiusInFlatPatternLabel. 

IncludeBendSequenceIDInFlatPatternLabel (self)

Getter for property: (bool) IncludeBendSequenceIDInFlatPatternLabel Returns the include bend sequence id in flat pattern bend label setting. 

IncludeBendSequenceIDInFlatPatternLabel (self, includeBendSeqID)

Setter for property: (bool) IncludeBendSequenceIDInFlatPatternLabel. 

IncludeCutoutDiameterInFlatPatternLabel (self)

Getter for property: (bool) IncludeCutoutDiameterInFlatPatternLabel Returns the include cutout diameter in flat pattern lightening cutout setting. 

IncludeCutoutDiameterInFlatPatternLabel (self, includeCutoutDiameter)

Setter for property: (bool) IncludeCutoutDiameterInFlatPatternLabel. 

IncludeExteriorCutLengthInFlatPatternNote (self)

Getter for property: (bool) IncludeExteriorCutLengthInFlatPatternNote Returns the include exterior cut length in flat pattern note setting. 

IncludeExteriorCutLengthInFlatPatternNote (self, includeExteriorCutLength)

Setter for property: (bool) IncludeExteriorCutLengthInFlatPatternNote. 

IncludeHoleDiameterInFlatPatternLabel (self)

Getter for property: (bool) IncludeHoleDiameterInFlatPatternLabel Returns the include hole diameter in flat pattern lightening cutout label setting. 

IncludeHoleDiameterInFlatPatternLabel (self, includeHoleDiameter)

Setter for property: (bool) IncludeHoleDiameterInFlatPatternLabel. 

IncludeInnerBendAngleInFlatPatternLabel (self)

Getter for property: (bool) IncludeInnerBendAngleInFlatPatternLabel Returns the include inner bend angle in flat pattern bend label setting. 

IncludeInnerBendAngleInFlatPatternLabel (self, includeInnerBendAngle)

Setter for property: (bool) IncludeInnerBendAngleInFlatPatternLabel. 

IncludeInteriorCutLengthInFlatPatternNote (self)

Getter for property: (bool) IncludeInteriorCutLengthInFlatPatternNote Returns the include interior cut length in flat pattern note setting. 

IncludeInteriorCutLengthInFlatPatternNote (self, includeInteriorCutLength)

Setter for property: (bool) IncludeInteriorCutLengthInFlatPatternNote. 

IncludeInteriorCutoutCountInFlatPatternNote (self)

Getter for property: (bool) IncludeInteriorCutoutCountInFlatPatternNote Returns the include interior cutout count in flat pattern note setting. 

IncludeInteriorCutoutCountInFlatPatternNote (self, includeInteriorCutoutCount)

Setter for property: (bool) IncludeInteriorCutoutCountInFlatPatternNote. 

IncludeJoggleDepthInFlatPatternLabel (self)

Getter for property: (bool) IncludeJoggleDepthInFlatPatternLabel Returns the include joggle depth in flat pattern joggle label setting. 

IncludeJoggleDepthInFlatPatternLabel (self, includeJoggleDepth)

Setter for property: (bool) IncludeJoggleDepthInFlatPatternLabel. 

IncludeJoggleRunoutInFlatPatternLabel (self)

Getter for property: (bool) IncludeJoggleRunoutInFlatPatternLabel Returns the include joggle runout in flat pattern joggle label setting. 

IncludeJoggleRunoutInFlatPatternLabel (self, includeJoggleRunout)

Setter for property: (bool) IncludeJoggleRunoutInFlatPatternLabel. 

IncludeMaterial (self)

Getter for property: (bool) IncludeMaterial Returns the include sm material setting. 

IncludeMaterial (self, includeSmMaterial)

Setter for property: (bool) IncludeMaterial. 

IncludeMinimumXInFlatPatternNote (self)

Getter for property: (bool) IncludeMinimumXInFlatPatternNote Returns the include minimum x in flat pattern note setting. 

IncludeMinimumXInFlatPatternNote (self, includeMinimumX)

Setter for property: (bool) IncludeMinimumXInFlatPatternNote. 

IncludeMinimumYInFlatPatternNote (self)

Getter for property: (bool) IncludeMinimumYInFlatPatternNote Returns the include minimum y in flat pattern note setting. 

IncludeMinimumYInFlatPatternNote (self, includeMinimumY)

Setter for property: (bool) IncludeMinimumYInFlatPatternNote. 

IncludeNeutralFactor (self)

Getter for property: (bool) IncludeNeutralFactor Returns the include neutral factor setting. 

IncludeNeutralFactor (self, includeNeutralFactor)

Setter for property: (bool) IncludeNeutralFactor. 

IncludeNeutralFactorInFlatPatternLabel (self)

Getter for property: (bool) IncludeNeutralFactorInFlatPatternLabel Returns the include neutral factor in flat pattern bend label setting. 

IncludeNeutralFactorInFlatPatternLabel (self, includeNeutralFactor)

Setter for property: (bool) IncludeNeutralFactorInFlatPatternLabel. 

IncludePhysicalMaterial (self)

Getter for property: (bool) IncludePhysicalMaterial Returns the include physical material setting. 

IncludePhysicalMaterial (self, includePhysicalMaterial)

Setter for property: (bool) IncludePhysicalMaterial. 

IncludeThickness (self)

Getter for property: (bool) IncludeThickness Returns the include material thickness setting. 

IncludeThickness (self, includeMaterialhickness)

Setter for property: (bool) IncludeThickness. 

IncludeTotalCutLengthInFlatPatternNote (self)

Getter for property: (bool) IncludeTotalCutLengthInFlatPatternNote Returns the include total cut length in flat pattern note setting. 

IncludeTotalCutLengthInFlatPatternNote (self, includeTotalCutLength)

Setter for property: (bool) IncludeTotalCutLengthInFlatPatternNote. 

LabelPlacementType (self)

Getter for property: (NXOpen.Annotations.SheetMetalPMISettingsBuilder.LabelPlacementTypes) LabelPlacementType Returns the sheet metal pmi orientation. 

LabelPlacementType (self, labelPlacementType)

Setter for property: (NXOpen.Annotations.SheetMetalPMISettingsBuilder.LabelPlacementTypes) LabelPlacementType. 

PmiLabelType (self)

Getter for property: (NXOpen.Annotations.SheetMetalPMISettingsBuilder.SmPmiType) PmiLabelType Returns the sheet metal pmi type. 

PmiLabelType (self, type)

Setter for property: (NXOpen.Annotations.SheetMetalPMISettingsBuilder.SmPmiType) PmiLabelType. 

PmiLayer (self)

Getter for property: (int) PmiLayer Returns the flat pattern PMI layer setting. 

PmiLayer (self, layer)

Setter for property: (int) PmiLayer. 

PmiLayerOption (self)

Getter for property: (NXOpen.Annotations.SheetMetalPMISettingsBuilder.PmiLayerOptions) PmiLayerOption Returns the layer option. 

PmiLayerOption (self, layerOption)

Setter for property: (NXOpen.Annotations.SheetMetalPMISettingsBuilder.PmiLayerOptions) PmiLayerOption. 

PmiNoteType (self)

Getter for property: (NXOpen.Annotations.SheetMetalPMISettingsBuilder.SmPmiNoteType) PmiNoteType Returns the sheet metal pmi note type. 

PmiNoteType (self, type)

Setter for property: (NXOpen.Annotations.SheetMetalPMISettingsBuilder.SmPmiNoteType) PmiNoteType. 

SetFlatPatternBendParameters (self, fpBendParameters)

Sets flat pattern bend labels. 

SetFlatPatternPropertiesNote (self, fpProperties)

Sets flat pattern properties note. 

SetPrefixForBendParameterType (self, parameterType, prefix)

Sets prefix for bend parameter type. 

SetPrefixForBodyParameterType (self, parameterType, prefix)

Sets prefix for body parameter type. 

SetPrefixForFlatPatternBendDataType (self, parameterType, prefix)

Sets prefix for flat pattern bend data type. 

SetPrefixForFlatPatternJoggleParameterType (self, parameterType, prefix)

Sets prefix for flat pattern joggle parameter type. 

SetPrefixForFlatPatternLighteningCutoutParameterType (self, parameterType, prefix)

Sets prefix for flat pattern lightening cutout parameter type. 

SetPrefixForFlatPatternNotePropertiesType (self, parameterType, prefix)

Sets prefix for flat pattern note properties type. 

SetSuffixForBendParameterType (self, parameterType, suffix)

Sets suffix for bend parameter type. 

SetSuffixForBodyParameterType (self, parameterType, suffix)

Sets suffix for body parameter type. 

SetSuffixForFlatPatternBendDataType (self, parameterType, suffix)

Sets suffix for flat pattern bend data type. 

SetSuffixForFlatPatternJoggleParameterType (self, parameterType, suffix)

Sets suffix for flat pattern joggle parameter type. 

SetSuffixForFlatPatternLighteningCutoutParameterType (self, parameterType, suffix)

Sets suffix for flat pattern lightening cutout parameter type. 

SetSuffixForFlatPatternNotePropertiesType (self, parameterType, suffix)

Sets suffix for flat pattern note properties type. 

ThroughHoleText (self)

Getter for property: (str) ThroughHoleText Returns the text for through hole in flat pattern hole details label. 

ThroughHoleText (self, throughHoleText)

Setter for property: (str) ThroughHoleText. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

SheetMetalPMISettingsBuilderBendParameters = SheetMetalPMISettingsBuilder.BendParameters

NXOpen.Annotations.SheetMetalPMISettingsBuilderBendParameters is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.BendParameters 

SheetMetalPMISettingsBuilderBendParameterType = SheetMetalPMISettingsBuilder.BendParameterType

NXOpen.Annotations.SheetMetalPMISettingsBuilderBendParameterType is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.BendParameterType 

SheetMetalPMISettingsBuilderBodyParameterType = SheetMetalPMISettingsBuilder.BodyParameterType

NXOpen.Annotations.SheetMetalPMISettingsBuilderBodyParameterType is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.BodyParameterType 

SheetMetalPMISettingsBuilderFlatpatternBendDataType = SheetMetalPMISettingsBuilder.FlatpatternBendDataType

NXOpen.Annotations.SheetMetalPMISettingsBuilderFlatpatternBendDataType is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternBendDataType 

SheetMetalPMISettingsBuilderFlatpatternJoggleParametersType = SheetMetalPMISettingsBuilder.FlatpatternJoggleParametersType

NXOpen.Annotations.SheetMetalPMISettingsBuilderFlatpatternJoggleParametersType is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternJoggleParametersType 

SheetMetalPMISettingsBuilderFlatpatternLighteningCutoutParametersType = SheetMetalPMISettingsBuilder.FlatpatternLighteningCutoutParametersType

NXOpen.Annotations.SheetMetalPMISettingsBuilderFlatpatternLighteningCutoutParametersType is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternLighteningCutoutParametersType 

SheetMetalPMISettingsBuilderFlatpatternNotePropertiesType = SheetMetalPMISettingsBuilder.FlatpatternNotePropertiesType

NXOpen.Annotations.SheetMetalPMISettingsBuilderFlatpatternNotePropertiesType is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternNotePropertiesType 

SheetMetalPMISettingsBuilderFpProperties = SheetMetalPMISettingsBuilder.FpProperties

NXOpen.Annotations.SheetMetalPMISettingsBuilderFpProperties is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.FpProperties 

SheetMetalPMISettingsBuilderLabelPlacementTypes = SheetMetalPMISettingsBuilder.LabelPlacementTypes

NXOpen.Annotations.SheetMetalPMISettingsBuilderLabelPlacementTypes is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.LabelPlacementTypes 

SheetMetalPMISettingsBuilderPmiLayerOptions = SheetMetalPMISettingsBuilder.PmiLayerOptions

NXOpen.Annotations.SheetMetalPMISettingsBuilderPmiLayerOptions is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.PmiLayerOptions 

SheetMetalPMISettingsBuilderSmPmiNoteType = SheetMetalPMISettingsBuilder.SmPmiNoteType

NXOpen.Annotations.SheetMetalPMISettingsBuilderSmPmiNoteType is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.SmPmiNoteType 

SheetMetalPMISettingsBuilderSmPmiType = SheetMetalPMISettingsBuilder.SmPmiType

NXOpen.Annotations.SheetMetalPMISettingsBuilderSmPmiType is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.SmPmiType 

## Detailed Description

Represents a NXOpen::Annotations::SheetMetalPMISettingsBuilder . 

This is a sub-builder class and cannot be directly instantiated 

Created in NX2007.0.0 

## Member Function Documentation

## ◆ AngularDecimalPlaces() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.AngularDecimalPlaces
(
self — )

Getter for property: (int) AngularDecimalPlaces Returns the angular decimal places setting. 

Only values from 0 to 6 (both inclusive) are valid.

Getter License requirements: None.

Created in NX2506.0.0 

Returns
int 

## ◆ AngularDecimalPlaces() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.AngularDecimalPlaces
(
self,

angularDecimalPlaces )

Setter for property: (int) AngularDecimalPlaces. 

Sets the angular decimal places setting. Only values from 0 to 6 (both inclusive) are valid.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2506.0.0 

## ◆ BlindHoleText() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.BlindHoleText
(
self — )

Getter for property: (str) BlindHoleText Returns the text for blind hole in flat pattern hole details label. 

Getter License requirements: None.

Created in NX2506.0.0 

Returns
str 

## ◆ BlindHoleText() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.BlindHoleText
(
self,

blindHoleText )

Setter for property: (str) BlindHoleText. 

Sets the text for blind hole in flat pattern hole details label.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2506.0.0 

## ◆ CreateFlatPatternBendLabel() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.CreateFlatPatternBendLabel
(
self — )

Getter for property: (bool) CreateFlatPatternBendLabel Returns the create flat pattern bend label setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ CreateFlatPatternBendLabel() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.CreateFlatPatternBendLabel
(
self,

createFlatPatternBendLabel )

Setter for property: (bool) CreateFlatPatternBendLabel. 

Sets the create flat pattern bend label setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ CreateFlatPatternHoleDetailsLabel() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.CreateFlatPatternHoleDetailsLabel
(
self — )

Getter for property: (bool) CreateFlatPatternHoleDetailsLabel Returns the create flat pattern hole details label setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ CreateFlatPatternHoleDetailsLabel() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.CreateFlatPatternHoleDetailsLabel
(
self,

createFlatPatternHoleDetailsLabel )

Setter for property: (bool) CreateFlatPatternHoleDetailsLabel. 

Sets the create flat pattern hole details label setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ CreateFlatPatternJoggleLabel() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.CreateFlatPatternJoggleLabel
(
self — )

Getter for property: (bool) CreateFlatPatternJoggleLabel Returns the create flat pattern joggle label setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ CreateFlatPatternJoggleLabel() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.CreateFlatPatternJoggleLabel
(
self,

createFlatPatternJoggleLabel )

Setter for property: (bool) CreateFlatPatternJoggleLabel. 

Sets the create flat pattern joggle label setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ CreateFlatPatternLighteningCutoutLabel() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.CreateFlatPatternLighteningCutoutLabel
(
self — )

Getter for property: (bool) CreateFlatPatternLighteningCutoutLabel Returns the create flat pattern lightening cutout label setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ CreateFlatPatternLighteningCutoutLabel() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.CreateFlatPatternLighteningCutoutLabel
(
self,

createFlatPatternLCutoutLabel )

Setter for property: (bool) CreateFlatPatternLighteningCutoutLabel. 

Sets the create flat pattern lightening cutout label setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ CreateFlatPatternNote() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.CreateFlatPatternNote
(
self — )

Getter for property: (bool) CreateFlatPatternNote Returns the create flat pattern note setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ CreateFlatPatternNote() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.CreateFlatPatternNote
(
self,

createFlatPatternNote )

Setter for property: (bool) CreateFlatPatternNote. 

Sets the create flat pattern note setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ CreateFlatPatternToolIDLabel() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.CreateFlatPatternToolIDLabel
(
self — )

Getter for property: (bool) CreateFlatPatternToolIDLabel Returns the create flat pattern tool id label setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ CreateFlatPatternToolIDLabel() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.CreateFlatPatternToolIDLabel
(
self,

createFlatPatternToolIdLabel )

Setter for property: (bool) CreateFlatPatternToolIDLabel. 

Sets the create flat pattern tool id label setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ DecimalPlaces() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.DecimalPlaces
(
self — )

Getter for property: (int) DecimalPlaces Returns the decimal places setting. 

Only values from 0 to 6 are valid.

Getter License requirements: None.

Created in NX2007.0.0 

Returns
int 

## ◆ DecimalPlaces() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.DecimalPlaces
(
self,

decimalPlaces )

Setter for property: (int) DecimalPlaces. 

Sets the decimal places setting. Only values from 0 to 6 are valid.

Setter License requirements: geometric_tol ("GDT"), nx_sheet_metal ("NX Sheet Metal")

Created in NX2007.0.0 

## ◆ FlatPatternHoleDetailsPrefix() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatPatternHoleDetailsPrefix
(
self — )

Getter for property: (str) FlatPatternHoleDetailsPrefix Returns the prefix characters for flat pattern hole details label. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
str 

## ◆ FlatPatternHoleDetailsPrefix() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatPatternHoleDetailsPrefix
(
self,

prefix )

Setter for property: (str) FlatPatternHoleDetailsPrefix. 

Sets the prefix characters for flat pattern hole details label.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ FlatPatternHoleDetailsSuffix() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatPatternHoleDetailsSuffix
(
self — )

Getter for property: (str) FlatPatternHoleDetailsSuffix Returns the suffix characters for flat pattern hole details label. 

Getter License requirements: None.

Created in NX2412.0.0 

Returns
str 

## ◆ FlatPatternHoleDetailsSuffix() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatPatternHoleDetailsSuffix
(
self,

suffix )

Setter for property: (str) FlatPatternHoleDetailsSuffix. 

Sets the suffix characters for flat pattern hole details label.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2412.0.0 

## ◆ FlatPatternToolIDPrefix() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatPatternToolIDPrefix
(
self — )

Getter for property: (str) FlatPatternToolIDPrefix Returns the prefix characters for flat pattern tool ID label. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
str 

## ◆ FlatPatternToolIDPrefix() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatPatternToolIDPrefix
(
self,

prefix )

Setter for property: (str) FlatPatternToolIDPrefix. 

Sets the prefix characters for flat pattern tool ID label.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ FlatPatternToolIDSuffix() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatPatternToolIDSuffix
(
self — )

Getter for property: (str) FlatPatternToolIDSuffix Returns the suffix characters for flat pattern tool ID label. 

Getter License requirements: None.

Created in NX2412.0.0 

Returns
str 

## ◆ FlatPatternToolIDSuffix() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatPatternToolIDSuffix
(
self,

suffix )

Setter for property: (str) FlatPatternToolIDSuffix. 

Sets the suffix characters for flat pattern tool ID label.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2412.0.0 

## ◆ GetFlatPatternBendParameters()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.GetFlatPatternBendParameters
(
self — )

Returns flat pattern bend labels. 

Returns
fpBendParameters (List[NXOpen.Annotations.SheetMetalPMISettingsBuilder.BendParameters]): .

Created in NX2506.0.0 

License requirements: None. 

## ◆ GetFlatPatternPropertiesNote()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.GetFlatPatternPropertiesNote
(
self — )

Returns flat pattern properties note. 

Returns
fpProperties (List[NXOpen.Annotations.SheetMetalPMISettingsBuilder.FpProperties]): .

Created in NX2506.0.0 

License requirements: None. 

## ◆ GetPrefixForBendParameterType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.GetPrefixForBendParameterType
(
self,

parameterType )

Gets prefix for bend parameter type. 

Returns
prefix (str): .

Created in NX2007.0.0 

License requirements: None.

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.BendParameterType)

## ◆ GetPrefixForBodyParameterType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.GetPrefixForBodyParameterType
(
self,

parameterType )

Gets prefix for body parameter type. 

Returns
prefix (str): .

Created in NX2007.0.0 

License requirements: None.

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.BodyParameterType)

## ◆ GetPrefixForFlatPatternBendDataType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.GetPrefixForFlatPatternBendDataType
(
self,

parameterType )

Gets prefix for flat pattern bend data type. 

Returns
prefix (str): .

Created in NX2007.0.0 

License requirements: None.

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternBendDataType)

## ◆ GetPrefixForFlatPatternJogggleParameterType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.GetPrefixForFlatPatternJogggleParameterType
(
self,

parameterType )

Gets prefix for flat pattern joggle parameter type. 

Returns
prefix (str): .

Created in NX2007.0.0 

License requirements: None.

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternJoggleParametersType)

## ◆ GetPrefixForFlatPatternLighteningCutoutParameterType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.GetPrefixForFlatPatternLighteningCutoutParameterType
(
self,

parameterType )

Gets prefix for flat pattern lightening cutout parameter type. 

Returns
prefix (str): .

Created in NX2007.0.0 

License requirements: None.

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternLighteningCutoutParametersType)

## ◆ GetPrefixForFlatPatternNotePropertiesType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.GetPrefixForFlatPatternNotePropertiesType
(
self,

parameterType )

Gets prefix for flat pattern note properties type. 

Returns
prefix (str): .

Created in NX2007.0.0 

License requirements: None.

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternNotePropertiesType)

## ◆ GetSuffixForBendParameterType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.GetSuffixForBendParameterType
(
self,

parameterType )

Gets suffix for bend parameter type. 

Returns
suffix (str): .

Created in NX2412.0.0 

License requirements: None.

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.BendParameterType)

## ◆ GetSuffixForBodyParameterType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.GetSuffixForBodyParameterType
(
self,

parameterType )

Gets suffix for body parameter type. 

Returns
suffix (str): .

Created in NX2412.0.0 

License requirements: None.

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.BodyParameterType)

## ◆ GetSuffixForFlatPatternBendDataType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.GetSuffixForFlatPatternBendDataType
(
self,

parameterType )

Gets suffix for flat pattern bend data type. 

Returns
suffix (str): .

Created in NX2412.0.0 

License requirements: None.

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternBendDataType)

## ◆ GetSuffixForFlatPatternJogggleParameterType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.GetSuffixForFlatPatternJogggleParameterType
(
self,

parameterType )

Gets suffix for flat pattern joggle parameter type. 

Returns
suffix (str): .

Created in NX2412.0.0 

License requirements: None.

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternJoggleParametersType)

## ◆ GetSuffixForFlatPatternLighteningCutoutParameterType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.GetSuffixForFlatPatternLighteningCutoutParameterType
(
self,

parameterType )

Gets suffix for flat pattern lightening cutout parameter type. 

Returns
suffix (str): .

Created in NX2412.0.0 

License requirements: None.

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternLighteningCutoutParametersType)

## ◆ GetSuffixForFlatPatternNotePropertiesType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.GetSuffixForFlatPatternNotePropertiesType
(
self,

parameterType )

Gets suffix for flat pattern note properties type. 

Returns
suffix (str): .

Created in NX2412.0.0 

License requirements: None.

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternNotePropertiesType)

## ◆ IncludeBendAngle() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeBendAngle
(
self — )

Getter for property: (bool) IncludeBendAngle Returns the include bend angle setting. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
bool 

## ◆ IncludeBendAngle() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeBendAngle
(
self,

includeBendAngle )

Setter for property: (bool) IncludeBendAngle. 

Sets the include bend angle setting.

Setter License requirements: geometric_tol ("GDT"), nx_sheet_metal ("NX Sheet Metal")

Created in NX2007.0.0 

## ◆ IncludeBendAngleInFlatPatternLabel() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeBendAngleInFlatPatternLabel
(
self — )

Getter for property: (bool) IncludeBendAngleInFlatPatternLabel Returns the include bend angle in flat pattern bend label setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IncludeBendAngleInFlatPatternLabel() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeBendAngleInFlatPatternLabel
(
self,

includeBendAngle )

Setter for property: (bool) IncludeBendAngleInFlatPatternLabel. 

Sets the include bend angle in flat pattern bend label setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ IncludeBendDirectionInFlatPatternLabel() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeBendDirectionInFlatPatternLabel
(
self — )

Getter for property: (bool) IncludeBendDirectionInFlatPatternLabel Returns the include bend direction in flat pattern bend label setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IncludeBendDirectionInFlatPatternLabel() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeBendDirectionInFlatPatternLabel
(
self,

includeBendDirection )

Setter for property: (bool) IncludeBendDirectionInFlatPatternLabel. 

Sets the include bend direction in flat pattern bend label setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ IncludeBendNameInFlatPatternLabel() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeBendNameInFlatPatternLabel
(
self — )

Getter for property: (bool) IncludeBendNameInFlatPatternLabel Returns the include bend name in flat pattern bend label setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IncludeBendNameInFlatPatternLabel() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeBendNameInFlatPatternLabel
(
self,

includeBendName )

Setter for property: (bool) IncludeBendNameInFlatPatternLabel. 

Sets the include bend name in flat pattern bend label setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ IncludeBendRadius() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeBendRadius
(
self — )

Getter for property: (bool) IncludeBendRadius Returns the include bend radius setting. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
bool 

## ◆ IncludeBendRadius() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeBendRadius
(
self,

includeBendRadius )

Setter for property: (bool) IncludeBendRadius. 

Sets the include bend radius setting.

Setter License requirements: geometric_tol ("GDT"), nx_sheet_metal ("NX Sheet Metal")

Created in NX2007.0.0 

## ◆ IncludeBendRadiusInFlatPatternLabel() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeBendRadiusInFlatPatternLabel
(
self — )

Getter for property: (bool) IncludeBendRadiusInFlatPatternLabel Returns the include bend radius in flat pattern bend label setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IncludeBendRadiusInFlatPatternLabel() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeBendRadiusInFlatPatternLabel
(
self,

includeBendRadius )

Setter for property: (bool) IncludeBendRadiusInFlatPatternLabel. 

Sets the include bend radius in flat pattern bend label setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ IncludeBendSequenceIDInFlatPatternLabel() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeBendSequenceIDInFlatPatternLabel
(
self — )

Getter for property: (bool) IncludeBendSequenceIDInFlatPatternLabel Returns the include bend sequence id in flat pattern bend label setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IncludeBendSequenceIDInFlatPatternLabel() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeBendSequenceIDInFlatPatternLabel
(
self,

includeBendSeqID )

Setter for property: (bool) IncludeBendSequenceIDInFlatPatternLabel. 

Sets the include bend sequence id in flat pattern bend label setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ IncludeCutoutDiameterInFlatPatternLabel() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeCutoutDiameterInFlatPatternLabel
(
self — )

Getter for property: (bool) IncludeCutoutDiameterInFlatPatternLabel Returns the include cutout diameter in flat pattern lightening cutout setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IncludeCutoutDiameterInFlatPatternLabel() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeCutoutDiameterInFlatPatternLabel
(
self,

includeCutoutDiameter )

Setter for property: (bool) IncludeCutoutDiameterInFlatPatternLabel. 

Sets the include cutout diameter in flat pattern lightening cutout setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ IncludeExteriorCutLengthInFlatPatternNote() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeExteriorCutLengthInFlatPatternNote
(
self — )

Getter for property: (bool) IncludeExteriorCutLengthInFlatPatternNote Returns the include exterior cut length in flat pattern note setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IncludeExteriorCutLengthInFlatPatternNote() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeExteriorCutLengthInFlatPatternNote
(
self,

includeExteriorCutLength )

Setter for property: (bool) IncludeExteriorCutLengthInFlatPatternNote. 

Sets the include exterior cut length in flat pattern note setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ IncludeHoleDiameterInFlatPatternLabel() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeHoleDiameterInFlatPatternLabel
(
self — )

Getter for property: (bool) IncludeHoleDiameterInFlatPatternLabel Returns the include hole diameter in flat pattern lightening cutout label setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IncludeHoleDiameterInFlatPatternLabel() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeHoleDiameterInFlatPatternLabel
(
self,

includeHoleDiameter )

Setter for property: (bool) IncludeHoleDiameterInFlatPatternLabel. 

Sets the include hole diameter in flat pattern lightening cutout label setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ IncludeInnerBendAngleInFlatPatternLabel() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeInnerBendAngleInFlatPatternLabel
(
self — )

Getter for property: (bool) IncludeInnerBendAngleInFlatPatternLabel Returns the include inner bend angle in flat pattern bend label setting. 

Getter License requirements: None.

Created in NX2206.3000.0 

Returns
bool 

## ◆ IncludeInnerBendAngleInFlatPatternLabel() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeInnerBendAngleInFlatPatternLabel
(
self,

includeInnerBendAngle )

Setter for property: (bool) IncludeInnerBendAngleInFlatPatternLabel. 

Sets the include inner bend angle in flat pattern bend label setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.3000.0 

## ◆ IncludeInteriorCutLengthInFlatPatternNote() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeInteriorCutLengthInFlatPatternNote
(
self — )

Getter for property: (bool) IncludeInteriorCutLengthInFlatPatternNote Returns the include interior cut length in flat pattern note setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IncludeInteriorCutLengthInFlatPatternNote() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeInteriorCutLengthInFlatPatternNote
(
self,

includeInteriorCutLength )

Setter for property: (bool) IncludeInteriorCutLengthInFlatPatternNote. 

Sets the include interior cut length in flat pattern note setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ IncludeInteriorCutoutCountInFlatPatternNote() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeInteriorCutoutCountInFlatPatternNote
(
self — )

Getter for property: (bool) IncludeInteriorCutoutCountInFlatPatternNote Returns the include interior cutout count in flat pattern note setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IncludeInteriorCutoutCountInFlatPatternNote() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeInteriorCutoutCountInFlatPatternNote
(
self,

includeInteriorCutoutCount )

Setter for property: (bool) IncludeInteriorCutoutCountInFlatPatternNote. 

Sets the include interior cutout count in flat pattern note setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ IncludeJoggleDepthInFlatPatternLabel() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeJoggleDepthInFlatPatternLabel
(
self — )

Getter for property: (bool) IncludeJoggleDepthInFlatPatternLabel Returns the include joggle depth in flat pattern joggle label setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IncludeJoggleDepthInFlatPatternLabel() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeJoggleDepthInFlatPatternLabel
(
self,

includeJoggleDepth )

Setter for property: (bool) IncludeJoggleDepthInFlatPatternLabel. 

Sets the include joggle depth in flat pattern joggle label setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ IncludeJoggleRunoutInFlatPatternLabel() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeJoggleRunoutInFlatPatternLabel
(
self — )

Getter for property: (bool) IncludeJoggleRunoutInFlatPatternLabel Returns the include joggle runout in flat pattern joggle label setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IncludeJoggleRunoutInFlatPatternLabel() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeJoggleRunoutInFlatPatternLabel
(
self,

includeJoggleRunout )

Setter for property: (bool) IncludeJoggleRunoutInFlatPatternLabel. 

Sets the include joggle runout in flat pattern joggle label setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ IncludeMaterial() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeMaterial
(
self — )

Getter for property: (bool) IncludeMaterial Returns the include sm material setting. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
bool 

## ◆ IncludeMaterial() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeMaterial
(
self,

includeSmMaterial )

Setter for property: (bool) IncludeMaterial. 

Sets the include sm material setting.

Setter License requirements: geometric_tol ("GDT"), nx_sheet_metal ("NX Sheet Metal")

Created in NX2007.0.0 

## ◆ IncludeMinimumXInFlatPatternNote() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeMinimumXInFlatPatternNote
(
self — )

Getter for property: (bool) IncludeMinimumXInFlatPatternNote Returns the include minimum x in flat pattern note setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IncludeMinimumXInFlatPatternNote() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeMinimumXInFlatPatternNote
(
self,

includeMinimumX )

Setter for property: (bool) IncludeMinimumXInFlatPatternNote. 

Sets the include minimum x in flat pattern note setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ IncludeMinimumYInFlatPatternNote() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeMinimumYInFlatPatternNote
(
self — )

Getter for property: (bool) IncludeMinimumYInFlatPatternNote Returns the include minimum y in flat pattern note setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IncludeMinimumYInFlatPatternNote() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeMinimumYInFlatPatternNote
(
self,

includeMinimumY )

Setter for property: (bool) IncludeMinimumYInFlatPatternNote. 

Sets the include minimum y in flat pattern note setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ IncludeNeutralFactor() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeNeutralFactor
(
self — )

Getter for property: (bool) IncludeNeutralFactor Returns the include neutral factor setting. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
bool 

## ◆ IncludeNeutralFactor() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeNeutralFactor
(
self,

includeNeutralFactor )

Setter for property: (bool) IncludeNeutralFactor. 

Sets the include neutral factor setting.

Setter License requirements: geometric_tol ("GDT"), nx_sheet_metal ("NX Sheet Metal")

Created in NX2007.0.0 

## ◆ IncludeNeutralFactorInFlatPatternLabel() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeNeutralFactorInFlatPatternLabel
(
self — )

Getter for property: (bool) IncludeNeutralFactorInFlatPatternLabel Returns the include neutral factor in flat pattern bend label setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IncludeNeutralFactorInFlatPatternLabel() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeNeutralFactorInFlatPatternLabel
(
self,

includeNeutralFactor )

Setter for property: (bool) IncludeNeutralFactorInFlatPatternLabel. 

Sets the include neutral factor in flat pattern bend label setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ IncludePhysicalMaterial() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludePhysicalMaterial
(
self — )

Getter for property: (bool) IncludePhysicalMaterial Returns the include physical material setting. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
bool 

## ◆ IncludePhysicalMaterial() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludePhysicalMaterial
(
self,

includePhysicalMaterial )

Setter for property: (bool) IncludePhysicalMaterial. 

Sets the include physical material setting.

Setter License requirements: geometric_tol ("GDT"), nx_sheet_metal ("NX Sheet Metal")

Created in NX2007.0.0 

## ◆ IncludeThickness() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeThickness
(
self — )

Getter for property: (bool) IncludeThickness Returns the include material thickness setting. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
bool 

## ◆ IncludeThickness() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeThickness
(
self,

includeMaterialhickness )

Setter for property: (bool) IncludeThickness. 

Sets the include material thickness setting.

Setter License requirements: geometric_tol ("GDT"), nx_sheet_metal ("NX Sheet Metal")

Created in NX2007.0.0 

## ◆ IncludeTotalCutLengthInFlatPatternNote() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeTotalCutLengthInFlatPatternNote
(
self — )

Getter for property: (bool) IncludeTotalCutLengthInFlatPatternNote Returns the include total cut length in flat pattern note setting. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
bool 

## ◆ IncludeTotalCutLengthInFlatPatternNote() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.IncludeTotalCutLengthInFlatPatternNote
(
self,

includeTotalCutLength )

Setter for property: (bool) IncludeTotalCutLengthInFlatPatternNote. 

Sets the include total cut length in flat pattern note setting.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ LabelPlacementType() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.LabelPlacementType
(
self — )

Getter for property: (NXOpen.Annotations.SheetMetalPMISettingsBuilder.LabelPlacementTypes) LabelPlacementType Returns the sheet metal pmi orientation. 

Getter License requirements: None.

Created in NX2506.0.0 

Returns
SheetMetalPMISettingsBuilder.LabelPlacementTypes 

## ◆ LabelPlacementType() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.LabelPlacementType
(
self,

labelPlacementType )

Setter for property: (NXOpen.Annotations.SheetMetalPMISettingsBuilder.LabelPlacementTypes) LabelPlacementType. 

Sets the sheet metal pmi orientation

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2506.0.0 

## ◆ PmiLabelType() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.PmiLabelType
(
self — )

Getter for property: (NXOpen.Annotations.SheetMetalPMISettingsBuilder.SmPmiType) PmiLabelType Returns the sheet metal pmi type. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
SheetMetalPMISettingsBuilder.SmPmiType 

## ◆ PmiLabelType() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.PmiLabelType
(
self,

type )

Setter for property: (NXOpen.Annotations.SheetMetalPMISettingsBuilder.SmPmiType) PmiLabelType. 

Sets the sheet metal pmi type

Setter License requirements: geometric_tol ("GDT"), nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ PmiLayer() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.PmiLayer
(
self — )

Getter for property: (int) PmiLayer Returns the flat pattern PMI layer setting. 

Only values from 1 to 256 (both inclusive) are valid.

Getter License requirements: None.

Created in NX2506.0.0 

Returns
int 

## ◆ PmiLayer() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.PmiLayer
(
self,

layer )

Setter for property: (int) PmiLayer. 

Sets the flat pattern PMI layer setting. Only values from 1 to 256 (both inclusive) are valid.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2506.0.0 

## ◆ PmiLayerOption() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.PmiLayerOption
(
self — )

Getter for property: (NXOpen.Annotations.SheetMetalPMISettingsBuilder.PmiLayerOptions) PmiLayerOption Returns the layer option. 

Getter License requirements: None.

Created in NX2506.0.0 

Returns
SheetMetalPMISettingsBuilder.PmiLayerOptions 

## ◆ PmiLayerOption() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.PmiLayerOption
(
self,

layerOption )

Setter for property: (NXOpen.Annotations.SheetMetalPMISettingsBuilder.PmiLayerOptions) PmiLayerOption. 

Sets the layer option.

Setter License requirements: nx_flexible_pcb ("NX Flexible PCB") OR nx_sheet_metal ("NX Sheet Metal")

Created in NX2506.0.0 

## ◆ PmiNoteType() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.PmiNoteType
(
self — )

Getter for property: (NXOpen.Annotations.SheetMetalPMISettingsBuilder.SmPmiNoteType) PmiNoteType Returns the sheet metal pmi note type. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
SheetMetalPMISettingsBuilder.SmPmiNoteType 

## ◆ PmiNoteType() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.PmiNoteType
(
self,

type )

Setter for property: (NXOpen.Annotations.SheetMetalPMISettingsBuilder.SmPmiNoteType) PmiNoteType. 

Sets the sheet metal pmi note type

Setter License requirements: geometric_tol ("GDT"), nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2206.0.0 

## ◆ SetFlatPatternBendParameters()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SetFlatPatternBendParameters
(
self,

fpBendParameters )

Sets flat pattern bend labels. 

Created in NX2506.0.0 

License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Parameters

fpBendParameters — (List[NXOpen.Annotations.SheetMetalPMISettingsBuilder.BendParameters])

## ◆ SetFlatPatternPropertiesNote()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SetFlatPatternPropertiesNote
(
self,

fpProperties )

Sets flat pattern properties note. 

Created in NX2506.0.0 

License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Parameters

fpProperties — (List[NXOpen.Annotations.SheetMetalPMISettingsBuilder.FpProperties])

## ◆ SetPrefixForBendParameterType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SetPrefixForBendParameterType
(
self,

parameterType,

prefix )

Sets prefix for bend parameter type. 

Created in NX2007.0.0 

License requirements: geometric_tol ("GDT"), nx_sheet_metal ("NX Sheet Metal")

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.BendParameterType)

prefix — (str)

## ◆ SetPrefixForBodyParameterType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SetPrefixForBodyParameterType
(
self,

parameterType,

prefix )

Sets prefix for body parameter type. 

Created in NX2007.0.0 

License requirements: geometric_tol ("GDT"), nx_sheet_metal ("NX Sheet Metal")

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.BodyParameterType)

prefix — (str)

## ◆ SetPrefixForFlatPatternBendDataType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SetPrefixForFlatPatternBendDataType
(
self,

parameterType,

prefix )

Sets prefix for flat pattern bend data type. 

Created in NX2206.0.0 

License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternBendDataType)

prefix — (str)

## ◆ SetPrefixForFlatPatternJoggleParameterType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SetPrefixForFlatPatternJoggleParameterType
(
self,

parameterType,

prefix )

Sets prefix for flat pattern joggle parameter type. 

Created in NX2206.0.0 

License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternJoggleParametersType)

prefix — (str)

## ◆ SetPrefixForFlatPatternLighteningCutoutParameterType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SetPrefixForFlatPatternLighteningCutoutParameterType
(
self,

parameterType,

prefix )

Sets prefix for flat pattern lightening cutout parameter type. 

Created in NX2206.0.0 

License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternLighteningCutoutParametersType)

prefix — (str)

## ◆ SetPrefixForFlatPatternNotePropertiesType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SetPrefixForFlatPatternNotePropertiesType
(
self,

parameterType,

prefix )

Sets prefix for flat pattern note properties type. 

Created in NX2206.0.0 

License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternNotePropertiesType)

prefix — (str)

## ◆ SetSuffixForBendParameterType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SetSuffixForBendParameterType
(
self,

parameterType,

suffix )

Sets suffix for bend parameter type. 

Created in NX2412.0.0 

License requirements: geometric_tol ("GDT"), nx_sheet_metal ("NX Sheet Metal")

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.BendParameterType)

suffix — (str)

## ◆ SetSuffixForBodyParameterType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SetSuffixForBodyParameterType
(
self,

parameterType,

suffix )

Sets suffix for body parameter type. 

Created in NX2412.0.0 

License requirements: geometric_tol ("GDT"), nx_sheet_metal ("NX Sheet Metal")

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.BodyParameterType)

suffix — (str)

## ◆ SetSuffixForFlatPatternBendDataType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SetSuffixForFlatPatternBendDataType
(
self,

parameterType,

suffix )

Sets suffix for flat pattern bend data type. 

Created in NX2412.0.0 

License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternBendDataType)

suffix — (str)

## ◆ SetSuffixForFlatPatternJoggleParameterType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SetSuffixForFlatPatternJoggleParameterType
(
self,

parameterType,

suffix )

Sets suffix for flat pattern joggle parameter type. 

Created in NX2412.0.0 

License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternJoggleParametersType)

suffix — (str)

## ◆ SetSuffixForFlatPatternLighteningCutoutParameterType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SetSuffixForFlatPatternLighteningCutoutParameterType
(
self,

parameterType,

suffix )

Sets suffix for flat pattern lightening cutout parameter type. 

Created in NX2412.0.0 

License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternLighteningCutoutParametersType)

suffix — (str)

## ◆ SetSuffixForFlatPatternNotePropertiesType()

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SetSuffixForFlatPatternNotePropertiesType
(
self,

parameterType,

suffix )

Sets suffix for flat pattern note properties type. 

Created in NX2412.0.0 

License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Parameters

parameterType — (NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternNotePropertiesType)

suffix — (str)

## ◆ ThroughHoleText() [1/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.ThroughHoleText
(
self — )

Getter for property: (str) ThroughHoleText Returns the text for through hole in flat pattern hole details label. 

Getter License requirements: None.

Created in NX2506.0.0 

Returns
str 

## ◆ ThroughHoleText() [2/2]

NXOpen.Annotations.SheetMetalPMISettingsBuilder.ThroughHoleText
(
self,

throughHoleText )

Setter for property: (str) ThroughHoleText. 

Sets the text for through hole in flat pattern hole details label.

Setter License requirements: nx_sheet_metal ("NX Sheet Metal") OR nx_flexible_pcb ("NX Flexible PCB")

Created in NX2506.0.0 

## Member Data Documentation

## ◆ SheetMetalPMISettingsBuilderBendParameters

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SheetMetalPMISettingsBuilderBendParameters = SheetMetalPMISettingsBuilder.BendParameters

NXOpen.Annotations.SheetMetalPMISettingsBuilderBendParameters is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.BendParameters 

## ◆ SheetMetalPMISettingsBuilderBendParameterType

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SheetMetalPMISettingsBuilderBendParameterType = SheetMetalPMISettingsBuilder.BendParameterType

NXOpen.Annotations.SheetMetalPMISettingsBuilderBendParameterType is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.BendParameterType 

## ◆ SheetMetalPMISettingsBuilderBodyParameterType

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SheetMetalPMISettingsBuilderBodyParameterType = SheetMetalPMISettingsBuilder.BodyParameterType

NXOpen.Annotations.SheetMetalPMISettingsBuilderBodyParameterType is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.BodyParameterType 

## ◆ SheetMetalPMISettingsBuilderFlatpatternBendDataType

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SheetMetalPMISettingsBuilderFlatpatternBendDataType = SheetMetalPMISettingsBuilder.FlatpatternBendDataType

NXOpen.Annotations.SheetMetalPMISettingsBuilderFlatpatternBendDataType is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternBendDataType 

## ◆ SheetMetalPMISettingsBuilderFlatpatternJoggleParametersType

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SheetMetalPMISettingsBuilderFlatpatternJoggleParametersType = SheetMetalPMISettingsBuilder.FlatpatternJoggleParametersType

NXOpen.Annotations.SheetMetalPMISettingsBuilderFlatpatternJoggleParametersType is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternJoggleParametersType 

## ◆ SheetMetalPMISettingsBuilderFlatpatternLighteningCutoutParametersType

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SheetMetalPMISettingsBuilderFlatpatternLighteningCutoutParametersType = SheetMetalPMISettingsBuilder.FlatpatternLighteningCutoutParametersType

NXOpen.Annotations.SheetMetalPMISettingsBuilderFlatpatternLighteningCutoutParametersType is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternLighteningCutoutParametersType 

## ◆ SheetMetalPMISettingsBuilderFlatpatternNotePropertiesType

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SheetMetalPMISettingsBuilderFlatpatternNotePropertiesType = SheetMetalPMISettingsBuilder.FlatpatternNotePropertiesType

NXOpen.Annotations.SheetMetalPMISettingsBuilderFlatpatternNotePropertiesType is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.FlatpatternNotePropertiesType 

## ◆ SheetMetalPMISettingsBuilderFpProperties

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SheetMetalPMISettingsBuilderFpProperties = SheetMetalPMISettingsBuilder.FpProperties

NXOpen.Annotations.SheetMetalPMISettingsBuilderFpProperties is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.FpProperties 

## ◆ SheetMetalPMISettingsBuilderLabelPlacementTypes

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SheetMetalPMISettingsBuilderLabelPlacementTypes = SheetMetalPMISettingsBuilder.LabelPlacementTypes

NXOpen.Annotations.SheetMetalPMISettingsBuilderLabelPlacementTypes is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.LabelPlacementTypes 

## ◆ SheetMetalPMISettingsBuilderPmiLayerOptions

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SheetMetalPMISettingsBuilderPmiLayerOptions = SheetMetalPMISettingsBuilder.PmiLayerOptions

NXOpen.Annotations.SheetMetalPMISettingsBuilderPmiLayerOptions is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.PmiLayerOptions 

## ◆ SheetMetalPMISettingsBuilderSmPmiNoteType

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SheetMetalPMISettingsBuilderSmPmiNoteType = SheetMetalPMISettingsBuilder.SmPmiNoteType

NXOpen.Annotations.SheetMetalPMISettingsBuilderSmPmiNoteType is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.SmPmiNoteType 

## ◆ SheetMetalPMISettingsBuilderSmPmiType

NXOpen.Annotations.SheetMetalPMISettingsBuilder.SheetMetalPMISettingsBuilderSmPmiType = SheetMetalPMISettingsBuilder.SmPmiType

NXOpen.Annotations.SheetMetalPMISettingsBuilderSmPmiType is an alias for NXOpen.Annotations.SheetMetalPMISettingsBuilder.SmPmiType 

Copyright 2025 Siemens
