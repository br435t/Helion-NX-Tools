# NXOpen.Annotations.LineWeldDataBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00178.html>

## Classes

class — ContourSymbolType

Represents the contour symbol type 

Enumerator — Comment

NotSet

Convex

Flat

Concave

BlendedToesIsoAndDinOnly

BackingStripPermanentIsoAndDinOnly

BackingStripRemovableIsoAndDinOnly

MeltThrough

Flush

MachiningGradedJunction

More...

class — FinishSymbolType

Represents the finish symbol type. More...

class — WeldSizeCodeType

Represents the weld size code type 

Enumerator — Comment

NotSet

A

C

D

S

Z

P

More...

class — WeldSymbolType

Represents the weld symbol type 

Enumerator — Comment

NotSet

ButtWeldWithRaisedEdges

SingleFlange

SquareButt

VButt

VButtWithBroadRootFace

BevelButt

BevelButtWithBroadRootFace

UButt

JButt

FlareV

FlareBevel

KGroove

Fillet

Stake

PlugSlot

Edge

Edge2

Spot

Spot2

Seam

Seam2

SteepFlankedVButt

SteepFlankedBevelButt

Backing

SurfaceJoint

SolderedJoint

InclinedJoint

FoldJoint

Stud

Surfacing

Intermittent

BackingPlate

NotSpecified

More...

Copyright 2025 Siemens
