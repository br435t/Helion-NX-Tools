# NXOpen.Annotations.PartsListContentsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00186.html>

## Classes

class — ScopeType

The options specify the configuration type level for the parts list 

Enumerator — Comment

AllLevels — All levels.

More...

class — TopLevelAssemblyType

The options specify the top level assembly type for the parts list 

Enumerator — Comment

ChildPart — Child Part.

More...

Copyright 2025 Siemens
