# NXOpen.Annotations.PmiSemanticGeneralBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13817.html>

Represents a NXOpen::Annotations::PmiSemanticGeneralBuilder. 
More...

Inheritance diagram for NXOpen.Annotations.PmiSemanticGeneralBuilder:

## Public Member Functions

Method (self)

Getter for property: (int) Method Returns the get method. 

Method (self, method)

Setter for property: (int) Method. 

UserDefinedSemanticNamePrefix (self)

Getter for property: (str) UserDefinedSemanticNamePrefix Returns the get semantic prefix. 

UserDefinedSemanticNamePrefix (self, semanticNamePrefixLabel)

Setter for property: (str) UserDefinedSemanticNamePrefix. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::PmiSemanticGeneralBuilder. 

Created in NX2506.0.0 

## Member Function Documentation

## ◆ Method() [1/2]

NXOpen.Annotations.PmiSemanticGeneralBuilder.Method
(
self — )

Getter for property: (int) Method Returns the get method. 

Getter License requirements: None.

Created in NX2506.0.0 

Returns
int 

## ◆ Method() [2/2]

NXOpen.Annotations.PmiSemanticGeneralBuilder.Method
(
self,

method )

Setter for property: (int) Method. 

Sets the get method

Setter License requirements: None.

Created in NX2506.0.0 

## ◆ UserDefinedSemanticNamePrefix() [1/2]

NXOpen.Annotations.PmiSemanticGeneralBuilder.UserDefinedSemanticNamePrefix
(
self — )

Getter for property: (str) UserDefinedSemanticNamePrefix Returns the get semantic prefix. 

Getter License requirements: None.

Created in NX2506.0.0 

Returns
str 

## ◆ UserDefinedSemanticNamePrefix() [2/2]

NXOpen.Annotations.PmiSemanticGeneralBuilder.UserDefinedSemanticNamePrefix
(
self,

semanticNamePrefixLabel )

Setter for property: (str) UserDefinedSemanticNamePrefix. 

Sets the get semantic prefix

Setter License requirements: None.

Created in NX2506.0.0 

Copyright 2025 Siemens
