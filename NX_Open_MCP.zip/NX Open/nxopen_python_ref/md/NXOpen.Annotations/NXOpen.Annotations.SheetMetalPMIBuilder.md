# NXOpen.Annotations.SheetMetalPMIBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00213.html>

## Classes

class — Types

This enum defines the type options. More...

Copyright 2025 Siemens
