# NXOpen.Annotations.HoleTableSettingsContentBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00166.html>

## Classes

class — Content

Represents Content options 

Enumerator — Comment

Diameter — Diameter

DiameterFit — DiameterFit

Depth — Depth

DepthFit — DepthFit

DrillType — DrillType

DrillDirection — DrillDirection

More...

Copyright 2025 Siemens
