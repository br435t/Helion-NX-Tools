# NXOpen.Annotations.BendTableBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11509.html>

Represents a NXOpen::Annotations::BendTableBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.BendTableBuilder:

## Public Member Functions

AnnotationOrigin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) AnnotationOrigin Returns the bend table origin. 

FlatPatternView (self)

Getter for property: (NXOpen.Drawings.SelectDraftingView) FlatPatternView Returns the flat pattern view the bend table is associated to. 

Style (self)

Getter for property: (NXOpen.Annotations.TableStyleBuilder) Style Returns the bend table style. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::BendTableBuilder . 

To create a new instance of this class, use NXOpen::Annotations::BendTableCollection::CreateBendTableBuilder 

Created in NX9.0.0 

## Member Function Documentation

## ◆ AnnotationOrigin()

NXOpen.Annotations.BendTableBuilder.AnnotationOrigin
(
self — )

Getter for property: (NXOpen.Annotations.OriginBuilder) AnnotationOrigin Returns the bend table origin. 

Getter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

Returns
OriginBuilder 

## ◆ FlatPatternView()

NXOpen.Annotations.BendTableBuilder.FlatPatternView
(
self — )

Getter for property: (NXOpen.Drawings.SelectDraftingView) FlatPatternView Returns the flat pattern view the bend table is associated to. 

Getter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

Returns
NXOpen.Drawings.SelectDraftingView 

## ◆ Style()

NXOpen.Annotations.BendTableBuilder.Style
(
self — )

Getter for property: (NXOpen.Annotations.TableStyleBuilder) Style Returns the bend table style. 

Getter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

Returns
TableStyleBuilder 

Copyright 2025 Siemens
