# NXOpen.Annotations.OriginBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13109.html>

Represents a NXOpen::Annotations::OriginBuilder 

This is a sub-builder class and cannot be directly instantiated 

More...

Inheritance diagram for NXOpen.Annotations.OriginBuilder:

## Public Member Functions

Anchor (self)

Getter for property: (NXOpen.Annotations.OriginBuilder.AlignmentPosition) Anchor Returns the anchor location of the origin on the annotation. 

Anchor (self, anchor)

Setter for property: (NXOpen.Annotations.OriginBuilder.AlignmentPosition) Anchor. 

AnnotationView (self)

Getter for property: (NXOpen.Drawings.SelectDraftingView) AnnotationView Returns the view of the annotation (drafting member views only) 

GetAssociativeOrigin (self)

Gets the data that specifies the origin's associativity. 

Origin (self)

Getter for property: (NXOpen.SelectDisplayableObject) Origin Returns the origin. 

OriginPoint (self)

Getter for property: (NXOpen.Point3d) OriginPoint Returns the origin point. 

OriginPoint (self, origin)

Setter for property: (NXOpen.Point3d) OriginPoint. 

Plane (self)

Getter for property: (NXOpen.Annotations.PlaneBuilder) Plane Returns the plane. 

SetAssociativeOrigin (self, assoc_origin)

Associates the annotation's origin to the specified objects. 

SetInferRelativeToGeometry (self, infer_relative_to_geometry)

Infers a relative to geometry associative on commit if no other associativity has been applied. 

SetInferRelativeToGeometryFromLeader (self, inferFromLeader)

Infers a relative to geometry associative origin from leader. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

OriginBuilderAlignmentPosition = OriginBuilder.AlignmentPosition

NXOpen.Annotations.OriginBuilderAlignmentPosition is an alias for NXOpen.Annotations.OriginBuilder.AlignmentPosition 

## Detailed Description

Represents a NXOpen::Annotations::OriginBuilder 

This is a sub-builder class and cannot be directly instantiated 

Created in NX6.0.0 

## Member Function Documentation

## ◆ Anchor() [1/2]

NXOpen.Annotations.OriginBuilder.Anchor
(
self — )

Getter for property: (NXOpen.Annotations.OriginBuilder.AlignmentPosition) Anchor Returns the anchor location of the origin on the annotation. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
OriginBuilder.AlignmentPosition 

## ◆ Anchor() [2/2]

NXOpen.Annotations.OriginBuilder.Anchor
(
self,

anchor )

Setter for property: (NXOpen.Annotations.OriginBuilder.AlignmentPosition) Anchor. 

Sets the anchor location of the origin on the annotation

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") OR solid_modeling ("SOLIDS MODELING")

Created in NX6.0.0 

## ◆ AnnotationView()

NXOpen.Annotations.OriginBuilder.AnnotationView
(
self — )

Getter for property: (NXOpen.Drawings.SelectDraftingView) AnnotationView Returns the view of the annotation (drafting member views only) 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.Drawings.SelectDraftingView 

## ◆ GetAssociativeOrigin()

NXOpen.Annotations.OriginBuilder.GetAssociativeOrigin
(
self — )

Gets the data that specifies the origin's associativity. 

Returns
assoc_origin (NXOpen.Annotations.Annotation.AssociativeOriginData): associativity data .

Created in NX6.0.0 

License requirements: None. 

## ◆ Origin()

NXOpen.Annotations.OriginBuilder.Origin
(
self — )

Getter for property: (NXOpen.SelectDisplayableObject) Origin Returns the origin. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectDisplayableObject 

## ◆ OriginPoint() [1/2]

NXOpen.Annotations.OriginBuilder.OriginPoint
(
self — )

Getter for property: (NXOpen.Point3d) OriginPoint Returns the origin point. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.Point3d 

## ◆ OriginPoint() [2/2]

NXOpen.Annotations.OriginBuilder.OriginPoint
(
self,

origin )

Setter for property: (NXOpen.Point3d) OriginPoint. 

Sets the origin point

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") OR solid_modeling ("SOLIDS MODELING") OR nx_2d_edit (" NX 2D Edit")

Created in NX6.0.0 

## ◆ Plane()

NXOpen.Annotations.OriginBuilder.Plane
(
self — )

Getter for property: (NXOpen.Annotations.PlaneBuilder) Plane Returns the plane. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
PlaneBuilder 

## ◆ SetAssociativeOrigin()

NXOpen.Annotations.OriginBuilder.SetAssociativeOrigin
(
self,

assoc_origin )

Associates the annotation's origin to the specified objects. 

Created in NX6.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") OR solid_modeling ("SOLIDS MODELING")

Parameters

assoc_origin — (NXOpen.Annotations.Annotation.AssociativeOriginData) associativity data

## ◆ SetInferRelativeToGeometry()

NXOpen.Annotations.OriginBuilder.SetInferRelativeToGeometry
(
self,

infer_relative_to_geometry )

Infers a relative to geometry associative on commit if no other associativity has been applied. 

Created in NX6.0.1 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") OR solid_modeling ("SOLIDS MODELING")

Parameters

infer_relative_to_geometry — (bool) relative to geometry flag

## ◆ SetInferRelativeToGeometryFromLeader()

NXOpen.Annotations.OriginBuilder.SetInferRelativeToGeometryFromLeader
(
self,

inferFromLeader )

Infers a relative to geometry associative origin from leader. 

Created in NX12.0.1 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") OR solid_modeling ("SOLIDS MODELING")

Parameters

inferFromLeader — (bool) infer relative to geometry from leader flag

## Member Data Documentation

## ◆ OriginBuilderAlignmentPosition

NXOpen.Annotations.OriginBuilder.OriginBuilderAlignmentPosition = OriginBuilder.AlignmentPosition

NXOpen.Annotations.OriginBuilderAlignmentPosition is an alias for NXOpen.Annotations.OriginBuilder.AlignmentPosition 

Copyright 2025 Siemens
