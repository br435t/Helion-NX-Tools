# NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13837.html>

Represents a NXOpen::Annotations::PmiSupplementalGeometryProductGridBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder:

## Public Member Functions

GridCFW (self)

Getter for property: (NXOpen.LineColorFontWidthBuilder) GridCFW Returns the grid color font and width. 

GridOverhang (self)

Getter for property: (float) GridOverhang Returns the grid overhang. 

GridOverhang (self, gridOverhang)

Setter for property: (float) GridOverhang. 

GridSpacing (self)

Getter for property: (float) GridSpacing Returns the grid spacing. 

GridSpacing (self, gridSpacing)

Setter for property: (float) GridSpacing. 

LabelDivisor (self)

Getter for property: (float) LabelDivisor Returns the label divisor. 

LabelDivisor (self, labelDivisor)

Setter for property: (float) LabelDivisor. 

LabelGap (self)

Getter for property: (float) LabelGap Returns the label gap. 

LabelGap (self, labelGap)

Setter for property: (float) LabelGap. 

LocationRelativeGridHorizontal (self)

Getter for property: (NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.HorizontalLabelDisplay) LocationRelativeGridHorizontal Returns the location of horizontal labels relative to the product grid. 

LocationRelativeGridHorizontal (self, locationRelativeGridHorizontal)

Setter for property: (NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.HorizontalLabelDisplay) LocationRelativeGridHorizontal. 

LocationRelativeGridValue (self)

Getter for property: (NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.GridLabelLocation) LocationRelativeGridValue Returns the location of the grid label relative to the grid value. 

LocationRelativeGridValue (self, locationRelativeGridValue)

Setter for property: (NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.GridLabelLocation) LocationRelativeGridValue. 

LocationRelativeGridVertical (self)

Getter for property: (NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.VerticalLabelDisplay) LocationRelativeGridVertical Returns the location of vertical labels relative to the product grid. 

LocationRelativeGridVertical (self, locationRelativeGridVertical)

Setter for property: (NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.VerticalLabelDisplay) LocationRelativeGridVertical. 

ReferenceXAxisLabel (self)

Getter for property: (str) ReferenceXAxisLabel Returns the label used to identify the product grid reference CSYS X axis. 

ReferenceXAxisLabel (self, referenceXAxisLabel)

Setter for property: (str) ReferenceXAxisLabel. 

ReferenceYAxisLabel (self)

Getter for property: (str) ReferenceYAxisLabel Returns the label used to identify the product grid reference CSYS Y axis. 

ReferenceYAxisLabel (self, referenceYAxisLabel)

Setter for property: (str) ReferenceYAxisLabel. 

ReferenceZAxisLabel (self)

Getter for property: (str) ReferenceZAxisLabel Returns the label used to identify the product grid reference CSYS Z axis. 

ReferenceZAxisLabel (self, referenceZAxisLabel)

Setter for property: (str) ReferenceZAxisLabel. 

ShowHorizontalGridLines (self)

Getter for property: (bool) ShowHorizontalGridLines Returns whether horizontal grid lines are displayed. 

ShowHorizontalGridLines (self, showHorizontalGridLines)

Setter for property: (bool) ShowHorizontalGridLines. 

ShowVerticalGridLines (self)

Getter for property: (bool) ShowVerticalGridLines Returns whether vertical grid lines are displayed. 

ShowVerticalGridLines (self, showVerticalGridLines)

Setter for property: (bool) ShowVerticalGridLines. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

PmiSupplementalGeometryProductGridBuilderGridLabelLocation = PmiSupplementalGeometryProductGridBuilder.GridLabelLocation

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilderGridLabelLocation is an alias for NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.GridLabelLocation 

PmiSupplementalGeometryProductGridBuilderHorizontalLabelDisplay = PmiSupplementalGeometryProductGridBuilder.HorizontalLabelDisplay

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilderHorizontalLabelDisplay is an alias for NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.HorizontalLabelDisplay 

PmiSupplementalGeometryProductGridBuilderVerticalLabelDisplay = PmiSupplementalGeometryProductGridBuilder.VerticalLabelDisplay

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilderVerticalLabelDisplay is an alias for NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.VerticalLabelDisplay 

## Detailed Description

Represents a NXOpen::Annotations::PmiSupplementalGeometryProductGridBuilder . 

This class queries and sets preferences and settings for product grids.

Created in NX1980.0.0 

## Member Function Documentation

## ◆ GridCFW()

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.GridCFW
(
self — )

Getter for property: (NXOpen.LineColorFontWidthBuilder) GridCFW Returns the grid color font and width. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
NXOpen.LineColorFontWidthBuilder 

## ◆ GridOverhang() [1/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.GridOverhang
(
self — )

Getter for property: (float) GridOverhang Returns the grid overhang. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
float 

## ◆ GridOverhang() [2/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.GridOverhang
(
self,

gridOverhang )

Setter for property: (float) GridOverhang. 

Sets the grid overhang

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ GridSpacing() [1/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.GridSpacing
(
self — )

Getter for property: (float) GridSpacing Returns the grid spacing. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
float 

## ◆ GridSpacing() [2/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.GridSpacing
(
self,

gridSpacing )

Setter for property: (float) GridSpacing. 

Sets the grid spacing

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ LabelDivisor() [1/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.LabelDivisor
(
self — )

Getter for property: (float) LabelDivisor Returns the label divisor. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
float 

## ◆ LabelDivisor() [2/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.LabelDivisor
(
self,

labelDivisor )

Setter for property: (float) LabelDivisor. 

Sets the label divisor

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ LabelGap() [1/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.LabelGap
(
self — )

Getter for property: (float) LabelGap Returns the label gap. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
float 

## ◆ LabelGap() [2/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.LabelGap
(
self,

labelGap )

Setter for property: (float) LabelGap. 

Sets the label gap

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ LocationRelativeGridHorizontal() [1/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.LocationRelativeGridHorizontal
(
self — )

Getter for property: (NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.HorizontalLabelDisplay) LocationRelativeGridHorizontal Returns the location of horizontal labels relative to the product grid. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
PmiSupplementalGeometryProductGridBuilder.HorizontalLabelDisplay 

## ◆ LocationRelativeGridHorizontal() [2/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.LocationRelativeGridHorizontal
(
self,

locationRelativeGridHorizontal )

Setter for property: (NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.HorizontalLabelDisplay) LocationRelativeGridHorizontal. 

Sets the location of horizontal labels relative to the product grid

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ LocationRelativeGridValue() [1/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.LocationRelativeGridValue
(
self — )

Getter for property: (NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.GridLabelLocation) LocationRelativeGridValue Returns the location of the grid label relative to the grid value. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
PmiSupplementalGeometryProductGridBuilder.GridLabelLocation 

## ◆ LocationRelativeGridValue() [2/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.LocationRelativeGridValue
(
self,

locationRelativeGridValue )

Setter for property: (NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.GridLabelLocation) LocationRelativeGridValue. 

Sets the location of the grid label relative to the grid value

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ LocationRelativeGridVertical() [1/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.LocationRelativeGridVertical
(
self — )

Getter for property: (NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.VerticalLabelDisplay) LocationRelativeGridVertical Returns the location of vertical labels relative to the product grid. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
PmiSupplementalGeometryProductGridBuilder.VerticalLabelDisplay 

## ◆ LocationRelativeGridVertical() [2/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.LocationRelativeGridVertical
(
self,

locationRelativeGridVertical )

Setter for property: (NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.VerticalLabelDisplay) LocationRelativeGridVertical. 

Sets the location of vertical labels relative to the product grid

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ ReferenceXAxisLabel() [1/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.ReferenceXAxisLabel
(
self — )

Getter for property: (str) ReferenceXAxisLabel Returns the label used to identify the product grid reference CSYS X axis. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
str 

## ◆ ReferenceXAxisLabel() [2/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.ReferenceXAxisLabel
(
self,

referenceXAxisLabel )

Setter for property: (str) ReferenceXAxisLabel. 

Sets the label used to identify the product grid reference CSYS X axis

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ ReferenceYAxisLabel() [1/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.ReferenceYAxisLabel
(
self — )

Getter for property: (str) ReferenceYAxisLabel Returns the label used to identify the product grid reference CSYS Y axis. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
str 

## ◆ ReferenceYAxisLabel() [2/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.ReferenceYAxisLabel
(
self,

referenceYAxisLabel )

Setter for property: (str) ReferenceYAxisLabel. 

Sets the label used to identify the product grid reference CSYS Y axis

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ ReferenceZAxisLabel() [1/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.ReferenceZAxisLabel
(
self — )

Getter for property: (str) ReferenceZAxisLabel Returns the label used to identify the product grid reference CSYS Z axis. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
str 

## ◆ ReferenceZAxisLabel() [2/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.ReferenceZAxisLabel
(
self,

referenceZAxisLabel )

Setter for property: (str) ReferenceZAxisLabel. 

Sets the label used to identify the product grid reference CSYS Z axis

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ ShowHorizontalGridLines() [1/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.ShowHorizontalGridLines
(
self — )

Getter for property: (bool) ShowHorizontalGridLines Returns whether horizontal grid lines are displayed. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
bool 

## ◆ ShowHorizontalGridLines() [2/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.ShowHorizontalGridLines
(
self,

showHorizontalGridLines )

Setter for property: (bool) ShowHorizontalGridLines. 

Sets whether horizontal grid lines are displayed

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX1980.0.0 

## ◆ ShowVerticalGridLines() [1/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.ShowVerticalGridLines
(
self — )

Getter for property: (bool) ShowVerticalGridLines Returns whether vertical grid lines are displayed. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
bool 

## ◆ ShowVerticalGridLines() [2/2]

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.ShowVerticalGridLines
(
self,

showVerticalGridLines )

Setter for property: (bool) ShowVerticalGridLines. 

Sets whether vertical grid lines are displayed

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX1980.0.0 

## Member Data Documentation

## ◆ PmiSupplementalGeometryProductGridBuilderGridLabelLocation

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.PmiSupplementalGeometryProductGridBuilderGridLabelLocation = PmiSupplementalGeometryProductGridBuilder.GridLabelLocation

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilderGridLabelLocation is an alias for NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.GridLabelLocation 

## ◆ PmiSupplementalGeometryProductGridBuilderHorizontalLabelDisplay

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.PmiSupplementalGeometryProductGridBuilderHorizontalLabelDisplay = PmiSupplementalGeometryProductGridBuilder.HorizontalLabelDisplay

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilderHorizontalLabelDisplay is an alias for NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.HorizontalLabelDisplay 

## ◆ PmiSupplementalGeometryProductGridBuilderVerticalLabelDisplay

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.PmiSupplementalGeometryProductGridBuilderVerticalLabelDisplay = PmiSupplementalGeometryProductGridBuilder.VerticalLabelDisplay

NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilderVerticalLabelDisplay is an alias for NXOpen.Annotations.PmiSupplementalGeometryProductGridBuilder.VerticalLabelDisplay 

Copyright 2025 Siemens
