# NXOpen.Annotations.HoleTableSettingsLabelBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12573.html>

Represents a NXOpen::Annotations::HoleTableSettingsLabelBuilder. 
More...

Inheritance diagram for NXOpen.Annotations.HoleTableSettingsLabelBuilder:

## Public Member Functions

CharactersToSkip (self)

Getter for property: (str) CharactersToSkip Returns the characters to skip. 

CharactersToSkip (self, charactersToSkip)

Setter for property: (str) CharactersToSkip. 

IndexFormat (self)

Getter for property: (NXOpen.Annotations.HoleTableSettingsLabelBuilder.IndexType) IndexFormat Returns the index format of hole label. 

IndexFormat (self, indexFormat)

Setter for property: (NXOpen.Annotations.HoleTableSettingsLabelBuilder.IndexType) IndexFormat. 

RelativeLocation (self)

Getter for property: (NXOpen.Annotations.HoleTableSettingsLabelBuilder.RelativeLocationType) RelativeLocation Returns the relative location of hole label. 

RelativeLocation (self, relativeLocation)

Setter for property: (NXOpen.Annotations.HoleTableSettingsLabelBuilder.RelativeLocationType) RelativeLocation. 

ShowLabelWithLeader (self)

Getter for property: (bool) ShowLabelWithLeader Returns the show hole label with leader. 

ShowLabelWithLeader (self, showLabelWithLeader)

Setter for property: (bool) ShowLabelWithLeader. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

HoleTableSettingsLabelBuilderIndexType = HoleTableSettingsLabelBuilder.IndexType

NXOpen.Annotations.HoleTableSettingsLabelBuilderIndexType is an alias for NXOpen.Annotations.HoleTableSettingsLabelBuilder.IndexType 

HoleTableSettingsLabelBuilderRelativeLocationType = HoleTableSettingsLabelBuilder.RelativeLocationType

NXOpen.Annotations.HoleTableSettingsLabelBuilderRelativeLocationType is an alias for NXOpen.Annotations.HoleTableSettingsLabelBuilder.RelativeLocationType 

## Detailed Description

Represents a NXOpen::Annotations::HoleTableSettingsLabelBuilder. 

Created in NX9.0.0 

## Member Function Documentation

## ◆ CharactersToSkip() [1/2]

NXOpen.Annotations.HoleTableSettingsLabelBuilder.CharactersToSkip
(
self — )

Getter for property: (str) CharactersToSkip Returns the characters to skip. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
str 

## ◆ CharactersToSkip() [2/2]

NXOpen.Annotations.HoleTableSettingsLabelBuilder.CharactersToSkip
(
self,

charactersToSkip )

Setter for property: (str) CharactersToSkip. 

Sets the characters to skip

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ IndexFormat() [1/2]

NXOpen.Annotations.HoleTableSettingsLabelBuilder.IndexFormat
(
self — )

Getter for property: (NXOpen.Annotations.HoleTableSettingsLabelBuilder.IndexType) IndexFormat Returns the index format of hole label. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
HoleTableSettingsLabelBuilder.IndexType 

## ◆ IndexFormat() [2/2]

NXOpen.Annotations.HoleTableSettingsLabelBuilder.IndexFormat
(
self,

indexFormat )

Setter for property: (NXOpen.Annotations.HoleTableSettingsLabelBuilder.IndexType) IndexFormat. 

Sets the index format of hole label

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ RelativeLocation() [1/2]

NXOpen.Annotations.HoleTableSettingsLabelBuilder.RelativeLocation
(
self — )

Getter for property: (NXOpen.Annotations.HoleTableSettingsLabelBuilder.RelativeLocationType) RelativeLocation Returns the relative location of hole label. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
HoleTableSettingsLabelBuilder.RelativeLocationType 

## ◆ RelativeLocation() [2/2]

NXOpen.Annotations.HoleTableSettingsLabelBuilder.RelativeLocation
(
self,

relativeLocation )

Setter for property: (NXOpen.Annotations.HoleTableSettingsLabelBuilder.RelativeLocationType) RelativeLocation. 

Sets the relative location of hole label

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## ◆ ShowLabelWithLeader() [1/2]

NXOpen.Annotations.HoleTableSettingsLabelBuilder.ShowLabelWithLeader
(
self — )

Getter for property: (bool) ShowLabelWithLeader Returns the show hole label with leader. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ ShowLabelWithLeader() [2/2]

NXOpen.Annotations.HoleTableSettingsLabelBuilder.ShowLabelWithLeader
(
self,

showLabelWithLeader )

Setter for property: (bool) ShowLabelWithLeader. 

Sets the show hole label with leader

Setter License requirements: drafting ("DRAFTING")

Created in NX9.0.0 

## Member Data Documentation

## ◆ HoleTableSettingsLabelBuilderIndexType

NXOpen.Annotations.HoleTableSettingsLabelBuilder.HoleTableSettingsLabelBuilderIndexType = HoleTableSettingsLabelBuilder.IndexType

NXOpen.Annotations.HoleTableSettingsLabelBuilderIndexType is an alias for NXOpen.Annotations.HoleTableSettingsLabelBuilder.IndexType 

## ◆ HoleTableSettingsLabelBuilderRelativeLocationType

NXOpen.Annotations.HoleTableSettingsLabelBuilder.HoleTableSettingsLabelBuilderRelativeLocationType = HoleTableSettingsLabelBuilder.RelativeLocationType

NXOpen.Annotations.HoleTableSettingsLabelBuilderRelativeLocationType is an alias for NXOpen.Annotations.HoleTableSettingsLabelBuilder.RelativeLocationType 

Copyright 2025 Siemens
