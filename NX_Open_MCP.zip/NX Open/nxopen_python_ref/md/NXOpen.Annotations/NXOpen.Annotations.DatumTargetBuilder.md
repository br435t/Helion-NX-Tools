# NXOpen.Annotations.DatumTargetBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00147.html>

## Classes

class — StandardTypes

represents the datum target standards 

Enumerator — Comment

NoStandard — NO_STANDARD

AsmeY145m1982 — ASME_Y145M_1982

AsmeY145m1994 — Y145M_1994

AsmeIso11011983 — ISO 1101 1983

GmAddendum94 — 94_GM_ADDENDUM

Asig2000 — ASIG_2000

AsmeY1452009 — ASME_Y145_2009

More...

class — TerminatorTypes

represents the datum target terminator type 

Enumerator — Comment

Arrow — terminated with Arrow only

X — terminated with x

Plus — terminated with plus

More...

class — Types

datum symbol type 

Enumerator — Comment

Point — point

Line — point

Rectangular — rectangular

Circular — circular

Annular — annular

Spherical — spherical

Cylindrical — cylindrical

Arbitrary — arbitrary

More...

Copyright 2025 Siemens
