# NXOpen.Annotations.DisplayStyleBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11989.html>

Represents a NXOpen::Annotations::DisplayStyleBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.DisplayStyleBuilder:

## Public Member Functions

BackgroundColor (self)

Getter for property: (int) BackgroundColor Returns the PMI background color. 

BackgroundColor (self, backgroundColor)

Setter for property: (int) BackgroundColor. 

EnableBackground (self)

Getter for property: (bool) EnableBackground Returns the PMI enable background setting. 

EnableBackground (self, enableBackground)

Setter for property: (bool) EnableBackground. 

LockSizeAndPosition (self)

Getter for property: (bool) LockSizeAndPosition Returns the PMI lock pan and zoom setting. 

LockSizeAndPosition (self, lockSizeAndPosition)

Setter for property: (bool) LockSizeAndPosition. 

ParallelToScreen (self)

Getter for property: (bool) ParallelToScreen Returns the PMI parallel to screen setting. 

ParallelToScreen (self, parallelToScreen)

Setter for property: (bool) ParallelToScreen. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::DisplayStyleBuilder . 

This is a sub-builder class and cannot be directly instantiated 

Created in NX11.0.1 

## Member Function Documentation

## ◆ BackgroundColor() [1/2]

NXOpen.Annotations.DisplayStyleBuilder.BackgroundColor
(
self — )

Getter for property: (int) BackgroundColor Returns the PMI background color. 

Getter License requirements: None.

Created in NX1872.0.0 

Returns
int 

## ◆ BackgroundColor() [2/2]

NXOpen.Annotations.DisplayStyleBuilder.BackgroundColor
(
self,

backgroundColor )

Setter for property: (int) BackgroundColor. 

Sets the PMI background color

Setter License requirements: geometric_tol ("GDT")

Created in NX1872.0.0 

## ◆ EnableBackground() [1/2]

NXOpen.Annotations.DisplayStyleBuilder.EnableBackground
(
self — )

Getter for property: (bool) EnableBackground Returns the PMI enable background setting. 

Getter License requirements: None.

Created in NX1872.0.0 

Returns
bool 

## ◆ EnableBackground() [2/2]

NXOpen.Annotations.DisplayStyleBuilder.EnableBackground
(
self,

enableBackground )

Setter for property: (bool) EnableBackground. 

Sets the PMI enable background setting

Setter License requirements: geometric_tol ("GDT")

Created in NX1872.0.0 

## ◆ LockSizeAndPosition() [1/2]

NXOpen.Annotations.DisplayStyleBuilder.LockSizeAndPosition
(
self — )

Getter for property: (bool) LockSizeAndPosition Returns the PMI lock pan and zoom setting. 

Getter License requirements: None.

Created in NX11.0.1 

Returns
bool 

## ◆ LockSizeAndPosition() [2/2]

NXOpen.Annotations.DisplayStyleBuilder.LockSizeAndPosition
(
self,

lockSizeAndPosition )

Setter for property: (bool) LockSizeAndPosition. 

Sets the PMI lock pan and zoom setting

Setter License requirements: geometric_tol ("GDT")

Created in NX11.0.1 

## ◆ ParallelToScreen() [1/2]

NXOpen.Annotations.DisplayStyleBuilder.ParallelToScreen
(
self — )

Getter for property: (bool) ParallelToScreen Returns the PMI parallel to screen setting. 

Getter License requirements: None.

Created in NX11.0.1 

Returns
bool 

## ◆ ParallelToScreen() [2/2]

NXOpen.Annotations.DisplayStyleBuilder.ParallelToScreen
(
self,

parallelToScreen )

Setter for property: (bool) ParallelToScreen. 

Sets the PMI parallel to screen setting

Setter License requirements: geometric_tol ("GDT")

Created in NX11.0.1 

Copyright 2025 Siemens
