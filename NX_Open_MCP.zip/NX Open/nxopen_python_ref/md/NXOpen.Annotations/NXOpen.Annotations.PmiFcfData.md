# NXOpen.Annotations.PmiFcfData Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00193.html>

## Classes

class — PmiFcfDataUnitBasisType

Specifies unit basis types 

Enumerator — Comment

NotSet — None

Length — length type

Area — area type

CircularArea — circular area type

SphericalArea — spherical area type

Square — square type

More...

Copyright 2025 Siemens
