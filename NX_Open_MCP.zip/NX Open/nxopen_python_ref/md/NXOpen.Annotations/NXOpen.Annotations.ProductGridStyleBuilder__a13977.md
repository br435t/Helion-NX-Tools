# NXOpen.Annotations.ProductGridStyleBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13977.html>

Represents a NXOpen::Annotations::ProductGridStyleBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.ProductGridStyleBuilder:

## Public Member Functions

GridOverhang (self)

Getter for property: (float) GridOverhang Returns the grid overhang. 

GridOverhang (self, gridOverhang)

Setter for property: (float) GridOverhang. 

GridSpacing (self)

Getter for property: (float) GridSpacing Returns the grid spacing. 

GridSpacing (self, gridSpacing)

Setter for property: (float) GridSpacing. 

LabelDivisor (self)

Getter for property: (float) LabelDivisor Returns the label divisor. 

LabelDivisor (self, labelDivisor)

Setter for property: (float) LabelDivisor. 

LabelGap (self)

Getter for property: (float) LabelGap Returns the label gap. 

LabelGap (self, labelGap)

Setter for property: (float) LabelGap. 

LineColor (self)

Getter for property: (NXOpen.NXColor) LineColor Returns the line color. 

LineColor (self, lineColor)

Setter for property: (NXOpen.NXColor) LineColor. 

LineFont (self)

Getter for property: (NXOpen.DisplayableObject.ObjectFont) LineFont Returns the line font. 

LineFont (self, lineFont)

Setter for property: (NXOpen.DisplayableObject.ObjectFont) LineFont. 

LineWidth (self)

Getter for property: (NXOpen.Annotations.LineWidth) LineWidth Returns the line width. 

LineWidth (self, lineWidth)

Setter for property: (NXOpen.Annotations.LineWidth) LineWidth. 

LocationRelativeGridHorizontal (self)

Getter for property: (NXOpen.Annotations.ProductGridStyleBuilder.HorizontalLabelDisplay) LocationRelativeGridHorizontal Returns the location of horizontal labels relative to the product grid. 

LocationRelativeGridHorizontal (self, locationRelativeGridHorizontal)

Setter for property: (NXOpen.Annotations.ProductGridStyleBuilder.HorizontalLabelDisplay) LocationRelativeGridHorizontal. 

LocationRelativeGridValue (self)

Getter for property: (NXOpen.Annotations.ProductGridStyleBuilder.GridLabelLocation) LocationRelativeGridValue Returns the location of the grid label relative to the grid value. 

LocationRelativeGridValue (self, locationRelativeGridValue)

Setter for property: (NXOpen.Annotations.ProductGridStyleBuilder.GridLabelLocation) LocationRelativeGridValue. 

LocationRelativeGridVertical (self)

Getter for property: (NXOpen.Annotations.ProductGridStyleBuilder.VerticalLabelDisplay) LocationRelativeGridVertical Returns the location of vertical labels relative to the product grid. 

LocationRelativeGridVertical (self, locationRelativeGridVertical)

Setter for property: (NXOpen.Annotations.ProductGridStyleBuilder.VerticalLabelDisplay) LocationRelativeGridVertical. 

ReferenceXAxisLabel (self)

Getter for property: (str) ReferenceXAxisLabel Returns the label used to identify the product grid reference CSYS X axis. 

ReferenceXAxisLabel (self, referenceXAxisLabel)

Setter for property: (str) ReferenceXAxisLabel. 

ReferenceYAxisLabel (self)

Getter for property: (str) ReferenceYAxisLabel Returns the label used to identify the product grid reference CSYS Y axis. 

ReferenceYAxisLabel (self, referenceYAxisLabel)

Setter for property: (str) ReferenceYAxisLabel. 

ReferenceZAxisLabel (self)

Getter for property: (str) ReferenceZAxisLabel Returns the label used to identify the product grid reference CSYS Z axis. 

ReferenceZAxisLabel (self, referenceZAxisLabel)

Setter for property: (str) ReferenceZAxisLabel. 

ShowHorizontalGridLines (self)

Getter for property: (bool) ShowHorizontalGridLines Returns whether horizontal grid lines are displayed. 

ShowHorizontalGridLines (self, showHorizontalGridLines)

Setter for property: (bool) ShowHorizontalGridLines. 

ShowVerticalGridLines (self)

Getter for property: (bool) ShowVerticalGridLines Returns whether vertical grid lines are displayed. 

ShowVerticalGridLines (self, showVerticalGridLines)

Setter for property: (bool) ShowVerticalGridLines. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

ProductGridStyleBuilderGridLabelLocation = ProductGridStyleBuilder.GridLabelLocation

NXOpen.Annotations.ProductGridStyleBuilderGridLabelLocation is an alias for NXOpen.Annotations.ProductGridStyleBuilder.GridLabelLocation 

ProductGridStyleBuilderHorizontalLabelDisplay = ProductGridStyleBuilder.HorizontalLabelDisplay

NXOpen.Annotations.ProductGridStyleBuilderHorizontalLabelDisplay is an alias for NXOpen.Annotations.ProductGridStyleBuilder.HorizontalLabelDisplay 

ProductGridStyleBuilderVerticalLabelDisplay = ProductGridStyleBuilder.VerticalLabelDisplay

NXOpen.Annotations.ProductGridStyleBuilderVerticalLabelDisplay is an alias for NXOpen.Annotations.ProductGridStyleBuilder.VerticalLabelDisplay 

## Detailed Description

Represents a NXOpen::Annotations::ProductGridStyleBuilder . 

This class queries and sets preferences for product grid type annotations when creating or editing.

Created in NX2007.0.0 

## Member Function Documentation

## ◆ GridOverhang() [1/2]

NXOpen.Annotations.ProductGridStyleBuilder.GridOverhang
(
self — )

Getter for property: (float) GridOverhang Returns the grid overhang. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
float 

## ◆ GridOverhang() [2/2]

NXOpen.Annotations.ProductGridStyleBuilder.GridOverhang
(
self,

gridOverhang )

Setter for property: (float) GridOverhang. 

Sets the grid overhang

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2007.0.0 

## ◆ GridSpacing() [1/2]

NXOpen.Annotations.ProductGridStyleBuilder.GridSpacing
(
self — )

Getter for property: (float) GridSpacing Returns the grid spacing. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
float 

## ◆ GridSpacing() [2/2]

NXOpen.Annotations.ProductGridStyleBuilder.GridSpacing
(
self,

gridSpacing )

Setter for property: (float) GridSpacing. 

Sets the grid spacing

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2007.0.0 

## ◆ LabelDivisor() [1/2]

NXOpen.Annotations.ProductGridStyleBuilder.LabelDivisor
(
self — )

Getter for property: (float) LabelDivisor Returns the label divisor. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
float 

## ◆ LabelDivisor() [2/2]

NXOpen.Annotations.ProductGridStyleBuilder.LabelDivisor
(
self,

labelDivisor )

Setter for property: (float) LabelDivisor. 

Sets the label divisor

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2007.0.0 

## ◆ LabelGap() [1/2]

NXOpen.Annotations.ProductGridStyleBuilder.LabelGap
(
self — )

Getter for property: (float) LabelGap Returns the label gap. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
float 

## ◆ LabelGap() [2/2]

NXOpen.Annotations.ProductGridStyleBuilder.LabelGap
(
self,

labelGap )

Setter for property: (float) LabelGap. 

Sets the label gap

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2007.0.0 

## ◆ LineColor() [1/2]

NXOpen.Annotations.ProductGridStyleBuilder.LineColor
(
self — )

Getter for property: (NXOpen.NXColor) LineColor Returns the line color. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
NXOpen.NXColor 

## ◆ LineColor() [2/2]

NXOpen.Annotations.ProductGridStyleBuilder.LineColor
(
self,

lineColor )

Setter for property: (NXOpen.NXColor) LineColor. 

Sets the line color

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2007.0.0 

## ◆ LineFont() [1/2]

NXOpen.Annotations.ProductGridStyleBuilder.LineFont
(
self — )

Getter for property: (NXOpen.DisplayableObject.ObjectFont) LineFont Returns the line font. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
NXOpen.DisplayableObject.ObjectFont 

## ◆ LineFont() [2/2]

NXOpen.Annotations.ProductGridStyleBuilder.LineFont
(
self,

lineFont )

Setter for property: (NXOpen.DisplayableObject.ObjectFont) LineFont. 

Sets the line font

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2007.0.0 

## ◆ LineWidth() [1/2]

NXOpen.Annotations.ProductGridStyleBuilder.LineWidth
(
self — )

Getter for property: (NXOpen.Annotations.LineWidth) LineWidth Returns the line width. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
LineWidth 

## ◆ LineWidth() [2/2]

NXOpen.Annotations.ProductGridStyleBuilder.LineWidth
(
self,

lineWidth )

Setter for property: (NXOpen.Annotations.LineWidth) LineWidth. 

Sets the line width

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2007.0.0 

## ◆ LocationRelativeGridHorizontal() [1/2]

NXOpen.Annotations.ProductGridStyleBuilder.LocationRelativeGridHorizontal
(
self — )

Getter for property: (NXOpen.Annotations.ProductGridStyleBuilder.HorizontalLabelDisplay) LocationRelativeGridHorizontal Returns the location of horizontal labels relative to the product grid. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
ProductGridStyleBuilder.HorizontalLabelDisplay 

## ◆ LocationRelativeGridHorizontal() [2/2]

NXOpen.Annotations.ProductGridStyleBuilder.LocationRelativeGridHorizontal
(
self,

locationRelativeGridHorizontal )

Setter for property: (NXOpen.Annotations.ProductGridStyleBuilder.HorizontalLabelDisplay) LocationRelativeGridHorizontal. 

Sets the location of horizontal labels relative to the product grid

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2007.0.0 

## ◆ LocationRelativeGridValue() [1/2]

NXOpen.Annotations.ProductGridStyleBuilder.LocationRelativeGridValue
(
self — )

Getter for property: (NXOpen.Annotations.ProductGridStyleBuilder.GridLabelLocation) LocationRelativeGridValue Returns the location of the grid label relative to the grid value. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
ProductGridStyleBuilder.GridLabelLocation 

## ◆ LocationRelativeGridValue() [2/2]

NXOpen.Annotations.ProductGridStyleBuilder.LocationRelativeGridValue
(
self,

locationRelativeGridValue )

Setter for property: (NXOpen.Annotations.ProductGridStyleBuilder.GridLabelLocation) LocationRelativeGridValue. 

Sets the location of the grid label relative to the grid value

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2007.0.0 

## ◆ LocationRelativeGridVertical() [1/2]

NXOpen.Annotations.ProductGridStyleBuilder.LocationRelativeGridVertical
(
self — )

Getter for property: (NXOpen.Annotations.ProductGridStyleBuilder.VerticalLabelDisplay) LocationRelativeGridVertical Returns the location of vertical labels relative to the product grid. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
ProductGridStyleBuilder.VerticalLabelDisplay 

## ◆ LocationRelativeGridVertical() [2/2]

NXOpen.Annotations.ProductGridStyleBuilder.LocationRelativeGridVertical
(
self,

locationRelativeGridVertical )

Setter for property: (NXOpen.Annotations.ProductGridStyleBuilder.VerticalLabelDisplay) LocationRelativeGridVertical. 

Sets the location of vertical labels relative to the product grid

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2007.0.0 

## ◆ ReferenceXAxisLabel() [1/2]

NXOpen.Annotations.ProductGridStyleBuilder.ReferenceXAxisLabel
(
self — )

Getter for property: (str) ReferenceXAxisLabel Returns the label used to identify the product grid reference CSYS X axis. 

Getter License requirements: None.

Created in NX1980.0.0 

Returns
str 

## ◆ ReferenceXAxisLabel() [2/2]

NXOpen.Annotations.ProductGridStyleBuilder.ReferenceXAxisLabel
(
self,

referenceXAxisLabel )

Setter for property: (str) ReferenceXAxisLabel. 

Sets the label used to identify the product grid reference CSYS X axis

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2007.0.0 

## ◆ ReferenceYAxisLabel() [1/2]

NXOpen.Annotations.ProductGridStyleBuilder.ReferenceYAxisLabel
(
self — )

Getter for property: (str) ReferenceYAxisLabel Returns the label used to identify the product grid reference CSYS Y axis. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
str 

## ◆ ReferenceYAxisLabel() [2/2]

NXOpen.Annotations.ProductGridStyleBuilder.ReferenceYAxisLabel
(
self,

referenceYAxisLabel )

Setter for property: (str) ReferenceYAxisLabel. 

Sets the label used to identify the product grid reference CSYS Y axis

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2007.0.0 

## ◆ ReferenceZAxisLabel() [1/2]

NXOpen.Annotations.ProductGridStyleBuilder.ReferenceZAxisLabel
(
self — )

Getter for property: (str) ReferenceZAxisLabel Returns the label used to identify the product grid reference CSYS Z axis. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
str 

## ◆ ReferenceZAxisLabel() [2/2]

NXOpen.Annotations.ProductGridStyleBuilder.ReferenceZAxisLabel
(
self,

referenceZAxisLabel )

Setter for property: (str) ReferenceZAxisLabel. 

Sets the label used to identify the product grid reference CSYS Z axis

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2007.0.0 

## ◆ ShowHorizontalGridLines() [1/2]

NXOpen.Annotations.ProductGridStyleBuilder.ShowHorizontalGridLines
(
self — )

Getter for property: (bool) ShowHorizontalGridLines Returns whether horizontal grid lines are displayed. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
bool 

## ◆ ShowHorizontalGridLines() [2/2]

NXOpen.Annotations.ProductGridStyleBuilder.ShowHorizontalGridLines
(
self,

showHorizontalGridLines )

Setter for property: (bool) ShowHorizontalGridLines. 

Sets whether horizontal grid lines are displayed

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2007.0.0 

## ◆ ShowVerticalGridLines() [1/2]

NXOpen.Annotations.ProductGridStyleBuilder.ShowVerticalGridLines
(
self — )

Getter for property: (bool) ShowVerticalGridLines Returns whether vertical grid lines are displayed. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
bool 

## ◆ ShowVerticalGridLines() [2/2]

NXOpen.Annotations.ProductGridStyleBuilder.ShowVerticalGridLines
(
self,

showVerticalGridLines )

Setter for property: (bool) ShowVerticalGridLines. 

Sets whether vertical grid lines are displayed

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX2007.0.0 

## Member Data Documentation

## ◆ ProductGridStyleBuilderGridLabelLocation

NXOpen.Annotations.ProductGridStyleBuilder.ProductGridStyleBuilderGridLabelLocation = ProductGridStyleBuilder.GridLabelLocation

NXOpen.Annotations.ProductGridStyleBuilderGridLabelLocation is an alias for NXOpen.Annotations.ProductGridStyleBuilder.GridLabelLocation 

## ◆ ProductGridStyleBuilderHorizontalLabelDisplay

NXOpen.Annotations.ProductGridStyleBuilder.ProductGridStyleBuilderHorizontalLabelDisplay = ProductGridStyleBuilder.HorizontalLabelDisplay

NXOpen.Annotations.ProductGridStyleBuilderHorizontalLabelDisplay is an alias for NXOpen.Annotations.ProductGridStyleBuilder.HorizontalLabelDisplay 

## ◆ ProductGridStyleBuilderVerticalLabelDisplay

NXOpen.Annotations.ProductGridStyleBuilder.ProductGridStyleBuilderVerticalLabelDisplay = ProductGridStyleBuilder.VerticalLabelDisplay

NXOpen.Annotations.ProductGridStyleBuilderVerticalLabelDisplay is an alias for NXOpen.Annotations.ProductGridStyleBuilder.VerticalLabelDisplay 

Copyright 2025 Siemens
