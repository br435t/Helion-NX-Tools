# NXOpen.Annotations.HatchBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12473.html>

This class is used to construct the crosshatching that lies within a boundary. 
More...

Inheritance diagram for NXOpen.Annotations.HatchBuilder:

## Public Member Functions

Angle (self)

Getter for property: (float) Angle Returns the angle. 

Angle (self, angle)

Setter for property: (float) Angle. 

AnnotationToExclude (self)

Getter for property: (NXOpen.SelectDisplayableObjectList) AnnotationToExclude Returns the select annotation to exclude. 

AnnotationType (self)

Getter for property: (NXOpen.Annotations.HatchBuilder.AnnotationTypes) AnnotationType Returns the type of hatch object. 

AnnotationType (self, type)

Setter for property: (NXOpen.Annotations.HatchBuilder.AnnotationTypes) AnnotationType. 

AreafillAngle (self)

Getter for property: (float) AreafillAngle Returns the areafill angle. 

AreafillAngle (self, angle)

Setter for property: (float) AreafillAngle. 

AutomaticallyExcludeText (self)

Getter for property: (bool) AutomaticallyExcludeText Returns the exclude text. 

AutomaticallyExcludeText (self, excludeText)

Setter for property: (bool) AutomaticallyExcludeText. 

Boundary (self)

Getter for property: (NXOpen.Annotations.BoundaryBuilder) Boundary Returns the boundary. 

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

CrosshatchFile (self)

Getter for property: (str) CrosshatchFile Returns the crosshatch file. 

CrosshatchFile (self, filename)

Setter for property: (str) CrosshatchFile. 

Distance (self)

Getter for property: (float) Distance Returns the distance. 

Distance (self, distance)

Setter for property: (float) Distance. 

GetMarginPercent (self, annotation)

Get margin percent of a annotation. 

HatchFillSettings (self)

Getter for property: (NXOpen.Annotations.HatchFillSettingsBuilder) HatchFillSettings Returns the HatchFillSetting. 

Material (self)

Getter for property: (NXOpen.Annotations.AreaFillMaterial) Material Returns the area fill material. 

Material (self, areaFillMaterial)

Setter for property: (NXOpen.Annotations.AreaFillMaterial) Material. 

Pattern (self)

Getter for property: (str) Pattern Returns the pattern. 

Pattern (self, identifier)

Setter for property: (str) Pattern. 

Scale (self)

Getter for property: (float) Scale Returns the scale. 

Scale (self, scale)

Setter for property: (float) Scale. 

SetCurveDirection (self, curveTag, curveDirection)

Set direction of a curve to the annotation The number of diection map elements need to specify before to the direction of the curve elements to the annotation. 

SetMarginPercent (self, annotation, marginpercent)

Set margin percent to a annotation. 

SetNumCurrentDirectionMapElements (self, numCurrentDirectionMapElement)

Set number of direction map elements to the annotation. 

SetSectionCurveDirections (self, section, curve, curveDirections)

Set directions of a curve to the annotation The number of diection map elements need to specify before to the direction of the curve elements to the annotation. 

Tolerance (self)

Getter for property: (float) Tolerance Returns the tolerance. 

Tolerance (self, tolerance)

Setter for property: (float) Tolerance. 

Width (self)

Getter for property: (NXOpen.Annotations.LineWidth) Width Returns the width. 

Width (self, width)

Setter for property: (NXOpen.Annotations.LineWidth) Width. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

HatchBuilderAnnotationTypes = HatchBuilder.AnnotationTypes

NXOpen.Annotations.HatchBuilderAnnotationTypes is an alias for NXOpen.Annotations.HatchBuilder.AnnotationTypes 

## Detailed Description

This class is used to construct the crosshatching that lies within a boundary. 

To create a new instance of this class, use NXOpen::Annotations::HatchCollection::CreateHatchBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ Angle() [1/2]

NXOpen.Annotations.HatchBuilder.Angle
(
self — )

Getter for property: (float) Angle Returns the angle. 

Getter License requirements: None.

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

Returns
float 

## ◆ Angle() [2/2]

NXOpen.Annotations.HatchBuilder.Angle
(
self,

angle )

Setter for property: (float) Angle. 

Sets the angle.

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

## ◆ AnnotationToExclude()

NXOpen.Annotations.HatchBuilder.AnnotationToExclude
(
self — )

Getter for property: (NXOpen.SelectDisplayableObjectList) AnnotationToExclude Returns the select annotation to exclude. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectDisplayableObjectList 

## ◆ AnnotationType() [1/2]

NXOpen.Annotations.HatchBuilder.AnnotationType
(
self — )

Getter for property: (NXOpen.Annotations.HatchBuilder.AnnotationTypes) AnnotationType Returns the type of hatch object. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
HatchBuilder.AnnotationTypes 

## ◆ AnnotationType() [2/2]

NXOpen.Annotations.HatchBuilder.AnnotationType
(
self,

type )

Setter for property: (NXOpen.Annotations.HatchBuilder.AnnotationTypes) AnnotationType. 

Sets the type of hatch object

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ AreafillAngle() [1/2]

NXOpen.Annotations.HatchBuilder.AreafillAngle
(
self — )

Getter for property: (float) AreafillAngle Returns the areafill angle. 

Getter License requirements: None.

Created in NX6.0.1 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

Returns
float 

## ◆ AreafillAngle() [2/2]

NXOpen.Annotations.HatchBuilder.AreafillAngle
(
self,

angle )

Setter for property: (float) AreafillAngle. 

Sets the areafill angle.

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.1 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

## ◆ AutomaticallyExcludeText() [1/2]

NXOpen.Annotations.HatchBuilder.AutomaticallyExcludeText
(
self — )

Getter for property: (bool) AutomaticallyExcludeText Returns the exclude text. 

This is not used if NXOpen::Annotations::BoundaryBuilder::SelectionMethodCurves is set.

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ AutomaticallyExcludeText() [2/2]

NXOpen.Annotations.HatchBuilder.AutomaticallyExcludeText
(
self,

excludeText )

Setter for property: (bool) AutomaticallyExcludeText. 

Sets the exclude text. This is not used if NXOpen::Annotations::BoundaryBuilder::SelectionMethodCurves is set.

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ Boundary()

NXOpen.Annotations.HatchBuilder.Boundary
(
self — )

Getter for property: (NXOpen.Annotations.BoundaryBuilder) Boundary Returns the boundary. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
BoundaryBuilder 

## ◆ Color() [1/2]

NXOpen.Annotations.HatchBuilder.Color
(
self — )

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Getter License requirements: None.

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

Returns
NXOpen.NXColor 

## ◆ Color() [2/2]

NXOpen.Annotations.HatchBuilder.Color
(
self,

color )

Setter for property: (NXOpen.NXColor) Color. 

Sets the color.

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

## ◆ CrosshatchFile() [1/2]

NXOpen.Annotations.HatchBuilder.CrosshatchFile
(
self — )

Getter for property: (str) CrosshatchFile Returns the crosshatch file. 

Getter License requirements: None.

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

Returns
str 

## ◆ CrosshatchFile() [2/2]

NXOpen.Annotations.HatchBuilder.CrosshatchFile
(
self,

filename )

Setter for property: (str) CrosshatchFile. 

Sets the crosshatch file.

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

## ◆ Distance() [1/2]

NXOpen.Annotations.HatchBuilder.Distance
(
self — )

Getter for property: (float) Distance Returns the distance. 

Getter License requirements: None.

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

Returns
float 

## ◆ Distance() [2/2]

NXOpen.Annotations.HatchBuilder.Distance
(
self,

distance )

Setter for property: (float) Distance. 

Sets the distance.

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

## ◆ GetMarginPercent()

NXOpen.Annotations.HatchBuilder.GetMarginPercent
(
self,

annotation )

Get margin percent of a annotation. 

Returns
marginpercent (float): .

Created in NX7.5.0 

License requirements: None.

Parameters

annotation — (NXOpen.NXObject) annotation or DraftingCombinedInstance

## ◆ HatchFillSettings()

NXOpen.Annotations.HatchBuilder.HatchFillSettings
(
self — )

Getter for property: (NXOpen.Annotations.HatchFillSettingsBuilder) HatchFillSettings Returns the HatchFillSetting. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
HatchFillSettingsBuilder 

## ◆ Material() [1/2]

NXOpen.Annotations.HatchBuilder.Material
(
self — )

Getter for property: (NXOpen.Annotations.AreaFillMaterial) Material Returns the area fill material. 

Getter License requirements: None.

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

Returns
AreaFillMaterial 

## ◆ Material() [2/2]

NXOpen.Annotations.HatchBuilder.Material
(
self,

areaFillMaterial )

Setter for property: (NXOpen.Annotations.AreaFillMaterial) Material. 

Sets the area fill material.

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

## ◆ Pattern() [1/2]

NXOpen.Annotations.HatchBuilder.Pattern
(
self — )

Getter for property: (str) Pattern Returns the pattern. 

Getter License requirements: None.

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

Returns
str 

## ◆ Pattern() [2/2]

NXOpen.Annotations.HatchBuilder.Pattern
(
self,

identifier )

Setter for property: (str) Pattern. 

Sets the pattern.

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

## ◆ Scale() [1/2]

NXOpen.Annotations.HatchBuilder.Scale
(
self — )

Getter for property: (float) Scale Returns the scale. 

Getter License requirements: None.

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

Returns
float 

## ◆ Scale() [2/2]

NXOpen.Annotations.HatchBuilder.Scale
(
self,

scale )

Setter for property: (float) Scale. 

Sets the scale.

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

## ◆ SetCurveDirection()

NXOpen.Annotations.HatchBuilder.SetCurveDirection
(
self,

curveTag,

curveDirection )

Set direction of a curve to the annotation The number of diection map elements need to specify before to the direction of the curve elements to the annotation. 

Created in NX8.0.0 

License requirements: drafting ("DRAFTING")

Parameters

curveTag — (NXOpen.NXObject)

curveDirection — (int)

## ◆ SetMarginPercent()

NXOpen.Annotations.HatchBuilder.SetMarginPercent
(
self,

annotation,

marginpercent )

Set margin percent to a annotation. 

Created in NX7.5.0 

License requirements: drafting ("DRAFTING")

Parameters

annotation — (NXOpen.NXObject) annotation or DraftingCombinedInstance

marginpercent — (float) text islands value

## ◆ SetNumCurrentDirectionMapElements()

NXOpen.Annotations.HatchBuilder.SetNumCurrentDirectionMapElements
(
self,

numCurrentDirectionMapElement )

Set number of direction map elements to the annotation. 

Created in NX8.0.0 

License requirements: drafting ("DRAFTING")

Parameters

numCurrentDirectionMapElement — (int)

## ◆ SetSectionCurveDirections()

NXOpen.Annotations.HatchBuilder.SetSectionCurveDirections
(
self,

section,

curve,

curveDirections )

Set directions of a curve to the annotation The number of diection map elements need to specify before to the direction of the curve elements to the annotation. 

Created in NX8.5.0 

License requirements: drafting ("DRAFTING")

Parameters

section — (NXOpen.NXObject)

curve — (NXOpen.NXObject)

curveDirections — (List[int]) array of directions for the curve

## ◆ Tolerance() [1/2]

NXOpen.Annotations.HatchBuilder.Tolerance
(
self — )

Getter for property: (float) Tolerance Returns the tolerance. 

Getter License requirements: None.

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

Returns
float 

## ◆ Tolerance() [2/2]

NXOpen.Annotations.HatchBuilder.Tolerance
(
self,

tolerance )

Setter for property: (float) Tolerance. 

Sets the tolerance.

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

## ◆ Width() [1/2]

NXOpen.Annotations.HatchBuilder.Width
(
self — )

Getter for property: (NXOpen.Annotations.LineWidth) Width Returns the width. 

Getter License requirements: None.

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

Returns
LineWidth 

## ◆ Width() [2/2]

NXOpen.Annotations.HatchBuilder.Width
(
self,

width )

Setter for property: (NXOpen.Annotations.LineWidth) Width. 

Sets the width.

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

Deprecated
Deprecated in NX7.5.0. Use NXOpen::Annotations::HatchFillSettingsBuilder instead. 

## Member Data Documentation

## ◆ HatchBuilderAnnotationTypes

NXOpen.Annotations.HatchBuilder.HatchBuilderAnnotationTypes = HatchBuilder.AnnotationTypes

NXOpen.Annotations.HatchBuilderAnnotationTypes is an alias for NXOpen.Annotations.HatchBuilder.AnnotationTypes 

Copyright 2025 Siemens
