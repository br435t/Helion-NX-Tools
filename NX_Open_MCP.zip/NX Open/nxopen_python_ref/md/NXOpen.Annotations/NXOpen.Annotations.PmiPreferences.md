# NXOpen.Annotations.PmiPreferences Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00200.html>

## Classes

class — PreferenceSymbolTypes

Specifies the allowable symbol types for Parallel To Screen and Lock Pan/Zoom 

Enumerator — Comment

Note — note

GeneralNote — general note

SpecificNote — specific note

EnterpriseId — enterprise id

MaterialSpecification — material specification

PartId — part id

ProcessSpecification — process specification

UrlNote — url note

StringNote — string note

NumberNote — number note

IntegerNote — integer note

BalloonNote — balloon note

CustomSymbol — custom symbol

GovernmentSecurityInfo — government security info

CompanySpecificProprietaryInfo — company specific proprietary info

ExportControl — export control

Table — table

CoordinateNote — coordinate note

CuttingPlaneSymbol — cutting plane symbol

FeatureControlFrame — feature control frame

More...

Copyright 2025 Siemens
