# NXOpen.Annotations.MasterSymbolListItemBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12957.html>

Represents a NXOpen::Annotations::MasterSymbolListItemBuilder 

To create a new instance of this class, use NXOpen::Annotations::CustomSymbolCollection::CreateMasterSymbolListItemBuilder 

More...

Inheritance diagram for NXOpen.Annotations.MasterSymbolListItemBuilder:

## Public Member Functions

DoubleDefault (self)

Getter for property: (float) DoubleDefault Returns the double default, this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesReal . 

DoubleDefault (self, doubleDefault)

Setter for property: (float) DoubleDefault. 

DoubleMax (self)

Getter for property: (float) DoubleMax Returns the double max, this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesReal . 

DoubleMax (self, doubleMax)

Setter for property: (float) DoubleMax. 

DoubleMin (self)

Getter for property: (float) DoubleMin Returns the double min, this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesReal . 

DoubleMin (self, doubleMin)

Setter for property: (float) DoubleMin. 

GetMultilineString (self)

Returns the multiple notes for a given Text Type. 

IntegerDefault (self)

Getter for property: (int) IntegerDefault Returns the integer default, this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesInteger . 

IntegerDefault (self, integerDefault)

Setter for property: (int) IntegerDefault. 

IntegerMax (self)

Getter for property: (int) IntegerMax Returns the integer max ,this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesInteger . 

IntegerMax (self, integerMax)

Setter for property: (int) IntegerMax. 

IntegerMin (self)

Getter for property: (int) IntegerMin Returns the integer min , this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesInteger . 

IntegerMin (self, integerMin)

Setter for property: (int) IntegerMin. 

NoteText (self)

Getter for property: (str) NoteText Returns the first line of note text. 

NoteText (self, noteText)

Setter for property: (str) NoteText. 

NoteTitle (self)

Getter for property: (str) NoteTitle Returns the note title. 

NoteTitle (self, noteTitle)

Setter for property: (str) NoteTitle. 

Rule (self)

Getter for property: (str) Rule Returns the note rule. 

Rule (self, rule)

Setter for property: (str) Rule. 

SetMultilineString (self, multilineString)

Sets the multiple notes for the given Text Type. 

TextType (self)

Getter for property: (NXOpen.Annotations.MasterSymbolListItemBuilder.TextTypes) TextType Returns the text type. 

TextType (self, textType)

Setter for property: (NXOpen.Annotations.MasterSymbolListItemBuilder.TextTypes) TextType. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

MasterSymbolListItemBuilderTextTypes = MasterSymbolListItemBuilder.TextTypes

NXOpen.Annotations.MasterSymbolListItemBuilderTextTypes is an alias for NXOpen.Annotations.MasterSymbolListItemBuilder.TextTypes 

## Detailed Description

Represents a NXOpen::Annotations::MasterSymbolListItemBuilder 

To create a new instance of this class, use NXOpen::Annotations::CustomSymbolCollection::CreateMasterSymbolListItemBuilder 

Created in NX7.5.0 

## Member Function Documentation

## ◆ DoubleDefault() [1/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.DoubleDefault
(
self — )

Getter for property: (float) DoubleDefault Returns the double default, this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesReal . 

Getter License requirements: None.

Created in NX7.5.0 

Returns
float 

## ◆ DoubleDefault() [2/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.DoubleDefault
(
self,

doubleDefault )

Setter for property: (float) DoubleDefault. 

Sets the double default, this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesReal 

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ DoubleMax() [1/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.DoubleMax
(
self — )

Getter for property: (float) DoubleMax Returns the double max, this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesReal . 

Getter License requirements: None.

Created in NX7.5.0 

Returns
float 

## ◆ DoubleMax() [2/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.DoubleMax
(
self,

doubleMax )

Setter for property: (float) DoubleMax. 

Sets the double max, this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesReal 

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ DoubleMin() [1/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.DoubleMin
(
self — )

Getter for property: (float) DoubleMin Returns the double min, this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesReal . 

Getter License requirements: None.

Created in NX7.5.0 

Returns
float 

## ◆ DoubleMin() [2/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.DoubleMin
(
self,

doubleMin )

Setter for property: (float) DoubleMin. 

Sets the double min, this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesReal 

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ GetMultilineString()

NXOpen.Annotations.MasterSymbolListItemBuilder.GetMultilineString
(
self — )

Returns the multiple notes for a given Text Type. 

this property is valid for NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesArbitrary , NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesControlled , NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesPartiallyControlled 

Returns
multilineString (List[str]): .

Created in NX7.5.0 

License requirements: None. 

## ◆ IntegerDefault() [1/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.IntegerDefault
(
self — )

Getter for property: (int) IntegerDefault Returns the integer default, this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesInteger . 

Getter License requirements: None.

Created in NX7.5.0 

Returns
int 

## ◆ IntegerDefault() [2/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.IntegerDefault
(
self,

integerDefault )

Setter for property: (int) IntegerDefault. 

Sets the integer default, this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesInteger 

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ IntegerMax() [1/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.IntegerMax
(
self — )

Getter for property: (int) IntegerMax Returns the integer max ,this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesInteger . 

Getter License requirements: None.

Created in NX7.5.0 

Returns
int 

## ◆ IntegerMax() [2/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.IntegerMax
(
self,

integerMax )

Setter for property: (int) IntegerMax. 

Sets the integer max ,this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesInteger 

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ IntegerMin() [1/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.IntegerMin
(
self — )

Getter for property: (int) IntegerMin Returns the integer min , this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesInteger . 

Getter License requirements: None.

Created in NX7.5.0 

Returns
int 

## ◆ IntegerMin() [2/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.IntegerMin
(
self,

integerMin )

Setter for property: (int) IntegerMin. 

Sets the integer min , this property is valid if text type is NXOpen::Annotations::MasterSymbolListItemBuilder::TextTypesInteger 

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ NoteText() [1/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.NoteText
(
self — )

Getter for property: (str) NoteText Returns the first line of note text. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
str 

## ◆ NoteText() [2/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.NoteText
(
self,

noteText )

Setter for property: (str) NoteText. 

Sets the first line of note text

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ NoteTitle() [1/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.NoteTitle
(
self — )

Getter for property: (str) NoteTitle Returns the note title. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
str 

## ◆ NoteTitle() [2/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.NoteTitle
(
self,

noteTitle )

Setter for property: (str) NoteTitle. 

Sets the note title

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## ◆ Rule() [1/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.Rule
(
self — )

Getter for property: (str) Rule Returns the note rule. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
str 

## ◆ Rule() [2/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.Rule
(
self,

rule )

Setter for property: (str) Rule. 

Sets the note rule

Setter License requirements: nx_layout ("NX Layout")

Created in NX8.0.0 

## ◆ SetMultilineString()

NXOpen.Annotations.MasterSymbolListItemBuilder.SetMultilineString
(
self,

multilineString )

Sets the multiple notes for the given Text Type. 

Created in NX7.5.0 

License requirements: drafting ("DRAFTING")

Parameters

multilineString — (List[str]) array of notes

## ◆ TextType() [1/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.TextType
(
self — )

Getter for property: (NXOpen.Annotations.MasterSymbolListItemBuilder.TextTypes) TextType Returns the text type. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
MasterSymbolListItemBuilder.TextTypes 

## ◆ TextType() [2/2]

NXOpen.Annotations.MasterSymbolListItemBuilder.TextType
(
self,

textType )

Setter for property: (NXOpen.Annotations.MasterSymbolListItemBuilder.TextTypes) TextType. 

Sets the text type

Setter License requirements: drafting ("DRAFTING")

Created in NX7.5.0 

## Member Data Documentation

## ◆ MasterSymbolListItemBuilderTextTypes

NXOpen.Annotations.MasterSymbolListItemBuilder.MasterSymbolListItemBuilderTextTypes = MasterSymbolListItemBuilder.TextTypes

NXOpen.Annotations.MasterSymbolListItemBuilderTextTypes is an alias for NXOpen.Annotations.MasterSymbolListItemBuilder.TextTypes 

Copyright 2025 Siemens
