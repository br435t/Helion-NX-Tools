# NXOpen.Annotations.FeatureControlFrameDataBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00159.html>

## Classes

class — AreaSymbolType

Specifies the unit type 

Enumerator — Comment

Rectangular — Rectangular

Circular — Circular

Spherical — Spherical

Square — Square

More...

class — ToleranceMaterialModifier

Specifies the tolerance material modifier condition 

Enumerator — Comment

NotSet — no material modifier

LeastMaterialCondition — least material condition

MaximumMaterialCondition — maximum material condition

RegardlessOfFeatureSize — regardless of feature size condition

More...

class — ToleranceZoneShape

Specifies the zone shape for the feature control frame 

Enumerator — Comment

NotSet — no zone shape

Diameter — diameter

SphericalDiameter — spherical diameter

Square — square

More...

Copyright 2025 Siemens
