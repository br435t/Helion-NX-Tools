# NXOpen.Annotations.Dimension Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00148.html>

## Classes

class — MeasurementTypes

Specifies dimension measurement types 

Enumerator — Comment

General — General

Directed — Directed

FeatureOfSize — FeatureOfSize

More...

Copyright 2025 Siemens
