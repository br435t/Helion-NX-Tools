# NXOpen.Annotations.AngularDimension Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11077.html>

Represents an angular dimension 

Abstract class 

More...

Inheritance diagram for NXOpen.Annotations.AngularDimension:

## Additional Inherited Members

Public Member Functions inherited from NXOpen.Annotations.Dimension

ComputedSize (self)

Getter for property: (float) ComputedSize Returns the computed size of the dimension. 

GetDimensionPreferences (self)

Returns the dimension preferences. 

GetDimensionText (self)

Returns the dimension text - both the main text and the dual text. 

GetFirstAssociativity (self)

Returns the first associativity data. 

GetMeasurementType (self)

Returns dimension measurement type. 

GetNarrowDimensionPreferences (self)

Returns the narrow dimension preferences for the given linear dimension. 

GetNarrowDimensionTextOffset (self)

Returns the narrow dimension text offset for the given chain dimension. 

GetSecondAssociativity (self)

Returns the second associativity data. 

InspectionDimensionFlag (self)

Getter for property: (bool) InspectionDimensionFlag Returns a setting to control the inspection box displayed around the dimension value. 

InspectionDimensionFlag (self, inspection_dimension_flag)

Setter for property: (bool) InspectionDimensionFlag. 

IsApproximate (self)

Returns whether or not the given dimension is approximate. 

IsDriving (self)

Determines if a dimension is driving. 

IsOriginCentered (self)

Getter for property: (bool) IsOriginCentered Returns a flag indicating whether the dimension text is centered equally between the extension lines. 

IsOriginCentered (self, is_origin_centered)

Setter for property: (bool) IsOriginCentered. 

LimitFitAnsiHoleType (self)

Getter for property: (NXOpen.Annotations.FitAnsiHoleType) LimitFitAnsiHoleType Returns the tolerance limit fit ANSI hole type. 

LimitFitAnsiHoleType (self, fitHoleType)

Setter for property: (NXOpen.Annotations.FitAnsiHoleType) LimitFitAnsiHoleType. 

LimitFitDeviation (self)

Getter for property: (str) LimitFitDeviation Returns the tolerance limit fit deviation. 

LimitFitDeviation (self, fitDeviation)

Setter for property: (str) LimitFitDeviation. 

LimitFitDisplayStyle (self)

Getter for property: (NXOpen.Annotations.FitDisplayStyle) LimitFitDisplayStyle Returns the tolerance limit fit display style. 

LimitFitDisplayStyle (self, fitDisplayStyle)

Setter for property: (NXOpen.Annotations.FitDisplayStyle) LimitFitDisplayStyle. 

LimitFitEnhancedDisplayType (self)

Getter for property: (NXOpen.Annotations.FitAnsiHoleType) LimitFitEnhancedDisplayType Returns the enhanced limit fit display type. 

LimitFitEnhancedDisplayType (self, fitEnhancedDisplayType)

Setter for property: (NXOpen.Annotations.FitAnsiHoleType) LimitFitEnhancedDisplayType. 

LimitFitGrade (self)

Getter for property: (int) LimitFitGrade Returns the tolerance limit fit grade. 

LimitFitGrade (self, fitGrade)

Setter for property: (int) LimitFitGrade. 

LimitFitShaftDeviation (self)

Getter for property: (str) LimitFitShaftDeviation Returns the deviation for limit fit representation of shaft tolerance. 

LimitFitShaftDeviation (self, fitShaftDeviation)

Setter for property: (str) LimitFitShaftDeviation. 

LimitFitShaftGrade (self)

Getter for property: (int) LimitFitShaftGrade Returns the grade for limit fit representation of shaft tolerance. 

LimitFitShaftGrade (self, fitShaftGrade)

Setter for property: (int) LimitFitShaftGrade. 

LowerMetricToleranceValue (self)

Getter for property: (float) LowerMetricToleranceValue Returns a setting to control the metric lower tolerance value of a dimension. 

LowerMetricToleranceValue (self, tolerance_value)

Setter for property: (float) LowerMetricToleranceValue. 

LowerToleranceValue (self)

Getter for property: (float) LowerToleranceValue Returns a setting to control the lower tolerance value of a dimension. 

LowerToleranceValue (self, upper_tolerance_value)

Setter for property: (float) LowerToleranceValue. 

MeasurementDirection (self)

Getter for property: (NXOpen.Direction) MeasurementDirection Returns the measurement direction. 

MeasurementDirection (self, direction)

Setter for property: (NXOpen.Direction) MeasurementDirection. 

MeasurementDirectionView (self)

Getter for property: (NXOpen.View) MeasurementDirectionView Returns the measurement direction view. 

MeasurementDirectionView (self, view)

Setter for property: (NXOpen.View) MeasurementDirectionView. 

MetricNominalDecimalPlaces (self)

Getter for property: (int) MetricNominalDecimalPlaces Returns a setting to control the number of decimal places for the nominal value of a metric dimension. 

MetricNominalDecimalPlaces (self, decimal_places)

Setter for property: (int) MetricNominalDecimalPlaces. 

MetricToleranceDecimalPlaces (self)

Getter for property: (int) MetricToleranceDecimalPlaces Returns a setting to control the number of decimal places for the metric tolerance value of a dimension. 

MetricToleranceDecimalPlaces (self, decimal_places)

Setter for property: (int) MetricToleranceDecimalPlaces. 

NominalDecimalPlaces (self)

Getter for property: (int) NominalDecimalPlaces Returns a setting to control the number of decimal places for the nominal value of a dimension. 

NominalDecimalPlaces (self, decimal_places)

Setter for property: (int) NominalDecimalPlaces. 

ReferenceDimensionFlag (self)

Getter for property: (bool) ReferenceDimensionFlag Returns a setting to control the visibility of the reference parenthesis of a dimension. 

ReferenceDimensionFlag (self, reference_dimension_flag)

Setter for property: (bool) ReferenceDimensionFlag. 

SetComputedSize (self, computed_size)

Created in NX5.0.0 

SetDimensionPreferences (self, preferences)

Sets the dimension preferences. 

SetDimensionText (self, main_text_lines)

Set the main dimension text. 

SetFirstAssociativity (self, new_associativity)

Sets the first associativity data. 

SetNarrowDimensionPreferences (self, narrow_dimension_data)

Sets the narrow dimension preferences to the given linear dimension. 

SetNarrowDimensionTextOffset (self, narrow_text_offset)

Sets the narrow dimension text offset for the given chain dimension. 

SetSecondAssociativity (self, new_associativity)

Sets the second associativity data. 

ShaftLowerToleranceValue (self)

Getter for property: (float) ShaftLowerToleranceValue Returns a setting to control the shaft lower tolerance value of a dimension. 

ShaftUpperToleranceValue (self)

Getter for property: (float) ShaftUpperToleranceValue Returns a setting to control the shaft upper tolerance value of a dimension. 

ToleranceDecimalPlaces (self)

Getter for property: (int) ToleranceDecimalPlaces Returns a setting to control the number of decimal places for the primary tolerance value of a dimension. 

ToleranceDecimalPlaces (self, decimal_places)

Setter for property: (int) ToleranceDecimalPlaces. 

ToleranceType (self)

Getter for property: (NXOpen.Annotations.ToleranceType) ToleranceType Returns a setting to control the tolerance display style. 

ToleranceType (self, tolerance_type)

Setter for property: (NXOpen.Annotations.ToleranceType) ToleranceType. 

UnretainForInconsistentSilhouette (self, index)

Unretain the dimension if it no longer has an inconsistent silhouette as the indexed associativity. 

UpperMetricToleranceValue (self)

Getter for property: (float) UpperMetricToleranceValue Returns a setting to control the metric upper tolerance value of a dimension. 

UpperMetricToleranceValue (self, tolerance_value)

Setter for property: (float) UpperMetricToleranceValue. 

UpperToleranceValue (self)

Getter for property: (float) UpperToleranceValue Returns a setting to control the upper tolerance value of a dimension. 

UpperToleranceValue (self, upper_tolerance_value)

Setter for property: (float) UpperToleranceValue. 

Public Member Functions inherited from NXOpen.Annotations.Annotation

AnnotationOrigin (self)

Getter for property: (NXOpen.Point3d) AnnotationOrigin Returns the origin (location) of the annotation. 

AnnotationOrigin (self, origin)

Setter for property: (NXOpen.Point3d) AnnotationOrigin. 

AnnotationPlane (self)

Getter for property: (NXOpen.Xform) AnnotationPlane Returns the annotation plane. 

AnnotationPlane (self, annotation_plane)

Setter for property: (NXOpen.Xform) AnnotationPlane. 

Freeze (self)

Getter for property: (bool) Freeze Returns the PMI freeze setting for rule created PMI. 

Freeze (self, freeze)

Setter for property: (bool) Freeze. 

GetAssociativeOrigin (self)

Gets data that specifies the origin's associativity. 

GetAssociativity (self, associativity_index)

Returns the associativity at specified index. 

GetInferredAnnotationPlane (self, ja_default_plane)

Returns the inferred annotation plane. 

GetLetteringPreferences (self)

Returns the lettering preferences for the annotation. 

GetLineAndArrowPreferences (self)

Returns the line and arrow preferences for the annotation. 

GetSymbolPreferences (self)

Returns the symbol preferences for the annotation. 

GetViews (self)

Returns the views that the PMI display instance object is displayed in NOTE: This method is only valid for PMI display instance objects. 

HasAssociativeOrigin (self)

Getter for property: (bool) HasAssociativeOrigin Returns a flag indicating whether the origin is associative. 

InsertIntoStack (self, stack, position)

Inserts the annotation into a stack. 

IsOutOfDate (self)

Getter for property: (bool) IsOutOfDate Returns the flag indicating whether the annotation is out of date. 

IsRetained (self)

Getter for property: (bool) IsRetained Returns a flag indicating whether the annotation is retained. 

LeaderOrientation (self)

Getter for property: (NXOpen.Annotations.LeaderOrientation) LeaderOrientation Returns the leader orientation for the annotation. 

LeaderOrientation (self, leader_orientation)

Setter for property: (NXOpen.Annotations.LeaderOrientation) LeaderOrientation. 

NumberOfAssociativities (self)

Getter for property: (int) NumberOfAssociativities Returns the number of associativities for the annotation. 

ParallelToScreen (self)

Getter for property: (bool) ParallelToScreen Returns the PMI parallel to screen setting. 

ParallelToScreen (self, parallelToScreen)

Setter for property: (bool) ParallelToScreen. 

RemoveFromStack (self)

Removes the annotation from a stack. 

SetAssociativeOrigin (self, assoc_origin, origin)

Associates the annotation's origin to the specified geometry. 

SetAssociativity (self, associativity_index, associativity)

Sets the associativity at specified index.The index starts from 1, and is less than or equal to the return value from NXOpen::Annotations::Annotation::NumberOfAssociativities . 

SetLetteringPreferences (self, lettering_prefs)

Sets the lettering preferences for the annotation. 

SetLineAndArrowPreferences (self, line_arrow_prefs)

Sets the line and arrow preferences for the annotation. 

SetSymbolPreferences (self, symbol_prefs)

Sets the symbol preferences for the annotation. 

SetViews (self, model_views)

Sets the views that the PMI display instance object is displayed in. 

Suppressed (self)

Getter for property: (bool) Suppressed Returns the flag indicating whether the annotation is suppressed. 

Public Member Functions inherited from NXOpen.DisplayableObject

Blank (self)

Blanks the object. 

Color (self)

Getter for property: (int) Color Returns the color of the object. 

Color (self, color)

Setter for property: (int) Color. 

Highlight (self)

Highlights the object. 

IsBlanked (self)

Getter for property: (bool) IsBlanked Returns the blank status of this object. 

Layer (self)

Getter for property: (int) Layer Returns the layer that the object is in. 

Layer (self, layer)

Setter for property: (int) Layer. 

LineFont (self)

Getter for property: (NXOpen.DisplayableObject.ObjectFont) LineFont Returns the line font of the object. 

LineFont (self, font)

Setter for property: (NXOpen.DisplayableObject.ObjectFont) LineFont. 

LineWidth (self)

Getter for property: (NXOpen.DisplayableObject.ObjectWidth) LineWidth Returns the line width of the object. 

LineWidth (self, width)

Setter for property: (NXOpen.DisplayableObject.ObjectWidth) LineWidth. 

NameLocation (self)

Getter for property: (NXOpen.Point3d) NameLocation Returns the location of the object's name. 

RedisplayObject (self)

Redisplays the object in all views. 

RemoveViewDependency (self)

Remove dependency on all views from an object. 

SetNameLocation (self, location)

Sets the location of the object's name. 

Unblank (self)

Unblanks the object. 

Unhighlight (self)

Unhighlights the object. 

Public Member Functions inherited from NXOpen.NXObject

CreateAttributeIterator (self)

Create an attribute iterator. 

DeleteAllAttributesByType (self, type)

Deletes all attributes of a specific type. 

DeleteAllAttributesByType (self, type, option)

Deletes all attributes of a specific type with the option to update or not. 

DeleteAttributeByTypeAndTitle (self, type, title)

Deletes an attribute by type and title. 

DeleteAttributeByTypeAndTitle (self, type, title, option)

Deletes an attribute by type and title with the option to update or not. 

DeleteUserAttribute (self, type, title, delete_entire_array, option)

Deletes the first attribute encountered with the given Type, Title. 

DeleteUserAttributes (self, iterator, option)

Deletes the attributes on the object, if any, that satisfy the given iterator. 

DeleteUserAttributes (self, type, option)

Deletes the attributes encountered with the given Type with option to update or not. 

GetAttributeTitlesByType (self, type)

Gets all the attribute titles of a specific type. 

GetBooleanUserAttribute (self, title, index)

Gets a boolean attribute by Title and array Index. 

GetComputationalTimeUserAttribute (self, title, index)

Gets a time attribute by Title and array Index. 

GetIntegerAttribute (self, title)

Gets an integer attribute by title. 

GetIntegerUserAttribute (self, title, index)

Gets an integer attribute by Title and array Index. 

GetNextUserAttribute (self, iterator)

Gets the next attribute encountered on the object, if any, that satisfies the given iterator. 

GetPdmReferenceAttributeValue (self, attributeTitle)

Gets the value of PDM Reference attribute for given object. 

GetRealAttribute (self, title)

Gets a real attribute by title. 

GetRealUserAttribute (self, title, index)

Gets a real attribute by Title and array Index. 

GetReferenceAttribute (self, title)

Gets the reference string (not the calculated value) of a string attribute that uses a reference string. 

GetStringAttribute (self, title)

Gets a string attribute value by title. 

GetStringUserAttribute (self, title, index)

Gets a string attribute by Title and array Index. 

GetTimeAttribute (self, format, title)

Gets a time attribute by title. 

GetTimeUserAttribute (self, title, index)

Gets a time attribute by Title and array Index. 

GetUserAttribute (self, title, includeUnset, addStringValues, type)

Gets the first attribute (or attribute array) encountered on the object, if any, with a given Title and Type. 

GetUserAttribute (self, title, type, index)

Gets the first attribute encountered on the object, if any, with a given Title, Type and array Index. 

GetUserAttributeAsString (self, title, type, index)

Gets the first attribute encountered on the object, if any, with a given title, type and array index. 

GetUserAttributeCount (self, iterator)

Gets the count of set attributes on the object, if any, that satisfy the given iterator. 

GetUserAttributeCount (self, iterator, countArrayAsOneAttribute)

Gets the count of set attributes on the object, if any, that satisfy the given iterator. 

GetUserAttributeCount (self, type)

Gets the count of set attributes on the object, if any, of the given type. 

GetUserAttributeCount (self, type, includeUnset, countArrayAsOneAttribute)

Gets the count of attributes on the object, if any, of the given type. 

GetUserAttributeLock (self, title, type)

Determine the lock of the given attribute. 

GetUserAttributes (self)

Gets all the attributes that have been set on the given object. 

GetUserAttributes (self, includeUnset)

Gets all the attributes of the given object. 

GetUserAttributes (self, includeUnset, addStringValues)

Gets all the attributes of the given object. 

GetUserAttributes (self, iterator)

Gets all the attributes that have been set on the given object, if any, that satisfy the given iterator. 

GetUserAttributesAsStrings (self)

Gets all the attributes that have been set on the given object. 

GetUserAttributeSize (self, title, type)

Gets the size of the first attribute encountered on the object, if any, with a given Title and Type. 

GetUserAttributeSourceObjects (self)

Returns an array of objects from which this object presents attributes. 

HasUserAttribute (self, iterator)

Determines if an attribute exists on the object, that satisfies the given iterator. 

HasUserAttribute (self, title, type, index)

Determines if an attribute with the given Title, Type and array Index is present on the object Unset attributes will not be detected by this function, as its purpose is to test for the actual presence of the attribute on the object. 

IsOccurrence (self)

Getter for property: (bool) IsOccurrence Returns whether this object is an occurrence or not. 

JournalIdentifier (self)

Getter for property: (str) JournalIdentifier Returns the identifier that would be recorded in a journal for this object. 

Name (self)

Getter for property: (str) Name Returns the custom name of the object. 

OwningComponent (self)

Getter for property: (NXOpen.Assemblies.Component) OwningComponent Returns the owning component, if this object is an occurrence. 

OwningPart (self)

Getter for property: (NXOpen.BasePart) OwningPart Returns the owning part of this object. 

Prototype (self)

Getter for property: (NXOpen.INXObject) Prototype Returns the prototype of this object if it is an occurrence. 

SetAttribute (self, title)

Creates or modifies a null attribute which is an attribute with a title and no value. 

SetAttribute (self, title, option)

Creates or modifies a null attribute with the option to update or not. 

SetAttribute (self, title, value)

Creates or modifies an integer attribute. 

SetAttribute (self, title, value)

Creates or modifies a real attribute. 

SetAttribute (self, title, value)

Creates or modifies a string attribute. 

SetAttribute (self, title, value, option)

Creates or modifies an integer attribute with the option to update or not. 

SetAttribute (self, title, value, option)

Creates or modifies a real attribute with the option to update or not. 

SetAttribute (self, title, value, option)

Creates or modifies a string attribute with the option to update or not. 

SetBooleanUserAttribute (self, title, index, value, option)

Creates or modifies a boolean attribute with the option to update or not. 

SetPdmReferenceAttribute (self, attributeTitle, attributeValue)

Sets the value of PDM Reference attribute on the object. 

SetReferenceAttribute (self, title, value)

Creates or modifies a string attribute which uses a reference string. 

SetReferenceAttribute (self, title, value, option)

Creates or modifies a string attribute which uses a reference string, with the option to update or not. 

SetTimeAttribute (self, title, value)

Creates or modifies a time attribute. 

SetTimeAttribute (self, title, value, option)

Creates or modifies a time attribute with the option to update or not. 

SetTimeUserAttribute (self, title, index, value, option)

Creates or modifies a time attribute with the option to update or not. 

SetTimeUserAttribute (self, title, index, value, option)

Creates or modifies a time attribute with the option to update or not. 

SetUserAttribute (self, info, option)

Creates or modifies an attribute with the option to update or not. 

SetUserAttribute (self, title, index, option)

Creates or modifies a null attribute with the option to update or not. 

SetUserAttribute (self, title, index, value, option)

Creates or modifies an integer attribute with the option to update or not. 

SetUserAttribute (self, title, index, value, option)

Creates or modifies a real attribute with the option to update or not. 

SetUserAttribute (self, title, index, value, option)

Creates or modifies a string attribute with the option to update or not. 

SetUserAttributeLock (self, title, type, lock)

Lock or unlock the given attribute. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

Public Attributes inherited from NXOpen.Annotations.Dimension

DimensionMeasurementTypes = Dimension.MeasurementTypes

NXOpen.Annotations.DimensionMeasurementTypes is an alias for NXOpen.Annotations.Dimension.MeasurementTypes 

Public Attributes inherited from NXOpen.Annotations.Annotation

AnnotationAssociativeOriginData_Struct = Annotation.AssociativeOriginData

NXOpen.Annotations.AnnotationAssociativeOriginData_Struct is an alias for NXOpen.Annotations.Annotation.AssociativeOriginData. 

Public Attributes inherited from NXOpen.DisplayableObject

DisplayableObjectObjectFont = DisplayableObject.ObjectFont

NXOpen.DisplayableObjectObjectFont is an alias for NXOpen.DisplayableObject.ObjectFont 

DisplayableObjectObjectWidth = DisplayableObject.ObjectWidth

NXOpen.DisplayableObjectObjectWidth is an alias for NXOpen.DisplayableObject.ObjectWidth 

Public Attributes inherited from NXOpen.NXObject

NXObjectAttributeInformation_Struct = NXObject.AttributeInformation

NXOpen.NXObjectAttributeInformation_Struct is an alias for NXOpen.NXObject.AttributeInformation. 

NXObjectAttributeType = NXObject.AttributeType

NXOpen.NXObjectAttributeType is an alias for NXOpen.NXObject.AttributeType 

NXObjectComputationalTime_Struct = NXObject.ComputationalTime

NXOpen.NXObjectComputationalTime_Struct is an alias for NXOpen.NXObject.ComputationalTime. 

NXObjectDateAndTimeFormat = NXObject.DateAndTimeFormat

NXOpen.NXObjectDateAndTimeFormat is an alias for NXOpen.NXObject.DateAndTimeFormat 

## Detailed Description

Represents an angular dimension 

Abstract class 

Created in NX4.0.0 

Copyright 2025 Siemens
