# NXOpen.Annotations.SheetMetalPMIBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a14305.html>

Represents a Annotations::SheetMetalPMIBuilder builder 

To create a new instance of this class, use NXOpen::Features::SheetMetal::SheetmetalManager::CreateSheetMetalPmiBuilder 

More...

Inheritance diagram for NXOpen.Annotations.SheetMetalPMIBuilder:

## Public Member Functions

PMIType (self)

Getter for property: (NXOpen.Annotations.SheetMetalPMIBuilder.Types) PMIType Returns the sheet metal pmi type. 

PMIType (self, type)

Setter for property: (NXOpen.Annotations.SheetMetalPMIBuilder.Types) PMIType. 

SelectedBody (self)

Getter for property: (NXOpen.SelectBody) SelectedBody Returns the body selection. 

SelectedFace (self)

Getter for property: (NXOpen.SelectFaceList) SelectedFace Returns the bend face selection. 

Public Member Functions inherited from NXOpen.Annotations.PmiNoteBuilder

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the NXOpen::Annotations::AssociatedObjectsBuilder for note. 

Public Member Functions inherited from NXOpen.Annotations.DraftingNoteBuilder

ForeshorteningSymbol (self)

Getter for property: (NXOpen.Annotations.ForeshorteningSymbolBuilder) ForeshorteningSymbol Returns the foreshortening symbol builder. 

Inherit (self)

Getter for property: (NXOpen.SelectDisplayableObject) Inherit Returns the note from which the properties are inherited. 

InheritProperties (self, annotation, recordNumber)

Inheriting properties from the note. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style builder. 

Text (self)

Getter for property: (NXOpen.Annotations.TextWithEditControlsBuilder) Text Returns the text. 

TextAlignment (self)

Getter for property: (NXOpen.Annotations.DraftingNoteBuilder.TextAlign) TextAlignment Returns the text alignment. 

TextAlignment (self, textAlignment)

Setter for property: (NXOpen.Annotations.DraftingNoteBuilder.TextAlign) TextAlignment. 

VerticalText (self)

Getter for property: (bool) VerticalText Returns the vertical text for text. 

VerticalText (self, verticalText)

Setter for property: (bool) VerticalText. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

SheetMetalPMIBuilderTypes = SheetMetalPMIBuilder.Types

NXOpen.Annotations.SheetMetalPMIBuilderTypes is an alias for NXOpen.Annotations.SheetMetalPMIBuilder.Types 

Public Attributes inherited from NXOpen.Annotations.DraftingNoteBuilder

DraftingNoteBuilderTextAlign = DraftingNoteBuilder.TextAlign

NXOpen.Annotations.DraftingNoteBuilderTextAlign is an alias for NXOpen.Annotations.DraftingNoteBuilder.TextAlign 

DraftingNoteBuilderThicknessTypes = DraftingNoteBuilder.ThicknessTypes

NXOpen.Annotations.DraftingNoteBuilderThicknessTypes is an alias for NXOpen.Annotations.DraftingNoteBuilder.ThicknessTypes 

## Detailed Description

Represents a Annotations::SheetMetalPMIBuilder builder 

To create a new instance of this class, use NXOpen::Features::SheetMetal::SheetmetalManager::CreateSheetMetalPmiBuilder 

Created in NX2007.0.0 

## Member Function Documentation

## ◆ PMIType() [1/2]

NXOpen.Annotations.SheetMetalPMIBuilder.PMIType
(
self — )

Getter for property: (NXOpen.Annotations.SheetMetalPMIBuilder.Types) PMIType Returns the sheet metal pmi type. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
SheetMetalPMIBuilder.Types 

## ◆ PMIType() [2/2]

NXOpen.Annotations.SheetMetalPMIBuilder.PMIType
(
self,

type )

Setter for property: (NXOpen.Annotations.SheetMetalPMIBuilder.Types) PMIType. 

Sets the sheet metal pmi type

Setter License requirements: geometric_tol ("GDT"), nx_sheet_metal ("NX Sheet Metal")

Created in NX2007.0.0 

## ◆ SelectedBody()

NXOpen.Annotations.SheetMetalPMIBuilder.SelectedBody
(
self — )

Getter for property: (NXOpen.SelectBody) SelectedBody Returns the body selection. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
NXOpen.SelectBody 

## ◆ SelectedFace()

NXOpen.Annotations.SheetMetalPMIBuilder.SelectedFace
(
self — )

Getter for property: (NXOpen.SelectFaceList) SelectedFace Returns the bend face selection. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
NXOpen.SelectFaceList 

## Member Data Documentation

## ◆ SheetMetalPMIBuilderTypes

NXOpen.Annotations.SheetMetalPMIBuilder.SheetMetalPMIBuilderTypes = SheetMetalPMIBuilder.Types

NXOpen.Annotations.SheetMetalPMIBuilderTypes is an alias for NXOpen.Annotations.SheetMetalPMIBuilder.Types 

Copyright 2025 Siemens
