# NXOpen.Annotations.AssociateDimensionBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11165.html>

Represents a NXOpen::Annotations::AssociateDimensionBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateAssociateDimensionBuilder 

More...

Inheritance diagram for NXOpen.Annotations.AssociateDimensionBuilder:

## Public Member Functions

Associativity1 (self)

Getter for property: (NXOpen.Annotations.AssociativityBuilder) Associativity1 Returns the first associativity. 

Associativity2 (self)

Getter for property: (NXOpen.Annotations.AssociativityBuilder) Associativity2 Returns the second associativity. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::AssociateDimensionBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateAssociateDimensionBuilder 

Created in NX5.0.0 

## Member Function Documentation

## ◆ Associativity1()

NXOpen.Annotations.AssociateDimensionBuilder.Associativity1
(
self — )

Getter for property: (NXOpen.Annotations.AssociativityBuilder) Associativity1 Returns the first associativity. 

Getter License requirements: None.

Created in NX5.0.0 

Returns
AssociativityBuilder 

## ◆ Associativity2()

NXOpen.Annotations.AssociateDimensionBuilder.Associativity2
(
self — )

Getter for property: (NXOpen.Annotations.AssociativityBuilder) Associativity2 Returns the second associativity. 

Getter License requirements: None.

Created in NX5.0.0 

Returns
AssociativityBuilder 

Copyright 2025 Siemens
