# NXOpen.Annotations.MasterSymbolListItemBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00180.html>

## Classes

class — TextTypes

The Enum for Text Types 

Enumerator — Comment

Mandatory

Arbitrary

Controlled

PartiallyControlled

Integer

Real

Rule

More...

Copyright 2025 Siemens
