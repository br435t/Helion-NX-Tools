# NXOpen.Annotations.RetainedAnnotationsBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a14069.html>

Represents a NXOpen::Annotations::RetainedAnnotationsBuilder. 
More...

Inheritance diagram for NXOpen.Annotations.RetainedAnnotationsBuilder:

## Public Member Functions

ApplyNonAssociativeOrigins (self)

Remove all retained annotation associative origin in the current layout of part that are currently in the "retained" state. 

LineColorFontWidth (self)

Getter for property: (NXOpen.LineColorFontWidthBuilder) LineColorFontWidth Returns the line color font width of retained drafting objects. 

ShowRetainedAnnotations (self)

Getter for property: (bool) ShowRetainedAnnotations Returns the flag indicating to show the retained annotations. 

ShowRetainedAnnotations (self, showRetainedAnnotations)

Setter for property: (bool) ShowRetainedAnnotations. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::RetainedAnnotationsBuilder. 

Created in NX9.0.0 

## Member Function Documentation

## ◆ ApplyNonAssociativeOrigins()

NXOpen.Annotations.RetainedAnnotationsBuilder.ApplyNonAssociativeOrigins
(
self — )

Remove all retained annotation associative origin in the current layout of part that are currently in the "retained" state. 

Created in NX2506.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING") 

## ◆ LineColorFontWidth()

NXOpen.Annotations.RetainedAnnotationsBuilder.LineColorFontWidth
(
self — )

Getter for property: (NXOpen.LineColorFontWidthBuilder) LineColorFontWidth Returns the line color font width of retained drafting objects. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
NXOpen.LineColorFontWidthBuilder 

## ◆ ShowRetainedAnnotations() [1/2]

NXOpen.Annotations.RetainedAnnotationsBuilder.ShowRetainedAnnotations
(
self — )

Getter for property: (bool) ShowRetainedAnnotations Returns the flag indicating to show the retained annotations. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ ShowRetainedAnnotations() [2/2]

NXOpen.Annotations.RetainedAnnotationsBuilder.ShowRetainedAnnotations
(
self,

showRetainedAnnotations )

Setter for property: (bool) ShowRetainedAnnotations. 

Sets the flag indicating to show the retained annotations.

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX9.0.0 

Copyright 2025 Siemens
