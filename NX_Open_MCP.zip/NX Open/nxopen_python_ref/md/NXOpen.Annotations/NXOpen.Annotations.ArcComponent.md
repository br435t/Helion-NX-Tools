# NXOpen.Annotations.ArcComponent Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00127.html>

## Classes

class — ArcType

the arc type 

Enumerator — Comment

Extension — extension arc

Dimension — dimension arc

AllAround — all around

Annotation — annotation arc

Inspection — inspection arc

AllOver — all over

GbDatum — GB Datum arc

More...

Copyright 2025 Siemens
