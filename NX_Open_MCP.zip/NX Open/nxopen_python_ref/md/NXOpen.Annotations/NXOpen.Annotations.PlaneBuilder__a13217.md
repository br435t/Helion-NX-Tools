# NXOpen.Annotations.PlaneBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13217.html>

Represents a NXOpen::Annotations::PlaneBuilder object. 
More...

Inheritance diagram for NXOpen.Annotations.PlaneBuilder:

## Public Member Functions

PlaneMethod (self)

Getter for property: (NXOpen.Annotations.PlaneBuilder.PlaneMethodType) PlaneMethod Returns the plane method. 

PlaneMethod (self, planeMethod)

Setter for property: (NXOpen.Annotations.PlaneBuilder.PlaneMethodType) PlaneMethod. 

ProjectOntoPlane (self)

Getter for property: (bool) ProjectOntoPlane Returns the option to specify project Annotation onto plane. 

ProjectOntoPlane (self, projectOntoPlane)

Setter for property: (bool) ProjectOntoPlane. 

UserDefinedPlane (self)

Getter for property: (NXOpen.Xform) UserDefinedPlane Returns the user-defined plane used by the operation. 

UserDefinedPlane (self, user_defined_plane)

Setter for property: (NXOpen.Xform) UserDefinedPlane. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

PlaneBuilderPlaneMethodType = PlaneBuilder.PlaneMethodType

NXOpen.Annotations.PlaneBuilderPlaneMethodType is an alias for NXOpen.Annotations.PlaneBuilder.PlaneMethodType 

## Detailed Description

Represents a NXOpen::Annotations::PlaneBuilder object. 

This object stored information about the plane in which an annotation lies. 

This is a sub-builder class and cannot be directly instantiated 

Created in NX6.0.0 

## Member Function Documentation

## ◆ PlaneMethod() [1/2]

NXOpen.Annotations.PlaneBuilder.PlaneMethod
(
self — )

Getter for property: (NXOpen.Annotations.PlaneBuilder.PlaneMethodType) PlaneMethod Returns the plane method. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
PlaneBuilder.PlaneMethodType 

## ◆ PlaneMethod() [2/2]

NXOpen.Annotations.PlaneBuilder.PlaneMethod
(
self,

planeMethod )

Setter for property: (NXOpen.Annotations.PlaneBuilder.PlaneMethodType) PlaneMethod. 

Sets the plane method

Setter License requirements: None.

Created in NX6.0.0 

## ◆ ProjectOntoPlane() [1/2]

NXOpen.Annotations.PlaneBuilder.ProjectOntoPlane
(
self — )

Getter for property: (bool) ProjectOntoPlane Returns the option to specify project Annotation onto plane. 

Getter License requirements: None.

Created in NX1872.0.0 

Returns
bool 

## ◆ ProjectOntoPlane() [2/2]

NXOpen.Annotations.PlaneBuilder.ProjectOntoPlane
(
self,

projectOntoPlane )

Setter for property: (bool) ProjectOntoPlane. 

Sets the option to specify project Annotation onto plane.

Setter License requirements: None.

Created in NX1872.0.0 

## ◆ UserDefinedPlane() [1/2]

NXOpen.Annotations.PlaneBuilder.UserDefinedPlane
(
self — )

Getter for property: (NXOpen.Xform) UserDefinedPlane Returns the user-defined plane used by the operation. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.Xform 

## ◆ UserDefinedPlane() [2/2]

NXOpen.Annotations.PlaneBuilder.UserDefinedPlane
(
self,

user_defined_plane )

Setter for property: (NXOpen.Xform) UserDefinedPlane. 

Sets the user-defined plane used by the operation

Setter License requirements: None.

Created in NX6.0.0 

## Member Data Documentation

## ◆ PlaneBuilderPlaneMethodType

NXOpen.Annotations.PlaneBuilder.PlaneBuilderPlaneMethodType = PlaneBuilder.PlaneMethodType

NXOpen.Annotations.PlaneBuilderPlaneMethodType is an alias for NXOpen.Annotations.PlaneBuilder.PlaneMethodType 

Copyright 2025 Siemens
