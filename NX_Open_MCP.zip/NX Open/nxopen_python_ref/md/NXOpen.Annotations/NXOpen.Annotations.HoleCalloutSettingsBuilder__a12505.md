# NXOpen.Annotations.HoleCalloutSettingsBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12505.html>

Represents a NXOpen::Annotations::HoleCalloutSettingsBuilder , this builder contains list(s) of parameter(s) for feature(s). 
More...

Inheritance diagram for NXOpen.Annotations.HoleCalloutSettingsBuilder:

## Public Member Functions

DeleteLineBreak (self, featureType, nth)

If the nth hole feature parameter of feature type is a line break and it can be deleted, deletes it. 

GetDisplayType (self)

Get Parameter display type that specifies if the thread size and pitch parameters are displayed as a vertical fraction or as a single line. 

GetLeaderAttachment (self)

Gets the leader attachment, which decides where the leader is attached to the call out. 

GetLineSpaceFactor (self)

Gets the line space factor, which defines the vertical space between parameters. 

GetListOfFeatures (self)

Gets the list of features. 

GetListOfParameters (self, featureType)

Gets the list of parameters for feature type. 

GetMetricExternalThreadTolerance (self, featureType)

Get Metric External Thread Tolerance Value, which defines thread tolerances on metric threads. 

GetMetricInternalThreadTolerance (self, featureType)

Get Metric Internal Thread Tolerance Value, which defines thread tolerances on metric threads. 

GetNthParameterDisplay (self, featureType, nth)

Gets the display status of the nth hole feature parameter of feature type. 

GetNthParameterPrefix (self, featureType, nth)

If the nth hole feature parameter of feature type can have prefix, gets its prefix. 

GetNthParameterStyle (self, featureType, nth)

Gets the parameter style of the nth hole feature parameter of feature type. 

GetNthParameterSuffix (self, featureType, nth)

If the nth hole feature parameter of feature type can have suffix, gets its suffix. 

GetNthParameterValue (self, featureType, nth)

Gets the parameter expression of the nth hole feature parameter of feature type. 

GetNthParameterValueString (self, featureType, nth)

Gets the parameter string representation of the nth hole feature parameter of feature type. 

GetParameterSpaceFactor (self)

Gets the parameter space factor, which defines the horizontal space between parameters. 

GetThroughHoleTextOfType (self, featureType)

Get Through Hole Text String. 

InsertLineBreak (self, featureType, nth)

If a line break can be inserted immediately after the nth hole feature parameter of feature type, inserts a line break at that position. 

ReorderParameters (self, featureType, parameters)

Reorder the parameters based on the input. 

ResetFromFeature (self, feature, partOccurrence, view, pickPoint)

Reset the builder data based on a feature if the feature is a hole feature. 

SetDisplayType (self, displayType)

Set Parameter display type that specifies if the thread size and pitch parameters are displayed as a vertical fraction or as a single line. 

SetLeaderAttachment (self, leaderAttachment)

Sets the leader attachment, which decides where the leader is attached to the call out. 

SetLineSpaceFactor (self, lineSpaceFactor)

Sets the line space factor, which defines the vertical space between parameters. 

SetMetricExternalThreadTolerance (self, featureType, externalThreadTolerance)

Set Metric External Thread Tolerance Value, which defines thread tolerances on metric threads. 

SetMetricInternalThreadTolerance (self, featureType, internalThreadTolerance)

Set Metric Internal Thread Tolerance Value, which defines thread tolerances on metric threads. 

SetNthParameterDisplay (self, featureType, nth, parameterDisplay)

Sets the display status of the nth hole feature parameter of feature type. 

SetNthParameterPrefix (self, featureType, nth, lines)

If the prefix of the nth hole feature parameter of feature type can be edited, sets its prefix. 

SetNthParameterSuffix (self, featureType, nth, lines)

If the suffix of the nth hole feature parameter of feature type can be edited, sets its suffix. 

SetNthParameterValue (self, featureType, nth, value)

Sets the parameter expression of the nth hole feature parameter of feature type. 

SetParameterSpaceFactor (self, parameterSpaceFactor)

Sets the parameter space factor, which defines the horizontal space between parameters. 

SetThroughHoleTextOfType (self, featureType, throughHoleTextString)

Set Through Hole Text String. 

ShiftDown (self, featureType, nth)

If the position of the nth hole feature parameter of feature type can be shifted down, shifts it down by one. 

ShiftUp (self, featureType, nth)

If the position of the nth hole feature parameter of feature type can be shifted up, shifts it up by one. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

HoleCalloutSettingsBuilderDisplaytype = HoleCalloutSettingsBuilder.Displaytype

NXOpen.Annotations.HoleCalloutSettingsBuilderDisplaytype is an alias for NXOpen.Annotations.HoleCalloutSettingsBuilder.Displaytype 

HoleCalloutSettingsBuilderFeaturetype = HoleCalloutSettingsBuilder.Featuretype

NXOpen.Annotations.HoleCalloutSettingsBuilderFeaturetype is an alias for NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype 

HoleCalloutSettingsBuilderLeaderAttachment = HoleCalloutSettingsBuilder.LeaderAttachment

NXOpen.Annotations.HoleCalloutSettingsBuilderLeaderAttachment is an alias for NXOpen.Annotations.HoleCalloutSettingsBuilder.LeaderAttachment 

HoleCalloutSettingsBuilderParametertype = HoleCalloutSettingsBuilder.Parametertype

NXOpen.Annotations.HoleCalloutSettingsBuilderParametertype is an alias for NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype 

## Detailed Description

Represents a NXOpen::Annotations::HoleCalloutSettingsBuilder , this builder contains list(s) of parameter(s) for feature(s). 

Each feature is categorized under a feature type, indicated by NXOpen::Annotations::HoleCalloutSettingsBuilder::Featuretype . For each feature, parameter(s) are arranged in an array, with a starting index of zero. 

This is a sub-builder class and cannot be directly instantiated 

Created in NX9.0.0 

## Member Function Documentation

## ◆ DeleteLineBreak()

NXOpen.Annotations.HoleCalloutSettingsBuilder.DeleteLineBreak
(
self,

featureType,

nth )

If the nth hole feature parameter of feature type is a line break and it can be deleted, deletes it. 

To delete the second parameter of feature type NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeGeneralHole , for instance, use the API: NXOpen::Annotations::HoleCalloutSettingsBuilder::DeleteLineBreak (NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeGeneralHole , 1)

Created in NX9.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

nth — (int)

## ◆ GetDisplayType()

NXOpen.Annotations.HoleCalloutSettingsBuilder.GetDisplayType
(
self — )

Get Parameter display type that specifies if the thread size and pitch parameters are displayed as a vertical fraction or as a single line. 

Only available when feature types are NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeThreadedHole , NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeSymbolicThread

Returns
displayType (NXOpen.Annotations.HoleCalloutSettingsBuilder.Displaytype): .

Created in NX2312.0.0 

License requirements: None. 

## ◆ GetLeaderAttachment()

NXOpen.Annotations.HoleCalloutSettingsBuilder.GetLeaderAttachment
(
self — )

Gets the leader attachment, which decides where the leader is attached to the call out. 

Returns
leaderAttachment (NXOpen.Annotations.HoleCalloutSettingsBuilder.LeaderAttachment): .

Created in NX9.0.0 

License requirements: None. 

## ◆ GetLineSpaceFactor()

NXOpen.Annotations.HoleCalloutSettingsBuilder.GetLineSpaceFactor
(
self — )

Gets the line space factor, which defines the vertical space between parameters. 

Returns
lineSpaceFactor (float): .

Created in NX9.0.0 

License requirements: None. 

## ◆ GetListOfFeatures()

NXOpen.Annotations.HoleCalloutSettingsBuilder.GetListOfFeatures
(
self — )

Gets the list of features. 

Returns
features (List[NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype]): .

Created in NX9.0.0 

License requirements: None. 

## ◆ GetListOfParameters()

NXOpen.Annotations.HoleCalloutSettingsBuilder.GetListOfParameters
(
self,

featureType )

Gets the list of parameters for feature type. 

Returns
parameters (List[NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype]): .

Created in NX9.0.0 

License requirements: None.

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

## ◆ GetMetricExternalThreadTolerance()

NXOpen.Annotations.HoleCalloutSettingsBuilder.GetMetricExternalThreadTolerance
(
self,

featureType )

Get Metric External Thread Tolerance Value, which defines thread tolerances on metric threads. 

Only available when feature type is NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeThreadedHole , NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeSymbolicThread 
Returns
externalThreadTolerance (str): .

Created in NX2206.0.0 

License requirements: None.

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype) ThreadedHole or SymbolicThread

## ◆ GetMetricInternalThreadTolerance()

NXOpen.Annotations.HoleCalloutSettingsBuilder.GetMetricInternalThreadTolerance
(
self,

featureType )

Get Metric Internal Thread Tolerance Value, which defines thread tolerances on metric threads. 

Only available when feature type is NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeThreadedHole , NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeSymbolicThread 
Returns
internalThreadTolerance (str): .

Created in NX2206.0.0 

License requirements: None.

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype) ThreadedHole or SymbolicThread

## ◆ GetNthParameterDisplay()

NXOpen.Annotations.HoleCalloutSettingsBuilder.GetNthParameterDisplay
(
self,

featureType,

nth )

Gets the display status of the nth hole feature parameter of feature type. 

Returns
parameterDisplay (bool): .

Created in NX9.0.0 

License requirements: None.

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

nth — (int)

## ◆ GetNthParameterPrefix()

NXOpen.Annotations.HoleCalloutSettingsBuilder.GetNthParameterPrefix
(
self,

featureType,

nth )

If the nth hole feature parameter of feature type can have prefix, gets its prefix. 

Returns
lines (List[str]): List of lines .

Created in NX9.0.0 

License requirements: None.

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

nth — (int)

## ◆ GetNthParameterStyle()

NXOpen.Annotations.HoleCalloutSettingsBuilder.GetNthParameterStyle
(
self,

featureType,

nth )

Gets the parameter style of the nth hole feature parameter of feature type. 

Returns
style (NXOpen.Annotations.StyleBuilder): .

Created in NX9.0.0 

License requirements: None.

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

nth — (int)

## ◆ GetNthParameterSuffix()

NXOpen.Annotations.HoleCalloutSettingsBuilder.GetNthParameterSuffix
(
self,

featureType,

nth )

If the nth hole feature parameter of feature type can have suffix, gets its suffix. 

Returns
lines (List[str]): List of lines .

Created in NX9.0.0 

License requirements: None.

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

nth — (int)

## ◆ GetNthParameterValue()

NXOpen.Annotations.HoleCalloutSettingsBuilder.GetNthParameterValue
(
self,

featureType,

nth )

Gets the parameter expression of the nth hole feature parameter of feature type. 

Returns
value (str): .

Created in NX9.0.0 

License requirements: None.

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

nth — (int)

## ◆ GetNthParameterValueString()

NXOpen.Annotations.HoleCalloutSettingsBuilder.GetNthParameterValueString
(
self,

featureType,

nth )

Gets the parameter string representation of the nth hole feature parameter of feature type. 

Differs from NXOpen::Annotations::HoleCalloutSettingsBuilder::GetNthParameterValue in that certain parameters which do not have a parameter value still have a string representation. This API will return that string representation instead of an empty string. 
Returns
value (str): .

Created in NX11.0.1 

License requirements: None.

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

nth — (int)

## ◆ GetParameterSpaceFactor()

NXOpen.Annotations.HoleCalloutSettingsBuilder.GetParameterSpaceFactor
(
self — )

Gets the parameter space factor, which defines the horizontal space between parameters. 

Returns
parameterSpaceFactor (float): .

Created in NX9.0.0 

License requirements: None. 

## ◆ GetThroughHoleTextOfType()

NXOpen.Annotations.HoleCalloutSettingsBuilder.GetThroughHoleTextOfType
(
self,

featureType )

Get Through Hole Text String. 

Returns
throughHoleTextString (str): .

Created in NX12.0.0 

License requirements: None.

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

## ◆ InsertLineBreak()

NXOpen.Annotations.HoleCalloutSettingsBuilder.InsertLineBreak
(
self,

featureType,

nth )

If a line break can be inserted immediately after the nth hole feature parameter of feature type, inserts a line break at that position. 

To insert a line break after the fourth parameter of feature type NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeGeneralHole , for instance, use the API: NXOpen::Annotations::HoleCalloutSettingsBuilder::InsertLineBreak (NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeGeneralHole , 3)

Created in NX9.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

nth — (int)

## ◆ ReorderParameters()

NXOpen.Annotations.HoleCalloutSettingsBuilder.ReorderParameters
(
self,

featureType,

parameters )

Reorder the parameters based on the input. 

This function only works if all input parameters exist in the builder and all builder parameters exist in the input. 
Returns
orderIsChanged (bool): .

Created in NX9.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

parameters — (List[NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype])

## ◆ ResetFromFeature()

NXOpen.Annotations.HoleCalloutSettingsBuilder.ResetFromFeature
(
self,

feature,

partOccurrence,

view,

pickPoint )

Reset the builder data based on a feature if the feature is a hole feature. 

Created in NX9.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

feature — (NXOpen.TaggedObject)

partOccurrence — (NXOpen.Assemblies.Component)

view — (NXOpen.View)

pickPoint — (NXOpen.Point3d) selected object point

## ◆ SetDisplayType()

NXOpen.Annotations.HoleCalloutSettingsBuilder.SetDisplayType
(
self,

displayType )

Set Parameter display type that specifies if the thread size and pitch parameters are displayed as a vertical fraction or as a single line. 

Only available when feature types are NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeThreadedHole , NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeSymbolicThread

Created in NX2312.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

displayType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Displaytype)

## ◆ SetLeaderAttachment()

NXOpen.Annotations.HoleCalloutSettingsBuilder.SetLeaderAttachment
(
self,

leaderAttachment )

Sets the leader attachment, which decides where the leader is attached to the call out. 

Created in NX9.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

leaderAttachment — (NXOpen.Annotations.HoleCalloutSettingsBuilder.LeaderAttachment)

## ◆ SetLineSpaceFactor()

NXOpen.Annotations.HoleCalloutSettingsBuilder.SetLineSpaceFactor
(
self,

lineSpaceFactor )

Sets the line space factor, which defines the vertical space between parameters. 

The line space factor cannot be less than zero.

Created in NX9.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

lineSpaceFactor — (float)

## ◆ SetMetricExternalThreadTolerance()

NXOpen.Annotations.HoleCalloutSettingsBuilder.SetMetricExternalThreadTolerance
(
self,

featureType,

externalThreadTolerance )

Set Metric External Thread Tolerance Value, which defines thread tolerances on metric threads. 

Only available when feature type is NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeThreadedHole , NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeSymbolicThread

Created in NX2206.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype) ThreadedHole or SymbolicThread

externalThreadTolerance — (str)

## ◆ SetMetricInternalThreadTolerance()

NXOpen.Annotations.HoleCalloutSettingsBuilder.SetMetricInternalThreadTolerance
(
self,

featureType,

internalThreadTolerance )

Set Metric Internal Thread Tolerance Value, which defines thread tolerances on metric threads. 

Only available when feature type is NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeThreadedHole , NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeSymbolicThread

Created in NX2206.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype) ThreadedHole or SymbolicThread

internalThreadTolerance — (str)

## ◆ SetNthParameterDisplay()

NXOpen.Annotations.HoleCalloutSettingsBuilder.SetNthParameterDisplay
(
self,

featureType,

nth,

parameterDisplay )

Sets the display status of the nth hole feature parameter of feature type. 

Created in NX9.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

nth — (int)

parameterDisplay — (bool)

## ◆ SetNthParameterPrefix()

NXOpen.Annotations.HoleCalloutSettingsBuilder.SetNthParameterPrefix
(
self,

featureType,

nth,

lines )

If the prefix of the nth hole feature parameter of feature type can be edited, sets its prefix. 

Created in NX9.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

nth — (int)

lines — (List[str]) List of new lines

## ◆ SetNthParameterSuffix()

NXOpen.Annotations.HoleCalloutSettingsBuilder.SetNthParameterSuffix
(
self,

featureType,

nth,

lines )

If the suffix of the nth hole feature parameter of feature type can be edited, sets its suffix. 

Created in NX9.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

nth — (int)

lines — (List[str]) List of new lines

## ◆ SetNthParameterValue()

NXOpen.Annotations.HoleCalloutSettingsBuilder.SetNthParameterValue
(
self,

featureType,

nth,

value )

Sets the parameter expression of the nth hole feature parameter of feature type. 

Created in NX9.0.0 

License requirements: None.

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

nth — (int)

value — (str)

## ◆ SetParameterSpaceFactor()

NXOpen.Annotations.HoleCalloutSettingsBuilder.SetParameterSpaceFactor
(
self,

parameterSpaceFactor )

Sets the parameter space factor, which defines the horizontal space between parameters. 

The parameter space factor cannot be less than zero.

Created in NX9.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

parameterSpaceFactor — (float)

## ◆ SetThroughHoleTextOfType()

NXOpen.Annotations.HoleCalloutSettingsBuilder.SetThroughHoleTextOfType
(
self,

featureType,

throughHoleTextString )

Set Through Hole Text String. 

Created in NX12.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

throughHoleTextString — (str)

## ◆ ShiftDown()

NXOpen.Annotations.HoleCalloutSettingsBuilder.ShiftDown
(
self,

featureType,

nth )

If the position of the nth hole feature parameter of feature type can be shifted down, shifts it down by one. 

To shift down the first parameter of feature type NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeGeneralHole , for instance, use the API: NXOpen::Annotations::HoleCalloutSettingsBuilder::ShiftDown (NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeGeneralHole , 0)

Created in NX9.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

nth — (int)

## ◆ ShiftUp()

NXOpen.Annotations.HoleCalloutSettingsBuilder.ShiftUp
(
self,

featureType,

nth )

If the position of the nth hole feature parameter of feature type can be shifted up, shifts it up by one. 

To shift up the third parameter of feature type NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeGeneralHole , for instance, use the API: NXOpen::Annotations::HoleCalloutSettingsBuilder::ShiftUp (NXOpen::Annotations::HoleCalloutSettingsBuilder::FeaturetypeGeneralHole , 2)

Created in NX9.0.0 

License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Parameters

featureType — (NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype)

nth — (int)

## Member Data Documentation

## ◆ HoleCalloutSettingsBuilderDisplaytype

NXOpen.Annotations.HoleCalloutSettingsBuilder.HoleCalloutSettingsBuilderDisplaytype = HoleCalloutSettingsBuilder.Displaytype

NXOpen.Annotations.HoleCalloutSettingsBuilderDisplaytype is an alias for NXOpen.Annotations.HoleCalloutSettingsBuilder.Displaytype 

## ◆ HoleCalloutSettingsBuilderFeaturetype

NXOpen.Annotations.HoleCalloutSettingsBuilder.HoleCalloutSettingsBuilderFeaturetype = HoleCalloutSettingsBuilder.Featuretype

NXOpen.Annotations.HoleCalloutSettingsBuilderFeaturetype is an alias for NXOpen.Annotations.HoleCalloutSettingsBuilder.Featuretype 

## ◆ HoleCalloutSettingsBuilderLeaderAttachment

NXOpen.Annotations.HoleCalloutSettingsBuilder.HoleCalloutSettingsBuilderLeaderAttachment = HoleCalloutSettingsBuilder.LeaderAttachment

NXOpen.Annotations.HoleCalloutSettingsBuilderLeaderAttachment is an alias for NXOpen.Annotations.HoleCalloutSettingsBuilder.LeaderAttachment 

## ◆ HoleCalloutSettingsBuilderParametertype

NXOpen.Annotations.HoleCalloutSettingsBuilder.HoleCalloutSettingsBuilderParametertype = HoleCalloutSettingsBuilder.Parametertype

NXOpen.Annotations.HoleCalloutSettingsBuilderParametertype is an alias for NXOpen.Annotations.HoleCalloutSettingsBuilder.Parametertype 

Copyright 2025 Siemens
