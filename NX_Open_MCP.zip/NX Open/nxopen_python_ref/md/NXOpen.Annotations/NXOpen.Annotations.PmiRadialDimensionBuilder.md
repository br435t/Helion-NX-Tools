# NXOpen.Annotations.PmiRadialDimensionBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13753.html>

Represents a NXOpen::Annotations::Dimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreatePmiRadialDimensionBuilder 

More...

Inheritance diagram for NXOpen.Annotations.PmiRadialDimensionBuilder:

## Public Member Functions

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the associated objects. 

Public Member Functions inherited from NXOpen.Annotations.BaseRadialDimensionBuilder

AppendedText (self)

Getter for property: (NXOpen.Annotations.AppendedTextBuilder) AppendedText Returns the appended text. 

DiameterDimensionDimLineAngle (self)

Getter for property: (float) DiameterDimensionDimLineAngle Returns the diameter dimension's dimension-line-angle. 

DiameterDimensionDimLineAngle (self, dimLineAngle)

Setter for property: (float) DiameterDimensionDimLineAngle. 

FirstAssociativity (self)

Getter for property: (NXOpen.SelectNXObject) FirstAssociativity Returns the first associativity. 

FoldLocation (self)

Getter for property: (NXOpen.SelectDisplayableObject) FoldLocation Returns the fold location. 

Inherit (self)

Getter for property: (NXOpen.SelectDisplayableObject) Inherit Returns the inherit. 

IsFoldedRadius (self)

Getter for property: (bool) IsFoldedRadius Returns the is folded radius. 

IsFoldedRadius (self, isFoldedRadius)

Setter for property: (bool) IsFoldedRadius. 

IsHoleStyle (self)

Getter for property: (bool) IsHoleStyle Returns the is hole style dimension. 

IsHoleStyle (self, isArrowsOutDia)

Setter for property: (bool) IsHoleStyle. 

IsRadiusToCenter (self)

Getter for property: (bool) IsRadiusToCenter Returns the is radius to center. 

IsRadiusToCenter (self, isRadiusToCenter)

Setter for property: (bool) IsRadiusToCenter. 

Measurement (self)

Getter for property: (NXOpen.Annotations.DimensionMeasurementBuilder) Measurement Returns the measurement. 

OffsetCenterPoint (self)

Getter for property: (NXOpen.SelectDisplayableObject) OffsetCenterPoint Returns the offset center point. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the origin. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::Dimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreatePmiRadialDimensionBuilder 

Created in NX9.0.0 

## Member Function Documentation

## ◆ AssociatedObjects()

NXOpen.Annotations.PmiRadialDimensionBuilder.AssociatedObjects
(
self — )

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the associated objects. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
AssociatedObjectsBuilder 

Copyright 2025 Siemens
