# NXOpen.Annotations.IntersectionSymbolBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12697.html>

Represents a NXOpen::Annotations::IntersectionSymbol builder 

To create a new instance of this class, use NXOpen::Annotations::IntersectionSymbolCollection::CreateIntersectionSymbolBuilder 

Default values. 
More...

Inheritance diagram for NXOpen.Annotations.IntersectionSymbolBuilder:

## Public Member Functions

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

Extension (self)

Getter for property: (float) Extension Returns the extension. 

Extension (self, extension)

Setter for property: (float) Extension. 

Inherit (self)

Getter for property: (NXOpen.SelectNXObject) Inherit Returns the inherit. 

IntersectionObject1 (self)

Getter for property: (NXOpen.SelectNXObject) IntersectionObject1 Returns the intersection object1. 

IntersectionObject2 (self)

Getter for property: (NXOpen.SelectNXObject) IntersectionObject2 Returns the intersection object2. 

Width (self)

Getter for property: (NXOpen.Annotations.IntersectionSymbolBuilder.Thickness) Width Returns the width. 

Width (self, width)

Setter for property: (NXOpen.Annotations.IntersectionSymbolBuilder.Thickness) Width. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

IntersectionSymbolBuilderThickness = IntersectionSymbolBuilder.Thickness

NXOpen.Annotations.IntersectionSymbolBuilderThickness is an alias for NXOpen.Annotations.IntersectionSymbolBuilder.Thickness 

## Detailed Description

Represents a NXOpen::Annotations::IntersectionSymbol builder 

To create a new instance of this class, use NXOpen::Annotations::IntersectionSymbolCollection::CreateIntersectionSymbolBuilder 

Default values. 

Property — Value

Extension 

3 

Width 

Thin 

Created in NX6.0.0 

## Member Function Documentation

## ◆ Color() [1/2]

NXOpen.Annotations.IntersectionSymbolBuilder.Color
(
self — )

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.NXColor 

## ◆ Color() [2/2]

NXOpen.Annotations.IntersectionSymbolBuilder.Color
(
self,

color )

Setter for property: (NXOpen.NXColor) Color. 

Sets the color

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ Extension() [1/2]

NXOpen.Annotations.IntersectionSymbolBuilder.Extension
(
self — )

Getter for property: (float) Extension Returns the extension. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ Extension() [2/2]

NXOpen.Annotations.IntersectionSymbolBuilder.Extension
(
self,

extension )

Setter for property: (float) Extension. 

Sets the extension

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ Inherit()

NXOpen.Annotations.IntersectionSymbolBuilder.Inherit
(
self — )

Getter for property: (NXOpen.SelectNXObject) Inherit Returns the inherit. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ IntersectionObject1()

NXOpen.Annotations.IntersectionSymbolBuilder.IntersectionObject1
(
self — )

Getter for property: (NXOpen.SelectNXObject) IntersectionObject1 Returns the intersection object1. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ IntersectionObject2()

NXOpen.Annotations.IntersectionSymbolBuilder.IntersectionObject2
(
self — )

Getter for property: (NXOpen.SelectNXObject) IntersectionObject2 Returns the intersection object2. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ Width() [1/2]

NXOpen.Annotations.IntersectionSymbolBuilder.Width
(
self — )

Getter for property: (NXOpen.Annotations.IntersectionSymbolBuilder.Thickness) Width Returns the width. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
IntersectionSymbolBuilder.Thickness 

## ◆ Width() [2/2]

NXOpen.Annotations.IntersectionSymbolBuilder.Width
(
self,

width )

Setter for property: (NXOpen.Annotations.IntersectionSymbolBuilder.Thickness) Width. 

Sets the width

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## Member Data Documentation

## ◆ IntersectionSymbolBuilderThickness

NXOpen.Annotations.IntersectionSymbolBuilder.IntersectionSymbolBuilderThickness = IntersectionSymbolBuilder.Thickness

NXOpen.Annotations.IntersectionSymbolBuilderThickness is an alias for NXOpen.Annotations.IntersectionSymbolBuilder.Thickness 

Copyright 2025 Siemens
