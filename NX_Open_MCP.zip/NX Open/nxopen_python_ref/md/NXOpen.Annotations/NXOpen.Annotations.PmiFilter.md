# NXOpen.Annotations.PmiFilter Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00194.html>

## Classes

class — ComponentMethod

Specifies the type of component method used on the associated components for display. More...

class — FilterType

Represents a type of PMI filter that can be created using the Part Navigator. More...

Copyright 2025 Siemens
