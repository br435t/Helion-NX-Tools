# NXOpen.Annotations.RegionBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00206.html>

## Classes

class — AlignmentPosition

Specifies the anchor location of the region 

Enumerator — Comment

TopLeft — top left

TopCenter — top center

TopRight — top right

MiddleLeft — middle left

MiddleCenter — middle center

MiddleRight — middle right

BottomLeft — bottom left

BottomCenter — bottom center

BottomRight — bottom right

More...

class — CrosshatchPatterns

Specifies the crosshatch pattern 

Enumerator — Comment

NotSet — none

GeneralUse — general use

More...

class — Types

Specifies the region type 

Enumerator — Comment

RectangularRegion — rectangular

CircularRegion — circular

AnnularRegion — annular

CylindricalRegion — cylindrical

ArbitraryRegion — arbitrary

More...

Copyright 2025 Siemens
