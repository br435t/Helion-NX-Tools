# NXOpen.Annotations.ArbitraryAreaSeedBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11121.html>

Represents a NXOpen::Annotations::ArbitraryAreaSeedBuilder 

To create a new instance of this class, use NXOpen::Annotations::PmiManager::CreateArbitraryAreaSeedBuilder 

More...

Inheritance diagram for NXOpen.Annotations.ArbitraryAreaSeedBuilder:

## Public Member Functions

ProjectionDirection (self)

Getter for property: (NXOpen.GeometricUtilities.ProjectionOptions) ProjectionDirection Returns the projection direction. 

SelectFace (self)

Getter for property: (NXOpen.SelectDisplayableObjectList) SelectFace Returns the select face. 

SpecifyCurves (self)

Getter for property: (NXOpen.SelectDisplayableObjectList) SpecifyCurves Returns the specify curves. 

SpecifyPoint (self)

Getter for property: (NXOpen.Point) SpecifyPoint Returns the specify point. 

SpecifyPoint (self, specifyPoint)

Setter for property: (NXOpen.Point) SpecifyPoint. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::ArbitraryAreaSeedBuilder 

To create a new instance of this class, use NXOpen::Annotations::PmiManager::CreateArbitraryAreaSeedBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ ProjectionDirection()

NXOpen.Annotations.ArbitraryAreaSeedBuilder.ProjectionDirection
(
self — )

Getter for property: (NXOpen.GeometricUtilities.ProjectionOptions) ProjectionDirection Returns the projection direction. 

Getter License requirements: None.

Created in NX2306.0.0 

Returns
NXOpen.GeometricUtilities.ProjectionOptions 

## ◆ SelectFace()

NXOpen.Annotations.ArbitraryAreaSeedBuilder.SelectFace
(
self — )

Getter for property: (NXOpen.SelectDisplayableObjectList) SelectFace Returns the select face. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectDisplayableObjectList 

## ◆ SpecifyCurves()

NXOpen.Annotations.ArbitraryAreaSeedBuilder.SpecifyCurves
(
self — )

Getter for property: (NXOpen.SelectDisplayableObjectList) SpecifyCurves Returns the specify curves. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectDisplayableObjectList 

## ◆ SpecifyPoint() [1/2]

NXOpen.Annotations.ArbitraryAreaSeedBuilder.SpecifyPoint
(
self — )

Getter for property: (NXOpen.Point) SpecifyPoint Returns the specify point. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.Point 

## ◆ SpecifyPoint() [2/2]

NXOpen.Annotations.ArbitraryAreaSeedBuilder.SpecifyPoint
(
self,

specifyPoint )

Setter for property: (NXOpen.Point) SpecifyPoint. 

Sets the specify point

Setter License requirements: geometric_tol ("GDT")

Created in NX6.0.0 

Copyright 2025 Siemens
