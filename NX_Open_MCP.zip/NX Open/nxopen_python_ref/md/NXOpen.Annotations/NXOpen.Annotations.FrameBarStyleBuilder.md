# NXOpen.Annotations.FrameBarStyleBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12357.html>

Represents a NXOpen::Annotations::FrameBarStyleBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.FrameBarStyleBuilder:

## Public Member Functions

AftPerpendicularStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) AftPerpendicularStyle Returns the style aft perpendicular. 

AlongHullBaselineStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) AlongHullBaselineStyle Returns the style along hulll baseline. 

AlongHullDecksStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) AlongHullDecksStyle Returns the style along hulll decks. 

AlongHullLongitudinalZFramesStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) AlongHullLongitudinalZFramesStyle Returns the style along hulll longitudinal z frames. 

AlongHullLongitudinalZInsertFramesStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) AlongHullLongitudinalZInsertFramesStyle Returns the style along hull longitudinal z insert frames. 

AlongHullWaterlineStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) AlongHullWaterlineStyle Returns the style along hulll waterline. 

BaselineStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) BaselineStyle Returns the style baseline. 

BulkHeadsStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) BulkHeadsStyle Returns the style bulk heads. 

CenterlineYStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) CenterlineYStyle Returns the style centerline y. 

DecksStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) DecksStyle Returns the style decks. 

ForwardPerpendicularStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) ForwardPerpendicularStyle Returns the style forward perpendicular. 

InterTransverseFramesStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) InterTransverseFramesStyle Returns the style inter transverse frames. 

LongitudinalBulkheadsStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) LongitudinalBulkheadsStyle Returns the style longitudinal bulkheads. 

LongitudinalYFramesStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) LongitudinalYFramesStyle Returns the style longitudinal y frames. 

LongitudinalYInsertFramesStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) LongitudinalYInsertFramesStyle Returns the style longitudinal y insert frames. 

LongitudinalZFramesStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) LongitudinalZFramesStyle Returns the style longitudinal z frames. 

LongitudinalZInsertFramesStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) LongitudinalZInsertFramesStyle Returns the style longitudinal z insert frames. 

MidshipStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) MidshipStyle Returns the style mid ship. 

TransversalInsertAreaStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) TransversalInsertAreaStyle Returns the style transversal insert area. 

TransverseFramesStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) TransverseFramesStyle Returns the style transverse frames. 

WaterlineStyle (self)

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) WaterlineStyle Returns the style waterline. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::FrameBarStyleBuilder . 

This class queries and sets FrameBar preferences when creating and editing FrameBar drafting annotations.

Created in NX6.0.0 

## Member Function Documentation

## ◆ AftPerpendicularStyle()

NXOpen.Annotations.FrameBarStyleBuilder.AftPerpendicularStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) AftPerpendicularStyle Returns the style aft perpendicular. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ AlongHullBaselineStyle()

NXOpen.Annotations.FrameBarStyleBuilder.AlongHullBaselineStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) AlongHullBaselineStyle Returns the style along hulll baseline. 

Getter License requirements: None.

Created in NX1899.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ AlongHullDecksStyle()

NXOpen.Annotations.FrameBarStyleBuilder.AlongHullDecksStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) AlongHullDecksStyle Returns the style along hulll decks. 

Getter License requirements: None.

Created in NX1899.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ AlongHullLongitudinalZFramesStyle()

NXOpen.Annotations.FrameBarStyleBuilder.AlongHullLongitudinalZFramesStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) AlongHullLongitudinalZFramesStyle Returns the style along hulll longitudinal z frames. 

Getter License requirements: None.

Created in NX1899.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ AlongHullLongitudinalZInsertFramesStyle()

NXOpen.Annotations.FrameBarStyleBuilder.AlongHullLongitudinalZInsertFramesStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) AlongHullLongitudinalZInsertFramesStyle Returns the style along hull longitudinal z insert frames. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ AlongHullWaterlineStyle()

NXOpen.Annotations.FrameBarStyleBuilder.AlongHullWaterlineStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) AlongHullWaterlineStyle Returns the style along hulll waterline. 

Getter License requirements: None.

Created in NX1899.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ BaselineStyle()

NXOpen.Annotations.FrameBarStyleBuilder.BaselineStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) BaselineStyle Returns the style baseline. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ BulkHeadsStyle()

NXOpen.Annotations.FrameBarStyleBuilder.BulkHeadsStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) BulkHeadsStyle Returns the style bulk heads. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ CenterlineYStyle()

NXOpen.Annotations.FrameBarStyleBuilder.CenterlineYStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) CenterlineYStyle Returns the style centerline y. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ DecksStyle()

NXOpen.Annotations.FrameBarStyleBuilder.DecksStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) DecksStyle Returns the style decks. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ ForwardPerpendicularStyle()

NXOpen.Annotations.FrameBarStyleBuilder.ForwardPerpendicularStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) ForwardPerpendicularStyle Returns the style forward perpendicular. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ InterTransverseFramesStyle()

NXOpen.Annotations.FrameBarStyleBuilder.InterTransverseFramesStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) InterTransverseFramesStyle Returns the style inter transverse frames. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ LongitudinalBulkheadsStyle()

NXOpen.Annotations.FrameBarStyleBuilder.LongitudinalBulkheadsStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) LongitudinalBulkheadsStyle Returns the style longitudinal bulkheads. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ LongitudinalYFramesStyle()

NXOpen.Annotations.FrameBarStyleBuilder.LongitudinalYFramesStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) LongitudinalYFramesStyle Returns the style longitudinal y frames. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ LongitudinalYInsertFramesStyle()

NXOpen.Annotations.FrameBarStyleBuilder.LongitudinalYInsertFramesStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) LongitudinalYInsertFramesStyle Returns the style longitudinal y insert frames. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ LongitudinalZFramesStyle()

NXOpen.Annotations.FrameBarStyleBuilder.LongitudinalZFramesStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) LongitudinalZFramesStyle Returns the style longitudinal z frames. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ LongitudinalZInsertFramesStyle()

NXOpen.Annotations.FrameBarStyleBuilder.LongitudinalZInsertFramesStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) LongitudinalZInsertFramesStyle Returns the style longitudinal z insert frames. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ MidshipStyle()

NXOpen.Annotations.FrameBarStyleBuilder.MidshipStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) MidshipStyle Returns the style mid ship. 

Getter License requirements: None.

Created in NX2206.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ TransversalInsertAreaStyle()

NXOpen.Annotations.FrameBarStyleBuilder.TransversalInsertAreaStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) TransversalInsertAreaStyle Returns the style transversal insert area. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ TransverseFramesStyle()

NXOpen.Annotations.FrameBarStyleBuilder.TransverseFramesStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) TransverseFramesStyle Returns the style transverse frames. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
FrameBarElementStyleBuilder 

## ◆ WaterlineStyle()

NXOpen.Annotations.FrameBarStyleBuilder.WaterlineStyle
(
self — )

Getter for property: (NXOpen.Annotations.FrameBarElementStyleBuilder) WaterlineStyle Returns the style waterline. 

Getter License requirements: None.

Created in NX8.0.0 

Returns
FrameBarElementStyleBuilder 

Copyright 2025 Siemens
