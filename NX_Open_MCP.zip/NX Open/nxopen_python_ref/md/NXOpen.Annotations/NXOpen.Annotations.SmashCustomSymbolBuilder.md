# NXOpen.Annotations.SmashCustomSymbolBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a14405.html>

Represents a NXOpen::Annotations::SmashCustomSymbolBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.SmashCustomSymbolBuilder:

## Public Member Functions

Symbol (self)

Getter for property: (NXOpen.SelectDisplayableObjectList) Symbol Returns the selected symbol instance. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::SmashCustomSymbolBuilder . 

This class allows selecting a custom symbol object to be smashed. 

To create a new instance of this class, use NXOpen::Annotations::CustomSymbolCollection::CreateSmashCustomSymbolBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ Symbol()

NXOpen.Annotations.SmashCustomSymbolBuilder.Symbol
(
self — )

Getter for property: (NXOpen.SelectDisplayableObjectList) Symbol Returns the selected symbol instance. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectDisplayableObjectList 

Copyright 2025 Siemens
