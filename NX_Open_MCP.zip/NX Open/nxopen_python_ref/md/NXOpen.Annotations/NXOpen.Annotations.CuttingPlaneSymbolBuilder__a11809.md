# NXOpen.Annotations.CuttingPlaneSymbolBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11809.html>

Represents a NXOpen::Annotations::CuttingPlaneSymbolBuilder 

This is a sub-builder class and cannot be directly instantiated 

More...

Inheritance diagram for NXOpen.Annotations.CuttingPlaneSymbolBuilder:

## Public Member Functions

AlternateArrow (self)

The Cutting Plane Symbol Alternate Arrow. 

AlternateArrowRotation (self)

The Cutting Plane Symbol Alternate Arrow Rotation. 

ArrowDirection (self)

Getter for property: (NXOpen.Annotations.CuttingPlaneSymbolBuilder.ArrowDirectionOption) ArrowDirection Returns the Cutting Plane Symbol Arrow Direction relative to plane. 

ArrowDirection (self, arrowDirection)

Setter for property: (NXOpen.Annotations.CuttingPlaneSymbolBuilder.ArrowDirectionOption) ArrowDirection. 

ArrowLength (self)

Getter for property: (float) ArrowLength Returns the Cutting Plane Symbol Arrow Length. 

ArrowLength (self, arrowLength)

Setter for property: (float) ArrowLength. 

Color (self)

Getter for property: (int) Color Returns the color of the Cutting Plane Symbol. 

Color (self, cuttingPlaneSymbolColor)

Setter for property: (int) Color. 

CuttingPlaneSymbolText (self)

Getter for property: (str) CuttingPlaneSymbolText Returns the Cutting Plane Symbol text. 

CuttingPlaneSymbolText (self, cuttingPlaneSymbolName)

Setter for property: (str) CuttingPlaneSymbolText. 

DisplayCuttingPlaneSymbol (self)

Getter for property: (bool) DisplayCuttingPlaneSymbol Returns the display cutting plane symbol. 

DisplayCuttingPlaneSymbol (self, displayCuttingPlaneSymbol)

Setter for property: (bool) DisplayCuttingPlaneSymbol. 

Font (self)

Getter for property: (NXOpen.LineFontBuilder) Font Returns the font. 

MarginPercentage (self)

Getter for property: (float) MarginPercentage Returns the margin. 

MarginPercentage (self, marginPercentage)

Setter for property: (float) MarginPercentage. 

ShadedPlane (self)

Getter for property: (bool) ShadedPlane Returns the shaded plane. 

ShadedPlane (self, shadedPlane)

Setter for property: (bool) ShadedPlane. 

SizeBasedOnSectionCut (self)

Getter for property: (bool) SizeBasedOnSectionCut Returns the size based on section cut. 

SizeBasedOnSectionCut (self, sizeBasedOnSectionCut)

Setter for property: (bool) SizeBasedOnSectionCut. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the Cutting Plane Symbol Style. 

TextPlaneRelativeToArrow (self)

Getter for property: (NXOpen.Annotations.CuttingPlaneSymbolBuilder.TextPlaneRelativeArrow) TextPlaneRelativeToArrow Returns the text plane relative to arrow. 

TextPlaneRelativeToArrow (self, textPlaneRelativeToArrow)

Setter for property: (NXOpen.Annotations.CuttingPlaneSymbolBuilder.TextPlaneRelativeArrow) TextPlaneRelativeToArrow. 

UseTwoArrows (self)

Getter for property: (bool) UseTwoArrows Returns the use two arrows. 

UseTwoArrows (self, useTwoArrows)

Setter for property: (bool) UseTwoArrows. 

ViewNameFormat (self)

Getter for property: (NXOpen.Annotations.CuttingPlaneSymbolBuilder.ViewNameFormatOption) ViewNameFormat Returns the name view from symbol. 

ViewNameFormat (self, viewNameFormat)

Setter for property: (NXOpen.Annotations.CuttingPlaneSymbolBuilder.ViewNameFormatOption) ViewNameFormat. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

CuttingPlaneSymbolBuilderArrowDirectionOption = CuttingPlaneSymbolBuilder.ArrowDirectionOption

NXOpen.Annotations.CuttingPlaneSymbolBuilderArrowDirectionOption is an alias for NXOpen.Annotations.CuttingPlaneSymbolBuilder.ArrowDirectionOption 

CuttingPlaneSymbolBuilderTextPlaneRelativeArrow = CuttingPlaneSymbolBuilder.TextPlaneRelativeArrow

NXOpen.Annotations.CuttingPlaneSymbolBuilderTextPlaneRelativeArrow is an alias for NXOpen.Annotations.CuttingPlaneSymbolBuilder.TextPlaneRelativeArrow 

CuttingPlaneSymbolBuilderViewNameFormatOption = CuttingPlaneSymbolBuilder.ViewNameFormatOption

NXOpen.Annotations.CuttingPlaneSymbolBuilderViewNameFormatOption is an alias for NXOpen.Annotations.CuttingPlaneSymbolBuilder.ViewNameFormatOption 

## Detailed Description

Represents a NXOpen::Annotations::CuttingPlaneSymbolBuilder 

This is a sub-builder class and cannot be directly instantiated 

Created in NX9.0.0 

## Member Function Documentation

## ◆ AlternateArrow()

NXOpen.Annotations.CuttingPlaneSymbolBuilder.AlternateArrow
(
self — )

The Cutting Plane Symbol Alternate Arrow. 

Created in NX9.0.0 

License requirements: None. 

## ◆ AlternateArrowRotation()

NXOpen.Annotations.CuttingPlaneSymbolBuilder.AlternateArrowRotation
(
self — )

The Cutting Plane Symbol Alternate Arrow Rotation. 

Created in NX2007.0.0 

License requirements: None. 

## ◆ ArrowDirection() [1/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.ArrowDirection
(
self — )

Getter for property: (NXOpen.Annotations.CuttingPlaneSymbolBuilder.ArrowDirectionOption) ArrowDirection Returns the Cutting Plane Symbol Arrow Direction relative to plane. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
CuttingPlaneSymbolBuilder.ArrowDirectionOption 

## ◆ ArrowDirection() [2/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.ArrowDirection
(
self,

arrowDirection )

Setter for property: (NXOpen.Annotations.CuttingPlaneSymbolBuilder.ArrowDirectionOption) ArrowDirection. 

Sets the Cutting Plane Symbol Arrow Direction relative to plane

Setter License requirements: geometric_tol ("GDT")

Created in NX11.0.0 

## ◆ ArrowLength() [1/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.ArrowLength
(
self — )

Getter for property: (float) ArrowLength Returns the Cutting Plane Symbol Arrow Length. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
float 

## ◆ ArrowLength() [2/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.ArrowLength
(
self,

arrowLength )

Setter for property: (float) ArrowLength. 

Sets the Cutting Plane Symbol Arrow Length

Setter License requirements: geometric_tol ("GDT")

Created in NX9.0.0 

## ◆ Color() [1/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.Color
(
self — )

Getter for property: (int) Color Returns the color of the Cutting Plane Symbol. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
int 

## ◆ Color() [2/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.Color
(
self,

cuttingPlaneSymbolColor )

Setter for property: (int) Color. 

Sets the color of the Cutting Plane Symbol

Setter License requirements: geometric_tol ("GDT")

Created in NX9.0.0 

## ◆ CuttingPlaneSymbolText() [1/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.CuttingPlaneSymbolText
(
self — )

Getter for property: (str) CuttingPlaneSymbolText Returns the Cutting Plane Symbol text. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
str 

## ◆ CuttingPlaneSymbolText() [2/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.CuttingPlaneSymbolText
(
self,

cuttingPlaneSymbolName )

Setter for property: (str) CuttingPlaneSymbolText. 

Sets the Cutting Plane Symbol text

Setter License requirements: geometric_tol ("GDT")

Created in NX9.0.0 

## ◆ DisplayCuttingPlaneSymbol() [1/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.DisplayCuttingPlaneSymbol
(
self — )

Getter for property: (bool) DisplayCuttingPlaneSymbol Returns the display cutting plane symbol. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ DisplayCuttingPlaneSymbol() [2/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.DisplayCuttingPlaneSymbol
(
self,

displayCuttingPlaneSymbol )

Setter for property: (bool) DisplayCuttingPlaneSymbol. 

Sets the display cutting plane symbol

Setter License requirements: geometric_tol ("GDT")

Created in NX9.0.0 

## ◆ Font()

NXOpen.Annotations.CuttingPlaneSymbolBuilder.Font
(
self — )

Getter for property: (NXOpen.LineFontBuilder) Font Returns the font. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
NXOpen.LineFontBuilder 

## ◆ MarginPercentage() [1/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.MarginPercentage
(
self — )

Getter for property: (float) MarginPercentage Returns the margin. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
float 

## ◆ MarginPercentage() [2/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.MarginPercentage
(
self,

marginPercentage )

Setter for property: (float) MarginPercentage. 

Sets the margin

Setter License requirements: geometric_tol ("GDT")

Created in NX2007.0.0 

## ◆ ShadedPlane() [1/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.ShadedPlane
(
self — )

Getter for property: (bool) ShadedPlane Returns the shaded plane. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ ShadedPlane() [2/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.ShadedPlane
(
self,

shadedPlane )

Setter for property: (bool) ShadedPlane. 

Sets the shaded plane

Setter License requirements: geometric_tol ("GDT")

Created in NX9.0.0 

## ◆ SizeBasedOnSectionCut() [1/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.SizeBasedOnSectionCut
(
self — )

Getter for property: (bool) SizeBasedOnSectionCut Returns the size based on section cut. 

Getter License requirements: None.

Created in NX2007.0.0 

Returns
bool 

## ◆ SizeBasedOnSectionCut() [2/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.SizeBasedOnSectionCut
(
self,

sizeBasedOnSectionCut )

Setter for property: (bool) SizeBasedOnSectionCut. 

Sets the size based on section cut

Setter License requirements: geometric_tol ("GDT")

Created in NX2007.0.0 

## ◆ Style()

NXOpen.Annotations.CuttingPlaneSymbolBuilder.Style
(
self — )

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the Cutting Plane Symbol Style. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
StyleBuilder 

## ◆ TextPlaneRelativeToArrow() [1/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.TextPlaneRelativeToArrow
(
self — )

Getter for property: (NXOpen.Annotations.CuttingPlaneSymbolBuilder.TextPlaneRelativeArrow) TextPlaneRelativeToArrow Returns the text plane relative to arrow. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
CuttingPlaneSymbolBuilder.TextPlaneRelativeArrow 

## ◆ TextPlaneRelativeToArrow() [2/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.TextPlaneRelativeToArrow
(
self,

textPlaneRelativeToArrow )

Setter for property: (NXOpen.Annotations.CuttingPlaneSymbolBuilder.TextPlaneRelativeArrow) TextPlaneRelativeToArrow. 

Sets the text plane relative to arrow

Setter License requirements: geometric_tol ("GDT")

Created in NX9.0.0 

## ◆ UseTwoArrows() [1/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.UseTwoArrows
(
self — )

Getter for property: (bool) UseTwoArrows Returns the use two arrows. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
bool 

## ◆ UseTwoArrows() [2/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.UseTwoArrows
(
self,

useTwoArrows )

Setter for property: (bool) UseTwoArrows. 

Sets the use two arrows

Setter License requirements: geometric_tol ("GDT")

Created in NX9.0.0 

## ◆ ViewNameFormat() [1/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.ViewNameFormat
(
self — )

Getter for property: (NXOpen.Annotations.CuttingPlaneSymbolBuilder.ViewNameFormatOption) ViewNameFormat Returns the name view from symbol. 

Getter License requirements: None.

Created in NX9.0.0 

Returns
CuttingPlaneSymbolBuilder.ViewNameFormatOption 

## ◆ ViewNameFormat() [2/2]

NXOpen.Annotations.CuttingPlaneSymbolBuilder.ViewNameFormat
(
self,

viewNameFormat )

Setter for property: (NXOpen.Annotations.CuttingPlaneSymbolBuilder.ViewNameFormatOption) ViewNameFormat. 

Sets the name view from symbol

Setter License requirements: geometric_tol ("GDT")

Created in NX9.0.0 

## Member Data Documentation

## ◆ CuttingPlaneSymbolBuilderArrowDirectionOption

NXOpen.Annotations.CuttingPlaneSymbolBuilder.CuttingPlaneSymbolBuilderArrowDirectionOption = CuttingPlaneSymbolBuilder.ArrowDirectionOption

NXOpen.Annotations.CuttingPlaneSymbolBuilderArrowDirectionOption is an alias for NXOpen.Annotations.CuttingPlaneSymbolBuilder.ArrowDirectionOption 

## ◆ CuttingPlaneSymbolBuilderTextPlaneRelativeArrow

NXOpen.Annotations.CuttingPlaneSymbolBuilder.CuttingPlaneSymbolBuilderTextPlaneRelativeArrow = CuttingPlaneSymbolBuilder.TextPlaneRelativeArrow

NXOpen.Annotations.CuttingPlaneSymbolBuilderTextPlaneRelativeArrow is an alias for NXOpen.Annotations.CuttingPlaneSymbolBuilder.TextPlaneRelativeArrow 

## ◆ CuttingPlaneSymbolBuilderViewNameFormatOption

NXOpen.Annotations.CuttingPlaneSymbolBuilder.CuttingPlaneSymbolBuilderViewNameFormatOption = CuttingPlaneSymbolBuilder.ViewNameFormatOption

NXOpen.Annotations.CuttingPlaneSymbolBuilderViewNameFormatOption is an alias for NXOpen.Annotations.CuttingPlaneSymbolBuilder.ViewNameFormatOption 

Copyright 2025 Siemens
