# NXOpen.Annotations.OrdinateDimension Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00182.html>

## Classes

class — DoglegPreferences

Specifies the ordinate dogleg preferences NXOpen.Annotations.OrdinateDimensionDoglegPreferences_Struct is an alias for NXOpen.Annotations.OrdinateDimension.DoglegPreferences. More...

Copyright 2025 Siemens
