# NXOpen.Annotations.PartIdentificationBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13137.html>

Represents a NXOpen::Annotations::PartIdentification builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePartIdentificationBuilder 

More...

Inheritance diagram for NXOpen.Annotations.PartIdentificationBuilder:

## Public Member Functions

DescriptiveModifier (self)

Getter for property: (str) DescriptiveModifier Returns the descriptive modifier. 

DescriptiveModifier (self, descriptiveModifier)

Setter for property: (str) DescriptiveModifier. 

ItemName (self)

Getter for property: (str) ItemName Returns the item name. 

ItemName (self, itemName)

Setter for property: (str) ItemName. 

ItemNameModifier (self)

Getter for property: (str) ItemNameModifier Returns the item name modifier. 

ItemNameModifier (self, itemNameModifier)

Setter for property: (str) ItemNameModifier. 

PartIdentifier (self)

Getter for property: (str) PartIdentifier Returns the part identifier. 

PartIdentifier (self, partIdentifier)

Setter for property: (str) PartIdentifier. 

Revision (self)

Getter for property: (str) Revision Returns the revision. 

Revision (self, revision)

Setter for property: (str) Revision. 

Title (self)

Getter for property: (str) Title Returns the str title. 

Title (self, title)

Setter for property: (str) Title. 

Public Member Functions inherited from NXOpen.Annotations.PmiAttributeBuilder

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the NXOpen::Annotations::AssociatedObjectsBuilder for the annotation. 

Attribute (self)

Getter for property: (NXOpen.Annotations.Pmi) Attribute Returns the NXOpen::Annotations::Pmi for this annotation. 

Attribute (self, attribute)

Setter for property: (NXOpen.Annotations.Pmi) Attribute. 

BusinessModifier (self)

Getter for property: (NXOpen.NXObject) BusinessModifier Returns the business modifier. 

BusinessModifier (self, businessModifier)

Setter for property: (NXOpen.NXObject) BusinessModifier. 

GetAttributeValues (self)

Returns the attribute values. 

KnowledgeFusionClassName (self)

Getter for property: (str) KnowledgeFusionClassName Returns the knowledge fusion class name file, the default class is UG provided pmi KF class. 

KnowledgeFusionClassName (self, knowledgeFusionClassName)

Setter for property: (str) KnowledgeFusionClassName. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the NXOpen::Annotations::OriginBuilder for the annotation. 

SetAttributeValues (self, attributeValues)

Sets the attribute values. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the NXOpen::Annotations::StyleBuilder for the annotation. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::PartIdentification builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePartIdentificationBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ DescriptiveModifier() [1/2]

NXOpen.Annotations.PartIdentificationBuilder.DescriptiveModifier
(
self — )

Getter for property: (str) DescriptiveModifier Returns the descriptive modifier. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ DescriptiveModifier() [2/2]

NXOpen.Annotations.PartIdentificationBuilder.DescriptiveModifier
(
self,

descriptiveModifier )

Setter for property: (str) DescriptiveModifier. 

Sets the descriptive modifier

Setter License requirements: None.

Created in NX6.0.0 

## ◆ ItemName() [1/2]

NXOpen.Annotations.PartIdentificationBuilder.ItemName
(
self — )

Getter for property: (str) ItemName Returns the item name. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ ItemName() [2/2]

NXOpen.Annotations.PartIdentificationBuilder.ItemName
(
self,

itemName )

Setter for property: (str) ItemName. 

Sets the item name

Setter License requirements: None.

Created in NX6.0.0 

## ◆ ItemNameModifier() [1/2]

NXOpen.Annotations.PartIdentificationBuilder.ItemNameModifier
(
self — )

Getter for property: (str) ItemNameModifier Returns the item name modifier. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ ItemNameModifier() [2/2]

NXOpen.Annotations.PartIdentificationBuilder.ItemNameModifier
(
self,

itemNameModifier )

Setter for property: (str) ItemNameModifier. 

Sets the item name modifier

Setter License requirements: None.

Created in NX6.0.0 

## ◆ PartIdentifier() [1/2]

NXOpen.Annotations.PartIdentificationBuilder.PartIdentifier
(
self — )

Getter for property: (str) PartIdentifier Returns the part identifier. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ PartIdentifier() [2/2]

NXOpen.Annotations.PartIdentificationBuilder.PartIdentifier
(
self,

partIdentifier )

Setter for property: (str) PartIdentifier. 

Sets the part identifier

Setter License requirements: None.

Created in NX6.0.0 

## ◆ Revision() [1/2]

NXOpen.Annotations.PartIdentificationBuilder.Revision
(
self — )

Getter for property: (str) Revision Returns the revision. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Revision() [2/2]

NXOpen.Annotations.PartIdentificationBuilder.Revision
(
self,

revision )

Setter for property: (str) Revision. 

Sets the revision

Setter License requirements: None.

Created in NX6.0.0 

## ◆ Title() [1/2]

NXOpen.Annotations.PartIdentificationBuilder.Title
(
self — )

Getter for property: (str) Title Returns the str title. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Title() [2/2]

NXOpen.Annotations.PartIdentificationBuilder.Title
(
self,

title )

Setter for property: (str) Title. 

Sets the str title

Setter License requirements: None.

Created in NX6.0.0 

Copyright 2025 Siemens
