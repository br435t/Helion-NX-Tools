# NXOpen.Annotations Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00125.html>

Classes, Enums and Structs under NXOpen.Annotations namespace. 
More...

## Namespaces

namespace — Annotation

namespace — ArcComponent

namespace — AssociativeText

namespace — AutomaticCenterlineBuilder

namespace — BaseCustomSymbolBuilder

namespace — BaseEdgeConditionSymbolBuilder

namespace — BaseFrameBarBuilder

namespace — BaseHoleCalloutDimensionBuilder

namespace — BaseOrdinateDimensionBuilder

namespace — BaseSurfaceFinishBuilder

namespace — BaseSurfaceFinishSymbolBuilder

namespace — BendTableSettingsBuilder

namespace — BillOfMaterialBuilder

namespace — BoundaryBuilder

namespace — CalloutGroupBuilder

namespace — Centerline2dBuilder

namespace — Centerline3dBuilder

namespace — CenterlineSettingsBuilder

namespace — CircleCenterlineBuilder

namespace — CuttingPlaneSymbolBuilder

namespace — DatumReferenceBuilder

namespace — DatumTargetBuilder

namespace — Dimension

namespace — DimensionMeasurementBuilder

namespace — DimensionSetBuilder

namespace — DraftingImage

namespace — DraftingNoteBuilder

namespace — DraftingSurfaceFinishBuilder

namespace — DrawingFormatTitleBuilder

namespace — DrivingValueBuilder

namespace — EditSymbolDisplayBuilder

namespace — EditText

namespace — FeatureControlFrameBuilder

namespace — FeatureControlFrameDataBuilder

namespace — FeatureControlFrameIndicatorBuilder

namespace — ForeshorteningSymbolSettingsBuilder

namespace — FrameBarElementStyleBuilder

namespace — HatchBuilder

namespace — HatchFillSettingsBuilder

namespace — HoleCalloutSettingsBuilder

namespace — HoleTableSettingsContentBuilder

namespace — HoleTableSettingsFormatBuilder

namespace — HoleTableSettingsHoleFiltersBuilder

namespace — HoleTableSettingsLabelBuilder

namespace — IdSymbolBuilder

namespace — ImportAutocadBlockBuilder

namespace — ImportSymbolBuilder

namespace — IntersectionSymbolBuilder

namespace — LeaderData

namespace — LineComponent

namespace — LineWeld

namespace — LineWeldBuilder

namespace — LineWeldDataBuilder

namespace — MasterSymbolBuilder

namespace — MasterSymbolListItemBuilder

namespace — OffsetCenterPointBuilder

namespace — OrdinateDimension

namespace — OriginAlignmentBuilder

namespace — OriginBuilder

namespace — PartsListBuilder

namespace — PartsListContentsBuilder

namespace — PinListBuilder

namespace — PlaneBuilder

namespace — Pmi

namespace — PmiContextGeneralBuilder

namespace — PmiDatumTargetData

namespace — PmiDimensionData

namespace — PmiFcfData

namespace — PmiFilter

namespace — PmiFilterByType

namespace — PmiGeneralSetupDisplayBuilder

namespace — PmiGeneralSetupEffectivityBuilder

namespace — PmiLineWeldData

namespace — PmiManager

namespace — PmiPreferences

namespace — PmiRegionData

namespace — PmiSectionViewCuttingPlaneSymbolBuilder

namespace — PmiSectionViewViewBuilder

namespace — PmiSupplementalGeometryProductGridBuilder

namespace — ProductGridStyleBuilder

namespace — RegionBuilder

namespace — SearchCriteriaCalloutBuilder

namespace — SearchCriteriaDatumTargetBuilder

namespace — SearchCriteriaDimensionBuilder

namespace — SearchCriteriaFeatureControlFrameBuilder

namespace — SearchCriteriaSurfaceFinishBuilder

namespace — SearchModelViewBuilder

namespace — SheetMetalPMIBuilder

namespace — SheetMetalPMISettingsBuilder

namespace — ShipDimensionBuilder

namespace — ShipDraftingFramebarGeneralBuilder

namespace — SuppressPMIBuilder

namespace — SurfaceFinishBuilder

namespace — SymbolStyleBuilder

namespace — SymmetricalCenterlineBuilder

namespace — Table

namespace — TableCellStyleBuilder

namespace — TableColumnBuilder

namespace — TableCommonSortingBuilder

namespace — TableSectionStyleBuilder

namespace — TabularNoteStyleBuilder

namespace — TargetPointBuilder

namespace — TextComponent

namespace — TextWithSymbolsBuilder

namespace — UserSymbolPreferences

## Classes

class — AddTicBuilder

Represents a NXOpen::Annotations::AddTicBuilder . More...

class — AECDesignBaseLine

Represents an AEC base line 

There is no KF creator for this class. More...

class — AlignmentPosition

Specifies the site location in the text box which can be used to locate a drafting object 

Enumerator — Comment

TopLeft

TopCenter

TopRight

MidLeft

MidCenter

MidRight

BottomLeft

BottomCeneter — Use NXOpen::Annotations::AlignmentPositionBottomCenter instead

BottomCenter

BottomRight

More...

class — AngularDimension

Represents an angular dimension 

Abstract class 

More...

class — AngularDimensionBuilder

Represents a NXOpen::Annotations::AngularDimension builder 

This is an abstract class and cannot be instantiated. More...

class — AngularDimensionFormat

Specifies the angular dimension format 

Enumerator — Comment

FractionalDegrees — Specifies fractional degrees format

WholeDegrees — Specifies whole degrees format

DegreesMinutes — Specifies degrees minutes format

DegreesMinutesSeconds — Specifies degrees minutes seconds format

Last — Last enum value.

More...

class — AngularSuppressZeros

Specifies the suppress zeros option for the angular dimension 

Enumerator — Comment

NotSet — Specifies no zeros suppressed

Leading — Specifies leading zeros suppressed

Any — Specifies any zeros suppressed

Trailing — Specifies trailing zeros suppressed

Last — Last enum value.

More...

class — AngularTolerance

Represents angular tolerance. More...

class — Annotation

Represents an annotation / PMI (Product and Manufacturing Information) display instance object. More...

class — AnnotationManager

Represents an object that manages annotation and PMI (Product and Manufacturing Information) display instance objects. More...

class — AnnotationPlacement

Represents an object that journals the adding of a leader and setting of the origin for dialogs that use a builder. More...

class — AppendedText

Represents Appended text. More...

class — AppendedTextBuilder

This class is used to set/access the appended text of a dimension 

This is a sub-builder class and cannot be directly instantiated 

More...

class — AppendedTextEditorBuilder

Represents a NXOpen::Annotations::AppendedTextEditorBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateAppendedTextEditorBuilder 

More...

class — ArbitraryAreaSeedBuilder

Represents a NXOpen::Annotations::ArbitraryAreaSeedBuilder 

To create a new instance of this class, use NXOpen::Annotations::PmiManager::CreateArbitraryAreaSeedBuilder 

More...

class — ArbitraryAreaSeedBuilderList

Represents a list of objects. More...

class — ArbitraryTarget

Represents an arbitrary datum target. More...

class — ArbitraryTargetData

Represents arbitrary datum target data. More...

class — ArcComponent

Represents a single arc in an annotation and can be queried for information about that arc. More...

class — ArcLengthDimension

Represents an arc length dimension 

To create or edit an instance of this class, use NXOpen::Annotations::CurveLengthDimensionBuilder 

More...

class — AreaFillMaterial

Specifies the area fill material type 

Enumerator — Comment

CorkFelt — Cork felt

SoundInsulation — Sound insulation

Concrete — Concrete

Earth — Earth

Rock — Rock

Sand — Sand

Liquids — Liquids

WoodAcrossGrain — Wood across grain

WoodAlongGrain — Wood along grain

SolidFill — Solid fill

More...

class — AreaTarget

Represents an area target 

To create or edit an instance of this class, use NXOpen::Annotations::PmiDatumTargetBuilder 

More...

class — ArrowComponent

Represents a single arrow in an annotation and can be queried for information about that arrow. More...

class — ArrowDisplay

Specifies the arrow display option 

Enumerator — Comment

Two — Displays both the arrows

First — Displays arrow to the first object selected to create the dimension

Second — Displays arrow to the second object selected to create the dimension

NotSet — Doesn't display arrows

Last — Last enum value.

More...

class — ArrowheadType

Specifies the arrowhead type 

Enumerator — Comment

FilledDatumArrow

FilledDot

FilledArrow

ClosedArrow

OpenArrow

CrossArrow

DotArrow

OriginSymbolArrow

NoArrow

UnfilledDatumArrow

ClosedSolidArrow

ClosedDoubleArrow

ClosedDoubleSolidArrow

OpenDoubleArrow

IntegralArrow

BoxArrow

FilledBox

FilledDoubleArrow

TopOpenArrow

BottomOpenArrow

TopFilledArrow

BottomFilledArrow

More...

class — AssociateDimensionBuilder

Represents a NXOpen::Annotations::AssociateDimensionBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateAssociateDimensionBuilder 

More...

class — AssociatedObject

Represents the objects to which the PMI applies. More...

class — AssociatedObjectsBuilder

The associated objects builder is used to store objects which annotations are associated to. More...

class — AssociatedObjectsSetsBuilder

The associated objects sets builder is used to store lists of objects which annotations are associated to. More...

class — AssociativeOriginType

Specifies the type of associativity for an annotation's origin 

Enumerator — Comment

Drag

RelativeToView

RelativeToGeometry

VerticallyAligned

HorizontallyAligned

AlignedWithArrows

AtAPoint

OffsetFromText

AttachedToStack

More...

class — AssociativeText

Associative text class creates text associated to object and part attributes as well as object properties such as a drawing sheet name. More...

class — Associativity

Represents an associativity object. More...

class — AssociativityBuilder

Represents a NXOpen::Annotations::AssociativityBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateAssociativityBuilder 

More...

class — AssociativityLineOption

Specifies the associativity line option 

Enumerator — Comment

NotSet — No line

ExistingLine — Existing line

PointVector — Vector from two points

ExtensionLine — Extension line

Centerline — Centerline - 

Linear 

Bolt circle 

Circular 

Angle — At angle

HorizontalRight — Horizontal right

VerticalUp — Vertical up

HorizontalLeft — Horizontal left

VerticalDown — Vertical down

BaseLine — Base line

Last — Last enum value.

More...

class — AssociativityPointOption

Specifies the associativity point option 

Enumerator — Comment

NotSet — No point

Control — Control point

ArcCenter — Arc center point

Tangent — Tangent point

Intersection — Intersection point

ScreenPosition — Screen position

OnCurve — Point on curve

Pole — Spline pole

Anchor — Conic Anchor

Defining — Spline defining point

Last — Last enum value.

More...

class — AutomaticCenterlineBuilder

Builder for creating Automatic Centerlines 

To create a new instance of this class, use NXOpen::Annotations::CenterlineCollection::CreateAutomaticCenterlineBuilder 

Default values. More...

class — BalloonNote

Represents a Balloon Note 

To create or edit an instance of this class, use NXOpen::Annotations::BalloonNoteBuilder 

More...

class — BalloonNoteBuilder

Represents a NXOpen::Annotations::BalloonNote builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateBalloonNoteBuilder 

More...

class — BalloonsBuilder

Represents a Annotations::BalloonsBuilder . More...

class — BalloonTypes

Specifies different types of balloon 

Enumerator — Comment

Circle — Circle

DividedCircle — Divided circle

TriangleDown — Triangle with point down

TriangleUp — Triangle with point up

Square — Square

DividedSquare — Divided square

Hexagon — Hexagon

DividedHexagon — Divided hexagon

QuadrantCircle — Quadrant circle

RoundedBox — Rounded box

Underline — Underline

Nosymbol — No Symbol

More...

class — BaseAngularDimension

Represents an angular dimension 

Abstract class 

More...

class — BaseAngularDimensionBuilder

Represents a NXOpen::Annotations::AngularDimension builder 

This is an abstract class and cannot be instantiated. More...

class — BaseApplicationStyleBuilder

Represents a NXOpen::Annotations::BaseApplicationStyleBuilder . More...

class — BaseArcLengthDimension

Represents a arc length dimension 

Abstract class 

More...

class — BaseArrow

Represents a BaseArrow 

There is no KF creator for this class. More...

class — BaseBoltCircleCenterline

Represents a base bolt centerline class 

This is an abstract class. More...

class — BaseBoltCircleCenterlineBuilder

Represents a Base Bolt Centerline Builder for Pmi and Drafting bolt circle centerline 

This is an abstract class and cannot be instantiated. More...

class — BaseCenterline3d

Represents a Base 3D centerline 

This is an abstract class. More...

class — BaseCenterline3dBuilder

Represents a Base Centerline3d Builder for pmi and drafting 3D centerlines 

This is an abstract class, and cannot be instantiated. More...

class — BaseCenterMark

Represents a base center mark class 

This is an abstract class. More...

class — BaseCenterMarkBuilder

Represents a Base CenterMark Builder for Pmi and Drafting centermark 

This is an abstract class, and cannot be instantiated. More...

class — BaseChamferDimension

Represents a chamfer dimension 

Abstract class 

More...

class — BaseChamferDimensionBuilder

Represents a NXOpen::Annotations::BaseChamferDimension builder 

This is an abstract class and cannot be instantiated. More...

class — BaseConcentricCircleDimension

Represents a concentric circle dimension 

Abstract class 

More...

class — BaseCurveLengthDimensionBuilder

Represents a NXOpen::Annotations::BaseArcLengthDimension builder 

This is an abstract class and cannot be instantiated. More...

class — BaseCustomSymbol

Represents a base custom symbol 

This is an abstract class and cannot be directly instantiated 

More...

class — BaseCustomSymbolBuilder

Represents a base Builder for Drafting and PMI Custom Symbol 

This is an abstract class, and cannot be instantiated. More...

class — BaseCylindricalDimension

Represents a cylindrical dimension 

Abstract class 

More...

class — BaseDatum

Represents a datum 

This is an abstract class, and cannot be created. More...

class — BaseDatumTarget

Represents a datum target 

This is an abstract class, and cannot be created. More...

class — BaseDiameterDimension

Represents a diameter dimension 

Abstract class 

More...

class — BaseEdgeConditionSymbol

Represents a base edge condition symbol 

This is an abstract class, and cannot be instantiated. More...

class — BaseEdgeConditionSymbolBuilder

Represents a base edge condition symbol 

This is an abstract class, and cannot be instantiated. More...

class — BaseFcf

Represents a datum 

This is an abstract class, and cannot be created. More...

class — BaseFoldedRadiusDimension

Represents a folded radius dimension 

Abstract class 

More...

class — BaseFrameBar

Represents a base frame bar class 

This is an abstract class and cannot be directly instantiated 

More...

class — BaseFrameBarBuilder

Represents a NXOpen::Annotations::BaseFrameBarBuilder . More...

class — BaseHoleCalloutDimensionBuilder

Represents a NXOpen::Annotations::BaseHoleCalloutDimensionBuilder builder 

This is an abstract class and cannot be instantiated. More...

class — BaseHoleDimension

Represents a hole dimension 

Abstract class 

More...

class — BaseHorizontalDimension

Represents a horizontal dimension 

Abstract class 

More...

class — BaseIdSymbol

Represents an BASE ID symbol 

This is an abstract class and cannot be directly instantiated 

More...

class — BaseIdSymbolBuilder

Represents a base id symbol 

This is an abstract class, and cannot be instantiated. More...

class — BaseLinearDimensionBuilder

Represents a NXOpen::Annotations::Dimension builder 

This is an abstract class and cannot be instantiated. More...

class — BaselineDimension

Represents a baseline dimension. More...

class — BaseNote

Represents a Note 

This is an abstract class and cannot be directly instantiated 

More...

class — BaseOrdinateDimensionBuilder

Represents a NXOpen::Annotations::OrdinateDimension builder 

This is an abstract class and cannot be instantiated. More...

class — BaseParallelDimension

Represents a parallel dimension 

Abstract class 

More...

class — BasePerpendicularDimension

Represents a perpendicular dimension 

Abstract class 

More...

class — BaseProductGrid

Represents the base product grid class 

This is an abstract class and cannot be directly instantiated 

More...

class — BaseProductGridBuilder

Represents a NXOpen::Annotations::BaseProductGridBuilder . More...

class — BaseRadialDimensionBuilder

Represents a NXOpen::Annotations::Dimension builder 

This is an abstract class and cannot be instantiated. More...

class — BaseRadiusDimension

Represents a radius dimension 

Abstract class 

More...

class — BaseRapidDimensionBuilder

Represents a NXOpen::Annotations::Dimension builder 

This is an abstract class and cannot be instantiated. More...

class — BaseSurfaceFinish

Represents a Base Surface Finish 

This is an abstract class, and cannot be instantiated. More...

class — BaseSurfaceFinishBuilder

Represents a NXOpen::Annotations::BaseSurfaceFinish builder 

This is an abstract class, and cannot be instantiated. More...

class — BaseSurfaceFinishSymbol

Represents a base surface finish symbol 

This is an abstract class, and cannot be instantiated. More...

class — BaseSurfaceFinishSymbolBuilder

Represents a base surface finish symbol 

This is an abstract class, and cannot be instantiated. More...

class — BaseSymbolBuilder

Represents a Base Symbol Builder 

This is an abstract class, and cannot be instantiated. More...

class — BaseThicknessDimensionBuilder

Represents a NXOpen::Annotations::BaseThicknessDimensionBuilder builder 

This is an abstract class and cannot be instantiated. More...

class — BaseTitleBlockBuilder

Represents a NXOpen::Annotations::BaseTitleBlockBuilder builder. More...

class — BaseVerticalDimension

Represents a horizontal dimension 

Abstract class 

More...

class — BendTable

This class represents a bend table. More...

class — BendTableBuilder

Represents a NXOpen::Annotations::BendTableBuilder . More...

class — BendTableCollection

Represents a collection of NXOpen::Annotations::BendTable objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — BendTableSettingsBuilder

Represents a NXOpen::Annotations::BendTableSettingsBuilder. More...

class — BillOfMaterialBuilder

Builder for Bill of Material functionality used in Routing. More...

class — BoltCircleCenterline

Represents a BoltCircleCenterline centerline 

To create or edit an instance of this class, use NXOpen::Annotations::BoltCircleCenterlineBuilder 

More...

class — BoltCircleCenterlineBuilder

Represents a BoltCircleCenterlineBuilder Builder 

To create a new instance of this class, use NXOpen::Annotations::CenterlineCollection::CreateBoltCircleCenterlineBuilder 

Default values. More...

class — BoundaryBuilder

This builder contains the boundaries that define a crosshatch pattern. More...

class — BreakSettingsBuilder

Represents a NXOpen::Annotations::BreakSettingsBuilder builder. More...

class — BusinessModifier

Represents a business modifier object. More...

class — BusinessModifierCollection

Represents a collection of NXOpen::Annotations::BusinessModifier objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — CalloutGroupBuilder

Represents a NXOpen::Annotations::CalloutGroupBuilder 

To create a new instance of this class, use NXOpen::Annotations::IdSymbolCollection::CreateCalloutGroupBuilder 

More...

class — Centerline

Represents a drafting centerline 

This is an abstract class. More...

class — Centerline2d

Represents a 2D centerline 

To create or edit an instance of this class, use NXOpen::Annotations::Centerline2dBuilder 

More...

class — Centerline2dBuilder

Builder for creating 2D Centerline. More...

class — Centerline2dSettingsBuilder

Represents a Builder for Centerline2dSettings. More...

class — Centerline3d

Represents a 3D centerline 

To create or edit an instance of this class, use NXOpen::Annotations::Centerline3dBuilder 

More...

class — Centerline3dBuilder

Builder for creating 3D Centerline. More...

class — Centerline3dSettingsBuilder

Represents a Builder for Centerline3dSettings. More...

class — CenterlineBuilder

Represents a Base Centerline Builder for all types of centerlines 

This is an abstract class, and cannot be instantiated. More...

class — CenterlineCollection

Represents a collection of NXOpen::Annotations::Centerline objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — CenterlineSettingsBuilder

Represents a Builder for Centerline Settings. More...

class — CenterMark

Represents a center mark class 

To create or edit an instance of this class, use NXOpen::Annotations::CenterMarkBuilder 

More...

class — CenterMarkBuilder

Builder for creating Center Mark. More...

class — CenterMarkSettingsBuilder

Represents a Builder for CenterMark Settings. More...

class — ChainDimension

Represents a chain dimension. More...

class — ChamferDimension

Represents a chamfer dimension 

To create or edit an instance of this class, use NXOpen::Annotations::ChamferDimensionBuilder 

More...

class — ChamferDimensionBuilder

Represents a NXOpen::Annotations::ChamferDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateChamferDimensionBuilder 

More...

class — ChamferDimensionPreferences

Represents chamfer dimension preferences. More...

class — ChamferForm

Specifies the chamfer dimension form 

Enumerator — Comment

Symbol — C5

Size — 5 x 5

SizeAngle — 5 x 45

AngleSize — 45 x 5

Last — Last enum value.

More...

class — ChamferLeaderPlacement

Specifies the chamfer dimension leader placement relative to the chamfer 

Enumerator — Comment

Perpendicular — Specifies leader perpendicular to the chamfer

Parallel — Specifies leader parallel to the chamfer

Linear — Specifies leader inline with the chamfer

Last — Last enum value.

More...

class — ChamferOrientationType

Specifies the linear chamfer dimension orientation 

Enumerator — Comment

Horizontal — default (same as the adjacent edge)

Vertical — perpendicular with default

Parallel — parallel to the chamfer line itself

More...

class — ChamferSeparatorType

Specifies the chamfer dimension separator type 

Enumerator — Comment

UppercaseX — Specifies X

LowercaseX — Specifies x

More...

class — ChamferStubType

Specifies the chamfer dimension stub type 

Enumerator — Comment

NoneTextAboveLeader — Specifies no stub and text above leader

NoneTextAfterLeader — Specifies no stub and text after leader

TextAbove — Specifies text above stub

TextAfter — Specifies text after stub

Last — Last enum value.

More...

class — ChamferSymbolPlacement

Specifies the chamfer dimension symbol placement 

Enumerator — Comment

NotSet — Specifies no symbol

Prefix — CHAM 5 x 5

Suffix — 5 x 5 CHAM

Last — Last enum value.

More...

class — CharacterSpaceFactor

Specifies the standard font character space factor for each of the text types. More...

class — CircleCenterline

Represents a CircleCenterline centerline 

This is an abstract class. More...

class — CircleCenterlineBuilder

Represents a CircleCenterline Builder 

This is an abstract class. More...

class — CircleCenterlineSettingsBuilder

Represents a Builder for Circle Centerline Settings. More...

class — CircularCenterline

Represents a CircularCenterline centerline 

To create or edit an instance of this class, use NXOpen::Annotations::CircularCenterlineBuilder 

More...

class — CircularCenterlineBuilder

Represents a CircularCenterlineBuilder Builder 

To create a new instance of this class, use NXOpen::Annotations::CenterlineCollection::CreateCircularCenterlineBuilder 

Default values. More...

class — CircularTarget

Represents a circular datum target 

To create or edit an instance of this class, use NXOpen::Annotations::PmiDatumTargetBuilder 

More...

class — CircularTargetData

Represents circular datum target data. More...

class — CommonWorkflowBuilder

Represents a NXOpen::Annotations::CommonWorkflowBuilder. More...

class — CompanyProprietaryInformation

Represents a Company Proprietary Information 

To create or edit an instance of this class, use NXOpen::Annotations::CompanyProprietaryInformationBuilder 

More...

class — CompanyProprietaryInformationBuilder

Represents a NXOpen::Annotations::CompanyProprietaryInformation builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateCompanyProprietaryInformationBuilder 

More...

class — ComponentData

A ComponentData object can be used to query the components of an annotation. More...

class — CompositesSettingsBuilder

Edits the settings for Composites PMI label object 

This is a sub-builder class and cannot be directly instantiated 

More...

class — CompoundDatumReferenceBuilder

Represents a NXOpen::Annotations::CompoundDatumReferenceBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateCompoundDatumReferenceBuilder 

More...

class — ConcentricCircleDimension

Represents a concentric circle dimension 

To create or edit an instance of this class, use NXOpen::Annotations::ThicknessDimensionBuilder 

More...

class — Constants

Constants for annotations 

Enumerator — Comment

MaxLeaders — The maximum number of leaders that an annotation can have

MaxLeaderIntermediatePoints — The maximum number of intermediate points that a leader can have

More...

class — ConvertPmiBuilder

Represents a NXOpen::Annotations::ConvertPmiBuilder builder. More...

class — CoordinateNote

Represents a Coordinate Note 

To create or edit an instance of this class, use NXOpen::Annotations::CoordinateNoteBuilder 

More...

class — CoordinateNoteBuilder

Represents a NXOpen::Annotations::CoordinateNote builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateCoordinateNoteBuilder 

Default values. More...

class — CurveLengthDimensionBuilder

Represents a NXOpen::Annotations::ArcLengthDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateCurveLengthDimensionBuilder 

More...

class — CustomerValueBusinessModifier

Represents business modifier that applies customer values such as CTQ (Critical To Quality), KC (Key Characteristic) to a PMI. More...

class — CustomerValueBusinessModifierBuilder

Represents a NXOpen::Annotations::CustomerValueBusinessModifier builder 

To create a new instance of this class, use NXOpen::Annotations::BusinessModifierCollection::CreateCustomerValueBusinessModifierBuilder 

More...

class — CustomSymbol

Represents a custom symbol 

To create or edit an instance of this class, use NXOpen::Annotations::DraftingCustomSymbolBuilder 

More...

class — CustomSymbolCollection

Represents a collection of NXOpen::Annotations::BaseCustomSymbol objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — CustomSymbolData

Represents custom symbol data. More...

class — CustomSymbolTextData

Represents custom symbol text data. More...

class — CutSheetBuilder

Builder for Formboard cut sheet functionality used in formboard. More...

class — CuttingPlaneSymbol

Represents a Cutting Plane Symbol 

Created with LightweightSection 

More...

class — CuttingPlaneSymbolBuilder

Represents a NXOpen::Annotations::CuttingPlaneSymbolBuilder 

This is a sub-builder class and cannot be directly instantiated 

More...

class — CylindricalDimension

Represents a cylindrical dimension 

To create or edit an instance of this class, use NXOpen::Annotations::LinearDimensionBuilder 

More...

class — Datum

Represents a datum 

To create or edit an instance of this class, use NXOpen::Annotations::PmiDatumFeatureSymbolBuilder 

More...

class — DatumData

Represents datum data. More...

class — DatumFeatureSymbolBuilder

Represents a Base Datum Feature Symbol Builder for all types of datum feature symbols 

This is an abstract class, and cannot be instantiated. More...

class — DatumReference

Represents a datum reference. More...

class — DatumReferenceBuilder

Represents a NXOpen::Annotations::DatumReferenceBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateEmptyDatumReferenceBuilder 

More...

class — DatumReferenceBuilderList

Represents a list of objects. More...

class — DatumTarget

Represents a datum target 

To create or edit an instance of this class, use NXOpen::Annotations::PmiDatumTargetBuilder 

More...

class — DatumTargetBuilder

Represents a Datum target Builder 

This is an abstract class, and cannot be instantiated. More...

class — DatumTargetCollection

Represents a collection of NXOpen::Annotations::DatumTarget objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — DatumTargetData

Represents datum target data. More...

class — DecimalPointCharacter

Specifies the decimal point character 

Enumerator — Comment

Period — Specifies period decimal point character

Comma — Specifies comma decimal point character

Last — Last enum value.

More...

class — DecimalPointDelimiter

Specifies the decimal point character 

Enumerator — Comment

Period — Specifies period decimal point character

Comma — Specifies comma decimal point character

Last — Last enum value.

More...

class — DefineTitleBlockBuilder

Represents a NXOpen::Annotations::DefineTitleBlockBuilder . More...

class — DiameterDimension

Represents a diameter dimension 

To create or edit an instance of this class, use NXOpen::Annotations::RadialDimensionBuilder 

More...

class — DiameterRadiusLeaderStub

Specifies the leader stub relative to diameter/radius dimension text 

Enumerator — Comment

Before — Specifies leader stub before the dimension text

Below — Specfies leader stub below the dimension text

Last — Last enum value.

More...

class — DiameterRadiusPreferences

Represents diameter and radius preferences. More...

class — DiameterRadiusSymbolPlacement

Specifies the diameter/radius symbol placement relative to the dimension text 

Enumerator — Comment

Below — Specifies diameter/radius symbol is placed below dimension text

Above — Specifies diameter/radius symbol is placed above dimension text

After — Specifies diameter/radius symbol is placed after dimension text

Before — Specifies diameter/radius symbol is placed before dimension text

Omit — Specifies diameter/radius symbol is omitted

Last — Last enum value.

More...

class — DiameterSymbol

Specifies the diameter symbol 

Enumerator — Comment

Dia — Specifies DIA symbol

Standard — Specifies standard symbol

UserDefined — Specifies user defined symbol

Spherical — Specifies spherical symbol

Last — Last enum value.

More...

class — Dimension

Represents a dimension 

Abstract class 

More...

class — DimensionCollection

Represents a collection of NXOpen::Annotations::Dimension objects 

This is an collection class. More...

class — DimensionData

Represents dimension data. More...

class — DimensionMeasurementBuilder

Represents a NXOpen::Annotations::DimensionMeasurementBuilder 

This is a sub-builder class and cannot be directly instantiated 

More...

class — DimensionPreferences

Represents dimension preferences. More...

class — DimensionSet

Represents a dimension set 

This is an abstract class. More...

class — DimensionSetBuilder

Represents a NXOpen::Annotations::DimensionSetBuilder 

This is a sub-builder class and cannot be directly instantiated 

More...

class — DimensionSetCollection

Represents a collection of NXOpen::Annotations::DimensionSet objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — DimensionStyleBuilder

Represents a NXOpen::Annotations::DimensionStyleBuilder . More...

class — DimensionTextFormat

Specifies the dimension text format 

Enumerator — Comment

Decimal — Specifies decimal format

HalfSizeFraction — Specifies 1/2 size fraction format

TwoThirdSizeFraction — Specfies 2/3 size fraction format

FullSizeFraction — Specifies full size fraction format

Last — Last enum value.

More...

class — DimensionType

Specifies the type of dimension being created 

Enumerator — Comment

AngularMajor — Major Angular dimension

AngularMinor — Minor Angular dimension

ArcLength — Arc Length dimension

Baseline — Baseline dimension

Chain — Chain dimension

Chamfer — Chamfer dimension

ConcentricCircle — Concentric Circle dimension

Cylindrical — Cylindrical dimension

Diameter — Diameter dimension

FoldedRadius — Folded Radius dimension

Hole — Hole dimension

Horizontal — Horizontal dimension

OrdinateHorizontal — Horizontal Ordinate dimension

OrdinateOrigin — Ordinate Origin dimension

OrdinateVertical — Vertical Ordinate dimension

Parallel — Parallel dimension

Perpendicular — Perpendicular dimension

Radius — Radius dimension

Vertical — Vertical dimension

Last — Last enum value.

More...

class — DimensionUnit

Specifies the dimension unit 

Enumerator — Comment

Millimeters — Specifies millimeters units

Meters — Specified meters units

Inches — Specifies inches units

ArchitecturalFeetInches — Specified architectural units - converts inches to feet for measurements larger than 12 inches

EngineeringFeetInches — Specified engineering units - converts inches to feet for measurements larger than 72 inches

Micrometers — Specified micrometers units

Last — Last enum value.

More...

class — DimensionWorkflowBuilder

Represents a Annotations WorkFlowBuilder. More...

class — DisplayPmiEffectivityMethod

Specifies the options for display PMI Effectivity 

Enumerator — Comment

AllAssocOccLoaded

AnyAssocOccLoaded

More...

class — DisplayStyleBuilder

Represents a NXOpen::Annotations::DisplayStyleBuilder . More...

class — DraftingAid

Represents a drafting aid 

This is an abstract class. More...

class — DraftingArbitraryTarget

Represents a drafting arbitrary datum target. More...

class — DraftingCustomSymbolBuilder

Represents builder for Drafting Custom Symbol 

To create a new instance of this class, use NXOpen::Annotations::CustomSymbolCollection::CreateDraftingCustomSymbolBuilder 

More...

class — DraftingDatum

Represents a datum 

To create or edit an instance of this class, use NXOpen::Annotations::DraftingDatumFeatureSymbolBuilder 

More...

class — DraftingDatumFeatureSymbolBuilder

datum feature symbol builder 

To create a new instance of this class, use NXOpen::Annotations::GdtDatumCollection::CreateDraftingDatumFeatureSymbolBuilder 

More...

class — DraftingDatumTarget

Represents a datum target 

To create or edit an instance of this class, use NXOpen::Annotations::DraftingDatumTargetBuilder 

More...

class — DraftingDatumTargetBuilder

Represents a NXOpen::Annotations::DraftingDatumTargetBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateDraftingDatumTargetBuilder 

Default values. More...

class — DraftingDatumTargetCollection

Represents a collection of NXOpen::Annotations::DraftingDatumTarget objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — DraftingFcf

Represents an FCF 

To create or edit an instance of this class, use NXOpen::Annotations::DraftingFeatureControlFrameBuilder 

More...

class — DraftingFeatureControlFrameBuilder

Represents a NXOpen::Annotations::DraftingFeatureControlFrameBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateDraftingFeatureControlFrameBuilder 

Default values. More...

class — DraftingImage

Represents a drafting image 

To create or edit an instance of this class, use NXOpen::Annotations::DraftingImageBuilder 

More...

class — DraftingImageBuilder

Represents a NXOpen.Annotations.DraftingImageBuilder class. More...

class — DraftingImageCollection

Represents a collection of NXOpen::Annotations::DraftingImage objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — DraftingLineTarget

Represents a drafting line datum target 

To create or edit an instance of this class, use NXOpen::Annotations::DraftingDatumTargetBuilder 

More...

class — DraftingNoteBuilder

Represents a NXOpen::Annotations::Note builder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateDraftingNoteBuilder 

Default values. More...

class — DraftingPointTarget

Represents drafting point datum target 

To create or edit an instance of this class, use NXOpen::Annotations::DraftingDatumTargetBuilder 

More...

class — DraftingSurfaceFinish

Represents a Drafting Surface Finish 

To create or edit an instance of this class, use NXOpen::Annotations::DraftingSurfaceFinishBuilder 

More...

class — DraftingSurfaceFinishBuilder

Represents a NXOpen::Annotations::DraftingSurfaceFinish builder 

To create a new instance of this class, use NXOpen::Annotations::DraftingSurfaceFinishCollection::CreateDraftingSurfaceFinishBuilder 

More...

class — DraftingSurfaceFinishCollection

Represents a collection of NXOpen::Annotations::DraftingSurfaceFinish objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — DraftingSurfaceFinishSymbol

Represents Drafting Surface Finish Symbol 

To create or edit an instance of this class, use NXOpen::Annotations::DraftingSurfaceFinishSymbolBuilder 

More...

class — DraftingSurfaceFinishSymbolBuilder

Represents builder for Drafting Surface Finish Symbol 

To create a new instance of this class, use NXOpen::Annotations::DraftingSurfaceFinishSymbolCollection::CreateDraftingSurfaceFinishSymbolBuilder 

More...

class — DraftingSurfaceFinishSymbolCollection

Represents a collection of NXOpen::Annotations::DraftingSurfaceFinishSymbol objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — DrawingFormatTitleBuilder

Represents a NXOpen::Annotations::DrawingFormatTitleBuilder. More...

class — DrivingValueBuilder

Created in NX9.0.0 

More...

class — DualDimensionPlacement

Specifies the dual dimension placement relative to the primary dimension 

Enumerator — Comment

Below — Specifies dual dimension below primary dimension

After — Specifies dual dimension after primary dimension

Above — Specifies dual dimension above primary dimension

Before — Specifies dual dimension before primary dimension

NotSet — Specifies no dual dimension

Last — Last enum value.

More...

class — EdgeConditionSymbol

Represents a drafting edge condition symbol 

To create or edit an instance of this class, use NXOpen::Annotations::EdgeConditionSymbolBuilder 

More...

class — EdgeConditionSymbolBuilder

Represents builder for Drafting Edge Condition Symbol 

To create a new instance of this class, use NXOpen::Annotations::EdgeConditionSymbolCollection::CreateEdgeConditionSymbolBuilder 

More...

class — EdgeConditionSymbolCollection

Represents a collection of edge condition symbol objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — EditAnnotationPlaneBuilder

Represents Annotations.EditAnnotationPlaneBuilder. More...

class — EditLeaderBuilder

Represents a builder that provides an interface to adding and editing leaders to table entities 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateEditLeaderBuilder 

More...

class — EditSettingsBuilder

the edit settings builder 

To create a new instance of this class, use NXOpen::Drafting::SettingsManager::CreateAnnotationEditSettingsBuilder 

More...

class — EditSymbolDisplayBuilder

Represents a EditSymbolPieces builder 

To create a new instance of this class, use NXOpen::Annotations::CustomSymbolCollection::EditSymbolDisplayBuilder 

Default values. More...

class — EditText

Represents Edit Text. More...

class — EditTitleBlockBuilder

Represents a NXOpen::Annotations::EditTitleBlockBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::TitleBlockCollection::CreateEditTitleBlockBuilder 

More...

class — EnterpriseIdentification

Represents a Enterprise Identification 

To create or edit an instance of this class, use NXOpen::Annotations::EnterpriseIdentificationBuilder 

More...

class — EnterpriseIdentificationBuilder

Represents a NXOpen::Annotations::EnterpriseIdentification builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateEnterpriseIdentificationBuilder 

More...

class — ExportControl

Represents a Export Control 

To create or edit an instance of this class, use NXOpen::Annotations::ExportControlBuilder 

More...

class — ExportControlBuilder

Represents a NXOpen::Annotations::ExportControl builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateExportControlBuilder 

More...

class — ExtensionLineDisplay

Specifies the extension line display option 

Enumerator — Comment

Two — Displays both the extension lines

First — Displays extension line attached to the first object selected to create the dimension

Second — Displays extension line attached to the second object selected to create the dimension

NotSet — Doesn't display extension lines

Last — Last enum value.

More...

class — Fcf

Represents an FCF 

To create or edit an instance of this class, use NXOpen::Annotations::PmiFeatureControlFrameBuilder 

More...

class — FcfCollection

Represents a collection of NXOpen::Annotations::Fcf objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — FcfData

Represents FCF data. More...

class — FcfDatumReference

Represents a NXOpen::Annotations::FcfDatumReference. More...

class — FcfFrame

Represents an FCF frame. More...

class — FcfFrameData

Represents FCF frames data. More...

class — FeatureControlFrameBuilder

Represents a NXOpen::Annotations::FeatureControlFrameBuilder 

This is an abstract class, and cannot be instantiated. More...

class — FeatureControlFrameData

Represents a NXOpen::Annotations::FeatureControlFrameData. More...

class — FeatureControlFrameDataBuilder

Represents a FeatureControlFrameDataBuilder. More...

class — FeatureControlFrameDataBuilderList

Represents a list of objects. More...

class — FeatureControlFrameIndicatorBuilder

Represents a FcfIndicatorBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateFeatureControlFrameIndicatorBuilder 

More...

class — FeatureControlFrameIndicatorBuilderList

Represents a list of objects. More...

class — FeatureIdBusinessModifier

Represents buiness modifier that indicates a featire identification PMI object. More...

class — FeatureIdBusinessModifierBuilder

Represents a NXOpen::Annotations::FeatureIdBusinessModifier builder 

To create a new instance of this class, use NXOpen::Annotations::BusinessModifierCollection::CreateFeatureIdBusinessModifierBuilder 

More...

class — FinishMethod

Specifies the weld finish method 

Enumerator — Comment

NotSet — Specifies no finishing method

Chipping — Specifies chipping finish

Grinding — Specifies grinding finish

Hammering — Specifies hammering finish

Machining — Specifies machining finish

Rolling — Specifies rolling finish

Peening — Specifies peening finish

Last — Last enum value.

More...

class — FitAnsiHoleType

Specifies the limit and fit ANSI hole 

Enumerator — Comment

Hole — Use hole values for the ANSI limit and fit tolerance

Shaft — Use shaft values for the ANSI limit and fit tolerance

Fit — Use fit values for the ANSI limit and fit tolerance

More...

class — FitAssemblyDisplayStyle

Specifies the limit and fit assembly display style This enum type is obsolete. More...

class — FitAssemblyNewDisplayStyle

Specifies the limit and fit assembly new display style 

Enumerator — Comment

SingleLine — Display single line

DoubleLine — Display double line

More...

class — FitDisplayAlignment

Specifies the limit and fit display alignment 

Enumerator — Comment

CenterValue — Center value

CenterValueAndFit — Center value and Fit

Bottom — Bottom

More...

class — FitDisplaySplitByDimline

Specifies the limit and fit assembly display when split by dimension line 

Enumerator — Comment

NotSet — No split

ToleranceOnly — Split tolerance only

ToleranceAndValue — Split tolerance and value

More...

class — FitDisplayStyle

Specifies the limit and fit display style 

Enumerator — Comment

FitSymbols — Display only the grade and deviation

FitSymbolsAndLimits — Display grade, deviation, and limit values

FitSymbolsAndTolerances — Display grade, deviation, and tolerance values

TolerancesOnly — Display the tolerance values only

More...

class — FlipOption

Specifies the custom symbol flip option. More...

class — FoldedRadiusDimension

Represents a folded radius dimension 

To create or edit an instance of this class, use NXOpen::Annotations::RadialDimensionBuilder 

More...

class — ForeshorteningSymbolBuilder

Represents a NXOpen::Annotations::ForeshorteningSymbolBuilder builder 

There is no KF creator for this class. More...

class — ForeshorteningSymbolSettingsBuilder

Represents a NXOpen::Annotations::ForeshorteningSymbolSettingsBuilder builder. More...

class — FractionDenominatorFormat

Specifies the fraction denominator format 

Enumerator — Comment

One

Two

Four

Eight

Sixteen

ThirtyTwo

SixtyFour

Last — Last enum value.

More...

class — FrameBar

Represents a frame bar class 

To create or edit an instance of this class, use NXOpen::Annotations::FrameBarBuilder 

More...

class — FrameBarBuilder

Represents a NXOpen::Annotations::FrameBarBuilder . More...

class — FrameBarCollection

Represents a collection of NXOpen::Annotations::FrameBar objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — FrameBarElements

Specifies the frame bar elements 

Enumerator — Comment

AftPerpendicular

ForwardPerpendicular

CenterlineY

Baseline

Waterline

TransversalInsertArea

BulkHeads

Decks

TransverseFrames

InterTransverseFrames

LongitudinalYFrames

LongitudinalZFrames

AlongHullBaseline

AlongHullWaterline

AlongHullDecks

AlongHullLongitudinalZFrames

LongitudinalBulkHeads

LongitudinalYInsertFrames

LongitudinalZInsertFrames

AlongHullLongitudinalZInsertFrames

Midship

Num

More...

class — FrameBarElementStyleBuilder

Represents a NXOpen::Annotations::FrameBarElementStyleBuilder . More...

class — FrameBarPreferences

Represents frame bar preferences. More...

class — FrameBarStyleBuilder

Represents a NXOpen::Annotations::FrameBarStyleBuilder . More...

class — Gdt

Represents a Geometric Dimensioning and Tolerancing symbol 

This is an abstract class, and cannot be instantiated 

More...

class — GdtCollection

Represents a collection of GDTs 

To obtain an instance of this class, refer to NXOpen::Part 

More...

class — GdtDatumCollection

Represents a collection of NXOpen::Annotations::Datum objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — GeneralArcLengthDimension

Represents a arc length dimension 

To obtain an instance of this class use NXOpen::Annotations::DimensionCollection 

More...

class — GeneralChamferDimension

Represents a chamfer dimension 

To obtain an instance of this class use NXOpen::Annotations::DimensionCollection 

More...

class — GeneralConcentricCircleDimension

Represents a concentric circle dimension 

To obtain an instance of this class use NXOpen::Annotations::DimensionCollection 

More...

class — GeneralCustomSymbol

Represents a general custom symbol. More...

class — GeneralCylindricalDimension

Represents a horizontal dimension 

To obtain an instance of this class use NXOpen::Annotations::DimensionCollection 

More...

class — GeneralDiameterDimension

Represents a horizontal dimension 

To obtain an instance of this class use NXOpen::Annotations::DimensionCollection 

More...

class — GeneralFoldedRadiusDimension

Represents a folded radius dimension 

To obtain an instance of this class use NXOpen::Annotations::DimensionCollection 

More...

class — GeneralHoleDimension

Represents a hole dimension 

To obtain an instance of this class use NXOpen::Annotations::DimensionCollection 

More...

class — GeneralHorizontalDimension

Represents a horizontal dimension 

To obtain an instance of this class use NXOpen::Annotations::DimensionCollection 

More...

class — GeneralLabel

Represents a General Label 

To obtain an instance of this class use NXOpen::Annotations::LabelCollection 

More...

class — GeneralMajorAngularDimension

Represents a major angular dimension 

To obtain an instance of this class use NXOpen::Annotations::DimensionCollection 

More...

class — GeneralMinorAngularDimension

Represents a minor angular dimension 

To obtain an instance of this class use NXOpen::Annotations::DimensionCollection 

More...

class — GeneralNote

Represents a General Note 

To create or edit an instance of this class, use NXOpen::Annotations::GeneralNoteBuilder 

More...

class — GeneralNoteBuilder

Represents a NXOpen::Annotations::GeneralNote builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateGeneralNoteBuilder 

More...

class — GeneralParallelDimension

Represents a parallel dimension 

To obtain an instance of this class use NXOpen::Annotations::DimensionCollection 

More...

class — GeneralPerpendicularDimension

Represents a horizontal dimension 

To obtain an instance of this class use NXOpen::Annotations::DimensionCollection 

More...

class — GeneralRadiusDimension

Represents a radius dimension 

To obtain an instance of this class use NXOpen::Annotations::DimensionCollection 

More...

class — GeneralVerticalDimension

Represents a horizontal dimension 

To obtain an instance of this class use NXOpen::Annotations::DimensionCollection 

More...

class — GenericNote

Represents a Generic Note 

To obtain an instance of this class use NXOpen::Annotations::NoteCollection 

More...

class — GeodesicDimensionBuilder

Represents a NXOpen::Annotations::Dimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateGeodesicDimensionBuilder 

More...

class — GeometricCharacteristic

Specifies the geometric characteristic for an FCF 

Enumerator — Comment

Straightness — Specifies straightnesss characteristics

Flatness — Specifies flatness characteristics

Circular — Specifies cirular characteristics

Cylindrical — Specifies cylindrical characteristics

LineProfile — Specifies line profile characteristics

SurfaceProfile — Specifies surface profile characteristics

Angular — Specifies angular characteristics

Perpendicular — Specifies perpendicular characteristics

Parallel — Specifies parallel characteristics

Position — Specifies position characteristics

Concentric — Specifies concentric characteristics

Symmetric — Specifies symmetric characteristics

CircularRunout — Specifies cirular runout characteristics

TotalRunout — Specifies total runout characteristics

Last — Last enum value.

More...

class — GeometryData

Represents Geometry data. More...

class — GovernmentSecurityInformation

Represents a Government Security Information 

To create or edit an instance of this class, use NXOpen::Annotations::GovernmentSecurityInformationBuilder 

More...

class — GovernmentSecurityInformationBuilder

Represents a NXOpen::Annotations::GovernmentSecurityInformation builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateGovernmentSecurityInformationBuilder 

More...

class — Hatch

Represents a crosshatch or area fill 

To create or edit an instance of this class, use NXOpen::Annotations::HatchBuilder 

More...

class — HatchBuilder

This class is used to construct the crosshatching that lies within a boundary. More...

class — HatchCollection

Represents a collection of NXOpen::Annotations::Hatch objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — HatchFillSettingsBuilder

This class is used to construct the Crosshatch and area Fill setting block . More...

class — HatchStyleBuilder

Represents a NXOpen::Annotations::HatchStyleBuilder . More...

class — HoleCalloutDimensionBuilder

Represents a NXOpen::Annotations::HoleCalloutDimensionBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateHoleCalloutDimensionBuilder 

More...

class — HoleCalloutSettingsBuilder

Represents a NXOpen::Annotations::HoleCalloutSettingsBuilder , this builder contains list(s) of parameter(s) for feature(s). More...

class — HoleDimension

Represents a hole dimension 

To create or edit an instance of this class, use NXOpen::Annotations::RadialDimensionBuilder 

More...

class — HoleTable

Represents a NXOpen::Annotations::HoleTable . More...

class — HoleTableBuilder

Represents a NXOpen::Annotations::HoleTableBuilder . More...

class — HoleTableCollection

Represents a collection of NXOpen::Annotations::HoleTable objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — HoleTableSettingsContentBuilder

Represents a NXOpen::Annotations::HoleTableSettingsContentBuilder. More...

class — HoleTableSettingsFormatBuilder

Represents a NXOpen::Annotations::HoleTableSettingsFormatBuilder. More...

class — HoleTableSettingsHoleFiltersBuilder

Represents a NXOpen::Annotations::HoleTableSettingsHoleFiltersBuilder. More...

class — HoleTableSettingsLabelBuilder

Represents a NXOpen::Annotations::HoleTableSettingsLabelBuilder. More...

class — HoleTableSettingsWorkflowBuilder

Represents a NXOpen::Annotations::HoleTableSettingsWorkflowBuilder. More...

class — HorizontalDimension

Represents a horizontal dimension 

To create or edit an instance of this class, use NXOpen::Annotations::LinearDimensionBuilder 

More...

class — HorizontalOrdinateDimension

Represents a horizontal ordinate dimension 

To create or edit an instance of this class, use NXOpen::Annotations::OrdinateDimensionBuilder 

More...

class — HorizontalOrdinateMargin

Represents a horizontal ordinate margin. More...

class — IAngularTolerance

Represents an object that has angular tolerance. More...

class — IAppendedText

Represents an object that has appended text. More...

class — IArbitraryTarget

Represents interface class for arbitrary datum target areas. More...

class — ICircularTarget

Represents interface class for a circular datum target. More...

class — IContainer

Represents an object that contains other objects. More...

class — IDatum

Represents interface class for a datum. More...

class — IDatumTarget

Represents interface class for a datum target. More...

class — IdentificationLineLocation

Specifies the weld identification line location (ISO and DIN only) 

Enumerator — Comment

NotSet — Specifies no identification line

Top — Specifies identification line above the reference line

Bottom — Specifies identification line below the reference line

Last — Last enum value.

More...

class — IdSymbol

Represents an ID symbol 

To create or edit an instance of this class, use NXOpen::Annotations::IdSymbolBuilder 

More...

class — IdSymbolBuilder

Represents a NXOpen::Annotations::IdSymbol builder 

To create a new instance of this class, use NXOpen::Annotations::IdSymbolCollection::CreateIdSymbolBuilder 

Default values. More...

class — IdSymbolCollection

Represents a collection of NXOpen::Annotations::IdSymbol objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — IFcf

Represents interface class for a feature control frame. More...

class — ILinearTolerance

Represents an object that has linear tolerance. More...

class — ILineTarget

Represents interface class for line datum target. More...

class — ImportAutocadBlockBuilder

Represents a builder allowing import of AutoCAD blocks. More...

class — ImportSymbolBuilder

Represents a builder allowing import of one or many foreign symbols. More...

class — IndustryBaseSymbol

Represents a industry basesymbol 

There is no KF creator for this class. More...

class — InspectionSymbolAroundAppendedText

Specifies on how an inspection symbol is drawn around appended text 

Enumerator — Comment

NotSet — None

Before — Include before appended text

After — Include after appended text

BeforeAfter — Include before and after appended textx

All — Include all appended texts

More...

class — IntersectionSymbol

Represents a intersection symbol 

To create or edit an instance of this class, use NXOpen::Annotations::IntersectionSymbolBuilder 

More...

class — IntersectionSymbolBuilder

Represents a NXOpen::Annotations::IntersectionSymbol builder 

To create a new instance of this class, use NXOpen::Annotations::IntersectionSymbolCollection::CreateIntersectionSymbolBuilder 

Default values. More...

class — IntersectionSymbolCollection

Represents a collection of NXOpen::Annotations::IntersectionSymbol objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — IPmi

Represents an object that has PMI(Product and Manufacturing Information) data. More...

class — IPmiSemantics

Interface class provides access to PMI semantic data. More...

class — IPointTarget

Represents interface class for a point datum target. More...

class — IRectangularTarget

Represents interface class for a rectangular datum target. More...

class — ISlotDimension

Represents a slot dimension. More...

class — JogOrientation

Specifies the options jog orientation 

Enumerator — Comment

JogIn — Jog orientation in

JogOut — Jog orientation out

More...

class — Label

Represents a label 

To create an instance of this class NXOpen::Annotations::AnnotationManager 

More...

class — LabelCollection

Represents a collection of labels 

To obtain an instance of this class, refer to NXOpen::Part 

More...

class — LabelData

Represents label data. More...

class — LeaderAlignment

Specifies the leader's alignment. More...

class — LeaderAttachment

Specifies what a leader is attached to 

Enumerator — Comment

Null — Should not be used

OnObject

Screen

Last — Last enum value.

More...

class — LeaderBuilder

Represents a NXOpen::Annotations::LeaderBuilder . More...

class — LeaderBundle

Represents the data for all the leaders of an annotation. More...

class — LeaderData

Represents a NXOpen::Annotations::LeaderData . More...

class — LeaderDataList

Represents a list of objects. More...

class — LeaderOrientation

Specifies the leader's orientation 

Enumerator — Comment

FromLeft

FromRight

FromTop

FromBottom

Inferred

More...

class — LeaderSide

Specifies which side the leader will be on 

Enumerator — Comment

Null — Should not be used

Left

Right

Inferred — When used with NXOpen API, leader side will be set to Left by default.

More...

class — LeaderType

Specifies the leader type. More...

class — LeaderVerticalAttachment

Specifies on what a leader is attached to 

Enumerator — Comment

Null — Should not be used

Top — Attach vertically to the top of the annotation

Center — Attach vertically to the center of the annotation

Bottom — Attach vertically to the bottom of the annotation

Legacy — Attach vertically to the middle of top row of annotation

Last — Last enum value.

More...

class — Lettering

Specifies lettering data. More...

class — LetteringPreferences

Represents lettering preferences. More...

class — LetteringStyleBuilder

Represents a NXOpen::Annotations::LetteringStyleBuilder . More...

class — LightweightSection

Represents a PMI Lightweight Section 

To create or edit an instance of this class, use NXOpen::Annotations::LightweightSectionBuilder 

More...

class — LightweightSectionBuilder

Represents a NXOpen::Annotations::LightweightSection builder 

To create a new instance of this class, use NXOpen::Annotations::PmiLightweightSectionCollection::CreateLightweightSectionBuilder 

Default values. More...

class — LightweightSectionView

Represents a PMI Lightweight Section View 

Created with LightweightSection 

More...

class — LineAndArrowPreferences

Represents line and arrow preferences. More...

class — LinearDimensionBuilder

Represents a NXOpen::Annotations::Dimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateLinearDimensionBuilder 

More...

class — LineArrowStyleBuilder

Represents a NXOpen::Annotations::LineArrowStyleBuilder . More...

class — LinearTolerance

Represents linear tolerance. More...

class — LineCfw

Specifies color, font, and width. More...

class — LineComponent

Represents a single line in an annotation and can be queried for information about that line. More...

class — LineTarget

Represents a line datum target 

To create or edit an instance of this class, use NXOpen::Annotations::PmiDatumTargetBuilder 

More...

class — LineWeld

Represents a line weld 

To create or edit an instance of this class, use NXOpen::Annotations::LineWeldBuilder 

More...

class — LineWeldBuilder

Represents a NXOpen::Annotations::LineWeldBuilder 

To create a new instance of this class, use NXOpen::Annotations::WeldCollection::CreateLineWeldBuilder 

Default values. More...

class — LineWeldData

Represents line weld data. More...

class — LineWeldDataBuilder

Represents a NXOpen::Annotations::LineWeldDataBuilder. More...

class — LineWeldSideData

Represents line weld side data. More...

class — LineWidth

Specifies the line width. More...

class — ListBusinessModifier

Represents a base class for list based business modifiers. More...

class — LocatorDesignator

Represents a Locator Designator 

To create or edit an instance of this class, use NXOpen::Annotations::LocatorDesignatorBuilder 

More...

class — LocatorDesignatorBuilder

Represents a NXOpen::Annotations::LocatorDesignator builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateLocatorDesignatorBuilder 

More...

class — MajorAngularDimension

Represents a major angular dimension 

To create or edit an instance of this class, use NXOpen::Annotations::MajorAngularDimensionBuilder 

More...

class — MajorAngularDimensionBuilder

Represents a NXOpen::Annotations::AngularDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateMajorAngularDimensionBuilder 

More...

class — MasterCustomSymbol

Represents a custom symbol. More...

class — MasterCustomSymbolData

Represents master custom symbol data. More...

class — MasterSymbol

Represents a part symbol folder 

To create or edit an instance of this class, use NXOpen::Annotations::MasterSymbolBuilder 

More...

class — MasterSymbolBuilder

Represents a Builder for MasterSymbol functionality 

To create a new instance of this class, use NXOpen::Annotations::CustomSymbolCollection::CreateMasterSymbolBuilder 

Default values. More...

class — MasterSymbolListItemBuilder

Represents a NXOpen::Annotations::MasterSymbolListItemBuilder 

To create a new instance of this class, use NXOpen::Annotations::CustomSymbolCollection::CreateMasterSymbolListItemBuilder 

More...

class — MasterSymbolListItemBuilderList

Represents a list of objects. More...

class — MaterialConditionModifier

Specifies the material condition modifier 

Enumerator — Comment

Mmc — Specifies maximum material condition modifier

Lmc — Specifies least material condition modifier

Rfs — Specified regardless of feature size modifier

Tangential — Specifies tangent plane modifier

NotSet — Specifies no material modifier.

More...

class — MaterialSpecification

Represents a Material Specification 

To create or edit an instance of this class, use NXOpen::Annotations::MaterialSpecificationBuilder 

More...

class — MaterialSpecificationBuilder

Represents a NXOpen::Annotations::MaterialSpecification builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateMaterialSpecificationBuilder 

More...

class — MinorAngularDimension

Represents a minor angular dimension 

To create or edit an instance of this class, use NXOpen::Annotations::MinorAngularDimensionBuilder 

More...

class — MinorAngularDimensionBuilder

Represents a NXOpen::Annotations::AngularDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateMinorAngularDimensionBuilder 

More...

class — NarrowDimensionData

Specifies the narrow dimension preferences. More...

class — NarrowDimensionPreferences

Represents narrow dimension preferences. More...

class — NarrowDisplayOption

Specifies the narrow dimension display option 

Enumerator — Comment

NotSet — Doesn't display narrow dimension

NoLeader — Displays narrow dimension without leader

WithLeaderNoStub — Displays narrow dimension with leader, but without stub

AboveStub — Displays narrow dimension above stub

AfterStub — Displays narrow dimension after stub

Last — Last enum value.

More...

class — NarrowTextOrientation

Specifies the narrow dimension text orientation 

Enumerator — Comment

Horizontal — Specifies horizontal text orientation

Parallel — Specifies parallel text orientation

Last — Last enum value.

More...

class — Note

Represents a Note 

To create or edit an instance of this class, use NXOpen::Annotations::DraftingNoteBuilder 

More...

class — NoteBase

Represents a base class for notes and labels 

This is an abstract class 

More...

class — NoteCollection

Represents a collection of notes 

To obtain an instance of this class, refer to NXOpen::Part 

More...

class — NoteData

Represents note data. More...

class — OffsetCenterPoint

Represents a offset center point 

To create or edit an instance of this class, use NXOpen::Annotations::OffsetCenterPointBuilder 

More...

class — OffsetCenterPointBuilder

Represents a NXOpen::Annotations::OffsetCenterPoint builder 

To create a new instance of this class, use NXOpen::Annotations::OffsetCenterPointCollection::CreateOffsetCenterPointBuilder 

Default values. More...

class — OffsetCenterPointCollection

Represents a collection of NXOpen::Annotations::OffsetCenterPoint objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — OrdinateBaselineBuilder

Represents a builder for an ordinate baseline 

This is a sub-builder class and cannot be directly instantiated 

More...

class — OrdinateDimension

Represents an ordinate dimension 

Abstract class 

More...

class — OrdinateDimensionBuilder

Represents a NXOpen::Annotations::OrdinateDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateOrdinateDimensionBuilder 

More...

class — OrdinateDimensionPreferences

Represents ordinate dimension preferences. More...

class — OrdinateDoglegCreationOption

Specifies the dogleg creation option when creating/editing the ordinate dimension 

Enumerator — Comment

Infer — Software infers whether the dogleg would be created

Yes — Dogleg will always be created

No — Dogleg will not be created

Last — Last enum value.

More...

class — OrdinateDoglegDefinition

Specifies the ordinate dimension dogleg definition 

A - Start offset 

B - End offset 

C - Dog leg angle 

More...

class — OrdinateLineArrowDisplayOption

Specifies the ordinate dimension line and arrow display option 

Enumerator — Comment

NotSet — Doesn't display line and arrow

All — Displays both the line and arrow

Last — Last enum value.

More...

class — OrdinateMargin

Represents an ordinate margin. More...

class — OrdinateMarginCollection

Represents a collection of NXOpen::Annotations::OrdinateMargin 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — OrdinateOriginDimension

Represents an ordinate origin dimension 

There is no KF creator for this class. More...

class — OrdinateOriginDisplayOption

Specifies the ordinate origin dimension display option 

Enumerator — Comment

UserDefinedSymbol — Displays user defined symbol at the ordinate origin

OrdinateSetName — Displays the ordinate set name at the ordinate origin

NoText — Display no text at the ordinate origin

Last — Last enum value.

More...

class — OrdinatePositiveDirection

Specifies the positive direction for ordinate dimensions 

Enumerator — Comment

All — Specifies positive direction for all dimensions

UpperRight — Specifies positive direction for dimensions in upper right qudrant

UpperLeft — Specifies positive direction for dimensions in upper left qudrant

LowerRight — Specifies positive direction for dimensions in lower right qudrant

LowerLeft — Specifies positive direction for dimensions in lower left qudrant

Last — Last enum value.

More...

class — OrdinateStyleBuilder

Represents a NXOpen::Annotations::OrdinateStyleBuilder . More...

class — OriginAlignmentBuilder

This is the Origin Alignment builder used to query or set origin alignment preferences. More...

class — OriginBuilder

Represents a NXOpen::Annotations::OriginBuilder 

This is a sub-builder class and cannot be directly instantiated 

More...

class — ParallelDimension

Represents a parallel dimension 

To create or edit an instance of this class, use NXOpen::Annotations::LinearDimensionBuilder 

More...

class — PartFamilyTable

Represents a NXOpen::Annotations::PartFamilyTable . More...

class — PartFamilyTableBuilder

Represents a NXOpen::Annotations::PartFamilyTableBuilder . More...

class — PartFamilyTableCollection

Represents a collection of NXOpen::Annotations::PartFamilyTable objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — PartFamilyTableSettingsBuilder

Represents a NXOpen::Annotations::PartFamilyTableSettingsBuilder. More...

class — PartIdentification

Represents a Part Identification 

To create or edit an instance of this class, use NXOpen::Annotations::PartIdentificationBuilder 

More...

class — PartIdentificationBuilder

Represents a NXOpen::Annotations::PartIdentification builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePartIdentificationBuilder 

More...

class — PartsList

Represents a Annotations.PartsList. More...

class — PartsListBuilder

Represents a NXOpen::Annotations::PartsListBuilder . More...

class — PartsListCollection

Represents a collection of Annotations::PartsList objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — PartsListContentsBuilder

Represents a Annotations::PartsListContentsBuilder . More...

class — PartSymbolFolder

Represents a part symbol folder 

To create or edit an instance of this class, use NXOpen::Annotations::PartSymbolFolderBuilder 

More...

class — PartSymbolFolderBuilder

Represents a NXOpen::Annotations::PartSymbolFolderBuilder . More...

class — PartSymbolFolderCollection

Represents a collection of NXOpen::Annotations::PartSymbolFolder objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — PerpendicularDimension

Represents a perpendicular dimension 

To create or edit an instance of this class, use NXOpen::Annotations::LinearDimensionBuilder 

More...

class — PinListBuilder

Builder for Formboard pin list functionality used in formboard. More...

class — PlaneBuilder

Represents a NXOpen::Annotations::PlaneBuilder object. More...

class — PlistBuilder

Represents a Annotations::PlistBuilder . More...

class — Pmi

Represents a PMI(Product and Manufacturing Information) object. More...

class — PmiAngularDimension

Represents a PMI angular dimension 

Abstract class 

More...

class — PmiAngularDimensionBuilder

Represents a NXOpen::Annotations::AngularDimension builder 

This is an abstract class and cannot be instantiated. More...

class — PmiArcLengthDimension

Represents a PMI arc length dimension 

To create or edit an instance of this class, use NXOpen::Annotations::PmiCurveLengthDimensionBuilder 

More...

class — PmiAttribute

Represents a Pmi Attribute 

To create or edit an instance of this class, use NXOpen::Annotations::PmiAttributeBuilder 

More...

class — PmiAttributeBuilder

Represents a NXOpen::Annotations::PmiAttribute builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiAttributeBuilder 

More...

class — PmiAttributeCollection

Represents a collection of NXOpen::Annotations::PmiAttribute objects. More...

class — PmiAttributeValue

Represents a PMI Attribute Value 

This is an abstract class. More...

class — PmiAttributeValueInteger

Represents a PMI Attribute Integer Value 

To create or edit an instance of this class, use NXOpen::Annotations::PmiAttributeValueIntegerBuilder 

More...

class — PmiAttributeValueIntegerBuilder

Represents a NXOpen::Annotations::PmiAttributeValueInteger builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiAttributeValueIntegerBuilder 

More...

class — PmiAttributeValueList

Represents a PMI Attribute List Value 

To create or edit an instance of this class, use NXOpen::Annotations::PmiAttributeValueListBuilder 

More...

class — PmiAttributeValueListBuilder

Represents a NXOpen::Annotations::PmiAttributeValueList builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiAttributeValueListBuilder 

More...

class — PmiAttributeValueMultipleString

Represents a PMI Attribute MultipleString Value 

To create or edit an instance of this class, use NXOpen::Annotations::PmiAttributeValueMultipleStringBuilder 

More...

class — PmiAttributeValueMultipleStringBuilder

Represents a NXOpen::Annotations::PmiAttributeValueMultipleString builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiAttributeValueMultipleStringBuilder 

More...

class — PmiAttributeValueNumber

Represents a PMI Attribute Number Value 

To create or edit an instance of this class, use NXOpen::Annotations::PmiAttributeValueNumberBuilder 

More...

class — PmiAttributeValueNumberBuilder

Represents a NXOpen::Annotations::PmiAttributeValueNumber builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiAttributeValueNumberBuilder 

More...

class — PmiAttributeValueString

Represents a PMI Attribute String Value 

To create or edit an instance of this class, use NXOpen::Annotations::PmiAttributeValueStringBuilder 

More...

class — PmiAttributeValueStringBuilder

Represents a NXOpen::Annotations::PmiAttributeValueString builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiAttributeValueStringBuilder 

More...

class — PmiAttributeValueUrl

Represents a PMI Attribute Url Value 

To create or edit an instance of this class, use NXOpen::Annotations::PmiAttributeValueUrlBuilder 

More...

class — PmiAttributeValueUrlBuilder

Represents a NXOpen::Annotations::PmiAttributeValueUrl builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiAttributeValueUrlBuilder 

More...

class — PmiBalloonIdSymbolData

Represents PMI Balloon IdSymbol data. More...

class — PmiBalloonNoteData

Represents PMI balloon note data. More...

class — PmiBaselineDimension

Represents a PMI baseline dimension. More...

class — PmiBoltCircleCenterline

Represents a PMI Bolt Circle Centerline class 

To create or edit an instance of this class, use NXOpen::Annotations::PmiBoltCircleCenterlineBuilder 

More...

class — PmiBoltCircleCenterlineBuilder

Builder for creating or editing PMI Bolt Circle Centerline 

To create a new instance of this class, use NXOpen::Annotations::CenterlineCollection::CreatePmiBoltCircleCenterlineBuilder 

Default values. More...

class — PmiCadNeutralAnnotation

Represents a PMI CAD neutral annotation class 

This class cannot be directly instantiated 

More...

class — PmiCenterline3d

Represents a Pmi 3D centerline 

To create or edit an instance of this class, use NXOpen::Annotations::PmiCenterline3dBuilder 

More...

class — PmiCenterline3dBuilder

Builder for creating Pmi 3D Centerline. More...

class — PmiCenterMark

Represents a PMI Center Mark class 

To create or edit an instance of this class, use NXOpen::Annotations::PmiCenterMarkBuilder 

More...

class — PmiCenterMarkBuilder

Builder for creating PMI Center Mark. More...

class — PmiChainDimension

Represents a PMI chain dimension. More...

class — PmiChamferDimension

Represents a PMI chamfer dimension 

To create or edit an instance of this class, use NXOpen::Annotations::PmiChamferDimensionBuilder 

More...

class — PmiChamferDimensionBuilder

Represents a NXOpen::Annotations::PmiChamferDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreatePmiChamferDimensionBuilder 

More...

class — PmiCollection

Represents a collection of NXOpen::Annotations::Pmi objects. More...

class — PmiConcentricCircleDimension

Represents a PMI concentric circle dimension 

To create or edit an instance of this class, use NXOpen::Annotations::PmiThicknessDimensionBuilder 

More...

class — PmiContextGeneralBuilder

Represents a NXOpen.Annotations.PmiContextGeneralBuilder. More...

class — PmiContextSettingsBuilder

Represents the Context Settings. More...

class — PmiCoordinateNoteData

Represents PMI Coordinate Note data. More...

class — PmiCurveLengthDimensionBuilder

Represents a NXOpen::Annotations::PmiArcLengthDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreatePmiCurveLengthDimensionBuilder 

More...

class — PmiCustomSymbol

Represents a PMI custom symbol 

To create or edit an instance of this class, use NXOpen::Annotations::PmiCustomSymbolBuilder 

More...

class — PmiCustomSymbolBuilder

Represents builder for PMI Custom Symbol 

To create a new instance of this class, use NXOpen::Annotations::CustomSymbolCollection::CreatePmiCustomSymbolBuilder 

More...

class — PmiCylindricalDimension

Represents a PMI cylindrical dimension 

To create or edit an instance of this class, use NXOpen::Annotations::PmiLinearDimensionBuilder 

More...

class — PmiData

Represents PMI(Product and Manufacturing Information) data. More...

class — PmiDatumData

Represents PMI datum data. More...

class — PmiDatumFeatureSymbolBuilder

datum feature symbol builder 

To create a new instance of this class, use NXOpen::Annotations::GdtDatumCollection::CreatePmiDatumFeatureSymbolBuilder 

More...

class — PmiDatumTargetBuilder

Represents a NXOpen::Annotations::PmiDatumTargetBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreatePmiDatumTargetBuilder 

Default values. More...

class — PmiDatumTargetData

Represents PMI datum target semantic data object. More...

class — PmiDefaultPlane

Specifies the options for the default PMI annotation plane 

Enumerator — Comment

XyOfWcs

ModelView

XzOfWcs

YzOfWcs

Last — Placeholder, do not use

More...

class — PmiDiameterDimension

Represents a PMI diameter dimension 

To create or edit an instance of this class, use NXOpen::Annotations::PmiRadialDimensionBuilder 

More...

class — PmiDimensionData

Represents PMI dimension data. More...

class — PmiEdgeConditionSymbol

Represents PMI edge condition symbol 

To create or edit an instance of this class, use NXOpen::Annotations::PmiEdgeConditionSymbolBuilder 

More...

class — PmiEdgeConditionSymbolBuilder

Represents builder for PMI Edge Condition Symbol 

To create a new instance of this class, use NXOpen::Annotations::PmiEdgeConditionSymbolCollection::CreatePmiEdgeConditionSymbolBuilder 

More...

class — PmiEdgeConditionSymbolCollection

Represents a collection of PMI edge condition symbol objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — PmiEdgeConditionSymbolData

Represents PMI Edge Condition Symbol Data. More...

class — PmiEditCuttingPlaneSymbolSettingsBuilder

Represents the Edit Cutting Plane Symbol Settings builder 

To create a new instance of this class, use NXOpen::Annotations::PmiSettingsManager::CreatePmiEditCuttingPlaneSymbolSettingsBuilder 

More...

class — PmiEditRegionSettingsBuilder

Represents the Edit Region Settings builder 

To create a new instance of this class, use NXOpen::Annotations::PmiSettingsManager::CreatePmiEditRegionSettingsBuilder 

More...

class — PmiEditSectionViewSettingsBuilder

Represents the Edit Lightweight Section View Settings builder 

To create a new instance of this class, use NXOpen::Annotations::PmiSettingsManager::CreatePmiEditSectionViewSettingsBuilder 

More...

class — PmiEnterpriseIdentifierData

Represents PMI Enterprise Identifier data. More...

class — PMIExplicitOrderBuilder

This is the NXOpen::Annotations::PMIExplicitOrderBuilder for the explicit order 

To create a new instance of this class, use NXOpen::Annotations::PmiManager::CreateExplicitOrderBuilder 

More...

class — PmiExportControlData

Represents PMI export control semantic data. More...

class — PmiFcfData

Represents PMI Feature Control Frame data. More...

class — PmiFcfDatumData

Represents PMI Feature Control Frame Datum data. More...

class — PmiFeatureControlFrameBuilder

Represents a NXOpen::Annotations::PmiFeatureControlFrameBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreatePmiFeatureControlFrameBuilder 

More...

class — PmiFilter

Represents a base class for a PMI filter. More...

class — PmiFilterByPart

Represents a PMI filter defined by a set of parts. More...

class — PmiFilterByType

Represents a PMI filter defined by a set of types. More...

class — PmiFilterByView

Represents a PMI filter defined by a set of views. More...

class — PmiFilterCollection

Represents the collection of all PMI filters in the part. More...

class — PmiFoldedRadiusDimension

Represents a PMI folded radius dimension 

To create or edit an instance of this class, use NXOpen::Annotations::PmiRadialDimensionBuilder 

More...

class — PmiGeneralSetupDisplayBuilder

Represents a NXOpen.Annotations.PmiGeneralSetupDisplayBuilder. More...

class — PmiGeneralSetupEffectivityBuilder

Represents a NXOpen.Annotations.PmiGeneralSetupEffectivityBuilder. More...

class — PmiGeneralSetupGeneralBuilder

Represents a NXOpen.Annotations.PmiGeneralSetupGeneralBuilder. More...

class — PmiGeneralSetupParallelToScreenBuilder

Represents a NXOpen.Annotations.PmiGeneralSetupParallelToScreenBuilder. More...

class — PmiGovernmentSecurityInfoData

Represents PMI government decurity information semantic data. More...

class — PmiHoleCalloutDimensionBuilder

Represents a NXOpen::Annotations::PmiHoleCalloutDimensionBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreatePmiHoleCalloutDimensionBuilder 

More...

class — PmiHoleDimension

Represents a PMI hole dimension 

To create or edit an instance of this class, use NXOpen::Annotations::PmiRadialDimensionBuilder 

More...

class — PmiHorizontalDimension

Represents a PMI horizontal dimension 

To create or edit an instance of this class, use NXOpen::Annotations::PmiLinearDimensionBuilder 

More...

class — PmiHorizontalOrdinateDimension

Represents a PMI horizontal ordinate dimension 

To create or edit an instance of this class, use NXOpen::Annotations::PmiOrdinateDimensionBuilder 

More...

class — PmiIdSymbol

Represents an PMI ID symbol 

To create or edit an instance of this class, use NXOpen::Annotations::PmiIdSymbolBuilder 

More...

class — PmiIdSymbolBuilder

Represents a NXOpen::Annotations::PmiIdSymbolBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::IdSymbolCollection::CreatePmiIdSymbolBuilder 

Default values. More...

class — PmiInteger

Represents a Pmi Integer 

To create or edit an instance of this class, use NXOpen::Annotations::PmiIntegerBuilder 

More...

class — PmiIntegerBuilder

Represents a NXOpen::Annotations::PmiInteger builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiIntegerBuilder 

Default values. More...

class — PmiInterpartSelectionBuilder

The interpart selection builder. More...

class — PmiLabel

Represents a PMI label. More...

class — PmiLightweightSectionCollection

Represents a collection of NXOpen::Annotations::LightweightSection objects 

To obtain an instance of this class, refer to NXOpen::Annotations::PmiManager 

More...

class — PmiLinearDimensionBuilder

Represents a NXOpen::Annotations::Dimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreatePmiLinearDimensionBuilder 

More...

class — PmiLineWeld

Represents a PMI line weld 

To create or edit an instance of this class, use NXOpen::Annotations::PmiLineWeldBuilder 

More...

class — PmiLineWeldBuilder

Represents a NXOpen::Annotations::PmiLineWeld builder 

To create a new instance of this class, use NXOpen::Annotations::WeldCollection::CreatePmiLineWeldBuilder 

Default values. More...

class — PmiLineWeldData

Represents PMI Line Weld data. More...

class — PmiLocatorDesignatorData

Represents PMI Locator data. More...

class — PmiMajorAngularDimension

Represents a PMI major angular dimension 

To create or edit an instance of this class, use NXOpen::Annotations::PmiMajorAngularDimensionBuilder 

More...

class — PmiMajorAngularDimensionBuilder

Represents a NXOpen::Annotations::AngularDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreatePmiMajorAngularDimensionBuilder 

More...

class — PmiManager

Represents an object that manages PMI objects. More...

class — PmiMaterialSpecificationData

Represents PMI material specification data. More...

class — PmiMinorAngularDimension

Represents a PMI minor angular dimension 

To create or edit an instance of this class, use NXOpen::Annotations::PmiMinorAngularDimensionBuilder 

More...

class — PmiMinorAngularDimensionBuilder

Represents a NXOpen::Annotations::AngularDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreatePmiMinorAngularDimensionBuilder 

More...

class — PmiNote

Represents a PMI note 

To create or edit an instance of this class, use NXOpen::Annotations::PmiNoteBuilder 

More...

class — PmiNoteBuilder

Represents a NXOpen::Annotations::Note builder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreatePmiNoteBuilder 

More...

class — PmiNoteData

Represents PMI Note semantic data. More...

class — PmiNumber

Represents a Pmi Number 

To create or edit an instance of this class, use NXOpen::Annotations::PmiNumberBuilder 

More...

class — PmiNumberBuilder

Represents a NXOpen::Annotations::PmiNumber builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiNumberBuilder 

Default values. More...

class — PmiOrdinateDimensionBuilder

Represents a NXOpen::Annotations::OrdinateDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreatePmiOrdinateDimensionBuilder 

More...

class — PmiOrdinateOriginDimension

Represents a PMI ordinate origin dimension 

There is no KF creator for this class. More...

class — PmiParallelDimension

Represents a PMI parallel dimension 

To create or edit an instance of this class, use NXOpen::Annotations::PmiLinearDimensionBuilder 

More...

class — PmiPartIdentificationData

Represents PMI Part Identification data. More...

class — PmiPerpendicularDimension

Represents a PMI perpendicular dimension 

To create or edit an instance of this class, use NXOpen::Annotations::PmiLinearDimensionBuilder 

More...

class — PmiPreferences

Represents line and arrow preferences. More...

class — PmiPreferencesBuilder

Represents a NXOpen.Annotations.PmiPreferencesBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::PmiSettingsManager::CreatePreferencesBuilder 

More...

class — PmiProcessSpecificationData

Represents PMI Process Specification Identifier data. More...

class — PmiProductGrid

Represents a pmi product grid 

To create or edit an instance of this class, use NXOpen::Annotations::PmiProductGridBuilder 

More...

class — PmiProductGridBuilder

Represents a NXOpen::Annotations::PmiProductGrid . More...

class — PmiProductGridData

Represents PMI material specification data. More...

class — PmiProprietaryInfoData

Represents PMI proprietary information semantic data. More...

class — PmiRadialDimensionBuilder

Represents a NXOpen::Annotations::Dimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreatePmiRadialDimensionBuilder 

More...

class — PmiRadiusDimension

Represents a PMI radius dimension 

To create or edit an instance of this class, use NXOpen::Annotations::PmiRadialDimensionBuilder 

More...

class — PmiRapidDimensionBuilder

Represents a NXOpen::Annotations::Dimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreatePmiRapidDimensionBuilder 

More...

class — PmiRegionCollection

Represents a collection of NXOpen::Annotations::Region objects 

To obtain an instance of this class, refer to NXOpen::Annotations::PmiManager 

More...

class — PmiRegionData

Represents PMI Region data. More...

class — PmiRegionSettingsBuilder

Represents the Region Settings. More...

class — PmiResizeMethod

Specifies the options for the resize method 

Enumerator — Comment

ViewScale

ZoomFactor

Independent

PartPreferences — Resize using part settings

More...

class — PmiSectionViewCuttingPlaneSymbolBuilder

Represents a NXOpen.Annotations.PmiSectionViewCuttingPlaneSymbolBuilder. More...

class — PmiSectionViewSettingsBuilder

Represents the Lightweight Section View Settings. More...

class — PmiSectionViewViewBuilder

Represents a NXOpen.Annotations.PmiSectionViewViewBuilder. More...

class — PmiSemanticData

Represents PMI semantic data object. More...

class — PmiSemanticGeneralBuilder

Represents a NXOpen::Annotations::PmiSemanticGeneralBuilder. More...

class — PmiSettingsManager

Represents an object that manages PMI objects. More...

class — PmiSfsData

Represents PMI surface finish symbol semantic data object. More...

class — PmiString

Represents a Pmi String 

To create or edit an instance of this class, use NXOpen::Annotations::PmiStringBuilder 

More...

class — PmiStringBuilder

Represents a NXOpen::Annotations::PmiString builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiStringBuilder 

More...

class — PmiSupplementalGeometryProductGridBuilder

Represents a NXOpen::Annotations::PmiSupplementalGeometryProductGridBuilder . More...

class — PmiSupplementalGeometryRegionBuilder

Represents a NXOpen.Annotations.PmiSupplementalGeometryRegionBuilder. More...

class — PmiSurfaceFinishData

Represents PMI Surface Finish Data. More...

class — PmiSurfaceFinishSymbol

Represents PMI Surface Finish Symbol 

To create or edit an instance of this class, use NXOpen::Annotations::PmiSurfaceFinishSymbolBuilder 

More...

class — PmiSurfaceFinishSymbolBuilder

Represents builder for Pmi Surface Finish Symbol 

To create a new instance of this class, use NXOpen::Annotations::PmiSurfaceFinishSymbolCollection::CreatePmiSurfaceFinishSymbolBuilder 

More...

class — PmiSurfaceFinishSymbolCollection

Represents a collection of NXOpen::Annotations::PmiSurfaceFinishSymbol objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — PmiTableBuilder

Represents a NXOpen::Annotations::PmiTableSection builder 

To create a new instance of this class, use NXOpen::Annotations::PmiTableSectionCollection::CreatePmiTableBuilder 

Default values. More...

class — PmiTableSection

Represents a PMI table section 

To create or edit an instance of this class, use NXOpen::Annotations::PmiTableBuilder 

More...

class — PmiTableSectionCollection

Represents a collection of NXOpen::Annotations::PmiTableSection objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — PmiThicknessDimensionBuilder

Represents a NXOpen::Annotations::PmiConcentricCircleDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreatePmiThicknessDimensionBuilder 

More...

class — PmiTrackingPropertiesBuilder

Represents a NXOpen::Annotations::PmiTrackingPropertiesBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreatePmiTrackingPropertiesBuilder 

More...

class — PmiUrlNote

Represents a Pmi url Note 

To create or edit an instance of this class, use NXOpen::Annotations::PmiUrlNoteBuilder 

More...

class — PmiUrlNoteBuilder

Represents a NXOpen::Annotations::PmiUrlNote builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiUrlNoteBuilder 

More...

class — PmiUserDefined

Represents a User Defined Attribute 

To create or edit an instance of this class, use NXOpen::Annotations::PmiUserDefinedBuilder 

More...

class — PmiUserDefinedBuilder

Represents a NXOpen::Annotations::PmiUserDefined builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreatePmiUserDefinedBuilder 

More...

class — PmiVerticalDimension

Represents a PMI vertical dimension 

To create or edit an instance of this class, use NXOpen::Annotations::PmiLinearDimensionBuilder 

More...

class — PmiVerticalOrdinateDimension

Represents a PMI vertical ordinate dimension 

To create or edit an instance of this class, use NXOpen::Annotations::PmiOrdinateDimensionBuilder 

More...

class — PmiWave

Represents a Wave 

To create or edit an instance of this class, use NXOpen::Annotations::PmiWaveLinkBuilder 

More...

class — PmiWaveCollection

Represents a collection of NXOpen::Annotations::PmiWave objects 

To obtain an instance of this class, refer to NXOpen::Annotations::PmiManager 

More...

class — PmiWaveLinkBuilder

Represents a NXOpen::Annotations::Pmi builder 

To create a new instance of this class, use NXOpen::Annotations::PmiWaveCollection::CreatePmiWaveLinkBuilder 

More...

class — PointTarget

Represents point datum target 

To create or edit an instance of this class, use NXOpen::Annotations::PmiDatumTargetBuilder 

More...

class — Polyline

Represents a polyline. More...

class — Polytriangle

Represents a polytriangle. More...

class — Primitive

Represents a primitive object. More...

class — PrimitiveGenerator

Represents Primitive Generator 

More...

class — PrimitiveGeneratorData

Represents Primitive Generator Data. More...

class — ProcessSpecification

Represents a Process Specification 

To create or edit an instance of this class, use NXOpen::Annotations::ProcessSpecificationBuilder 

More...

class — ProcessSpecificationBuilder

Represents a NXOpen::Annotations::ProcessSpecification builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateProcessSpecificationBuilder 

More...

class — ProductGrid

Represents a product grid 

To create or edit an instance of this class, use NXOpen::Annotations::ProductGridBuilder 

More...

class — ProductGridBuilder

Represents a NXOpen::Annotations::ProductGridBuilder . More...

class — ProductGridCollection

Represents a collection of NXOpen::Annotations::BaseProductGrid objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — ProductGridStyleBuilder

Represents a NXOpen::Annotations::ProductGridStyleBuilder . More...

class — QueryPmiBuilder

Represents a NXOpen::Annotations::QueryPmiBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateQueryPmiBuilder 

Default values. More...

class — RadialDimensionBuilder

Represents a NXOpen::Annotations::Dimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateRadialDimensionBuilder 

More...

class — RadialStyleBuilder

Represents a NXOpen::Annotations::RadialStyleBuilder . More...

class — RadiusDimension

Represents a radius dimension 

To create or edit an instance of this class, use NXOpen::Annotations::RadialDimensionBuilder 

More...

class — RadiusDimensionType

Specifies the radius dimension type 

Enumerator — Comment

ToCenter — Radius dimension to center

NotToCenter — Radius dimension not to center

Last — Last enum value.

More...

class — RadiusSymbol

Specifies the radius symbol 

Enumerator — Comment

R — Specifies R symbol

RAD — Specfies RAD symbol

UserDefined — Specfies user defined symbol

SR — Specifes SR symbol

CR — Specifies CR symbol

Last — Last enum value.

More...

class — RapidDimensionBuilder

Represents a NXOpen::Annotations::Dimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateRapidDimensionBuilder 

More...

class — RasterImage

Represents a NXOpen.Annotations.RasterImage class. More...

class — RasterImageBuilder

Represents a raster image builder class 

To create a new instance of this class, use NXOpen::Annotations::DraftingImageCollection::CreateRasterImageBuilder 

More...

class — RectangularTarget

Represents a rectangular datum target 

To create or edit an instance of this class, use NXOpen::Annotations::PmiDatumTargetBuilder 

More...

class — RectangularTargetData

Represents rectangular datum target data. More...

class — ReferenceIncludeType

Specifies the dimension reference include type 

Enumerator — Comment

ValuePrefixTolerance — Value, prefix and tolerance

OnlyValue — Only Value

More...

class — Region

Represents a Region 

To create or edit an instance of this class, use NXOpen::Annotations::RegionBuilder 

More...

class — RegionBuilder

Represents a NXOpen::Annotations::RegionBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::PmiRegionCollection::CreateRegionBuilder 

Default values. More...

class — ReplaceSymbolBuilder

Represents a Builder for Replace Custom Symbol functionality 

To create a new instance of this class, use NXOpen::Annotations::CustomSymbolCollection::CreateReplaceSymbolBuilder 

Default values. More...

class — RetainedAnnotationsBuilder

Represents a NXOpen::Annotations::RetainedAnnotationsBuilder. More...

class — RevisionBusinessModifier

Represents business modifier that applies a revision (in the string format such as -A1) to a PMI. More...

class — RevisionBusinessModifierBuilder

Represents a NXOpen::Annotations::RevisionBusinessModifier builder 

To create a new instance of this class, use NXOpen::Annotations::BusinessModifierCollection::CreateRevisionBusinessModifierBuilder 

More...

class — SafetyClassBusinessModifier

Represents buiness modifier that applies safety classification such as Critical, Major to a PMI. More...

class — SafetyClassBusinessModifierBuilder

Represents a NXOpen::Annotations::SafetyClassBusinessModifier builder 

To create a new instance of this class, use NXOpen::Annotations::BusinessModifierCollection::CreateSafetyClassBusinessModifierBuilder 

More...

class — SearchCriteriaCalloutBuilder

Represents SearchCriteriaCalloutBuilder 

This is a sub-builder class and cannot be directly instantiated 

More...

class — SearchCriteriaDatumFeatureSymbolBuilder

Represents SearchCriteriaDatumFeatureSymbolBuilder 

To create a new instance of this class, use NXOpen::Annotations::SearchModelViewCollection::CreateSearchCriteriaDatumFeatureSymbolBuilder 

More...

class — SearchCriteriaDatumTargetBuilder

Represents SearchCriteriaDatumTargetBuilder 

To create a new instance of this class, use NXOpen::Annotations::SearchModelViewCollection::CreateSearchCriteriaDatumTargetBuilder 

More...

class — SearchCriteriaDimensionBuilder

Represents SearchCriteriaDimensionBuilder 

To create a new instance of this class, use NXOpen::Annotations::SearchModelViewCollection::CreateSearchCriteriaDimensionBuilder 

More...

class — SearchCriteriaFeatureControlFrameBuilder

Represents SearchCriteriaFeatureControlFrameBuilder 

To create a new instance of this class, use NXOpen::Annotations::SearchModelViewCollection::CreateSearchCriteriaFeatureControlFrameBuilder 

More...

class — SearchCriteriaPMINotesBuilder

Represents SearchCriteriaPMINotesBuilder 

To create a new instance of this class, use NXOpen::Annotations::SearchModelViewCollection::CreateSearchCriteriaPminotesBuilder 

More...

class — SearchCriteriaSurfaceFinishBuilder

Represents SearchCriteriaSurfaceFinishBuilder 

To create a new instance of this class, use NXOpen::Annotations::SearchModelViewCollection::CreateSearchCriteriaSurfaceFinishBuilder 

More...

class — SearchModelView

Represents a search model view 

To create or edit an instance of this class, use NXOpen::Annotations::SearchModelViewBuilder 

More...

class — SearchModelViewBuilder

Represents a NXOpen::Annotations::SearchModelViewBuilder 

To create a new instance of this class, use NXOpen::Annotations::SearchModelViewCollection::CreateSearchModelViewBuilder 

Default values. More...

class — SearchModelViewCollection

Represents a collection of NXOpen::Annotations::SearchModelView objects. More...

class — SelectAnnotation

Represents a single object selection. More...

class — SelectAnnotationList

Represents a list of objects on a selection list. More...

class — SelectBaseCustomSymbolList

Represents a list of objects on a selection list. More...

class — SelectBaseEdgeConditionSymbol

Represents a single object selection. More...

class — SelectBaseSurfaceFinishSymbol

Represents a single object selection. More...

class — SelectDimension

Represents a single object selection. More...

class — SelectIdSymbol

Represents a single object selection. More...

class — SelectOrdinateDimensionList

Represents a list of objects on a selection list. More...

class — SelectPmiCadNeutralAnnotationList

Represents a list of objects on a selection list. More...

class — SelectTableSectionList

Represents a list of objects on a selection list. More...

class — SheetMetalPMIBuilder

Represents a Annotations::SheetMetalPMIBuilder builder 

To create a new instance of this class, use NXOpen::Features::SheetMetal::SheetmetalManager::CreateSheetMetalPmiBuilder 

More...

class — SheetMetalPMISettingsBuilder

Represents a NXOpen::Annotations::SheetMetalPMISettingsBuilder . More...

class — ShipDimensionBuilder

Represents a NXOpen::Annotations::Dimension builder 

To create a new instance of this class, use NXOpen::Annotations::ShipDimensionCollection::CreateShipDimensionBuilder 

More...

class — ShipDimensionCollection

Represents a collection of NXOpen::Annotations::Dimension objects 

To obtain an instance of this class, refer to NXOpen::Part 

More...

class — ShipDraftingFramebarGeneralBuilder

Represents a NXOpen::Annotations::ShipDraftingFramebarGeneralBuilder 

This is a sub-builder class and cannot be directly instantiated 

More...

class — ShipFrameBar

Represents a ship frame bar class 

To create or edit an instance of this class, use NXOpen::Annotations::FrameBarBuilder 

More...

class — SimpleDraftingAid

Represents a simple drafting aid. More...

class — SimpleDraftingAidPreferences

Represents simple drafting aid preferences. More...

class — SingleSidedDisplayBuilder

Represents a NXOpen::Annotations::SingleSidedDisplayBuilder . More...

class — SizeLetterCode

Specifies the weld size letter code (ISO and DIN only) 

Enumerator — Comment

NotSet — Specifies no letter code

A — Specifies size letter code "a"

C — Specifies size letter code "c"

D — Specifies size letter code "d"

S — Specifies size letter code "s"

Z — Specifies size letter code "z"

P — Specifies size letter code "P"

Last — Last enum value.

More...

class — SmashCustomSymbolBuilder

Represents a NXOpen::Annotations::SmashCustomSymbolBuilder . More...

class — SpecificNote

Represents a Specific Note 

To create or edit an instance of this class, use NXOpen::Annotations::SpecificNoteBuilder 

More...

class — SpecificNoteBuilder

Represents a NXOpen::Annotations::SpecificNote builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateSpecificNoteBuilder 

More...

class — StackAlignmentPosition

Specifies the site location of a stack 

Enumerator — Comment

Above

Below

Left

Right

More...

class — StackHorizontalAlignment

Specifies the horizontal alignment(left/right alignment) option when aligning annotations within a stack 

Enumerator — Comment

Top — Align horizontally along top edge of text box

Middle — Align horizontally along middle line of text box

Bottom — Align horizontally along bottom edge of text box

More...

class — StackVerticalAlignment

Specifies the vertical alignment(above/below alignment) option when aligning annotations within a stack 

Enumerator — Comment

Left — Align vertically along left edge of text box

Center — Align vertically along center of text box

Right — Align vertically along right edge of text box

More...

class — StubSymbolType

Specifies on what type of symbol is attached to dimension stub 

Enumerator — Comment

NotSet — None

AllAround — All around symbol

AllOver — All over symbol

More...

class — StyleBuilder

Represents a NXOpen::Annotations::StyleBuilder . More...

class — SupplementarySymbol

Specifies the supplementary weld symbol 

Enumerator — Comment

NotSet — Specifies no supplementary weld symbol

Convex — Specifies convex supplementary weld symbol

Flush — Specifies flush supplementary weld symbol

Concave — Specifies concave supplementary weld symbol

BlendedToes — Specifies blended toes supplementary weld symbol

BackingStripPermanent — Specifies backing strip permanent supplementary weld symbol

BackingStripRemovable — Specifies backing strip removable supplementary weld symbol

MeltThrough — Specifies melt through supplementary weld symbol

Last — Last enum value.

More...

class — SuppressPMIBuilder

Represents Annotations.SuppressPMIBuilder. More...

class — SurfaceFinish

Represents a PMI Surface Finish 

To create or edit an instance of this class, use NXOpen::Annotations::SurfaceFinishBuilder 

More...

class — SurfaceFinishBuilder

Represents a NXOpen::Annotations::SurfaceFinish builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateSurfaceFinishBuilder 

More...

class — SurfaceFinishStandard

Specifies the drafting surface finish standard type 

Enumerator — Comment

Ansi — ANSI

Iso — ISO

Jis — JIS

Din — DIN

Iso2002 — ISO 2002

Din2002 — DIN 2002

Gb — GB131-93

Eskd — ESKD

Iso2021 — ISO 2021

Iso25178 — ISO 25178-1

More...

class — Symbol

Specifies the elementary weld symbol 

Enumerator — Comment

NotSet — Speifies no weld symbol

ButtWithRaisedEdges — Specifies butt weld with raised edges

SingleFlange — Specifiies single flange weld symbol (JIS only)

SquareButt — Specifies square butt weld symbol

VButt — Specifies V butt weld symbol

VButtBroadRootFace — Specifies V butt with broad root face weld symbol (ISO and DIN only)

BevelButt — Specifies bevel butt weld symbol

BevelButtBroadRootFace — Specifies bevel butt with broad root face weld symbol (ISO and DIN only)

UButt — Specifies U butt weld symbol

JButt — Specifies J buttt weld symbol

FlareV — Specifies flare V weld symbol

FlareBevel — Specifies flare bevel weld symbol

KGroove — Specifies K-Groove weld symbol

Fillet — Specifies fillet weld symbol

Stake — Specifies fillet weld symbol

PlugSlot — Specifies plug/slot weld symbol

Edge — Specifies edge weld symbol

Edge2 — Specifies edge2 weld symbol

Spot — Specifies spot weld symbol

Spot2 — Specifies spot2 weld symbol

Seam — Specfies seam weld symbol

Seam2 — Specfies seam2 weld symbol

SteepFlankedV — Specifies steep flanked V butt weld symbol (ISO and DIN only)

SteepFlankedBevel — Specifies steeep flanked bevel butt weld symbol ( ISO and DIN only)

Backing — Specifies backing weld symbol (only one side of reference line )

SurfaceJoint — Specifies surface joint weld symbol (ISO and DIN only )

SolderedJoint — Specifies soldered joint weld symbol

InclinedJoint — Specifies inclined joint weld symbol

FoldJoint — Specifies fold joint weld symbol (ISO and DIN only, only on one side of reference line)

Stud — Specifies stud weld symbol (Arrow side only )

Surfacing — Specifies surfacing weld symbol (ISO and DIN only)

Intermittent — Specifies intermittent weld symbol (ESKD only)

BackingPlate — Specifies backing plate weld symbol (GB only)

NotSpecified — Specifies weld symbol not specified

Last — Last enum value.

More...

class — SymbolCatalogBuilder

Represents a builder to instantiate a symbol from a parameterized family of standard symbols defined in catalogs, e.g. More...

class — SymbolCatalogParameterBuilder

This builder allows you to define one parameter for a symbol 

To create a new instance of this class, use NXOpen::Annotations::SymbolCatalogBuilder::NewParameter 

More...

class — SymbolCatalogParameterBuilderList

Represents a list of objects. More...

class — SymbolFile

Represents a symbolFile 

To create or edit an instance of this class, use NXOpen::Annotations::SymbolFileBuilder 

More...

class — SymbolFileBuilder

Represents builder for drafting Symbol file builder 

To create a new instance of this class, use NXOpen::Annotations::SymbolFileCollection::CreateSymbolFileBuilder 

More...

class — SymbolFileCollection

Represents a collection of NXOpen::Annotations::SymbolFile objects 

Use NXOpen::Annotations::SymbolFile to get the instance of this class. More...

class — SymbolPreferences

Represents symbol preferences. More...

class — SymbolPreferencesOption

Specifies the custom symbol preferences for the following - 

Crosshatch 

Area fill 

Color, font and line width 

This option is only available when creating. More...

class — SymbolStyleBuilder

Represents a NXOpen::Annotations::SymbolStyleBuilder . More...

class — SymbolWorkflowBuilder

Represents a NXOpen::Annotations::SymbolWorkflowBuilder. More...

class — SymmetricalCenterline

Represents a Symmetrical Centerline 

To create or edit an instance of this class, use NXOpen::Annotations::SymmetricalCenterlineBuilder 

More...

class — SymmetricalCenterlineBuilder

Builder for creating Symmetrical Centerline. More...

class — SymmetricalCenterlineSettingsBuilder

Represents a Builder for Symmetrical Centerline Settings. More...

class — Table

Represents a NXOpen::Annotations::Table . More...

class — TableCellStyleBuilder

Represents a NXOpen::Annotations::TableCellStyleBuilder . More...

class — TableCollection

Represents a collection of NXOpen::Annotations::Table objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — TableColumnBuilder

Represents a. More...

class — TableColumnBuilderList

Represents a list of objects. More...

class — TableColumnSettingsBuilder

Represents a Annotations::TableColumnSettingsBuilder . More...

class — TableCommonSortingBuilder

Represents a. More...

class — TableEditSettingsBuilder

Represents a NXOpen::Annotations::TableEditSettingsBuilder . More...

class — TableRowSortingBuilder

Represents a Annotations::TableRowSortingBuilder . More...

class — TableSection

Represents a NXOpen::Annotations::TableSection . More...

class — TableSectionBuilder

Represents a NXOpen::Annotations::TableSection builder 

To create a new instance of this class, use NXOpen::Annotations::TableSectionCollection::CreateTableSectionBuilder 

Default values. More...

class — TableSectionCollection

Represents a collection of NXOpen::Annotations::TableSection objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — TableSectionStyleBuilder

Represents a NXOpen::Annotations::TableSectionStyleBuilder . More...

class — TableStyleBuilder

Represents a NXOpen::Annotations::TableStyleBuilder . More...

class — TabularNoteStyleBuilder

Represents a NXOpen::Annotations::TabularNoteStyleBuilder . More...

class — Tail

Specifies the weld tail for the reference line 

Enumerator — Comment

NotSet — Specifies no tail

Fork — Specifies fork tail

Box — Specifies box tail

Last — Last enum value.

More...

class — TargetPoint

Represents a target point 

To create or edit an instance of this class, use NXOpen::Annotations::TargetPointBuilder 

More...

class — TargetPointBuilder

Represents a NXOpen::Annotations::TargetPoint builder 

To create a new instance of this class, use NXOpen::Annotations::TargetPointCollection::CreateTargetPointBuilder 

Default values. More...

class — TargetPointCollection

Represents a collection of NXOpen::Annotations::TargetPoint objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — TextCfw

Specifies color, font, and width for text. More...

class — TextComponent

Represents a single text in an annotation and can be queried for information about that text. More...

class — TextEditorBuilder

Represents a NXOpen::Annotations::TextEditorBuilder builder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateTextEditorBuilder 

Default values. More...

class — TextJustification

Represents the horizontal text justification 

Enumerator — Comment

Left

Center

Right

More...

class — TextOrientation

Specifies the dimension text orientation 

Enumerator — Comment

Horizontal — Specifies horizontal dimension text

Aligned — Specifies dimenson text aligned with the dimension line

OverDimensionLine — Specifies dimenson text aligned with and above the dimension line

ByAngle — Specifies dimension text at angle

Perpendicular — Specifies dimension text perpendicular to the dimension line

SplitByDimensionLine — Specifies dimenson text split by the dimension line

Last — Last enum value.

More...

class — TextPlacement

Specifies the dimension text placement 

Enumerator — Comment

Automatic — Specifies automatic text placement

ManualArrowsIn — Specifies manual text placement with arrows inside the extension lines

ManualArrowsOut — Specifies manual text placement with arrows outside the extension lines

ManualArrowsInSameDirection — Specifies manual text placement with arrows in the same direction

Last — Last enum value.

More...

class — TextPosition

Specifies the dimension text position 

Enumerator — Comment

AfterStub — Specifies text position after stub

AboveStub — Specifies text position above stub

Last — Last enum value.

More...

class — TextPreferencesOption

Specifies the custom symbol text preferences option. More...

class — TextType

Specifies the custom symbol text type 

Enumerator — Comment

Mandatory — Specifies text defined in the master symbol which can't be modified in the custom symbol.

More...

class — TextWithEditControlsBuilder

Represents a NXOpen::Annotations::TextWithEditControlsBuilder which collects internationalized text strings from the user for processing on an annotation object. More...

class — TextWithSymbolsBuilder

Represents a NXOpen::Annotations::TextWithSymbolsBuilder which collects internationalized text strings from the user for processing on an annotation object. More...

class — ThicknessDimensionBuilder

Represents a NXOpen::Annotations::ConcentricCircleDimension builder 

To create a new instance of this class, use NXOpen::Annotations::DimensionCollection::CreateThicknessDimensionBuilder 

More...

class — TitleBlock

Represents a NXOpen::Annotations::TitleBlock 

To create or edit an instance of this class, use NXOpen::Annotations::DefineTitleBlockBuilder 

More...

class — TitleBlockCellBuilder

Represents a NXOpen::Annotations::TitleBlockCellBuilder 

To create a new instance of this class, use NXOpen::Annotations::TitleBlockCollection::CreateCellBuilder 

More...

class — TitleBlockCellBuilderList

Represents a list of objects. More...

class — TitleBlockCollection

Represents a collection of NXOpen::Annotations::TitleBlock . More...

class — TitleBlockPreferences

Represents title_block preferences. More...

class — TolerancePlacement

Specifies the tolerance text placement relative to the dimension text 

Enumerator — Comment

Below — Specifies tolerance below dimension text

After — Specifies tolerance after dimension text

Above — Specifies tolerance above dimension text

Last — Last enum value.

More...

class — ToleranceType

Specifies the tolerance type 

Enumerator — Comment

NotSet — No tolerance

LimitOneLine — -LIM +LIM

LimitTwoLines — +LIM 

-LIM 

BilateralOneLine — +-TOL

BilateralTwoLines — +TOL 

-TOL 

UnilateralAbove — +TOL 

-.000 

UnilateralBelow — +.000 

-TOL 

Basic — |xxx|

Reference — (xxx)

LimitLargerFirst — +LIM -LIM

LimitLargerBelow — -LIM 

+LIM 

LimitsAndFits — A5

NotToScale — xxx 

DiameterReference — (DIA xxx)

BasicNotToScale — |xxx| —

SingleLimitMax — MAX

SingleLimitMin — MIN

More...

class — ToleranceZoneShape

Specifies the tolerance zone shape 

Enumerator — Comment

Planar — Specifies planar zone shape

Cylindrical — Specifies cylindrical zone shape

Spherical — Specifies spherical zone shape

Last — Last enum value.

More...

class — TrimDimensionLineStyle

Specifies the dimension trim dimension line style. More...

class — TrueLengthTextPosition

Specifies the True Length Text position 

Enumerator — Comment

NotSet — Do not display True Length Text

Prefix — Display True Length Text before dimension value

Suffix — Display True Length Text after dimension value

More...

class — UnitsFormatPreferences

Represents units and format preferences. More...

class — UnitsStyleBuilder

Represents a NXOpen::Annotations::UnitsStyleBuilder . More...

class — UrlBusinessModifier

Represents business modifier that applies an URL to a PMI. More...

class — UrlBusinessModifierBuilder

Represents a NXOpen::Annotations::UrlBusinessModifier builder 

To create a new instance of this class, use NXOpen::Annotations::BusinessModifierCollection::CreateUrlBusinessModifierBuilder 

More...

class — UserSymbolPreferences

Represents preferences related to user-defined symbols. More...

class — Value

Specifies the value data. More...

class — VerticalDimension

Represents a vertical dimension 

To create or edit an instance of this class, use NXOpen::Annotations::LinearDimensionBuilder 

More...

class — VerticalOrdinateDimension

Represents a vertical ordinate dimension 

To create or edit an instance of this class, use NXOpen::Annotations::OrdinateDimensionBuilder 

More...

class — VerticalOrdinateMargin

Represents a vertical ordinate margin. More...

class — VerticalTextJustification

Represents the vertical text justification 

Enumerator — Comment

Top

Middle

Bottom

More...

class — Weld

Represents a weld 

To obtain an instance of this class, use NXOpen::Annotations::WeldCollection 

More...

class — WeldCollection

Represents a collection of NXOpen::Annotations::Weld objects 

To obtain an instance of this class, refer to NXOpen::Annotations::AnnotationManager 

More...

class — WeldStandard

Specifies the weld standard 

Enumerator — Comment

Ansi — ANSI standard

Din — DIN standard

Jis — JIS standard

Iso — ISO standard

Eskd — ESKD standard

Gb — GB standard

Last — Last enum value.

More...

class — ZeroToleranceDisplayStyle

Specifies the 0 tolerance display style 

Enumerator — Comment

BasedOnUnits — Zero tolerance display is tied to display units

AsZero — Always display zero tolerance as 0

OmittedAndInlined — Omit the display of zero tolerance and inline the remaining tolerance

Omitted — Omit the display of zero tolerance and maintain position of remaining tolerance

More...

## Detailed Description

Classes, Enums and Structs under NXOpen.Annotations namespace. 

Copyright 2025 Siemens
