# NXOpen.Annotations.BaseHoleCalloutDimensionBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00133.html>

## Classes

class — HolecalloutType

holecallout type for the hole callout dimension. More...

Copyright 2025 Siemens
