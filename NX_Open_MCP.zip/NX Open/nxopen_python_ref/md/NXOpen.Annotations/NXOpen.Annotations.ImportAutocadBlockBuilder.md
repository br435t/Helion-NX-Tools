# NXOpen.Annotations.ImportAutocadBlockBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00171.html>

## Classes

class — EntityType

Represents the Import Entity Type. More...

class — FileFolder

the Selection mode Enum 

Enumerator — Comment

File — File Selection mode

Folder — Folder Selection mode

More...

class — Type

Symbol Type Enum. More...

Copyright 2025 Siemens
