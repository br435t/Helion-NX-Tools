# NXOpen.Annotations.FcfDatumReference Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12197.html>

Represents a NXOpen::Annotations::FcfDatumReference. 
More...

Inheritance diagram for NXOpen.Annotations.FcfDatumReference:

## Additional Inherited Members

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::FcfDatumReference. 

Created in NX6.0.0 

Copyright 2025 Siemens
