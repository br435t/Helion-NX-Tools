# NXOpen.Annotations.PartsListBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00185.html>

## Classes

class — PartsListGrowDirectionOptions

Grow direction options The options specify the direction of growth for the parts list. More...

class — PartsListMainSymbolText

Main Symbol Text Types Specifies the text to display in the main callout symbol. More...

class — PartsListReferenceSymbolText

Reference Symbol Text Types Specifies the text to display in the reference callout symbol. More...

class — PartsListShowLockedDeletedRows

Locked deleted rows options The options specify how to show rows that are locked, but reference components that have been removed from the assembly. More...

class — PartsListSymbolType

Symbol Types The types specify the balloon type used to call out members. More...

class — PartsListVerticalGroupLeaderAttachment

Represents leader attachment for vertical callout groups. More...

Copyright 2025 Siemens
