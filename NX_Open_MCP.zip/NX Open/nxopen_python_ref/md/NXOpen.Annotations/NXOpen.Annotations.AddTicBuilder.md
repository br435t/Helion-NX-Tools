# NXOpen.Annotations.AddTicBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11057.html>

Represents a NXOpen::Annotations::AddTicBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.AddTicBuilder:

## Public Member Functions

HideTic (self, ticIdentifier)

Hide a tic use the tic identifier. 

SelectTic (self, index)

Stores index of the tic for adding the tic. 

ShowTic (self, ticIdentifier)

Show a tic use the tic identifier. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::AddTicBuilder . 

This class allows to create Add Tic 

To create a new instance of this class, use NXOpen::Annotations::FrameBarCollection::CreateAddTicBuilder 

Created in NX8.0.0 

## Member Function Documentation

## ◆ HideTic()

NXOpen.Annotations.AddTicBuilder.HideTic
(
self,

ticIdentifier )

Hide a tic use the tic identifier. 

Created in NX2007.0.0 

License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Parameters

ticIdentifier — (str) identifier of deselected tic

## ◆ SelectTic()

NXOpen.Annotations.AddTicBuilder.SelectTic
(
self,

index )

Stores index of the tic for adding the tic. 

Created in NX8.0.0 

License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Parameters

index — (int) index of selected tic

## ◆ ShowTic()

NXOpen.Annotations.AddTicBuilder.ShowTic
(
self,

ticIdentifier )

Show a tic use the tic identifier. 

Created in NX2007.0.0 

License requirements: nx_ship_gen_arrange ("Ship General Arrangement") OR nx_ship_basic ("Ship Basic Design") OR nx_ship_detail ("Ship Detail Design") OR nx_ship_mfg_prep ("Ship Manufacturing")

Parameters

ticIdentifier — (str) identifier of selected tic

Copyright 2025 Siemens
