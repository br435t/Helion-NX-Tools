# NXOpen.Annotations.BendTableSettingsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00137.html>

## Classes

class — ColumnType

This enum represents the type of the column in the bend table 

Enumerator — Comment

BendID — Bend ID

BendName — Bend Name

BendRadius — Bend Radius

BendAngle — Bend Angle

BendDirection — Bend Direction

IncludedAngle — Included Angle

More...

Copyright 2025 Siemens
