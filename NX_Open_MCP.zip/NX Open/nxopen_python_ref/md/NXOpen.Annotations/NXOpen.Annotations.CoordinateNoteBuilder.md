# NXOpen.Annotations.CoordinateNoteBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11769.html>

Represents a NXOpen::Annotations::CoordinateNote builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateCoordinateNoteBuilder 

Default values. 
More...

Inheritance diagram for NXOpen.Annotations.CoordinateNoteBuilder:

## Public Member Functions

Category (self)

Getter for property: (str) Category Returns the category. 

Category (self, category)

Setter for property: (str) Category. 

DecimalPlace (self)

Getter for property: (int) DecimalPlace Returns the decimal place for coordinate note display. 

DecimalPlace (self, decimalPlace)

Setter for property: (int) DecimalPlace. 

Identifier (self)

Getter for property: (str) Identifier Returns the identifier. 

Identifier (self, identifier)

Setter for property: (str) Identifier. 

Revision (self)

Getter for property: (str) Revision Returns the revision. 

Revision (self, revision)

Setter for property: (str) Revision. 

StringPrefixI (self)

Getter for property: (str) StringPrefixI Returns the string prefix i. 

StringPrefixI (self, stringPrefixI)

Setter for property: (str) StringPrefixI. 

StringPrefixJ (self)

Getter for property: (str) StringPrefixJ Returns the string prefix j. 

StringPrefixJ (self, stringPrefixJ)

Setter for property: (str) StringPrefixJ. 

StringPrefixK (self)

Getter for property: (str) StringPrefixK Returns the string prefix k. 

StringPrefixK (self, stringPrefixK)

Setter for property: (str) StringPrefixK. 

StringPrefixLabel (self)

Getter for property: (str) StringPrefixLabel Returns the string prefix label. 

StringPrefixLabel (self, stringPrefixLabel)

Setter for property: (str) StringPrefixLabel. 

StringPrefixLevel (self)

Getter for property: (str) StringPrefixLevel Returns the string prefix level. 

StringPrefixLevel (self, stringPrefixLevel)

Setter for property: (str) StringPrefixLevel. 

StringPrefixX (self)

Getter for property: (str) StringPrefixX Returns the string prefix x. 

StringPrefixX (self, stringPrefixX)

Setter for property: (str) StringPrefixX. 

StringPrefixY (self)

Getter for property: (str) StringPrefixY Returns the string prefix y. 

StringPrefixY (self, stringPrefixY)

Setter for property: (str) StringPrefixY. 

StringPrefixZ (self)

Getter for property: (str) StringPrefixZ Returns the string prefix z. 

StringPrefixZ (self, stringPrefixZ)

Setter for property: (str) StringPrefixZ. 

StringSuffixI (self)

Getter for property: (str) StringSuffixI Returns the string suffix i. 

StringSuffixI (self, stringSuffixI)

Setter for property: (str) StringSuffixI. 

StringSuffixJ (self)

Getter for property: (str) StringSuffixJ Returns the string suffix j. 

StringSuffixJ (self, stringSuffixJ)

Setter for property: (str) StringSuffixJ. 

StringSuffixK (self)

Getter for property: (str) StringSuffixK Returns the string suffix k. 

StringSuffixK (self, stringSuffixK)

Setter for property: (str) StringSuffixK. 

StringSuffixLabel (self)

Getter for property: (str) StringSuffixLabel Returns the string suffix label. 

StringSuffixLabel (self, stringSuffixLabel)

Setter for property: (str) StringSuffixLabel. 

StringSuffixLevel (self)

Getter for property: (str) StringSuffixLevel Returns the string suffix level. 

StringSuffixLevel (self, stringSuffixLevel)

Setter for property: (str) StringSuffixLevel. 

StringSuffixX (self)

Getter for property: (str) StringSuffixX Returns the string suffix x. 

StringSuffixX (self, stringSuffixX)

Setter for property: (str) StringSuffixX. 

StringSuffixY (self)

Getter for property: (str) StringSuffixY Returns the string suffix y. 

StringSuffixY (self, stringSuffixY)

Setter for property: (str) StringSuffixY. 

StringSuffixZ (self)

Getter for property: (str) StringSuffixZ Returns the string suffix z. 

StringSuffixZ (self, stringSuffixZ)

Setter for property: (str) StringSuffixZ. 

Title (self)

Getter for property: (str) Title Returns the str title. 

Title (self, title)

Setter for property: (str) Title. 

ToggleI (self)

Getter for property: (bool) ToggleI Returns the toggle i. 

ToggleI (self, toggleI)

Setter for property: (bool) ToggleI. 

ToggleJ (self)

Getter for property: (bool) ToggleJ Returns the toggle j. 

ToggleJ (self, toggleJ)

Setter for property: (bool) ToggleJ. 

ToggleK (self)

Getter for property: (bool) ToggleK Returns the toggle k. 

ToggleK (self, toggleK)

Setter for property: (bool) ToggleK. 

ToggleLabel (self)

Getter for property: (bool) ToggleLabel Returns the toggle label. 

ToggleLabel (self, toggleLabel)

Setter for property: (bool) ToggleLabel. 

ToggleLevel (self)

Getter for property: (bool) ToggleLevel Returns the toggle level. 

ToggleLevel (self, toggleLevel)

Setter for property: (bool) ToggleLevel. 

ToggleX (self)

Getter for property: (bool) ToggleX Returns the toggle x. 

ToggleX (self, toggleX)

Setter for property: (bool) ToggleX. 

ToggleY (self)

Getter for property: (bool) ToggleY Returns the toggle y. 

ToggleY (self, toggleY)

Setter for property: (bool) ToggleY. 

ToggleZ (self)

Getter for property: (bool) ToggleZ Returns the toggle z. 

ToggleZ (self, toggleZ)

Setter for property: (bool) ToggleZ. 

TrackingCsys (self)

Getter for property: (NXOpen.CoordinateSystem) TrackingCsys Returns the tracking csys. 

TrackingCsys (self, trackingCsys)

Setter for property: (NXOpen.CoordinateSystem) TrackingCsys. 

TrackingPoint (self)

Getter for property: (NXOpen.Point) TrackingPoint Returns the tracking point. 

TrackingPoint (self, trackingPoint)

Setter for property: (NXOpen.Point) TrackingPoint. 

Public Member Functions inherited from NXOpen.Annotations.PmiAttributeBuilder

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the NXOpen::Annotations::AssociatedObjectsBuilder for the annotation. 

Attribute (self)

Getter for property: (NXOpen.Annotations.Pmi) Attribute Returns the NXOpen::Annotations::Pmi for this annotation. 

Attribute (self, attribute)

Setter for property: (NXOpen.Annotations.Pmi) Attribute. 

BusinessModifier (self)

Getter for property: (NXOpen.NXObject) BusinessModifier Returns the business modifier. 

BusinessModifier (self, businessModifier)

Setter for property: (NXOpen.NXObject) BusinessModifier. 

GetAttributeValues (self)

Returns the attribute values. 

KnowledgeFusionClassName (self)

Getter for property: (str) KnowledgeFusionClassName Returns the knowledge fusion class name file, the default class is UG provided pmi KF class. 

KnowledgeFusionClassName (self, knowledgeFusionClassName)

Setter for property: (str) KnowledgeFusionClassName. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the NXOpen::Annotations::OriginBuilder for the annotation. 

SetAttributeValues (self, attributeValues)

Sets the attribute values. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the NXOpen::Annotations::StyleBuilder for the annotation. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::CoordinateNote builder 

To create a new instance of this class, use NXOpen::Annotations::PmiAttributeCollection::CreateCoordinateNoteBuilder 

Default values. 

Property — Value

ToggleI 

0 

ToggleJ 

0 

ToggleK 

0 

ToggleLabel 

0 

ToggleLevel 

0 

ToggleX 

0 

ToggleY 

0 

ToggleZ 

0 

Created in NX6.0.0 

## Member Function Documentation

## ◆ Category() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.Category
(
self — )

Getter for property: (str) Category Returns the category. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Category() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.Category
(
self,

category )

Setter for property: (str) Category. 

Sets the category

Setter License requirements: None.

Created in NX6.0.0 

## ◆ DecimalPlace() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.DecimalPlace
(
self — )

Getter for property: (int) DecimalPlace Returns the decimal place for coordinate note display. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
int 

## ◆ DecimalPlace() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.DecimalPlace
(
self,

decimalPlace )

Setter for property: (int) DecimalPlace. 

Sets the decimal place for coordinate note display

Setter License requirements: None.

Created in NX6.0.0 

## ◆ Identifier() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.Identifier
(
self — )

Getter for property: (str) Identifier Returns the identifier. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Identifier() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.Identifier
(
self,

identifier )

Setter for property: (str) Identifier. 

Sets the identifier

Setter License requirements: None.

Created in NX6.0.0 

## ◆ Revision() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.Revision
(
self — )

Getter for property: (str) Revision Returns the revision. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Revision() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.Revision
(
self,

revision )

Setter for property: (str) Revision. 

Sets the revision

Setter License requirements: None.

Created in NX6.0.0 

## ◆ StringPrefixI() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringPrefixI
(
self — )

Getter for property: (str) StringPrefixI Returns the string prefix i. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ StringPrefixI() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringPrefixI
(
self,

stringPrefixI )

Setter for property: (str) StringPrefixI. 

Sets the string prefix i

Setter License requirements: None.

Created in NX6.0.0 

## ◆ StringPrefixJ() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringPrefixJ
(
self — )

Getter for property: (str) StringPrefixJ Returns the string prefix j. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ StringPrefixJ() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringPrefixJ
(
self,

stringPrefixJ )

Setter for property: (str) StringPrefixJ. 

Sets the string prefix j

Setter License requirements: None.

Created in NX6.0.0 

## ◆ StringPrefixK() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringPrefixK
(
self — )

Getter for property: (str) StringPrefixK Returns the string prefix k. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ StringPrefixK() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringPrefixK
(
self,

stringPrefixK )

Setter for property: (str) StringPrefixK. 

Sets the string prefix k

Setter License requirements: None.

Created in NX6.0.0 

## ◆ StringPrefixLabel() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringPrefixLabel
(
self — )

Getter for property: (str) StringPrefixLabel Returns the string prefix label. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ StringPrefixLabel() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringPrefixLabel
(
self,

stringPrefixLabel )

Setter for property: (str) StringPrefixLabel. 

Sets the string prefix label

Setter License requirements: None.

Created in NX6.0.0 

## ◆ StringPrefixLevel() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringPrefixLevel
(
self — )

Getter for property: (str) StringPrefixLevel Returns the string prefix level. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ StringPrefixLevel() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringPrefixLevel
(
self,

stringPrefixLevel )

Setter for property: (str) StringPrefixLevel. 

Sets the string prefix level

Setter License requirements: None.

Created in NX6.0.0 

## ◆ StringPrefixX() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringPrefixX
(
self — )

Getter for property: (str) StringPrefixX Returns the string prefix x. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ StringPrefixX() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringPrefixX
(
self,

stringPrefixX )

Setter for property: (str) StringPrefixX. 

Sets the string prefix x

Setter License requirements: None.

Created in NX6.0.0 

## ◆ StringPrefixY() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringPrefixY
(
self — )

Getter for property: (str) StringPrefixY Returns the string prefix y. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ StringPrefixY() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringPrefixY
(
self,

stringPrefixY )

Setter for property: (str) StringPrefixY. 

Sets the string prefix y

Setter License requirements: None.

Created in NX6.0.0 

## ◆ StringPrefixZ() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringPrefixZ
(
self — )

Getter for property: (str) StringPrefixZ Returns the string prefix z. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ StringPrefixZ() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringPrefixZ
(
self,

stringPrefixZ )

Setter for property: (str) StringPrefixZ. 

Sets the string prefix z

Setter License requirements: None.

Created in NX6.0.0 

## ◆ StringSuffixI() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringSuffixI
(
self — )

Getter for property: (str) StringSuffixI Returns the string suffix i. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ StringSuffixI() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringSuffixI
(
self,

stringSuffixI )

Setter for property: (str) StringSuffixI. 

Sets the string suffix i

Setter License requirements: None.

Created in NX6.0.0 

## ◆ StringSuffixJ() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringSuffixJ
(
self — )

Getter for property: (str) StringSuffixJ Returns the string suffix j. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ StringSuffixJ() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringSuffixJ
(
self,

stringSuffixJ )

Setter for property: (str) StringSuffixJ. 

Sets the string suffix j

Setter License requirements: None.

Created in NX6.0.0 

## ◆ StringSuffixK() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringSuffixK
(
self — )

Getter for property: (str) StringSuffixK Returns the string suffix k. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ StringSuffixK() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringSuffixK
(
self,

stringSuffixK )

Setter for property: (str) StringSuffixK. 

Sets the string suffix k

Setter License requirements: None.

Created in NX6.0.0 

## ◆ StringSuffixLabel() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringSuffixLabel
(
self — )

Getter for property: (str) StringSuffixLabel Returns the string suffix label. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ StringSuffixLabel() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringSuffixLabel
(
self,

stringSuffixLabel )

Setter for property: (str) StringSuffixLabel. 

Sets the string suffix label

Setter License requirements: None.

Created in NX6.0.0 

## ◆ StringSuffixLevel() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringSuffixLevel
(
self — )

Getter for property: (str) StringSuffixLevel Returns the string suffix level. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ StringSuffixLevel() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringSuffixLevel
(
self,

stringSuffixLevel )

Setter for property: (str) StringSuffixLevel. 

Sets the string suffix level

Setter License requirements: None.

Created in NX6.0.0 

## ◆ StringSuffixX() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringSuffixX
(
self — )

Getter for property: (str) StringSuffixX Returns the string suffix x. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ StringSuffixX() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringSuffixX
(
self,

stringSuffixX )

Setter for property: (str) StringSuffixX. 

Sets the string suffix x

Setter License requirements: None.

Created in NX6.0.0 

## ◆ StringSuffixY() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringSuffixY
(
self — )

Getter for property: (str) StringSuffixY Returns the string suffix y. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ StringSuffixY() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringSuffixY
(
self,

stringSuffixY )

Setter for property: (str) StringSuffixY. 

Sets the string suffix y

Setter License requirements: None.

Created in NX6.0.0 

## ◆ StringSuffixZ() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringSuffixZ
(
self — )

Getter for property: (str) StringSuffixZ Returns the string suffix z. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ StringSuffixZ() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.StringSuffixZ
(
self,

stringSuffixZ )

Setter for property: (str) StringSuffixZ. 

Sets the string suffix z

Setter License requirements: None.

Created in NX6.0.0 

## ◆ Title() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.Title
(
self — )

Getter for property: (str) Title Returns the str title. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ Title() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.Title
(
self,

title )

Setter for property: (str) Title. 

Sets the str title

Setter License requirements: None.

Created in NX6.0.0 

## ◆ ToggleI() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.ToggleI
(
self — )

Getter for property: (bool) ToggleI Returns the toggle i. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ ToggleI() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.ToggleI
(
self,

toggleI )

Setter for property: (bool) ToggleI. 

Sets the toggle i

Setter License requirements: None.

Created in NX6.0.0 

## ◆ ToggleJ() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.ToggleJ
(
self — )

Getter for property: (bool) ToggleJ Returns the toggle j. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ ToggleJ() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.ToggleJ
(
self,

toggleJ )

Setter for property: (bool) ToggleJ. 

Sets the toggle j

Setter License requirements: None.

Created in NX6.0.0 

## ◆ ToggleK() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.ToggleK
(
self — )

Getter for property: (bool) ToggleK Returns the toggle k. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ ToggleK() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.ToggleK
(
self,

toggleK )

Setter for property: (bool) ToggleK. 

Sets the toggle k

Setter License requirements: None.

Created in NX6.0.0 

## ◆ ToggleLabel() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.ToggleLabel
(
self — )

Getter for property: (bool) ToggleLabel Returns the toggle label. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ ToggleLabel() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.ToggleLabel
(
self,

toggleLabel )

Setter for property: (bool) ToggleLabel. 

Sets the toggle label

Setter License requirements: None.

Created in NX6.0.0 

## ◆ ToggleLevel() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.ToggleLevel
(
self — )

Getter for property: (bool) ToggleLevel Returns the toggle level. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ ToggleLevel() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.ToggleLevel
(
self,

toggleLevel )

Setter for property: (bool) ToggleLevel. 

Sets the toggle level

Setter License requirements: None.

Created in NX6.0.0 

## ◆ ToggleX() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.ToggleX
(
self — )

Getter for property: (bool) ToggleX Returns the toggle x. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ ToggleX() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.ToggleX
(
self,

toggleX )

Setter for property: (bool) ToggleX. 

Sets the toggle x

Setter License requirements: None.

Created in NX6.0.0 

## ◆ ToggleY() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.ToggleY
(
self — )

Getter for property: (bool) ToggleY Returns the toggle y. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ ToggleY() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.ToggleY
(
self,

toggleY )

Setter for property: (bool) ToggleY. 

Sets the toggle y

Setter License requirements: None.

Created in NX6.0.0 

## ◆ ToggleZ() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.ToggleZ
(
self — )

Getter for property: (bool) ToggleZ Returns the toggle z. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
bool 

## ◆ ToggleZ() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.ToggleZ
(
self,

toggleZ )

Setter for property: (bool) ToggleZ. 

Sets the toggle z

Setter License requirements: None.

Created in NX6.0.0 

## ◆ TrackingCsys() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.TrackingCsys
(
self — )

Getter for property: (NXOpen.CoordinateSystem) TrackingCsys Returns the tracking csys. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.CoordinateSystem 

## ◆ TrackingCsys() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.TrackingCsys
(
self,

trackingCsys )

Setter for property: (NXOpen.CoordinateSystem) TrackingCsys. 

Sets the tracking csys

Setter License requirements: None.

Created in NX6.0.0 

## ◆ TrackingPoint() [1/2]

NXOpen.Annotations.CoordinateNoteBuilder.TrackingPoint
(
self — )

Getter for property: (NXOpen.Point) TrackingPoint Returns the tracking point. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.Point 

## ◆ TrackingPoint() [2/2]

NXOpen.Annotations.CoordinateNoteBuilder.TrackingPoint
(
self,

trackingPoint )

Setter for property: (NXOpen.Point) TrackingPoint. 

Sets the tracking point

Setter License requirements: None.

Created in NX6.0.0 

Copyright 2025 Siemens
