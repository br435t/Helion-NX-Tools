# NXOpen.Annotations.PmiContextGeneralBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00190.html>

## Classes

class — ArrangementSuppressContextType

the arrangement suppress context type 

Enumerator — Comment

RelatedToInactiveArrangement — Related To Inactive Arrangement

NotSet — None

More...

Copyright 2025 Siemens
