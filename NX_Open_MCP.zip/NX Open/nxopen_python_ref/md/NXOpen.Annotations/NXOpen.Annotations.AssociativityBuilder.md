# NXOpen.Annotations.AssociativityBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11193.html>

Represents a NXOpen::Annotations::AssociativityBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateAssociativityBuilder 

More...

Inheritance diagram for NXOpen.Annotations.AssociativityBuilder:

## Public Member Functions

Angle (self)

Getter for property: (float) Angle Returns the angle. 

Angle (self, angle)

Setter for property: (float) Angle. 

LineOption (self)

Getter for property: (NXOpen.Annotations.AssociativityLineOption) LineOption Returns the line option. 

LineOption (self, lineOption)

Setter for property: (NXOpen.Annotations.AssociativityLineOption) LineOption. 

SelectObject (self)

Getter for property: (NXOpen.SelectDisplayableObject) SelectObject Returns the select object. 

Vector (self)

Getter for property: (NXOpen.SelectDisplayableObjectList) Vector Returns the vector. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::AssociativityBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreateAssociativityBuilder 

Created in NX5.0.0 

## Member Function Documentation

## ◆ Angle() [1/2]

NXOpen.Annotations.AssociativityBuilder.Angle
(
self — )

Getter for property: (float) Angle Returns the angle. 

Getter License requirements: None.

Created in NX5.0.0 

Returns
float 

## ◆ Angle() [2/2]

NXOpen.Annotations.AssociativityBuilder.Angle
(
self,

angle )

Setter for property: (float) Angle. 

Sets the angle

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX5.0.0 

## ◆ LineOption() [1/2]

NXOpen.Annotations.AssociativityBuilder.LineOption
(
self — )

Getter for property: (NXOpen.Annotations.AssociativityLineOption) LineOption Returns the line option. 

Getter License requirements: None.

Created in NX5.0.0 

Returns
AssociativityLineOption 

## ◆ LineOption() [2/2]

NXOpen.Annotations.AssociativityBuilder.LineOption
(
self,

lineOption )

Setter for property: (NXOpen.Annotations.AssociativityLineOption) LineOption. 

Sets the line option

Setter License requirements: drafting ("DRAFTING") OR geometric_tol ("GDT")

Created in NX5.0.0 

## ◆ SelectObject()

NXOpen.Annotations.AssociativityBuilder.SelectObject
(
self — )

Getter for property: (NXOpen.SelectDisplayableObject) SelectObject Returns the select object. 

Getter License requirements: None.

Created in NX5.0.0 

Returns
NXOpen.SelectDisplayableObject 

## ◆ Vector()

NXOpen.Annotations.AssociativityBuilder.Vector
(
self — )

Getter for property: (NXOpen.SelectDisplayableObjectList) Vector Returns the vector. 

Getter License requirements: None.

Created in NX5.0.0 

Returns
NXOpen.SelectDisplayableObjectList 

Copyright 2025 Siemens
