# NXOpen.Annotations.IdSymbolBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00170.html>

## Classes

class — SymbolTypes

the valid types for an id symbol 

Enumerator — Comment

Circle — Circle

DividedCircle — Divided circle

Triangle — Triangle with point down

TriangleUp — Triangle with point up

Square — Square

DividedSquare — Divided square

Hexagon — Hexagon

DividedHexagon — Divided hexagon

QuadrantCircle — Quadrant circle

RoundedBox — Rounded box

Underline — Underline

Nosymbol — No Symbol

More...

Copyright 2025 Siemens
