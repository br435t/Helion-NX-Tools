# NXOpen.Annotations.RadialStyleBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a14005.html>

Represents a NXOpen::Annotations::RadialStyleBuilder . 
More...

Inheritance diagram for NXOpen.Annotations.RadialStyleBuilder:

## Public Member Functions

DiameterRadiusPlacement (self)

Getter for property: (NXOpen.Annotations.DiameterRadiusSymbolPlacement) DiameterRadiusPlacement Returns the diameter radius symbol placement with respect to the dimension text. 

DiameterRadiusPlacement (self, diameterRadiusPlacement)

Setter for property: (NXOpen.Annotations.DiameterRadiusSymbolPlacement) DiameterRadiusPlacement. 

DiameterSymbol (self)

Getter for property: (str) DiameterSymbol Returns the text for a user-defined diameter symbol. 

DiameterSymbol (self, diameterSymbol)

Setter for property: (str) DiameterSymbol. 

DiameterSymbolType (self)

Getter for property: (NXOpen.Annotations.DiameterSymbol) DiameterSymbolType Returns the diameter symbol type. 

DiameterSymbolType (self, diameterSymbolType)

Setter for property: (NXOpen.Annotations.DiameterSymbol) DiameterSymbolType. 

FoldedRadiusAngle (self)

Getter for property: (float) FoldedRadiusAngle Returns the folded radius angle. 

FoldedRadiusAngle (self, foldedRadiusAngle)

Setter for property: (float) FoldedRadiusAngle. 

RadiusSymbol (self)

Getter for property: (str) RadiusSymbol Returns the text for a user-defined radius symbol. 

RadiusSymbol (self, radiusSymbol)

Setter for property: (str) RadiusSymbol. 

RadiusSymbolType (self)

Getter for property: (NXOpen.Annotations.RadiusSymbol) RadiusSymbolType Returns the radius symbol type. 

RadiusSymbolType (self, radiusSymbolType)

Setter for property: (NXOpen.Annotations.RadiusSymbol) RadiusSymbolType. 

SymbolToDimensionTextDistance (self)

Getter for property: (float) SymbolToDimensionTextDistance Returns the symbol to dimension text distance in character spaces. 

SymbolToDimensionTextDistance (self, symbolToDimensionTextDistance)

Setter for property: (float) SymbolToDimensionTextDistance. 

TextAboveLeader (self)

Getter for property: (NXOpen.Annotations.DiameterRadiusLeaderStub) TextAboveLeader Returns the location of the dimension text relative to the leader stub. 

TextAboveLeader (self, textAboveLeader)

Setter for property: (NXOpen.Annotations.DiameterRadiusLeaderStub) TextAboveLeader. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::Annotations::RadialStyleBuilder . 

This class queries and sets preferences specific to radial dimensions when creating or editing a radial type dimension.

Created in NX6.0.0 

## Member Function Documentation

## ◆ DiameterRadiusPlacement() [1/2]

NXOpen.Annotations.RadialStyleBuilder.DiameterRadiusPlacement
(
self — )

Getter for property: (NXOpen.Annotations.DiameterRadiusSymbolPlacement) DiameterRadiusPlacement Returns the diameter radius symbol placement with respect to the dimension text. 

One of the options specifies that no symbol be displayed

Getter License requirements: None.

Created in NX6.0.0 

Returns
DiameterRadiusSymbolPlacement 

## ◆ DiameterRadiusPlacement() [2/2]

NXOpen.Annotations.RadialStyleBuilder.DiameterRadiusPlacement
(
self,

diameterRadiusPlacement )

Setter for property: (NXOpen.Annotations.DiameterRadiusSymbolPlacement) DiameterRadiusPlacement. 

Sets the diameter radius symbol placement with respect to the dimension text.

One of the options specifies that no symbol be displayed

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DiameterSymbol() [1/2]

NXOpen.Annotations.RadialStyleBuilder.DiameterSymbol
(
self — )

Getter for property: (str) DiameterSymbol Returns the text for a user-defined diameter symbol. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ DiameterSymbol() [2/2]

NXOpen.Annotations.RadialStyleBuilder.DiameterSymbol
(
self,

diameterSymbol )

Setter for property: (str) DiameterSymbol. 

Sets the text for a user-defined diameter symbol

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ DiameterSymbolType() [1/2]

NXOpen.Annotations.RadialStyleBuilder.DiameterSymbolType
(
self — )

Getter for property: (NXOpen.Annotations.DiameterSymbol) DiameterSymbolType Returns the diameter symbol type. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
DiameterSymbol 

## ◆ DiameterSymbolType() [2/2]

NXOpen.Annotations.RadialStyleBuilder.DiameterSymbolType
(
self,

diameterSymbolType )

Setter for property: (NXOpen.Annotations.DiameterSymbol) DiameterSymbolType. 

Sets the diameter symbol type

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ FoldedRadiusAngle() [1/2]

NXOpen.Annotations.RadialStyleBuilder.FoldedRadiusAngle
(
self — )

Getter for property: (float) FoldedRadiusAngle Returns the folded radius angle. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ FoldedRadiusAngle() [2/2]

NXOpen.Annotations.RadialStyleBuilder.FoldedRadiusAngle
(
self,

foldedRadiusAngle )

Setter for property: (float) FoldedRadiusAngle. 

Sets the folded radius angle

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ RadiusSymbol() [1/2]

NXOpen.Annotations.RadialStyleBuilder.RadiusSymbol
(
self — )

Getter for property: (str) RadiusSymbol Returns the text for a user-defined radius symbol. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
str 

## ◆ RadiusSymbol() [2/2]

NXOpen.Annotations.RadialStyleBuilder.RadiusSymbol
(
self,

radiusSymbol )

Setter for property: (str) RadiusSymbol. 

Sets the text for a user-defined radius symbol

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ RadiusSymbolType() [1/2]

NXOpen.Annotations.RadialStyleBuilder.RadiusSymbolType
(
self — )

Getter for property: (NXOpen.Annotations.RadiusSymbol) RadiusSymbolType Returns the radius symbol type. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
RadiusSymbol 

## ◆ RadiusSymbolType() [2/2]

NXOpen.Annotations.RadialStyleBuilder.RadiusSymbolType
(
self,

radiusSymbolType )

Setter for property: (NXOpen.Annotations.RadiusSymbol) RadiusSymbolType. 

Sets the radius symbol type

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ SymbolToDimensionTextDistance() [1/2]

NXOpen.Annotations.RadialStyleBuilder.SymbolToDimensionTextDistance
(
self — )

Getter for property: (float) SymbolToDimensionTextDistance Returns the symbol to dimension text distance in character spaces. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ SymbolToDimensionTextDistance() [2/2]

NXOpen.Annotations.RadialStyleBuilder.SymbolToDimensionTextDistance
(
self,

symbolToDimensionTextDistance )

Setter for property: (float) SymbolToDimensionTextDistance. 

Sets the symbol to dimension text distance in character spaces

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ TextAboveLeader() [1/2]

NXOpen.Annotations.RadialStyleBuilder.TextAboveLeader
(
self — )

Getter for property: (NXOpen.Annotations.DiameterRadiusLeaderStub) TextAboveLeader Returns the location of the dimension text relative to the leader stub. 

Getter License requirements: None.

Created in NX6.0.0 

Deprecated
Deprecated in NX9.0.0. Use NXOpen::Annotations::DimensionStyleBuilder::TextPosition instead. 

Returns
DiameterRadiusLeaderStub 

## ◆ TextAboveLeader() [2/2]

NXOpen.Annotations.RadialStyleBuilder.TextAboveLeader
(
self,

textAboveLeader )

Setter for property: (NXOpen.Annotations.DiameterRadiusLeaderStub) TextAboveLeader. 

Sets the location of the dimension text relative to the leader stub

Setter License requirements: geometric_tol ("GDT") OR drafting ("DRAFTING")

Created in NX6.0.0 

Deprecated
Deprecated in NX9.0.0. Use NXOpen::Annotations::DimensionStyleBuilder::SetTextPosition instead. 

Copyright 2025 Siemens
