# NXOpen.Annotations.BendTable Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11525.html>

This class represents a bend table. 
More...

Inheritance diagram for NXOpen.Annotations.BendTable:

## Public Member Functions

Update (self)

Update bend table. 

Public Member Functions inherited from NXOpen.Annotations.Table

DoUpdate (self)

Update tabular note. 

EditCellText (self, tableCell, text)

Edit Cell Text. 

EvaluateRulesAndUpdate (self)

Evalute rules and update tabular note. 

InsertColumns (self, selectedColumns, insertColumnsInTabularNote)

Insert Columns. 

InsertHeaderRow (self)

Insert Header Row. 

InsertRows (self, selectedRows, insertRowsInTabularNote)

Insert Rows. 

IsRowLocked (self, row)

Check Row Lock/Unlock Status. 

LockUnlockRows (self, rows)

Lock or Unlock Rows. 

ResizeRowsCols (self, rowsOrColumns, resizeValue)

Resize rows and columns. 

SaveAsTemplate (self, filePath)

Save Parts List or Table as Template. 

Public Member Functions inherited from NXOpen.DisplayableObject

Blank (self)

Blanks the object. 

Color (self)

Getter for property: (int) Color Returns the color of the object. 

Color (self, color)

Setter for property: (int) Color. 

Highlight (self)

Highlights the object. 

IsBlanked (self)

Getter for property: (bool) IsBlanked Returns the blank status of this object. 

Layer (self)

Getter for property: (int) Layer Returns the layer that the object is in. 

Layer (self, layer)

Setter for property: (int) Layer. 

LineFont (self)

Getter for property: (NXOpen.DisplayableObject.ObjectFont) LineFont Returns the line font of the object. 

LineFont (self, font)

Setter for property: (NXOpen.DisplayableObject.ObjectFont) LineFont. 

LineWidth (self)

Getter for property: (NXOpen.DisplayableObject.ObjectWidth) LineWidth Returns the line width of the object. 

LineWidth (self, width)

Setter for property: (NXOpen.DisplayableObject.ObjectWidth) LineWidth. 

NameLocation (self)

Getter for property: (NXOpen.Point3d) NameLocation Returns the location of the object's name. 

RedisplayObject (self)

Redisplays the object in all views. 

RemoveViewDependency (self)

Remove dependency on all views from an object. 

SetNameLocation (self, location)

Sets the location of the object's name. 

Unblank (self)

Unblanks the object. 

Unhighlight (self)

Unhighlights the object. 

Public Member Functions inherited from NXOpen.NXObject

CreateAttributeIterator (self)

Create an attribute iterator. 

DeleteAllAttributesByType (self, type)

Deletes all attributes of a specific type. 

DeleteAllAttributesByType (self, type, option)

Deletes all attributes of a specific type with the option to update or not. 

DeleteAttributeByTypeAndTitle (self, type, title)

Deletes an attribute by type and title. 

DeleteAttributeByTypeAndTitle (self, type, title, option)

Deletes an attribute by type and title with the option to update or not. 

DeleteUserAttribute (self, type, title, delete_entire_array, option)

Deletes the first attribute encountered with the given Type, Title. 

DeleteUserAttributes (self, iterator, option)

Deletes the attributes on the object, if any, that satisfy the given iterator. 

DeleteUserAttributes (self, type, option)

Deletes the attributes encountered with the given Type with option to update or not. 

GetAttributeTitlesByType (self, type)

Gets all the attribute titles of a specific type. 

GetBooleanUserAttribute (self, title, index)

Gets a boolean attribute by Title and array Index. 

GetComputationalTimeUserAttribute (self, title, index)

Gets a time attribute by Title and array Index. 

GetIntegerAttribute (self, title)

Gets an integer attribute by title. 

GetIntegerUserAttribute (self, title, index)

Gets an integer attribute by Title and array Index. 

GetNextUserAttribute (self, iterator)

Gets the next attribute encountered on the object, if any, that satisfies the given iterator. 

GetPdmReferenceAttributeValue (self, attributeTitle)

Gets the value of PDM Reference attribute for given object. 

GetRealAttribute (self, title)

Gets a real attribute by title. 

GetRealUserAttribute (self, title, index)

Gets a real attribute by Title and array Index. 

GetReferenceAttribute (self, title)

Gets the reference string (not the calculated value) of a string attribute that uses a reference string. 

GetStringAttribute (self, title)

Gets a string attribute value by title. 

GetStringUserAttribute (self, title, index)

Gets a string attribute by Title and array Index. 

GetTimeAttribute (self, format, title)

Gets a time attribute by title. 

GetTimeUserAttribute (self, title, index)

Gets a time attribute by Title and array Index. 

GetUserAttribute (self, title, includeUnset, addStringValues, type)

Gets the first attribute (or attribute array) encountered on the object, if any, with a given Title and Type. 

GetUserAttribute (self, title, type, index)

Gets the first attribute encountered on the object, if any, with a given Title, Type and array Index. 

GetUserAttributeAsString (self, title, type, index)

Gets the first attribute encountered on the object, if any, with a given title, type and array index. 

GetUserAttributeCount (self, iterator)

Gets the count of set attributes on the object, if any, that satisfy the given iterator. 

GetUserAttributeCount (self, iterator, countArrayAsOneAttribute)

Gets the count of set attributes on the object, if any, that satisfy the given iterator. 

GetUserAttributeCount (self, type)

Gets the count of set attributes on the object, if any, of the given type. 

GetUserAttributeCount (self, type, includeUnset, countArrayAsOneAttribute)

Gets the count of attributes on the object, if any, of the given type. 

GetUserAttributeLock (self, title, type)

Determine the lock of the given attribute. 

GetUserAttributes (self)

Gets all the attributes that have been set on the given object. 

GetUserAttributes (self, includeUnset)

Gets all the attributes of the given object. 

GetUserAttributes (self, includeUnset, addStringValues)

Gets all the attributes of the given object. 

GetUserAttributes (self, iterator)

Gets all the attributes that have been set on the given object, if any, that satisfy the given iterator. 

GetUserAttributesAsStrings (self)

Gets all the attributes that have been set on the given object. 

GetUserAttributeSize (self, title, type)

Gets the size of the first attribute encountered on the object, if any, with a given Title and Type. 

GetUserAttributeSourceObjects (self)

Returns an array of objects from which this object presents attributes. 

HasUserAttribute (self, iterator)

Determines if an attribute exists on the object, that satisfies the given iterator. 

HasUserAttribute (self, title, type, index)

Determines if an attribute with the given Title, Type and array Index is present on the object Unset attributes will not be detected by this function, as its purpose is to test for the actual presence of the attribute on the object. 

IsOccurrence (self)

Getter for property: (bool) IsOccurrence Returns whether this object is an occurrence or not. 

JournalIdentifier (self)

Getter for property: (str) JournalIdentifier Returns the identifier that would be recorded in a journal for this object. 

Name (self)

Getter for property: (str) Name Returns the custom name of the object. 

OwningComponent (self)

Getter for property: (NXOpen.Assemblies.Component) OwningComponent Returns the owning component, if this object is an occurrence. 

OwningPart (self)

Getter for property: (NXOpen.BasePart) OwningPart Returns the owning part of this object. 

Prototype (self)

Getter for property: (NXOpen.INXObject) Prototype Returns the prototype of this object if it is an occurrence. 

SetAttribute (self, title)

Creates or modifies a null attribute which is an attribute with a title and no value. 

SetAttribute (self, title, option)

Creates or modifies a null attribute with the option to update or not. 

SetAttribute (self, title, value)

Creates or modifies an integer attribute. 

SetAttribute (self, title, value)

Creates or modifies a real attribute. 

SetAttribute (self, title, value)

Creates or modifies a string attribute. 

SetAttribute (self, title, value, option)

Creates or modifies an integer attribute with the option to update or not. 

SetAttribute (self, title, value, option)

Creates or modifies a real attribute with the option to update or not. 

SetAttribute (self, title, value, option)

Creates or modifies a string attribute with the option to update or not. 

SetBooleanUserAttribute (self, title, index, value, option)

Creates or modifies a boolean attribute with the option to update or not. 

SetPdmReferenceAttribute (self, attributeTitle, attributeValue)

Sets the value of PDM Reference attribute on the object. 

SetReferenceAttribute (self, title, value)

Creates or modifies a string attribute which uses a reference string. 

SetReferenceAttribute (self, title, value, option)

Creates or modifies a string attribute which uses a reference string, with the option to update or not. 

SetTimeAttribute (self, title, value)

Creates or modifies a time attribute. 

SetTimeAttribute (self, title, value, option)

Creates or modifies a time attribute with the option to update or not. 

SetTimeUserAttribute (self, title, index, value, option)

Creates or modifies a time attribute with the option to update or not. 

SetTimeUserAttribute (self, title, index, value, option)

Creates or modifies a time attribute with the option to update or not. 

SetUserAttribute (self, info, option)

Creates or modifies an attribute with the option to update or not. 

SetUserAttribute (self, title, index, option)

Creates or modifies a null attribute with the option to update or not. 

SetUserAttribute (self, title, index, value, option)

Creates or modifies an integer attribute with the option to update or not. 

SetUserAttribute (self, title, index, value, option)

Creates or modifies a real attribute with the option to update or not. 

SetUserAttribute (self, title, index, value, option)

Creates or modifies a string attribute with the option to update or not. 

SetUserAttributeLock (self, title, type, lock)

Lock or unlock the given attribute. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.Annotations.Table

TableInsertColumnsType = Table.InsertColumnsType

NXOpen.Annotations.TableInsertColumnsType is an alias for NXOpen.Annotations.Table.InsertColumnsType 

TableInsertRowsType = Table.InsertRowsType

NXOpen.Annotations.TableInsertRowsType is an alias for NXOpen.Annotations.Table.InsertRowsType 

Public Attributes inherited from NXOpen.DisplayableObject

DisplayableObjectObjectFont = DisplayableObject.ObjectFont

NXOpen.DisplayableObjectObjectFont is an alias for NXOpen.DisplayableObject.ObjectFont 

DisplayableObjectObjectWidth = DisplayableObject.ObjectWidth

NXOpen.DisplayableObjectObjectWidth is an alias for NXOpen.DisplayableObject.ObjectWidth 

Public Attributes inherited from NXOpen.NXObject

NXObjectAttributeInformation_Struct = NXObject.AttributeInformation

NXOpen.NXObjectAttributeInformation_Struct is an alias for NXOpen.NXObject.AttributeInformation. 

NXObjectAttributeType = NXObject.AttributeType

NXOpen.NXObjectAttributeType is an alias for NXOpen.NXObject.AttributeType 

NXObjectComputationalTime_Struct = NXObject.ComputationalTime

NXOpen.NXObjectComputationalTime_Struct is an alias for NXOpen.NXObject.ComputationalTime. 

NXObjectDateAndTimeFormat = NXObject.DateAndTimeFormat

NXOpen.NXObjectDateAndTimeFormat is an alias for NXOpen.NXObject.DateAndTimeFormat 

## Detailed Description

This class represents a bend table. 

To create or edit an instance of this class, use NXOpen::Annotations::BendTableBuilder 

Created in NX9.0.0 

## Member Function Documentation

## ◆ Update()

NXOpen.Annotations.BendTable.Update
(
self — )

Update bend table. 

Created in NX9.0.0 

License requirements: None. 

Copyright 2025 Siemens
