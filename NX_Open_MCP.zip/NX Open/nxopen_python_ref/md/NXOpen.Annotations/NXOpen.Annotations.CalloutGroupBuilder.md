# NXOpen.Annotations.CalloutGroupBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00140.html>

## Classes

class — Layout

Represents group layout 

Enumerator — Comment

Horizontal — Horizontal

Vertical — Vertical

More...

class — Mode

Represents Group or Ungroup mode. More...

class — VerticalGroupLeaderAttachment

Represents leader attachment for vertical callout groups. More...

Copyright 2025 Siemens
