# NXOpen.Annotations.PmiFeatureControlFrameBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13489.html>

Represents a NXOpen::Annotations::PmiFeatureControlFrameBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreatePmiFeatureControlFrameBuilder 

More...

Inheritance diagram for NXOpen.Annotations.PmiFeatureControlFrameBuilder:

## Public Member Functions

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the associated objects builder for the annotation. 

Public Member Functions inherited from NXOpen.Annotations.FeatureControlFrameBuilder

Characteristic (self)

Getter for property: (NXOpen.Annotations.FeatureControlFrameBuilder.FcfCharacteristic) Characteristic Returns the characteristic. 

Characteristic (self, characteristic)

Setter for property: (NXOpen.Annotations.FeatureControlFrameBuilder.FcfCharacteristic) Characteristic. 

FeatureControlFrameData (self)

The feature control frame data list. 

FeatureControlFrameDataList (self)

Getter for property: (NXOpen.Annotations.FeatureControlFrameDataBuilderList) FeatureControlFrameDataList Returns the feature control frame data list. 

FrameStyle (self)

Getter for property: (NXOpen.Annotations.FeatureControlFrameBuilder.FcfFrameStyle) FrameStyle Returns the frame style. 

FrameStyle (self, frameStyle)

Setter for property: (NXOpen.Annotations.FeatureControlFrameBuilder.FcfFrameStyle) FrameStyle. 

InheritFrom (self, inheritTag)

The feature control frame is inherited form existing feature control frame. 

Leader (self)

Getter for property: (NXOpen.Annotations.LeaderBuilder) Leader Returns the NXOpen::Annotations::LeaderBuilder for the annotation. 

Origin (self)

Getter for property: (NXOpen.Annotations.OriginBuilder) Origin Returns the NXOpen::Annotations::OriginBuilder for the annotation. 

Style (self)

Getter for property: (NXOpen.Annotations.StyleBuilder) Style Returns the style. 

Text (self)

Getter for property: (NXOpen.Annotations.TextWithSymbolsBuilder) Text Returns the text. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.Annotations.FeatureControlFrameBuilder

FeatureControlFrameBuilderFcfCharacteristic = FeatureControlFrameBuilder.FcfCharacteristic

NXOpen.Annotations.FeatureControlFrameBuilderFcfCharacteristic is an alias for NXOpen.Annotations.FeatureControlFrameBuilder.FcfCharacteristic 

FeatureControlFrameBuilderFcfFrameStyle = FeatureControlFrameBuilder.FcfFrameStyle

NXOpen.Annotations.FeatureControlFrameBuilderFcfFrameStyle is an alias for NXOpen.Annotations.FeatureControlFrameBuilder.FcfFrameStyle 

## Detailed Description

Represents a NXOpen::Annotations::PmiFeatureControlFrameBuilder 

To create a new instance of this class, use NXOpen::Annotations::AnnotationManager::CreatePmiFeatureControlFrameBuilder 

Created in NX6.0.0 

## Member Function Documentation

## ◆ AssociatedObjects()

NXOpen.Annotations.PmiFeatureControlFrameBuilder.AssociatedObjects
(
self — )

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the associated objects builder for the annotation. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
AssociatedObjectsBuilder 

Copyright 2025 Siemens
