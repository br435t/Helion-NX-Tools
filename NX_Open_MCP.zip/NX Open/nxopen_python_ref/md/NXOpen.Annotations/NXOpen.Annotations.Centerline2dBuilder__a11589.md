# NXOpen.Annotations.Centerline2dBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11589.html>

Builder for creating 2D Centerline. 
More...

Inheritance diagram for NXOpen.Annotations.Centerline2dBuilder:

## Public Member Functions

Inherit (self)

Getter for property: (NXOpen.SelectNXObject) Inherit Returns the inherit object. 

OffsetDistance (self)

Getter for property: (float) OffsetDistance Returns the offset distance for centerline by points. 

OffsetDistance (self, offsetDistance)

Setter for property: (float) OffsetDistance. 

OffsetMethod (self)

Getter for property: (NXOpen.Annotations.Centerline2dBuilder.Offset) OffsetMethod Returns the offset method for centerline by points. 

OffsetMethod (self, offsetMethod)

Setter for property: (NXOpen.Annotations.Centerline2dBuilder.Offset) OffsetMethod. 

OffsetObject (self)

Getter for property: (NXOpen.SelectNXObject) OffsetObject Returns the offset object for centerline by points. 

Point1 (self)

Getter for property: (NXOpen.SelectNXObject) Point1 Returns the point 1 of 2D Centerline for centerline by points. 

Point2 (self)

Getter for property: (NXOpen.SelectNXObject) Point2 Returns the point 2 of 2D Centerline for centerline by points. 

Settings (self)

Getter for property: (NXOpen.Annotations.Centerline2dSettingsBuilder) Settings Returns the settings builder. 

Side1 (self)

Getter for property: (NXOpen.SelectNXObject) Side1 Returns the side 1 of 2D Centerline for centerline from curves. 

Side2 (self)

Getter for property: (NXOpen.SelectNXObject) Side2 Returns the side 2 of 2D Centerline for centerline from curves. 

Type (self)

Getter for property: (NXOpen.Annotations.Centerline2dBuilder.Types) Type Returns the type. 

Type (self, type)

Setter for property: (NXOpen.Annotations.Centerline2dBuilder.Types) Type. 

Public Member Functions inherited from NXOpen.Annotations.CenterlineBuilder

AddEndExtensions (self, start, end)

Adds extensions only at ends. 

AddExtension (self, index, defaultValue)

Adds extension based on select object index. 

GetAllExtensions (self)

Returns all extensions. 

GetAllIndividualExtensions (self)

Returns individual extensions. 

GetEndExtensions (self)

Returns end extensions only. 

RemoveEndExtensions (self)

Removes extensions only at ends. 

RemoveExtension (self, index)

Removes extension based on select object index. 

ResetAllExtensions (self, defaultValue)

Reset all extensions by the supplied defaultValue. 

SetAllIndividualExtensions (self, extensionValues)

Sets all individual extensions. 

SetEndExtensions (self, start, end)

Modifies end extensions only. 

SetIndividualExtensions (self, index, value1, value2)

Modifies extensions based on select object index. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

Centerline2dBuilderOffset = Centerline2dBuilder.Offset

NXOpen.Annotations.Centerline2dBuilderOffset is an alias for NXOpen.Annotations.Centerline2dBuilder.Offset 

Centerline2dBuilderTypes = Centerline2dBuilder.Types

NXOpen.Annotations.Centerline2dBuilderTypes is an alias for NXOpen.Annotations.Centerline2dBuilder.Types 

## Detailed Description

Builder for creating 2D Centerline. 

It creates or edits 2D Centerlines 

To create a new instance of this class, use NXOpen::Annotations::CenterlineCollection::CreateCenterline2dBuilder 

Default values. 

Property — Value

OffsetDistance 

0 

OffsetMethod 

None 

Settings.Extension 

6.35 (millimeters part), 0.25 (inches part) 

Settings.Gap 

1.5875 (millimeters part), 0.0625 (inches part) 

Settings.IndividualDistance 

0 

Settings.Size 

3.175 (millimeters part), 0.125 (inches part) 

Settings.Width 

Thin 

Type 

FromCurves 

Created in NX6.0.0 

## Member Function Documentation

## ◆ Inherit()

NXOpen.Annotations.Centerline2dBuilder.Inherit
(
self — )

Getter for property: (NXOpen.SelectNXObject) Inherit Returns the inherit object. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ OffsetDistance() [1/2]

NXOpen.Annotations.Centerline2dBuilder.OffsetDistance
(
self — )

Getter for property: (float) OffsetDistance Returns the offset distance for centerline by points. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
float 

## ◆ OffsetDistance() [2/2]

NXOpen.Annotations.Centerline2dBuilder.OffsetDistance
(
self,

offsetDistance )

Setter for property: (float) OffsetDistance. 

Sets the offset distance for centerline by points

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ OffsetMethod() [1/2]

NXOpen.Annotations.Centerline2dBuilder.OffsetMethod
(
self — )

Getter for property: (NXOpen.Annotations.Centerline2dBuilder.Offset) OffsetMethod Returns the offset method for centerline by points. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
Centerline2dBuilder.Offset 

## ◆ OffsetMethod() [2/2]

NXOpen.Annotations.Centerline2dBuilder.OffsetMethod
(
self,

offsetMethod )

Setter for property: (NXOpen.Annotations.Centerline2dBuilder.Offset) OffsetMethod. 

Sets the offset method for centerline by points

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## ◆ OffsetObject()

NXOpen.Annotations.Centerline2dBuilder.OffsetObject
(
self — )

Getter for property: (NXOpen.SelectNXObject) OffsetObject Returns the offset object for centerline by points. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ Point1()

NXOpen.Annotations.Centerline2dBuilder.Point1
(
self — )

Getter for property: (NXOpen.SelectNXObject) Point1 Returns the point 1 of 2D Centerline for centerline by points. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ Point2()

NXOpen.Annotations.Centerline2dBuilder.Point2
(
self — )

Getter for property: (NXOpen.SelectNXObject) Point2 Returns the point 2 of 2D Centerline for centerline by points. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ Settings()

NXOpen.Annotations.Centerline2dBuilder.Settings
(
self — )

Getter for property: (NXOpen.Annotations.Centerline2dSettingsBuilder) Settings Returns the settings builder. 

Getter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

Returns
Centerline2dSettingsBuilder 

## ◆ Side1()

NXOpen.Annotations.Centerline2dBuilder.Side1
(
self — )

Getter for property: (NXOpen.SelectNXObject) Side1 Returns the side 1 of 2D Centerline for centerline from curves. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ Side2()

NXOpen.Annotations.Centerline2dBuilder.Side2
(
self — )

Getter for property: (NXOpen.SelectNXObject) Side2 Returns the side 2 of 2D Centerline for centerline from curves. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ Type() [1/2]

NXOpen.Annotations.Centerline2dBuilder.Type
(
self — )

Getter for property: (NXOpen.Annotations.Centerline2dBuilder.Types) Type Returns the type. 

Getter License requirements: None.

Created in NX6.0.0 

Returns
Centerline2dBuilder.Types 

## ◆ Type() [2/2]

NXOpen.Annotations.Centerline2dBuilder.Type
(
self,

type )

Setter for property: (NXOpen.Annotations.Centerline2dBuilder.Types) Type. 

Sets the type

Setter License requirements: drafting ("DRAFTING")

Created in NX6.0.0 

## Member Data Documentation

## ◆ Centerline2dBuilderOffset

NXOpen.Annotations.Centerline2dBuilder.Centerline2dBuilderOffset = Centerline2dBuilder.Offset

NXOpen.Annotations.Centerline2dBuilderOffset is an alias for NXOpen.Annotations.Centerline2dBuilder.Offset 

## ◆ Centerline2dBuilderTypes

NXOpen.Annotations.Centerline2dBuilder.Centerline2dBuilderTypes = Centerline2dBuilder.Types

NXOpen.Annotations.Centerline2dBuilderTypes is an alias for NXOpen.Annotations.Centerline2dBuilder.Types 

Copyright 2025 Siemens
