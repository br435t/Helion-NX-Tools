# NXOpen.Annotations.PmiCenterline3dBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a13329.html>

Builder for creating Pmi 3D Centerline. 
More...

Inheritance diagram for NXOpen.Annotations.PmiCenterline3dBuilder:

## Public Member Functions

AssociatedObjects (self)

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the associated objects for the 3D Centerline. 

Public Member Functions inherited from NXOpen.Annotations.BaseCenterline3dBuilder

Face (self)

Getter for property: (NXOpen.SelectNXObjectList) Face Returns the face. 

ReferenceIndex (self)

Getter for property: (int) ReferenceIndex Returns the reference index. 

ReferenceIndex (self, referenceIndex)

Setter for property: (int) ReferenceIndex. 

Settings (self)

Getter for property: (NXOpen.Annotations.Centerline3dSettingsBuilder) Settings Returns the settings builder. 

Public Member Functions inherited from NXOpen.Annotations.CenterlineBuilder

AddEndExtensions (self, start, end)

Adds extensions only at ends. 

AddExtension (self, index, defaultValue)

Adds extension based on select object index. 

GetAllExtensions (self)

Returns all extensions. 

GetAllIndividualExtensions (self)

Returns individual extensions. 

GetEndExtensions (self)

Returns end extensions only. 

RemoveEndExtensions (self)

Removes extensions only at ends. 

RemoveExtension (self, index)

Removes extension based on select object index. 

ResetAllExtensions (self, defaultValue)

Reset all extensions by the supplied defaultValue. 

SetAllIndividualExtensions (self, extensionValues)

Sets all individual extensions. 

SetEndExtensions (self, start, end)

Modifies end extensions only. 

SetIndividualExtensions (self, index, value1, value2)

Modifies extensions based on select object index. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Builder for creating Pmi 3D Centerline. 

It creates or edits Pmi 3D Centerlines 

To create a new instance of this class, use NXOpen::Annotations::CenterlineCollection::CreatePmiCenterline3dBuilder 

Created in NX7.5.0 

## Member Function Documentation

## ◆ AssociatedObjects()

NXOpen.Annotations.PmiCenterline3dBuilder.AssociatedObjects
(
self — )

Getter for property: (NXOpen.Annotations.AssociatedObjectsBuilder) AssociatedObjects Returns the associated objects for the 3D Centerline. 

Getter License requirements: None.

Created in NX7.5.0 

Returns
AssociatedObjectsBuilder 

Copyright 2025 Siemens
