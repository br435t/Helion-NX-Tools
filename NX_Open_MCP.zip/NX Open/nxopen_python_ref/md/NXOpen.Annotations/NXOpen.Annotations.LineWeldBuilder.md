# NXOpen.Annotations.LineWeldBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00177.html>

## Classes

class — FieldWeldType

Represents the field weld type 

Enumerator — Comment

Plain

TopField

TopFieldSimpleFlag

More...

class — IdLineType

Represents the id line type 

Enumerator — Comment

Plain

IdLineAbove

IdLineBelow

CenteredSpotWeld

CenteredSeamWeld

Centered

More...

class — StaggeredWeldType

Represents the staggered weld type 

Enumerator — Comment

NoStaggeredSymbol

StaggeredSymbol

StaggeredSymbolWeldSide

More...

class — TailType

represents the tail type 

Enumerator — Comment

NoTail

Tail

Box

More...

class — WeldSymbolWeldAlongContourType

Represents the weld along contour option 

Enumerator — Comment

NotSet

Closed

Unclosed

TrilateralWeld

AllAround

More...

Copyright 2025 Siemens
