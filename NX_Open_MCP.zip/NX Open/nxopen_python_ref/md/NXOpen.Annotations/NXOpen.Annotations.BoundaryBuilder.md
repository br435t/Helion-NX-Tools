# NXOpen.Annotations.BoundaryBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00139.html>

## Classes

class — SelectionMethod

This enum represents the methods for selecting boundaries 

Enumerator — Comment

Curves — Select boundaries by selecting curves

Location — Select boundaries by cursor location

More...

Copyright 2025 Siemens
