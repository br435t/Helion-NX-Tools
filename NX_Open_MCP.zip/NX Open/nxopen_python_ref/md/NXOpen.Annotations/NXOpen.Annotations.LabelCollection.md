# NXOpen.Annotations.LabelCollection Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12737.html>

Represents a collection of labels 

To obtain an instance of this class, refer to NXOpen::Part 

More...

Inheritance diagram for NXOpen.Annotations.LabelCollection:

## Public Member Functions

CreatePmiLabel (self, label_data, pmi_data, annotation_plane, origin, leader)

Creates a PMI label. 

NewLabelData (self)

Creates new LabelData object. 

## Detailed Description

Represents a collection of labels 

To obtain an instance of this class, refer to NXOpen::Part 

Created in NX3.0.0 

## Member Function Documentation

## ◆ CreatePmiLabel()

NXOpen.Annotations.LabelCollection.CreatePmiLabel
(
self,

label_data,

pmi_data,

annotation_plane,

origin,

leader )

Creates a PMI label. 

Returns
label (NXOpen.Annotations.PmiLabel): New PMI label .

Created in NX4.0.0 

License requirements: geometric_tol ("GDT")

Parameters

label_data — (NXOpen.Annotations.LabelData) Label data

pmi_data — (NXOpen.Annotations.PmiData) PMI data

annotation_plane — (NXOpen.Xform) Annotation plane on which the label lies

origin — (NXOpen.Point3d) Origin for the label

leader — (NXOpen.Annotations.LeaderBundle) Specifies the leaders for the label

## ◆ NewLabelData()

NXOpen.Annotations.LabelCollection.NewLabelData
(
self — )

Creates new LabelData object. 

Returns
label_data (NXOpen.Annotations.LabelData): New LabelData .

Created in NX4.0.0 

License requirements: None. 

Copyright 2025 Siemens
