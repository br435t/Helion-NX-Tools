# NXOpen.Annotations.PmiRegionData Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00201.html>

## Classes

class — RegionTypes

Specifies the PMI Region type 

Enumerator — Comment

Unspecified

AnnularType

CircularType

CylindricalType

RectangularType

ArbitraryType

More...

Copyright 2025 Siemens
