# NXOpen.Annotations.HoleTableSettingsContentBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a12537.html>

Represents a NXOpen::Annotations::HoleTableSettingsContentBuilder. 
More...

Inheritance diagram for NXOpen.Annotations.HoleTableSettingsContentBuilder:

## Public Member Functions

GetContentOrder (self)

Returns content order. 

SetContentOrder (self, contentOrder)

Sets content order. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

HoleTableSettingsContentBuilderContent = HoleTableSettingsContentBuilder.Content

NXOpen.Annotations.HoleTableSettingsContentBuilderContent is an alias for NXOpen.Annotations.HoleTableSettingsContentBuilder.Content 

## Detailed Description

Represents a NXOpen::Annotations::HoleTableSettingsContentBuilder. 

Created in NX9.0.0 

## Member Function Documentation

## ◆ GetContentOrder()

NXOpen.Annotations.HoleTableSettingsContentBuilder.GetContentOrder
(
self — )

Returns content order. 

Returns
contentOrder (List[NXOpen.Annotations.HoleTableSettingsContentBuilder.Content]): .

Created in NX9.0.0 

License requirements: None. 

## ◆ SetContentOrder()

NXOpen.Annotations.HoleTableSettingsContentBuilder.SetContentOrder
(
self,

contentOrder )

Sets content order. 

Created in NX9.0.0 

License requirements: drafting ("DRAFTING")

Parameters

contentOrder — (List[NXOpen.Annotations.HoleTableSettingsContentBuilder.Content])

## Member Data Documentation

## ◆ HoleTableSettingsContentBuilderContent

NXOpen.Annotations.HoleTableSettingsContentBuilder.HoleTableSettingsContentBuilderContent = HoleTableSettingsContentBuilder.Content

NXOpen.Annotations.HoleTableSettingsContentBuilderContent is an alias for NXOpen.Annotations.HoleTableSettingsContentBuilder.Content 

Copyright 2025 Siemens
