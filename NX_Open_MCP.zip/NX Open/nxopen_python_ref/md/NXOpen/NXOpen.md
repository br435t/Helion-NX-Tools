# NXOpen Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00006.html>

Classes, Enums and Structs under NXOpen namespace. 
More...

## Namespaces

namespace — AcisExporter

namespace — AECDesign

Classes, Enums and Structs under NXOpen.AECDesign namespace. 

namespace — ALP

Classes, Enums and Structs under NXOpen.ALP namespace. 

namespace — AME

Classes, Enums and Structs under NXOpen.AME namespace. 

namespace — AnimationDesigner

Classes, Enums and Structs under NXOpen.AnimationDesigner namespace. 

namespace — Annotations

Classes, Enums and Structs under NXOpen.Annotations namespace. 

namespace — Appearance

Classes, Enums and Structs under NXOpen.Appearance namespace. 

namespace — ASCImporter

namespace — Assemblies

Classes, Enums and Structs under NXOpen.Assemblies namespace. 

namespace — AssembliesUtils

namespace — AttributePropertiesBaseBuilder

namespace — AttributePropertiesBuilder

namespace — AttributeTemplatesBuilder

namespace — AutomatedTesting

Classes, Enums and Structs under NXOpen.AutomatedTesting namespace. 

namespace — AutomaticTraceline

namespace — Axis

namespace — BaseCreator

namespace — BaseImporter

namespace — BaseObjectStateManager

namespace — BasePart

namespace — BasePropertyTable

namespace — BlockStyler

Classes, Enums and Structs under NXOpen.BlockStyler namespace. 

namespace — BodyDes

Classes, Enums and Structs under NXOpen.BodyDes namespace. 

namespace — CableRouter

Classes, Enums and Structs under NXOpen.CableRouter namespace. 

namespace — CADCAEPrep

Classes, Enums and Structs under NXOpen.CADCAEPrep namespace. 

namespace — CAE

Classes, Enums and Structs under NXOpen.CAE namespace. 

namespace — CaeDseWorkflow

Classes, Enums and Structs under NXOpen.CaeDseWorkflow namespace. 

namespace — CaeObjectType

namespace — CAM

Classes, Enums and Structs under NXOpen.CAM namespace. 

namespace — Catiav4Creator

namespace — Catiav5Creator

namespace — Catiav5Importer

namespace — CGMBuilder

namespace — CLDKin

Classes, Enums and Structs under NXOpen.CLDKin namespace. 

namespace — CollaborationApplication

Classes, Enums and Structs under NXOpen.CollaborationApplication namespace. 

namespace — Composites

Classes, Enums and Structs under NXOpen.Composites namespace. 

namespace — ContactlessInspection

Classes, Enums and Structs under NXOpen.ContactlessInspection namespace. 

namespace — ContentDefinition

namespace — ConvertToFromReferenceBuilder

namespace — CreoImporter

namespace — DateItemBuilder

namespace — DatumAxis

namespace — DatumConstraint

namespace — DatumPlane

namespace — DesignSimulation

Classes, Enums and Structs under NXOpen.DesignSimulation namespace. 

namespace — Diagramming

Classes, Enums and Structs under NXOpen.Diagramming namespace. 

namespace — DiagrammingLibraryAuthor

Classes, Enums and Structs under NXOpen.DiagrammingLibraryAuthor namespace. 

namespace — Die

Classes, Enums and Structs under NXOpen.Die namespace. 

namespace — Direction

namespace — Display

Classes, Enums and Structs under NXOpen.Display namespace. 

namespace — DisplayableObject

namespace — DisplayManager

namespace — DisplayModification

namespace — DMU

Classes, Enums and Structs under NXOpen.DMU namespace. 

namespace — Document

Classes, Enums and Structs under NXOpen.Document namespace. 

namespace — Drafting

Classes, Enums and Structs under NXOpen.Drafting namespace. 

namespace — Drawings

Classes, Enums and Structs under NXOpen.Drawings namespace. 

namespace — DSE

Classes, Enums and Structs under NXOpen.DSE namespace. 

namespace — DSEDesignWorkflow

Classes, Enums and Structs under NXOpen.DSEDesignWorkflow namespace. 

namespace — DSEPlatform

Classes, Enums and Structs under NXOpen.DSEPlatform namespace. 

namespace — DxfdwgCreator

namespace — DxfdwgImporter

namespace — Edge

namespace — EffectivityConditionBuilder

namespace — ElectricalRouting

Classes, Enums and Structs under NXOpen.ElectricalRouting namespace. 

namespace — EndCutBlockBuilder

namespace — Expression

namespace — ExpressionCollection

namespace — ExtendedRealityFileCreator

namespace — ExternalFileReference

namespace — ExternalFileReferenceAdapter

namespace — Face

namespace — Facet

Classes, Enums and Structs under NXOpen.Facet namespace. 

namespace — FeatureProcessBuilderStatus

namespace — Features

Classes, Enums and Structs under NXOpen.Features namespace. 

namespace — Fields

Classes, Enums and Structs under NXOpen.Fields namespace. 

namespace — FontCollection

namespace — Formboard

Classes, Enums and Structs under NXOpen.Formboard namespace. 

namespace — Frame

namespace — G3DImporter

namespace — Gateway

Classes, Enums and Structs under NXOpen.Gateway namespace. 

namespace — GCTools

Classes, Enums and Structs under NXOpen.GCTools namespace. 

namespace — GenericMeasure

namespace — GeometricAnalysis

Classes, Enums and Structs under NXOpen.GeometricAnalysis namespace. 

namespace — GeometricUtilities

Classes, Enums and Structs under NXOpen.GeometricUtilities namespace. 

namespace — GeospatialDataImporter

namespace — GroupBuilder

namespace — HumanData

namespace — HumanH10DialogBuilder

namespace — HumanHandsDialogBuilder

namespace — HumanHandShapeData

namespace — HumanHCPDialogBuilder

namespace — HumanPosturePredictionBuilder

namespace — HumanReachZone

namespace — IfcCreator

namespace — IfcImporter

namespace — IgesCreator

namespace — IgesImporter

namespace — Implicit

Classes, Enums and Structs under NXOpen.Implicit namespace. 

namespace — Importer3MF

namespace — InferSnapType

namespace — Information

namespace — InfoWindow

Classes, Enums and Structs under NXOpen.InfoWindow namespace. 

namespace — Inspector

Classes, Enums and Structs under NXOpen.Inspector namespace. 

namespace — InterpartExpressionsBuilder

namespace — InventorImporter

namespace — Issue

Classes, Enums and Structs under NXOpen.Issue namespace. 

namespace — Join

Classes, Enums and Structs under NXOpen.Join namespace. 

namespace — JtCreator

namespace — Layer

Classes, Enums and Structs under NXOpen.Layer namespace. 

namespace — Layout2d

Classes, Enums and Structs under NXOpen.Layout2d namespace. 

namespace — LayoutDefinition

namespace — LicenseManager

namespace — Light

namespace — LineDesigner

Classes, Enums and Structs under NXOpen.LineDesigner namespace. 

namespace — LineFontBuilder

namespace — LinkedMirrorPartBuilder

namespace — ListCreator

namespace — ListingWindow

namespace — LoadOptions

namespace — Markup

Classes, Enums and Structs under NXOpen.Markup namespace. 

namespace — MassPropertiesBuilder

namespace — MaterialUtilities

namespace — MeasureAngleBuilder

namespace — MeasureBodies

namespace — MeasureBuilder

namespace — MeasureDistanceBuilder

namespace — MeasureElement

namespace — MeasureFaces

namespace — MeasureManager

namespace — MeasureMaster

namespace — Measurement

namespace — MeasurePrefsBuilder

namespace — MechanicalRouting

Classes, Enums and Structs under NXOpen.MechanicalRouting namespace. 

namespace — Mechatronics

Classes, Enums and Structs under NXOpen.Mechatronics namespace. 

namespace — MenuBar

Classes, Enums and Structs under NXOpen.MenuBar namespace. 

namespace — MeshParameterData

namespace — MeshProfileString

namespace — Mfg

Classes, Enums and Structs under NXOpen.Mfg namespace. 

namespace — MfgModel

Classes, Enums and Structs under NXOpen.MfgModel namespace. 

namespace — MFGViewMaker

Classes, Enums and Structs under NXOpen.MFGViewMaker namespace. 

namespace — MigrationManager

Classes, Enums and Structs under NXOpen.MigrationManager namespace. 

namespace — ModelingViewHighQualityImage

namespace — ModlConstraint

namespace — ModlDirect

Classes, Enums and Structs under NXOpen.ModlDirect namespace. 

namespace — ModlUtils

Classes, Enums and Structs under NXOpen.ModlUtils namespace. 

namespace — MoldCooling

Classes, Enums and Structs under NXOpen.MoldCooling namespace. 

namespace — Motion

Classes, Enums and Structs under NXOpen.Motion namespace. 

namespace — MovieSettingsBuilder

namespace — NestingPart

namespace — NestingSettings

namespace — NestingStock

namespace — NXColor

namespace — NXMessageBox

namespace — NXObject

namespace — NXTo2dCreator

namespace — ObjectList

namespace — ObjectSelector

namespace — Offset

namespace — OpenXml

Classes, Enums and Structs under NXOpen.OpenXml namespace. 

namespace — Optimization

Classes, Enums and Structs under NXOpen.Optimization namespace. 

namespace — Options

Classes, Enums and Structs under NXOpen.Options namespace. 

namespace — ParasolidExporter

namespace — Part

namespace — PartCleanup

namespace — PartCollection

namespace — PartDelayedUpdateStatus

namespace — PartFamily

Classes, Enums and Structs under NXOpen.PartFamily namespace. 

namespace — PartImporter

namespace — PartMfg

Classes, Enums and Structs under NXOpen.PartMfg namespace. 

namespace — PartSaveOptions

namespace — PasteSpecialBuilder

namespace — PcbExchange

Classes, Enums and Structs under NXOpen.PcbExchange namespace. 

namespace — PDM

Classes, Enums and Structs under NXOpen.PDM namespace. 

namespace — PhysicalMaterial

namespace — PhysMat

Classes, Enums and Structs under NXOpen.PhysMat namespace. 

namespace — PID

Classes, Enums and Structs under NXOpen.PID namespace. 

namespace — Placement

Classes, Enums and Structs under NXOpen.Placement namespace. 

namespace — PlaneTypes

namespace — PLAS

Classes, Enums and Structs under NXOpen.PLAS namespace. 

namespace — PlasticDesigner

Classes, Enums and Structs under NXOpen.PlasticDesigner namespace. 

namespace — PlotBuilder

namespace — PlotColorsWidthsBuilder

namespace — Point

namespace — PointCollection

namespace — Positioning

Classes, Enums and Structs under NXOpen.Positioning namespace. 

namespace — PositioningDimension

namespace — Preferences

Classes, Enums and Structs under NXOpen.Preferences namespace. 

namespace — PreviewPropertiesBuilder

namespace — Print3dBuilder

namespace — PrintBuilder

namespace — PrintPDFBuilder

namespace — ProeImporter

namespace — PropertyContainer

namespace — QuickUsdzCreator

namespace — RegionRecognition

Classes, Enums and Structs under NXOpen.RegionRecognition namespace. 

namespace — ReplaceExpressionsBuilder

namespace — Report

Classes, Enums and Structs under NXOpen.Report namespace. 

namespace — ResizeHoleData

namespace — RevitImporter

namespace — RhinoImporter

namespace — Routing

Classes, Enums and Structs under NXOpen.Routing namespace. 

namespace — RoutingCommon

Classes, Enums and Structs under NXOpen.RoutingCommon namespace. 

namespace — Rule

Classes, Enums and Structs under NXOpen.Rule namespace. 

namespace — RuleManager

namespace — Scalar

namespace — Schematic

Classes, Enums and Structs under NXOpen.Schematic namespace. 

namespace — Section

namespace — SectionCollection

namespace — Select

Classes, Enums and Structs under NXOpen.Select namespace. 

namespace — Selection

namespace — SelectionIntentRule

namespace — Session

namespace — ShapeSearch

Classes, Enums and Structs under NXOpen.ShapeSearch namespace. 

namespace — SheetMetal

Classes, Enums and Structs under NXOpen.SheetMetal namespace. 

namespace — ShipDesign

Classes, Enums and Structs under NXOpen.ShipDesign namespace. 

namespace — SIM

Classes, Enums and Structs under NXOpen.SIM namespace. 

namespace — Simplify

Classes, Enums and Structs under NXOpen.Simplify namespace. 

namespace — Sketch

namespace — SketchAlignmentConstraint

namespace — SketchAlongPathBuilder

namespace — SketchArcBuilder

namespace — SketchArcFromCenterBuilder

namespace — SketchAssociativeTrimBuilder

namespace — SketchAutoDimensionBuilder

namespace — SketchChamferBuilder

namespace — SketchCheckingSettingsBuilder

namespace — SketchCircleThreePointsBuilder

namespace — SketchConstraintBuilder

namespace — SketchDefineWorkRegionBuilder

namespace — SketchDimensionalConstraint

namespace — SketchDimensionBuilder

namespace — SketchExpressionModifierBuilder

namespace — SketchG1Constraint

namespace — SketchGeometryBuilder

namespace — SketchIssue

namespace — SketchMakeEqualBuilder

namespace — SketchMakeRelationBuilder

namespace — SketchOffset

namespace — SketchOperationBuilder

namespace — SketchOperationData

namespace — SketchPattern

namespace — SketchPolygonBuilder

namespace — SketchProjectBuilder

namespace — SketchRemoteFindingBuilder

namespace — SketchSilhouetteBuilder

namespace — SketchWorkRegionBuilder

namespace — SmartObject

namespace — SpreadsheetCellData

namespace — SpreadsheetManager

namespace — StageModel

Classes, Enums and Structs under NXOpen.StageModel namespace. 

namespace — StageModelTemplate

Classes, Enums and Structs under NXOpen.StageModelTemplate namespace. 

namespace — Step203Importer

namespace — Step214Importer

namespace — Step242Importer

namespace — StepCreator

namespace — STLCreator

namespace — STLImporter

namespace — StructureDesign

Classes, Enums and Structs under NXOpen.StructureDesign namespace. 

namespace — SuppressByExpressionBuilder

namespace — SurfaceRebuildData

namespace — Sustainability

Classes, Enums and Structs under NXOpen.Sustainability namespace. 

namespace — TDP

Classes, Enums and Structs under NXOpen.TDP namespace. 

namespace — ThreeDXMLImporter

namespace — ToolDesigner

Classes, Enums and Structs under NXOpen.ToolDesigner namespace. 

namespace — Tooling

Classes, Enums and Structs under NXOpen.Tooling namespace. 

namespace — UF

Classes, Enums and Structs under NXOpen.UF namespace. 

namespace — UI

namespace — UIStyler

Classes, Enums and Structs under NXOpen.UIStyler namespace. 

namespace — UnitCollection

namespace — Update

namespace — UserDefinedObjects

Classes, Enums and Structs under NXOpen.UserDefinedObjects namespace. 

namespace — UserDefinedTemplate

Classes, Enums and Structs under NXOpen.UserDefinedTemplate namespace. 

namespace — Validate

Classes, Enums and Structs under NXOpen.Validate namespace. 

namespace — Validation

namespace — View

namespace — ViewCollection

namespace — ViewDependentDisplayManager

namespace — ViewSet

namespace — VisualReporting

Classes, Enums and Structs under NXOpen.VisualReporting namespace. 

namespace — VRMLImporter

namespace — Vsa

Classes, Enums and Structs under NXOpen.Vsa namespace. 

namespace — WavefrontObjCreator

namespace — WavefrontObjImporter

namespace — WCS

namespace — Weld

Classes, Enums and Structs under NXOpen.Weld namespace. 

namespace — XformCollection

## Classes

class — AcisExporter

Represents a AcisExporter to be used when importing the Acis Data This class is created using DexManager . More...

class — AcisImporter

Represents a AcisImporter to be used when importing the Acis Data This class is created using DexManager . More...

class — AdjacentSheetBodiesRule

Represents a NXOpen::SelectionIntentRule that collects the adjacent bodies connected with the selected seed body. More...

class — AlignmentStyleT

alignment style 

Enumerator — Comment

NotSet

Horizontal

Vertical

More...

class — ApparentChainingRule

Represents a NXOpen::SelectionIntentRule that collects curves which appear connected or tangent connected in a particular drafting view. More...

class — ApparentChainingRuleSelection

Selection Intent filter method to use with apparent chaining. More...

class — ApparentChainingRuleType

Selection Intent method to use with apparent chaining. More...

class — Arc

Represents an arc curve. More...

class — ArcCollection

Represents a collection of arcs. More...

class — ASCImporter

Represents a NXOpen::ASCImporter . More...

class — AssembliesUtils

Contains various assembly utility methods 

To obtain an instance of this class, refer to NXOpen::Session 

More...

class — AssyCloneLogFileFailures

Represents a structure used to report extra details of an error detected when reading a log file. More...

class — AssyCloneNamingFailures

Represents a list of part names with associated status codes. More...

class — AttributeIterator

This class is used to iterate over the user attributes of an object, with options to restrict or extend such searches. More...

class — AttributeManager

Provides methods for querying and updating attributes. More...

class — AttributePropertiesBaseBuilder

Represents an NXOpen::AttributePropertiesBaseBuilder to be used for creating attributes. More...

class — AttributePropertiesBuilder

Represents an NXOpen::AttributePropertiesBuilder . More...

class — AttributeTemplatesBuilder

Represents an NXOpen::AttributeTemplatesBuilder to be used when creating attribute templates. More...

class — AutomaticTraceline

Represents an automatic traceline. More...

class — Axis

Represents an NXOpen::Axis class. More...

class — AxisCollection

Represents a collection of NXOpen::Axis . More...

class — AxisOrientation

Specifies axis orientation 

Enumerator — Comment

Horizontal

Vertical

More...

class — BaseCreator

This is an abstract class that provides the basic functionality common to all dex export builders. More...

class — BaseImporter

Represents a NXOpen::BaseImporter to be used when importing the Managed mode Data This class is created using NXOpen::DexManager . More...

class — BaseObjectStateManager

Represents base object state manager which allows managing state of copied, reused, wave-linked objects. More...

class — BasePart

Base class for an NX part. More...

class — BasePropertyTable

Represents a property table. More...

class — BaseSession

/ More...

class — BasicEffectivityBuilder

Represent an interface class for basic effectivity block to assign or edit discrete effectivity unit values. More...

class — Body

Represents a Body. More...

class — BodyCollection

Represents a collection of bodies in a part 

To obtain an instance of this class, refer to NXOpen::Part 

More...

class — BodyDumbRule

Represents a NXOpen::SelectionIntentRule that collects bodies without any intent i.e. More...

class — BodyFacetsRule

Represents a NXOpen::FacetSelectionRule that collects all facets from a Face Body. More...

class — BodyFeatureRule

Represents a NXOpen::SelectionIntentRule that collects all bodies created or modified by a feature. More...

class — BodyGroupRule

Represents a NXOpen::SelectionIntentRule that collects all bodies of a group. More...

class — BodyList

Represents a list of objects. More...

class — BorderLineStyleT

border line style 

Enumerator — Comment

NotSet

Continuous

Dash

DashDot

DashDotDot

Dot

Double

SlantDashDot

More...

class — BrushFacetsRule

Represents a NXOpen::FacetSelectionRule that collects facets with brush tool intent. More...

class — Builder

A Builder is an object that is used to create and edit other objects. More...

class — BunchFacetsOnFaceRule

Represents a NXOpen::FacetSelectionRule that collects all facets from a face or a NX faceted body. More...

class — CaeObjectType

Represent options for CAE selection. More...

class — CartesianCoordinateSystem

Represents a cartesian coordinate system 

To create a new instance of this class, use NXOpen::CoordinateSystemCollection::CreateCoordinateSystem 

More...

class — Catiav4Creator

Represents a NXOpen::Catiav4Creator to be used when exporting the CATIA V4 Data This class is created using NXOpen::DexManager . More...

class — Catiav4Importer

Represents a NXOpen::Catiav4Importer to be used when importing the CATIA V4 Data This class is created using NXOpen::DexManager . More...

class — Catiav5Creator

Represents a NXOpen::Catiav5Creator to be used when exporting the CATIA V5 Data This class is created using NXOpen::DexManager . More...

class — Catiav5Importer

Represents a NXOpen::Catiav5Importer to be used when importing the CATIA V5 Data This class is created using NXOpen::DexManager . More...

class — CDF

Represents a NXOpen::CDF , which is a representation of an NX color palette. More...

class — CGMBuilder

Represents a NXOpen::CGMBuilder to be used when exporting the Current Display or drawing sheets to a CGM. More...

class — CGMImporter

Used to import a CGM file into the work part. More...

class — ClipboardOperationsManager

Used to create importer objects. More...

class — CollaborativeContentManager

Represents the manager for the various collaborative design contents and this class is usable only when NX is running in managed mode. More...

class — CollaborativeDesign

A collaborative design is created in Teamcenter. More...

class — CollaborativeDesignCollection

A collection of collaborative designs. More...

class — ColorDefinition

Represents a NXOpen::ColorDefinition , which is a representation of one color on an NX color palette. More...

class — ColorDefinitionRgb

Specifies rgb values for color. More...

class — ColorManager

Contains functionality pertaining to colors 

To obtain an instance of this class, refer to NXOpen::BasePart 

More...

class — ColorRegionRule

Represents a NXOpen::FacetSelectionRule that chains to collect all connected facets of same color. More...

class — ColorWidth

Represents a NXOpen::ColorWidth used by NXOpen::WidthDefinition to define a custom width for each color. More...

class — ComponentReferenceCollector

Represents a Component Reference collector object. More...

class — Conic

Represents a conic curve. More...

class — ConnectedSheetBodiesRule

Represents a NXOpen::SelectionIntentRule that collects the connected bodies connected with the selected seed body. More...

class — ContentDefinition

Represents a class that defines the contents that will be pulled in to a subset. More...

class — ConvergentFacet

Represents a facet from convergent topology. More...

class — ConvertToFromReferenceBuilder

Represents a NXOpen::ConvertToFromReferenceBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateConvertToFromReferenceBuilder 

More...

class — CoordinateSystem

Represents a coordinate system 

This is an abstract class 

More...

class — CoordinateSystemCollection

Represents a collection of NXOpen::CoordinateSystem . More...

class — Creator3MF

Represents a NXOpen::Creator3MF to be used when exporting the 3mf Data This class is created using NXOpen::DexManager . More...

class — CreoImporter

Represents a NXOpen::CreoImporter to be used when importing the Creo Data This class is created using NXOpen::DexManager . More...

class — Curve

Represents a curve. More...

class — CurveChainRule

Represents a NXOpen::SelectionIntentRule that collects end-to-end connected curves from the seed curve. More...

class — CurveCollection

Represents a collection of NXOpen::Curve . More...

class — CurveDumbRule

Represents a NXOpen::SelectionIntentRule that collects curves without any intent i.e. More...

class — CurveFeatureChainRule

Represents a NXOpen::SelectionIntentRule that collects end-to-end connected curves from the feature of the seed. More...

class — CurveFeatureRule

Represents a NXOpen::SelectionIntentRule that collects all curves created by a feature. More...

class — CurveFeatureTangentRule

Represents a NXOpen::SelectionIntentRule that collects tangent connected curves from the feature of the seed. More...

class — CurveGroupRule

Represents a NXOpen::SelectionIntentRule that collects all curves of a group. More...

class — CurveParameterType

Specifies curve parameter type as arc length or percent arc length 

Enumerator — Comment

ArcLength

PercentArcLength

ThroughPoint

More...

class — CurveSnapOptionsBuilder

Represents a NXOpen::CurveSnapOptionsBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateCurveSnapOptionsBuilder 

More...

class — CurveTangentRule

Represents a NXOpen::SelectionIntentRule that collects tangent connected curves from the seed curve. More...

class — CustomPopupMenu

Represents Custom Popup Menu Item class. More...

class — CustomPopupMenuHandler

Represents Custom Popup Menu Handler class. More...

class — CustomPopupMenuItem

Represents Custom Popup Menu Item class. More...

class — CustomWidth

Represents a NXOpen::CustomWidth used by NXOpen::WidthDefinition to define the three custom widths associated with each WidthDefinition. More...

class — CutView

Represents a Cut View 

Cut Views may only be created via a Master Cut Builder. More...

class — CutViewCollection

Represents a collection of NXOpen::CutView objects. More...

class — CylindricalCoordinateSystem

Represents a cylindrical coordinate system 

To create a new instance of this class, use NXOpen::CoordinateSystemCollection::CreateCylindricalCoordinateSystem 

More...

class — DataContainer

Represents a list of data. More...

class — DateBuilder

The DateBuilder class allows for entering or querying a date and/or time, a From-To range of date and/or time, or a list of dates and/or times. More...

class — DateItemBuilder

This class stores a date and time. More...

class — DateItemBuilderList

Represents a list of objects. More...

class — DatumAxis

Represents a datum axis 

This object can not be created by KF it's the display objet of the datum axis 

More...

class — DatumCollection

Represents a collection of datum geometry. More...

class — DatumConstraint

Represents a constraint that specifies the location of a NXOpen::Features::DatumFeature . More...

class — DatumPlane

Represents a datum plane 

This object can be created from NXOpen::Features::DatumPlaneBuilder . More...

class — Decal

Represents a Material Texture decal pair 

This class is restricted to being called from a program running during an Interactive NX session. More...

class — DesignSessionBuilder

Represents a NXOpen::DesignSessionBuilder builder class. More...

class — DexBuilder

This is an abstract class that provides the basic functionality common to all dex builders. More...

class — DexManager

The DexManager class provides methods to create Dex Builder objects. More...

class — Direction

Represents a direction. More...

class — DirectionCollection

Represents a collection of NXOpen::Direction . More...

class — DisplayableObject

Base class for all objects that are displayable. More...

class — DisplayManager

Represents an object to manage display settings. More...

class — DisplayModification

Represents changes to the display characteristics of an object. More...

class — DisplayPartOption

Controls whether or not a new display part may be displayed in addition to existing display parts, or instead of the currently active display part. More...

class — DMUSessionCollection

Represents a Design Session utilities class. More...

class — DraftingManager

Represents an object that manages drafting objects and member views. More...

class — DraftPointDataCollection

This class contains the factory methods for creating a DraftPointData object. More...

class — DrawingCompareManager

Represents an object that manages drawing compare. More...

class — DrawingUtils

Contains various drawing utility methods 

To obtain an instance of this class, refer to NXOpen::Session 

More...

class — DrawShapeTaskEnvironment

Represents the draw shape task environment associated with a session. More...

class — DxfdwgCreator

Represents a NXOpen::DxfdwgCreator to be used when exporting the DXF/DWG Data This class is created using NXOpen::DexManager . More...

class — DxfdwgImporter

Represents a NXOpen::DxfdwgImporter to be used when importing the DXF/DWG Data This class is created using NXOpen::DexManager . More...

class — Edge

Represents an edge 

An edge is obtained from its parent NXOpen::Body 

More...

class — EdgeBodyRule

Represents a NXOpen::SelectionIntentRule that collects all the edges of a body. More...

class — EdgeBoundaryRule

Represents a NXOpen::SelectionIntentRule that collects all the edges of a face. More...

class — EdgeChainRule

Represents a NXOpen::SelectionIntentRule that collects end-to-end connected edges from the body of the seed edge. More...

class — EdgeDumbRule

Represents a NXOpen::SelectionIntentRule that collects edges without any intent i.e. More...

class — EdgeFaceRule

Represents a NXOpen::SelectionIntentRule that collects all edges of a face. More...

class — EdgeFeatureRule

Represents a NXOpen::SelectionIntentRule that collects all edges created or modified by a feature. More...

class — EdgeIntersectRule

Represents a NXOpen::SelectionIntentRule that collects all intersection edges between a set of faces. More...

class — EdgeMultipleSeedTangentRule

Represents a NXOpen::SelectionIntentRule that collects tangent connected edges from the body of the seed edge. More...

class — EdgeSheetBoundaryRule

Represents a NXOpen::SelectionIntentRule that collects boundary edges of a sheet body. More...

class — EdgeTangentRule

Represents a NXOpen::SelectionIntentRule that collects tangent connected edges from the body of the seed edge. More...

class — EdgeVertexRule

Represents a NXOpen::SelectionIntentRule that collects the vertex edge and and its adjacent edges. More...

class — EdgeVertexTangentRule

Represents a NXOpen::SelectionIntentRule that collects the vertex edge and the edges adjacent and tangent to it. More...

class — EffectivityConditionBuilder

Represent a utility class to assign or edit discrete and range effectivity unit values in the context of a NXOpen::CollaborativeDesign . More...

class — Ellipse

Represents an ellipse curve. More...

class — EllipseCollection

Represents a collection of ellipses. More...

class — EndCutBlockBuilder

Represents a End Cut Block Builder. More...

class — EngineeringFunction

Contains Engineering Function methods 

To obtain an instance of this class, refer to NXOpen::Session 

More...

class — ErrorInfo

Contains information about an error that occurred. More...

class — ErrorList

Represents a list of errors. More...

class — ExcelFileFormatT

excel file format 

Enumerator — Comment

WorkbookNormal — .xls

WorkbookDefault — .xlsx

More...

class — Expression

Represents an expression. More...

class — ExpressionCollection

Represents a collection of expressions. More...

class — ExpressionCollectorSet

An object that binds an expression with an entity section in the context of a list. More...

class — ExpressionCollectorSetList

Represents a list of objects. More...

class — ExpressionGroup

Represents an expression group. More...

class — ExpressionGroupCollection

Represents a collection of expressions groups. More...

class — ExpressionSectionSet

An object that binds an expression with an entity section in the context of a list. More...

class — ExpressionSectionSetList

Represents a list of objects. More...

class — ExtendedRealityFileCreator

Represents a NXOpen::ExtendedRealityFileCreator to be used when exporting the extended reality Data This class is created using NXOpen::DexManager . More...

class — ExternalFileReference

Represents an external file reference class 

Use NXOpen::ExternalFileReferenceManager::GetExternalFileReferences to get instance of this class. More...

class — ExternalFileReferenceAdapter

Represents a managed external file reference adapter object to communicate the external file reference information. More...

class — ExternalFileReferenceManager

Provides methods for querying and updating external file references. More...

class — ExtrudeLimitDataLimitType

This enum represents the type of limit 

Enumerator — Comment

Distance

UntilNext

UntilSelected

UntilSelectedExtendFace

ThroughAll

More...

class — ExtrudeOffsetDataOffsetType

This enum represents the type of offset 

Enumerator — Comment

NotSet — No offset

NormalOffset — Offset with two different distances

SymmetricOffset — Offset with same distance in both directions

SingleOffset — Offset with single distance in one direction

More...

class — ExtrudeTaperDataTaperType

This enum represents the type of taper 

Enumerator — Comment

NotSet — No taper

SimpleFromStart — Simple taper from start edges

SimpleFromProfile — Simple taper from profile

Symmetric — Symmetric taper

MatchedEnds — Matched end taper

Asymmetric — ASymmetric taper

More...

class — FabricCollectionValidator

validator for the base fabric data model in a part. More...

class — Face

Represents a face. More...

class — FaceAdjacentRule

Represents a NXOpen::SelectionIntentRule that collects the faces adjacent to the seed face of a body. More...

class — FaceAllBlendRule

Represents a NXOpen::SelectionIntentRule that collects all blend faces. More...

class — FaceAndAdjacentFacesRule

Represents a NXOpen::SelectionIntentRule that collects both the seed face and all its adjacent faces. More...

class — FaceBodyRule

Represents a NXOpen::SelectionIntentRule that collects all the faces of a body. More...

class — FaceBossPocketFacesRule

Represents a NXOpen::SelectionIntentRule that collects all faces of a boss or pocket. More...

class — FaceConnectedBlendRule

Represents a NXOpen::SelectionIntentRule that collects all connected blend faces. More...

class — FaceCurvatureCrossSectionFacesRule

Represents a NXOpen::SelectionIntentRule that collects curvature cross section faces. More...

class — FaceDumbRule

Represents a NXOpen::SelectionIntentRule that collects faces without any intent i.e. More...

class — FaceFacetsRule

Represents a NXOpen::FacetSelectionRule that collects all facets from a face or NX facet body. More...

class — FaceFeatureRule

Represents a NXOpen::SelectionIntentRule that collects all faces created or modified by a feature. More...

class — FaceHoleFacesRule

Represents a NXOpen::SelectionIntentRule that collects all faces of a hole. More...

class — FaceMergedRibFacesRule

Represents a NXOpen::SelectionIntentRule that collects all merged rib faces. More...

class — FaceRegionBoundaryRule

Represents a NXOpen::SelectionIntentRule that collects a region of faces that are tangent connected. More...

class — FaceRegionRule

Represents a NXOpen::SelectionIntentRule that collects a region of faces. More...

class — FaceRibFacesRule

Represents a NXOpen::SelectionIntentRule that collects all rib faces. More...

class — FaceSlotFacesRule

Represents a NXOpen::SelectionIntentRule that collects all faces of a pocket. More...

class — FaceTangentRule

Represents a NXOpen::SelectionIntentRule that collects tangent connected faces from the body of the seed face. More...

class — FacetCollector

Represents collection of facets 

To create a new instance of this class, use NXOpen::FacetCollectorCollection::CreateCollector 

More...

class — FacetCollectorCollection

This class contains the factory method for creating a facet collector. More...

class — FacetSelectionRule

Represents a NXOpen::FacetSelectionRule facet collection rules. More...

class — FacetSelectionRuleFactory

This class contains the factory methods for creating facet selection intent rules 

To obtain an instance of this class, refer to NXOpen::Part 

More...

class — FeatureGeneralPropertiesBuilder

Represents a NXOpen::FeatureGeneralPropertiesBuilder to be used for modifying the names of features and general objects. More...

class — FeatureIntersectionEdgesRule

Represents a NXOpen::SelectionIntentRule that collects the intersection edges of boolean like features. More...

class — FeaturePointsRule

Represents a NXOpen::SelectionIntentRule that collects all points created by a feature. More...

class — FeatureProcessBuilderStatus

Created in NX7.5.0 

More...

class — FileNew

Represents a NXOpen::FileNew 

To create an instance of this class, use NXOpen::PartCollection::FileNew . More...

class — FileNewApplication

The application type of the new file being created through a template. More...

class — FileNewTemplate

Represents a NXOpen::FileNewTemplate 

Use the NXOpen::FileNew to query objects of this class. More...

class — FileNewTemplateType

Enumeration used for templates to determine the type of the template. More...

class — FillBoundaryRule

Represents a NXOpen::FacetSelectionRule that collects flood filled facets without doing any check of facet's existence in current collection. More...

class — FineBrushFacetsRule

Represents a NXOpen::FacetSelectionRule that collects facets with fine brush tool intent. More...

class — FloodFillFacetsRule

Represents a NXOpen::FloodFillFacetsRule that collects flood filled facets. More...

class — FollowFilletRule

Represents a NXOpen::SelectionIntentRule that collects curves/edges which are connected or tangent connected and follow onto and off an untrimmed fillet. More...

class — FollowFilletRuleType

Selection Intent method to use with follow fillet rule. More...

class — FontCollection

Represents a collection of typographical fonts (for example, Arial, OldEnglish) 

To obtain an instance of this class, refer to NXOpen::BasePart 

More...

class — FourPointSurfaceBuilder

Represents a four point sheet body builder 

To create a new instance of this class, use NXOpen::BodyCollection::CreateFourPointSurfaceBuilder 

More...

class — Frame

Represents a frame. More...

class — G3DImporter

Represents a NXOpen::G3DImporter to be used when importing G3D Data This class is created using NXOpen::DexManager . More...

class — GeneralScalarTable

Represents a General M x N table of scalar (real) values. More...

class — GenericMeasure

Represents a single valued measurement. More...

class — GeospatialDataImporter

Represents a NXOpen::GeospatialDataImporter This class is created using NXOpen::DexManager . More...

class — Group

Represents a gateway group 

To create or edit an instance of this class, use NXOpen::GroupBuilder 

More...

class — GroupBuilder

Represents a NXOpen::GroupBuilder 

To create a new instance of this class, use NXOpen::BasePart::CreateGatewayGroupBuilder 

Default values. More...

class — HumanData

Represent the data used to create the human. More...

class — HumanH10DialogBuilder

Dialog for creating and editing V10 Jack Human figures 

To create a new instance of this class, use NXOpen::Features::HumanBuilder::CreateHumanH10DialogBuilder 

Default values. More...

class — HumanHandsDialogBuilder

Dialog for creating and editing standalone/"disembodied" hand figures 

To create a new instance of this class, use NXOpen::Features::HumanBuilder::CreateHumanHandsDialogBuilder 

Default values. More...

class — HumanHandShapeData

Represent hand shape data. More...

class — HumanHCPDialogBuilder

Dialog for manipulating Jack Human figures 

To create a new instance of this class, use NXOpen::Features::HumanBuilder::CreateHumanHcpdialogBuilder 

Default values. More...

class — HumanPosturePrediction

Represent posture prediction object 

To create or edit an instance of this class, use NXOpen::HumanPosturePredictionBuilder 

More...

class — HumanPosturePredictionBuilder

Represents a Human Posture Prediction Builder. More...

class — HumanReachZone

Represents a human reach zone. More...

class — Hyperbola

Represents a hyperbola curve. More...

class — HyperbolaCollection

Represents a collection of hyperbolas. More...

class — IAttributeSourceObjectBuilder

Represents an interface to perform various database operations on an array of NXOpen::NXObject . More...

class — IBaseCurve

Represents something containing a two dimensional curve. More...

class — IBasePlane

Represents a Plane or Datum Plane. More...

class — IBody

Represents something containing a body. More...

class — ICurve

Represents something containing a two dimensional modeling curve. More...

class — IDatum

Represents datum object. More...

class — IExternalFileReferencer

Represents an interface needed to be implemented by the application object which wants to establish an external file reference managed in Teamcenter. More...

class — IFacet

Represents a facet. More...

class — IfcCreator

Represents a NXOpen::IfcCreator to be used when exporting the IFC Data This class is created using NXOpen::DexManager . More...

class — IfcImporter

Represents a NXOpen::IfcImporter to be used when importing IFC Data This class is created using NXOpen::DexManager . More...

class — IFitTo

Represents something that can be supplied to View::FitToObjects. More...

class — IgesCreator

Represents a NXOpen::IgesCreator to be used when exporting the IGES Data This class is created using NXOpen::DexManager . More...

class — IgesImporter

Represents a NXOpen::IgesImporter to be used when importing the IGES Data This class is created using NXOpen::DexManager . More...

class — ILocation

Represents something that can be supplied to an location selection. More...

class — ImplicitModelingTaskEnvironment

Represents the Implicit Modeling task environment associated with a session. More...

class — Importer

Base class for importing data into the work part. More...

class — Importer3MF

Represents a NXOpen::Importer3MF to be used when importing 3MF Data This class is created using NXOpen::DexManager . More...

class — ImportManager

Used to create importer objects. More...

class — InferredConstraintsBuilder

Represents a NXOpen::InferredConstraintsBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateInferredConstraintsBuilder 

More...

class — InferSnapType

Represent options for snap selection. More...

class — InfiniteLine

Represents a infinite line curve. More...

class — InfiniteLineCollection

Represents a collection of infinite lines. More...

class — Information

Represents a class that provides methods for displaying information about part history, interpart parents and children, features, points, and other NX Objects. More...

class — InterpartExpressionsBuilder

This class creates interpart expressions from the source part to the current work part via the naming rule defined. More...

class — InventorImporter

Represents a NXOpen::InventorImporter to be used when importing Inventor Data This class is created using NXOpen::DexManager . More...

class — INXObject

Represents an interface from which most NXOpen classes inherit. More...

class — IOrientation

Represents something that can be supplied to an orientation selection. More...

class — IParameterizedSurface

Represents something containing a face. More...

class — IPlane

Represents an Plane class. More...

class — IPlaneForXformByThreePlanes

Represents something containing a two dimensional surface that can be used in creating an Xform from three planes. More...

class — IProfile

Represents something that can be supplied to a profile. More...

class — IReferenceAxis

Represents an object that could be used as a reference axis for a feature. More...

class — ISketchHelpedConstraint

Represents a sketch constraint that has a help point or help parameter. More...

class — ISurface

Represents something containing a two dimensional surface. More...

class — ITableEditorDataProvider

Interface for providing basic data for a Table Editor block. More...

class — ItemCacheMappedEntityBuilder

Generic journal methods for ItemCacheMappedEntityBuilder 

Not support KF. More...

class — JournalManager

Represents the JournalManager which is used to query data about journals when recording and replaying journal files. More...

class — JtCreator

Represents a NXOpen::JtCreator to be used when exporting the JT Data This class is created using NXOpen::PvtransManager . More...

class — KFObject

Represents an KF object in the part. More...

class — Layout

Represents a layout. More...

class — LayoutCollection

Represents a collection of layouts. More...

class — LayoutDefinition

Represents the definition of a layout. More...

class — LicenseManager

Provides utility methods for managing licenses. More...

class — Light

Represents a light source. More...

class — LightCollection

Represents a collection of NXOpen::Light s. More...

class — Line

Represents a line curve. More...

class — LineCollection

Represents a collection of lines. More...

class — LineColorFontWidthBuilder

Represent a NXOpen::LineColorFontWidthBuilder 

This is a sub-builder class and cannot be directly instantiated 

More...

class — LineFontBuilder

Represent a NXOpen::LineFontBuilder 

This is a sub-builder class and cannot be directly instantiated 

More...

class — LineFontOption

the line font options. More...

class — LineWidthBuilder

Represents a NXOpen::LineWidthBuilder. More...

class — LineWidthOption

the line width options. More...

class — LinkedMirrorPartAttributeEditData

JA interface for LinkedMirrorPartAttributeEditData object 

This cannot be created 

More...

class — LinkedMirrorPartAttributeEditEvent

JA interface for LinkedMirrorPartAttributeEditEvent object 

This cannot be created 

More...

class — LinkedMirrorPartBuilder

builder class of LinkedMirrorPartBuilder 

To create a new instance of this class, use NXOpen::PartCollection::CreateLinkedMirrorPartBuilder 

Default values. More...

class — LinkedMirrorPartEntityMapData

JA interface for LinkedMirrorPartEntityMapData oject 

This cannot be created 

More...

class — LinkedMirrorPartEntityMapEvent

JA interface for LinkedMirrorPartEntityMapEvent object 

This cannot be created 

More...

class — LinkedPartManager

Represents the customization interface during linked mirror part creation and update. More...

class — ListCreator

Represents a NXOpen::ListCreator to be used when exporting the JT Data This class is created using NXOpen::PvtransManager . More...

class — ListCreatorList

Represents a list of objects. More...

class — ListingWindow

Represents Listing devices; either files, the UI Information window, or both. More...

class — LoadOptions

Contains accessor methods for all the part load options. More...

class — LogFile

Represents the system log file 

To obtain an instance of this class, refer to NXOpen::Session 

More...

class — Markup

Represents a NXOpen::Markup::Markup 

To create a new instance of this class, use NXOpen::Markup::MarkupCollection::CreateMarkup 

More...

class — MassPropertiesBuilder

Represents a NXOpen::MassPropertiesBuilder for calculating the weight of selected objects as well as informing the part that the assemblies weight property data needs to be updated on save. More...

class — Material

Represents Material 

This is an abstract class 

More...

class — MaterialManager

A manager to deal with all material objects 

To obtain an instance of this class, refer to NXOpen::BasePart 

More...

class — MaterialUtilities

Represents Physical NXOpen::MaterialUtilities class 

To obtain an instance of this class, refer to NXOpen::CAE::CaeSession 

More...

class — MathUtils

Contains various math utility methods 

To obtain an instance of this class, refer to NXOpen::Session 

More...

class — Matrix3x3

Represents a 3 x 3 matrix. More...

class — Matrix4x4

Represents a homogenous coordinate system transformation matrix. More...

class — Measure

Represents a measurement feature 

To create an instance of this use NXOpen::MeasureBodies , NXOpen::MeasureDistance , NXOpen::MeasureAngle , NXOpen::MeasureFaces , and NXOpen::MeasureLength 

More...

class — MeasureAngle

Represents a single valued Angle measurement 

To create or edit an instance of this class, use NXOpen::MeasureAngleBuilder 

More...

class — MeasureAngleBuilder

Represents a NXOpen::MeasureAngleBuilder 

To create a new instance of this class, use NXOpen::MeasureManager::CreateMeasureAngleBuilder 

More...

class — MeasureBodies

Represents the measurement specific mass properties for a set of bodies 

To create or edit an instance of this class, use NXOpen::MeasureBodyBuilder 

More...

class — MeasureBodyBuilder

Represents a NXOpen::MeasureBodyBuilder 

To create a new instance of this class, use NXOpen::MeasureManager::CreateMeasureBodyBuilder 

More...

class — MeasureBuilder

Represents a NXOpen::MeasureBuilder 

This is an abstract class, and cannot be instantiated. More...

class — MeasureDistance

Represents a single valued distance measurement 

To create or edit an instance of this class, use NXOpen::MeasureDistanceBuilder 

More...

class — MeasureDistanceBuilder

Represents a NXOpen::MeasureDistanceBuilder 

To create a new instance of this class, use NXOpen::MeasureManager::CreateMeasureDistanceBuilder 

More...

class — MeasureElement

Represents an element of a master measurement. More...

class — MeasureExtremePoint

Represents an extreme point measurement. More...

class — MeasureFaceBuilder

Represents a NXOpen::MeasureFaceBuilder 

To create a new instance of this class, use NXOpen::MeasureManager::CreateMeasureFaceBuilder 

More...

class — MeasureFaces

Represents the measurement of perimeter and area of a set of faces 

To create or edit an instance of this class, use NXOpen::MeasureFaceBuilder 

More...

class — MeasureLength

Represents a single valued length measurement. More...

class — MeasureManager

Provides methods for manipulating the measurement objects in a part. More...

class — MeasureMaster

Represents a collector of measure elements 

To create an instance of this use NXOpen::MeasureManager 

More...

class — MeasureMasterBuilder

Represents a NXOpen::MeasureMasterBuilder 

To create a new instance of this class, use NXOpen::MeasureManager::CreateMeasureMasterBuilder 

More...

class — Measurement

Provides methods for calculating and displaying the measurement information. More...

class — MeasurePoint

Represents a point measurement. More...

class — MeasurePolarAngle

Represents a single valued polar angle measurement. More...

class — MeasurePolarArea

Represents a single valued polar area measurement. More...

class — MeasurePolarRadius

Represents a single valued polar radius measurement. More...

class — MeasurePrefsBuilder

Represents a NXOpen::MeasurePrefsBuilder 

To create a new instance of this class, use NXOpen::Preferences::SessionPreferences::CreateModelingPreferencesBuilder 

More...

class — MeasureRectangularExtreme

Represents a rectangular extreme point measurement. More...

class — MeshParameterData

Represents surface rebuild data structure. More...

class — MeshProfileString

Represents Mesh profile string 

To create a new instance of this class, use NXOpen::Features::MeshSurfaceBuilder::NewProfile 

More...

class — ModelingView

Represents a Modeling View 

Modeling Views may only be created by Save As. More...

class — ModelingViewCollection

Represents a collection of ModelingView s. More...

class — ModelingViewHighQualityImage

Represents the properties and methods for generating a High Quality Image of a Modeling View 

To obtain an instance of this class, refer to NXOpen::ModelingView 

More...

class — ModelingViewList

Represents a list of objects. More...

class — ModlConstraint

Represents a constraint in NX for Skylight. More...

class — MorphMeshTaskEnvironment

Represents the Morph Mesh task environment associated with a session. More...

class — MovieManager

Represents a MovieManager class. More...

class — MovieSettingsBuilder

This class is the builder for the Movie Settings. More...

class — NavigatorFilter

Represents a NXOpen::NavigatorFilter object. More...

class — NestedSolution

Represents a sheet metal nesting solution class. More...

class — NestingPart

Represents a sheet metal nesting part class. More...

class — NestingSettings

Represents a sheet metal nesting settings class. More...

class — NestingStock

Represents a sheet metal nesting stock class. More...

class — NXColor

Represents a standard NX color. More...

class — NXEvent

class — NXException

A base class for exceptions thrown by NXOpen methods. More...

class — NxFacet

Represents a facet from convergent topology. More...

class — NXMatrix

Represents an NX matrix. More...

class — NXMatrixCollection

Represents a collection of NX Matrixes. More...

class — NXMessageBox

Displays message box. More...

class — NXObject

A base class providing low-level services for most NXOpen classes. More...

class — NXObjectList

Represents a list of objects. More...

class — NXTo2dCreator

Represents a NXOpen::NXTo2dCreator to be used when exporting the 2D Data This class is created using NXOpen::DexManager . More...

class — Object

class — ObjectGeneralPropertiesBuilder

Represents an NXOpen::ObjectGeneralPropertiesBuilder to be used for modifying the names and properties of objects. More...

class — ObjectList

Represents a list of objects. More...

class — ObjectSelector

Represents a NXOpen::ObjectSelector to be used when exporting the the selected objects from NX part.This class is created using NXOpen::DexManager . More...

class — ObjectTypeSelector

Represents a NXOpen::ObjectTypeSelector to be used when filter out the objects based on the type during import/export. More...

class — Offset

Represents a NXOpen::Offset . More...

class — OffsetCollection

Represents a collection of NXOpen::Offset . More...

class — OriginMethod

Specifies origin method 

Enumerator — Comment

SpecifyPoint — Specify Point

WorkPartOrigin — Use Work Part Origin

More...

class — OuterEdgesOfFacesRule

Represents a NXOpen::SelectionIntentRule that collects the outer edges of a group of faces. More...

class — Parabola

Represents a parabola curve. More...

class — ParabolaCollection

Represents a collection of Parabolas 

To obtain an instance of this class, refer to NXOpen::BasePart 

More...

class — ParameterTable

Represents a parameter table. More...

class — ParameterTableCollection

Represents a collection of parameterTable. More...

class — ParamLibLibraryManagerBuilder

Represents a ParamLibLibraryManagerBuilder builder. More...

class — ParamLibParameter

Represents Parameter. More...

class — ParamLibParameterBuilder

Represents a ParamLibParameterBuilder builder. More...

class — ParamLibParameterCollection

Represents the collection of all ParamLibParameter objects in this Part. More...

class — ParamLibParameterLibraryManager

A manager to deal with all parameter objects 

To obtain an instance of this class, refer to NXOpen::BasePart 

More...

class — ParamLibParameterListBuilder

This builder is used by the Parameters list component that allows copying, editing, deleting, etc. More...

class — ParasolidExporter

Represents a NXOpen::ParasolidExporter to be used when exporting Parasolid entities. More...

class — ParasolidImporter

Represents a NXOpen::ParasolidImporter to be used when importing the Parasolid Data This class is created using NXOpen::DexManager . More...

class — Part

Represents an NX part of type .prt. More...

class — PartCleanup

Provides utilities to to eliminate certain inaccessible objects from the part file. More...

class — PartCloseResponses

Manages a list of part name/response pairs which are used to determine whether a part should be closed if modified during part close. More...

class — PartCloseStatus

This class represents a list of part names with associated status codes that serve to communicate why these parts were not able to be closed. More...

class — PartCollection

Represents the collection of all parts in a session. More...

class — PartDelayedUpdateStatus

Represents a list of part names with associated delay status codes. More...

class — PartDisplayPartWorkPartOption

Controls what the work part will be when setting active display part. More...

class — PartFamilyManager

This class represents part family 

Use NXOpen::Part::GetPartFamilyManager to get the instance of this class. More...

class — PartFamilyMemberData

This class is responsible for storing part family member data Use the method NXOpen::Part::NewPartFamilyMemberData to create new instance of this class. More...

class — PartFamilyMemberValues

This class is responsible for storing part family member attribute values. More...

class — PartImporter

Used to import a part into the work part. More...

class — PartLoadState

Represents the part load information. More...

class — PartLoadStatus

Represents a list of part names with associated status codes. More...

class — PartReopenReport

Contains information about a part and its components after it has been reopened. More...

class — PartReopenStatus

Contains information about a part after an attempt was made to reopen it. More...

class — PartSaveOptions

Contains accessor methods for all part save options that follow the part. More...

class — PartSaveStatus

This class represents a list of part names with associated status codes that serve to communicate why these parts where not able to be saved during part save. More...

class — PasteSpecialBuilder

Represents a NXOpen::PasteSpecialBuilder 

To create a new instance of this class, use NXOpen::ClipboardOperationsManager::CreatePasteSpecialBuilder 

Default values. More...

class — PerformanceManagerOutputDevice

Represents the options to print all the performance statistics information into output device 

Enumerator — Comment

Syslog — Print all data to sylog

ListingWindow — Print all data to listing window

Xml — Print all data to xml in autotest mode only

NotSet — No output

More...

class — Persistence

Specifies persistence 

Enumerator — Comment

Temporary

Permanent

More...

class — PhysicalMaterial

Represents Physical Material. More...

class — PhysicalMaterialBuilder

Represents a NXOpen::PhysicalMaterial builder 

To create a new instance of this class, use NXOpen::PhysicalMaterialCollection::CreatePhysicalMaterialBuilder 

More...

class — PhysicalMaterialCollection

Represents the collection of all NXOpen::PhysicalMaterial objects in this Part. More...

class — Plane

Represents an Plane class. More...

class — PlaneCollection

Represents a collection of NXOpen::Plane . More...

class — PlaneList

Represents a list of objects. More...

class — PlaneNormalOrientation

Specifies the orientation of a plane's normal 

Enumerator — Comment

Inward

Outward

More...

class — PlaneTypes

Represents an NXOpen::PlaneTypes class. More...

class — PlotBuilder

Represents a NXOpen::PlotBuilder . More...

class — PlotColorsWidthsBuilder

Represents a NXOpen::PlotColorsWidthsBuilder to be used for plotting. More...

class — PlotManager

The PlotManager class provides methods to create Gateway Builder objects. More...

class — PlotSourceBuilder

Represents a NXOpen::PlotSourceBuilder. More...

class — Point

Represents a smart Point . More...

class — Point2d

Represents two-dimensional cartesian coordinates for a point. More...

class — Point3d

Represents three-dimensional cartesian coordinates for a point. More...

class — Point4d

Represents four-dimensional homogeneous coordinates for a point. More...

class — PointCollection

Represents a collection of smart NXOpen::Point . More...

class — PointList

Represents a list of objects. More...

class — PolygonModelingTaskEnvironment

Represents the Polygon Modeling task environment associated with a session. More...

class — Polyline

Represents a polyline curve. More...

class — PolylineCollection

Represents a collection of polylines. More...

class — PositioningDimension

Represents a dimension object attached to the feature 

Intances of this object cannot be directly be created. More...

class — PreviewBuilder

Represents a Preview Builder. More...

class — PreviewPropertiesBuilder

Represents a NXOpen::PreviewPropertiesBuilder to be used for creating and storing previews. More...

class — PrimitiveFacetsRule

Represents a NXOpen::PrimitiveFacetsRule that collects primitive facets. More...

class — Print3dBuilder

This class sends the 3d model for 3dprinting. More...

class — PrintBuilder

Represents a NXOpen::PrintBuilder . More...

class — PrintPDFBuilder

Represents a NXOpen::PrintPDFBuilder to be used when exporting the Current Display or selected sheets to a PDF document. More...

class — PrintSVGBuilder

Represents a NXOpen::PrintSVGBuilder to be used when exporting the current display or selected sheets to a SVG document. More...

class — ProeImporter

Represents a NXOpen::ProeImporter to be used when importing the ProE Data This class is created using NXOpen::DexManager . More...

class — PropertiesManager

The PropertiesManager class provides methods to create Gateway Properties Builder objects. More...

class — PropertyContainer

Represents a list of properties. More...

class — PvtransManager

The PvtransManager class provides methods to create Pvtrans Builder objects. More...

class — QuickUsdzCreator

Represents a NXOpen::QuickUsdzCreator to be used when quick exporting USDZ file This class is created using NXOpen::DexManager . More...

class — ReferenceSet

Represents a NXOpen::ReferenceSet . More...

class — RegionBoundaryRule

Represents a NXOpen::SelectionIntentRule that collects curves as specified by an enclosed region. More...

class — RegionPoint

Represents a point and body context on a region point. More...

class — RegionPointList

Represents a list of objects. More...

class — RelationFinderSettingsBuilder

Represents a NXOpen::RelationFinderSettingsBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateRelationFinderSettingsBuilder 

More...

class — ReplaceExpressionsBuilder

This class creates Replace expressions from the source part to the current work part via the naming rule defined. More...

class — Report

Represents a report. More...

class — ResizeHoleData

Represents a NXOpen::ResizeHoleData to get the hole data follow the same recognition of hole in Resize Hole. More...

class — RevitImporter

Represents a NXOpen::RevitImporter to be used when importing Revit Data This class is created using NXOpen::DexManager . More...

class — RhinoImporter

Represents a NXOpen::RhinoImporter to be used when importing Rhino Data This class is created using NXOpen::DexManager . More...

class — RibTopFaceEdgesRule

Represents a NXOpen::SelectionIntentRule that collects the like convexity outer edges of a group of faces. More...

class — RotationDirection

Specifies rotation direction 

Enumerator — Comment

RightHand

LeftHand

More...

class — RoughBrushFacetsRule

Represents a NXOpen::FacetSelectionRule that collects facets with rough brush tool intent. More...

class — RuleManager

Provides methods for manipulating the Knowledge Fusion rules in a part. More...

class — SaveOptions

Contains accessor methods for all part save options that follow the session. More...

class — Scalar

Represents a scalar. More...

class — ScalarCollection

Represents a collection of NXOpen::Scalar objects. More...

class — ScalarMatrixValue

Represents a General M x N matrix of scalar (real) values. More...

class — ScalarTableValue

Represents a General M x N table of scalar (real) values. More...

class — ScCollector

Represents a collector 

ScCollector consists of collection of either faces, bodies, edges, curves or a mixed collection of these entities. More...

class — ScCollectorAllowTypes

Defines entity types allowed 

Enumerator — Comment

Uninitialized — This is uninitialized state.

More...

class — ScCollectorCollection

This class contains the factory methods for creating a sc collector. More...

class — ScCollectorList

Represents a list of objects. More...

class — ScEvaluationFiltertype

Tokens used to create different evaluation filters on ScCollector 

Enumerator — Comment

SleepyEntity

LaminarEdge

MinimumBody

SheetBody

FacetEntity

More...

class — ScRuleFactory

This class contains the factory methods for creating selection intent rules 

To obtain an instance of this class, refer to NXOpen::BasePart 

More...

class — Section

Represents a section 

Section consists of "chained_entity", a chain or a single entity of edge or curve. More...

class — SectionCollection

This class contains the factory methods for creating a section. More...

class — SectionData

Represents section data. More...

class — SectionElementData

Represents section element data. More...

class — SectionList

Represents a list of objects. More...

class — SelectArc

Represents a single object selection. More...

class — SelectBody

Represents a single object selection. More...

class — SelectBodyList

Represents a list of objects on a selection list. More...

class — SelectCartesianCoordinateSystem

Represents a single object selection. More...

class — SelectCoordinateSystem

Represents a single object selection. More...

class — SelectCoordinateSystemList

Represents a list of objects on a selection list. More...

class — SelectCurve

Represents a single object selection. More...

class — SelectCurveList

Represents a list of objects on a selection list. More...

class — SelectDatumPlane

Represents a single object selection. More...

class — SelectDatumPlaneList

Represents a list of objects on a selection list. More...

class — SelectDisplayableObject

Represents a single object selection. More...

class — SelectDisplayableObjectList

Represents a list of objects on a selection list. More...

class — SelectEdge

Represents a single object selection. More...

class — SelectEdgeList

Represents a list of objects on a selection list. More...

class — SelectExpressionList

Represents a list of objects on a selection list. More...

class — SelectFace

Represents a single object selection. More...

class — SelectFaceList

Represents a list of objects on a selection list. More...

class — SelectGridBuilder

This class allow you to select grid plane from the grid part in the ship application 

This is an abstract class, and cannot be instantiated. More...

class — SelectGroup

Represents a single object selection. More...

class — SelectGroupList

Represents a list of objects on a selection list. More...

class — SelectIBaseCurve

Represents a single object selection. More...

class — SelectIBaseCurveList

Represents a list of objects on a selection list. More...

class — SelectIBasePlaneList

Represents a list of objects on a selection list. More...

class — SelectIBody

Represents a single object selection. More...

class — SelectICurve

Represents a single object selection. More...

class — SelectICurveList

Represents a list of objects on a selection list. More...

class — SelectINXObjectList

Represents a list of objects on a selection list. More...

class — Selection

Defines an interface object for executing selection operations 

To obtain an instance of this class, refer to NXOpen::UI 

More...

class — SelectionHandle

Represents a SelectionHandle for UI Styler. More...

class — SelectionIntentRule

Represents a NXOpen::SelectionIntentRule which essentially provides capabilities to collect curves, edges, faces and bodies. More...

class — SelectionIntentRuleOptions

Represents a NXOpen::SelectionIntentRuleOptions which essentially provides capabilities to collect various paramters controlling the rule creation. More...

class — SelectionMethod

Represents the output from a smart selector method 

This is an abstract class, and cannot be created. More...

class — SelectionSubscriber

Defines a SelectionSubscriber for managing selection events 

To create a new instance of this class, use NXOpen::Selection::CreateSelectionSubscriber 

More...

class — SelectIParameterizedSurface

Represents a single object selection. More...

class — SelectIParameterizedSurfaceList

Represents a list of objects on a selection list. More...

class — SelectIReferenceAxis

Represents a single object selection. More...

class — SelectISurface

Represents a single object selection. More...

class — SelectLine

Represents a single object selection. More...

class — SelectModelingViewList

Represents a list of objects on a selection list. More...

class — SelectNXObject

Represents a single object selection. More...

class — SelectNXObjectList

Represents a list of objects on a selection list. More...

class — SelectObject

Represents a single object selection. More...

class — SelectObjectList

Represents a list of objects on a selection list. More...

class — SelectPart

Represents a single object selection. More...

class — SelectPartList

Represents a list of objects on a selection list. More...

class — SelectPlane

Represents a single object selection. More...

class — SelectPoint

Represents a single object selection. More...

class — SelectPointList

Represents a list of objects on a selection list. More...

class — SelectSelectObject

Represents a single object selection. More...

class — SelectSketch

Represents a single object selection. More...

class — SelectSketchList

Represents a list of objects on a selection list. More...

class — SelectSketchMakeUniformScaleBuilderList

Represents a list of objects on a selection list. More...

class — SelectSmartObject

Represents a single object selection. More...

class — SelectSmartObjectList

Represents a list of objects on a selection list. More...

class — SelectSpline

Represents a single object selection. More...

class — SelectSplineList

Represents a list of objects on a selection list. More...

class — SelectTaggedObject

Represents a single object selection. More...

class — SelectTaggedObjectList

Represents a list of objects on a selection list. More...

class — SelectView

Represents a single object selection. More...

class — SelectViewList

Represents a list of objects on a selection list. More...

class — Sense

Specifies sense direction 

Enumerator — Comment

Forward

Reverse

More...

class — Session

Represents the NX session. More...

class — SheetAndAdjacentSheetBodiesRule

Represents a NXOpen::SelectionIntentRule that collects the adjacent bodies connected with the selected seed body along with selected body. More...

class — SimpleSketchInPlaceBuilder

Use the NXOpen::SimpleSketchInPlaceBuilder to create a NXOpen::Sketch on a NXOpen::DatumPlane or planar NXOpen::Face . More...

class — SingleFacetRule

Represents a NXOpen::FacetSelectionRule that collects facets without any intent i.e. More...

class — SingleMeasure

Represents a single valued measurement. More...

class — Sketch

Represents a sketch 

Use the NXOpen::SketchCollection class to create a sketch. More...

class — SketchAlignmentConstraint

Represents a sketch alignment constraint 

Use NXOpen::SketchConstraintBuilder to create an instance of this class. More...

class — SketchAlongPathBuilder

Use the NXOpen::SketchAlongPathBuilder to create or reattach a NXOpen::Sketch along a path. More...

class — SketchAngularDimensionBuilder

Represents a NXOpen::SketchAngularDimensionBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateAngularDimensionBuilder 

More...

class — SketchArcBuilder

Create an arc in the active sketch. More...

class — SketchArcFromCenterBuilder

Create an Arc-From-Center in the active sketch. More...

class — SketchAssociativeTrim

Represents a sketch associative trim constraint 

Use SketchCollection::CreateSketchAssociativeTrimBuilder to create an instance of this class. More...

class — SketchAssociativeTrimBuilder

Represents a NXOpen::SketchAssociativeTrimBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateSketchAssociativeTrimBuilder 

Default values. More...

class — SketchAutoConstrainBuilder

Represents a NXOpen::SketchAutoConstrainBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateAutoConstrainBuilder 

Default values. More...

class — SketchAutoDimensionBuilder

Represents a NXOpen::SketchAutoDimensionBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateAutoDimensionBuilder 

Default values. More...

class — SketchChamferBuilder

Represents a Chamfer builder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateSketchChamferBuilder 

Default values. More...

class — SketchCheckingSettingsBuilder

Represents a NXOpen::SketchCheckingSettingsBuilder . More...

class — SketchCircleBuilder

Create a Circle-From-Center in the active sketch. More...

class — SketchCircleThreePointsBuilder

Create a Three-Point Circle in the active sketch. More...

class — SketchCollection

Represents a collection of sketches 

To obtain an instance of this class, refer to NXOpen::Part 

More...

class — SketchConicBuilder

Represents a NXOpen::SketchConicBuilder builder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateSketchConicBuilder 

Default values. More...

class — SketchConstraint

Represents a constraint in a sketch. More...

class — SketchConstraintBuilder

Represents a NXOpen::SketchConstraint builder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateConstraintBuilder 

More...

class — SketchControlPoint

Sketch operations can involve an entire geometric object, such as a NXOpen::Line , or a control point of the geometry, such as a start point or center point. More...

class — SketchCornerBuilder

Create a corner between two sketch curves. More...

class — SketchDefineWorkRegionBuilder

Represents a NXOpen::SketchDefineWorkRegionBuilder builder. More...

class — SketchDimensionalConstraint

Represents a dimensional constraint 

To create an instance of this class refer to NXOpen::Sketch 

More...

class — SketchDimensionBuilder

Edit the geometry references of an existing sketch dimension. More...

class — SketchDragGeometryBuilder

The NXOpen::SketchDragGeometryBuilder is used to move sketch geometry while honoring found and persistent relations. More...

class — SketchEditDefiningSectionBuilder

Represents a NXOpen::SketchEditDefiningSectionBuilder builder. More...

class — SketchEditDimensionValueBuilder

Represents a NXOpen::SketchEditDimensionValueBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateEditDimensionValueBuilder 

More...

class — SketchEditParametersBuilder

Represents a NXOpen::SketchEditParametersBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateEditParametersBuilder 

More...

class — SketchEllipseBuilder

Represents a NXOpen::SketchEllipseBuilder builder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateSketchEllipseBuilder 

Default values. More...

class — SketchEvaluator

Represents a sketch-on-path evaluator. More...

class — SketchEvaluatorCollection

Represents a collection of NXOpen::SketchEvaluator . More...

class — SketchExpressionModifierBuilder

Represents a Sketch Expression Modifier Builder. More...

class — SketchFindIssuesBuilder

Represents a NXOpen::SketchFindIssuesBuilder . More...

class — SketchFindMovableObjectsBuilder

Represents a NXOpen::SketchFindMovableObjectsBuilder builder. More...

class — SketchFixObjectsBuilder

Represents a NXOpen::SketchFixObjectsBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateSketchFixObjectsBuilder 

More...

class — SketchFoundRelation

Represents a relation in a sketch. More...

class — SketchG1Constraint

Represents a sketch G1 constraint 

Use NXOpen::Features::FeatureCollection::CreateSketchSplineBuilder to create an instance of this class. More...

class — SketchG2Constraint

Represents a sketch G2 constraint 

Use NXOpen::Features::FeatureCollection::CreateSketchSplineBuilder to create an instance of this class. More...

class — SketchGeometricConstraint

Represents a geometric sketch constraint 

To create an instance of this class refer to Sketch 

More...

class — SketchGeometryBuilder

Create geometry in the active sketch. More...

class — SketchHelpedDimensionalConstraint

Represents a dimensional sketch constraint that has a help point or help parameter 

More...

class — SketchHelpedGeometricConstraint

Represents a geometric sketch constraint that has a help point or help parameter 

To obtain an instance of this class, use Sketch 

More...

class — SketchIgnoreRelationBuilder

Represents a NXOpen::SketchIgnoreRelationBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateIgnoreRelationBuilder 

More...

class — SketchIncludeGeometryBuilder

Represents a NXOpen::SketchIncludeGeometryBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateSketchIncludeGeometryBuilder 

More...

class — SketchInDraftingBuilder

Use the NXOpen::SketchInDraftingBuilder to create a NXOpen::Sketch on a NXOpen::Drawings::DraftingView or NXOpen::Drawings::DrawingSheet . More...

class — SketchInPlaceBuilder

Use the NXOpen::SketchInPlaceBuilder to create or reattach a NXOpen::Sketch on a NXOpen::DatumPlane or planar NXOpen::Face . More...

class — SketchIntersectionCurve

Represents a Intersection Curve operation inside sketch 

To create an instance of this object use NXOpen::SketchIntersectionCurveBuilder 

More...

class — SketchIntersectionCurveBuilder

Represents a NXOpen::SketchIntersectionCurve builder 

To obtain an instance of this class use NXOpen::SketchCollection::CreateIntersectionCurveBuilder . More...

class — SketchIntersectionPoint

Represents an Intersection Point operation inside sketch 

To create an instance of this object use NXOpen::SketchIntersectionPointBuilder 

More...

class — SketchIntersectionPointBuilder

Represents a NXOpen::SketchIntersectionPoint builder 

To obtain an instance of this class use NXOpen::SketchCollection::CreateIntersectionPointBuilder . More...

class — SketchIssue

Represents a sketch checking issue. More...

class — SketchLinearDimensionBuilder

Represents a NXOpen::SketchLinearDimensionBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateLinearDimensionBuilder 

More...

class — SketchLineBuilder

Create a line in the active sketch. More...

class — SketchMakeCoincidentBuilder

Represents a NXOpen::SketchMakeCoincidentBuilder builder. More...

class — SketchMakeCollinearBuilder

Represents a NXOpen::SketchMakeCollinearBuilder builder. More...

class — SketchMakeEqualBuilder

Represents a NXOpen::SketchMakeEqualBuilder builder. More...

class — SketchMakeHorizontalBuilder

Represents a NXOpen::SketchMakeHorizontalBuilder builder. More...

class — SketchMakeMidpointAlignedBuilder

Represents a NXOpen::SketchMakeMidpointAlignedBuilder builder. More...

class — SketchMakeParallelBuilder

Represents a NXOpen::SketchMakeParallelBuilder builder. More...

class — SketchMakePerpendicularBuilder

Represents a NXOpen::SketchMakePerpendicularBuilder builder. More...

class — SketchMakePerpendicularToStringBuilder

Represents a NXOpen::SketchMakePerpendicularToStringBuilder builder. More...

class — SketchMakePointOnStringBuilder

Represents a NXOpen::SketchMakePointOnStringBuilder builder. More...

class — SketchMakeRelationBuilder

Represents a NXOpen::SketchMakeRelationBuilder builder. More...

class — SketchMakeSymmetricBuilder

This class is used to add symmetric contraint to objects from a NXOpen::SketchMakeSymmetricBuilder . More...

class — SketchMakeTangentBuilder

Represents a NXOpen::SketchMakeTangentBuilder builder. More...

class — SketchMakeTangentToStringBuilder

Represents a NXOpen::SketchMakeTangentToStringBuilder builder. More...

class — SketchMakeUniformScaleBuilder

Represents a NXOpen::SketchMakeUniformScaleBuilder builder. More...

class — SketchMakeVerticalBuilder

Represents a NXOpen::SketchMakeVerticalBuilder builder. More...

class — SketchManageSymmetryLinesBuilder

Represents a NXOpen::SketchManageSymmetryLinesBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateSketchManageSymmetryLinesBuilder 

More...

class — SketchMirrorPatternBuilder

Represents a NXOpen::SketchMirrorPatternBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateSketchMirrorPatternBuilder 

Default values. More...

class — SketchOffset

Represents a sketch offset constraint 

Use SketchCollection::CreateSketchOffsetBuilder to create an instance of this class. More...

class — SketchOffsetBuilder

Represents a NXOpen::SketchOffsetBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateSketchOffsetBuilder 

Default values. More...

class — SketchOperationBuilder

Represents a NXOpen::SketchOperationBuilder . More...

class — SketchOperationData

Represents a NXOpen::SketchOperationData . More...

class — SketchOperationgeometry

Sketch operations can use an entire geometry, such as a NXOpen::Line , or a control point of the geometry, such as a start point or center point. More...

class — SketchPasteBuilder

Represents a NXOpen::SketchPasteBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateSketchPasteBuilder 

Default values. More...

class — SketchPattern

Represents a sketch pattern constraint 

Use SketchCollection::CreateSketchPatternBuilder to create an instance of this class. More...

class — SketchPatternBuilder

Represents a NXOpen::SketchPatternBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateSketchPatternBuilder 

Default values. More...

class — SketchPolygon

Represents a polygon constraint in a sketch 

To create or edit an instance of this class, use NXOpen::SketchPolygonBuilder 

More...

class — SketchPolygonBuilder

Represents a NXOpen::SketchPolygon builder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateSketchPolygonBuilder 

Default values. More...

class — SketchProjectBuilder

Represents a NXOpen::SketchProjectBuilder builder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateProjectBuilder 

Default values. More...

class — SketchQuickExtendBuilder

Represents a NXOpen::SketchQuickExtendBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateQuickExtendBuilder 

Default values. More...

class — SketchQuickTrimBuilder

Represents a NXOpen::SketchQuickTrimBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateQuickTrimBuilder 

Default values. More...

class — SketchRadialDimensionBuilder

Represents a NXOpen::SketchRadialDimensionBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateRadialDimensionBuilder 

More...

class — SketchRapidDimensionBuilder

Represents a NXOpen::SketchRapidDimensionBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateRapidDimensionBuilder 

More...

class — SketchRectangleBuilder

Create a Two-Point Rectangle in the active sketch. More...

class — SketchRectangleFromCenterBuilder

Create a Rectangle From Center in the active sketch. More...

class — SketchRectangleThreePointsBuilder

Create a Three-Point Rectangle in the active sketch. More...

class — SketchRelation

Represents a constraint or found relation in a sketch. More...

class — SketchRelationBuilder

Represents a NXOpen::SketchRelationBuilder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateRelationBuilder 

More...

class — SketchRemoteFindingBuilder

Represents a NXOpen::SketchRemoteFindingBuilder . More...

class — SketchSilhouette

Represents a silhouette feature 

To create or edit an instance of this class, use NXOpen::SketchSilhouetteBuilder 

More...

class — SketchSilhouetteBuilder

Represents a NXOpen::SketchSilhouetteBuilder builder 

To create a new instance of this class, use NXOpen::SketchCollection::CreateSilhouetteBuilder 

Default values. More...

class — SketchSlotBuilder

Create a Slot in the active sketch. More...

class — SketchSymmetricBuilder

Represents a NXOpen::SketchSymmetricBuilder builder. More...

class — SketchTangentConstraint

Represents a tangent constraint 

To create an instance of this object use Sketch::CreateTangentConstraint 

More...

class — SketchTangentToStringConstraint

Represents a sketch tangent to string constraint 

Use SketchCollection::CreateConstraintBuilder to create an instance of this class. More...

class — SketchVirtualPoint

Represents a sketch virtual point. More...

class — SketchWorkRegionBuilder

Represents a NXOpen::SketchWorkRegionBuilder builder. More...

class — SmartDiffValidatorBuilder

Represents a SmartDiffValidator builder 

An instance of this class can be obtained through CAE::CaeAutotest 

More...

class — SmartObject

Represents a smart object. More...

class — SphericalCoordinateSystem

Represents a spherical coordinate system 

To create a new instance of this class, use NXOpen::CoordinateSystemCollection::CreateSphericalCoordinateSystem 

More...

class — Spline

Represents a spline curve. More...

class — SplineCollection

Represents a collection of splines. More...

class — Spreadsheet

Represents a class for internal spreadsheet. More...

class — SpreadsheetCellData

Represents a class for Spreadsheet cell data. More...

class — SpreadsheetExternal

Represents a class for external spreadsheet. More...

class — SpreadsheetManager

Represents a class for interacting with spreadsheets. More...

class — Step203Importer

Represents a NXOpen::Step203Importer to be used when importing the STEP203 Data This class is created using NXOpen::DexManager . More...

class — Step214Importer

Represents a NXOpen::Step214Importer to be used when importing the STEP214 Data This class is created using NXOpen::DexManager . More...

class — Step242Importer

Represents a NXOpen::Step242Importer to be used when importing STEP242 Data This class is created using NXOpen::DexManager . More...

class — StepCreator

Represents a NXOpen::StepCreator to be used when exporting the STEP Data This class is created using NXOpen::DexManager . More...

class — STLCreator

Represents a NXOpen::STLCreator to be used when exporting the STL Data This class is created using NXOpen::DexManager . More...

class — STLImporter

Used to import an STL file into the work part. More...

class — Stroke

Represents a stroke. More...

class — StrokeCollection

Represents a collection of strokes. More...

class — StudioMaterialManager

Represents the properties and methods for studio material Manager 

To obtain an instance of this class, refer to NXOpen::Session 

More...

class — SubdivisionMeshBody

Represents a subdivision mesh. More...

class — SubdivisionMeshBodyTopologyData

Represents a subdivision mesh body topological connectivity data. More...

class — SubdivisionMeshEdge

Represents a subdivision mesh edge. More...

class — SubdivisionMeshEdgeTopologyData

Represents a subdivision mesh edge topological connectivity data. More...

class — SubdivisionMeshFace

Represents a subdivision mesh face. More...

class — SubdivisionMeshFaceTopologyData

Represents a subdivision mesh face topological connectivity data. More...

class — SubdivisionMeshVertex

Represents a subdivision mesh vertex. More...

class — SubdivisionTaskEnvironment

Represents the subdivision task environment associated with a session. More...

class — SuppressByExpressionBuilder

Represents a NXOpen::SuppressByExpressionBuilder 

To create a new instance of this class, use NXOpen::ExpressionCollection::CreateSuppressByExpressionBuilder 

Default values. More...

class — SurfaceRebuildData

Represents surface rebuild data structure. More...

class — SurfaceUVDirectionBuilder

Represents an edit surface u/v direction builder that allows reversing or swapping parametric directions. More...

class — SymbolFont

Represents a symbol font 

This class cannot be created, but an instance can be obtained from NXOpen::Annotations::AnnotationManager::LoadSymbolFontFromSbfFile . More...

class — SystemInformation

Represents a class that can be used to query about the System the automation program is running on. More...

class — TableEditorDefaultDataProvider

Provides basic data for a Table Editor block. More...

class — TaggedObject

An object which has a Tag. More...

class — TaggedObjectCollection

A base class for all NXOpen tagged object collections. More...

class — TaggedObjectList

Represents a list of objects. More...

class — TaggedObjectManager

This class is useful to get the TaggedObject corresponding to given tag. More...

class — TangentFacetsRule

Represents a NXOpen::TangentFacetsRule that collects facets maintaining the tangency within given tolerance. More...

class — TangentSheetBodiesRule

Represents a NXOpen::SelectionIntentRule that collects the tangent bodies connected with the selected seed body. More...

class — TextAlignmentModeT

text alignment mode 

Enumerator — Comment

VertTop

VertMiddle

VertBottom

VertJustify

VertDistributed

HorGeneral

HorLeft

HorCenter

HorRight

HorFill

HorJustify

HorCenterAcrossSelection

HorDistributed

More...

class — TextColorFontWidthBuilder

Represent a NXOpen::TextColorFontWidthBuilder 

This is a sub-builder class and cannot be directly instantiated 

More...

class — TextureModelingTaskEnvironment

Represents the texture modeling task environment associated with a session. More...

class — ThreeDXMLImporter

Represents a NXOpen::ThreeDXMLImporter to be used when importing 3DXML Data This class is created using NXOpen::DexManager . More...

class — TopologyOptimizationTaskEnvironment

Represents the topology optimization task environment associated with a session. More...

class — Traceline

Represents a traceline. More...

class — TracelineCollection

Represents a collection of tracelines 

To obtain an instance of this class, refer to NXOpen::Part 

More...

class — TransientObject

A base class for all NXOpen transient objects. More...

class — TreeListNode

Represents a TreeList Node Object. More...

class — UI

This class contains the various elements that represent the NX User Interface. More...

class — UnderlineStyleT

underline style 

Enumerator — Comment

NotSet

Single

SingleAccounting

Double

DoubleAccounting

More...

class — Unit

Represents a unit 

To obtain an instance of this class use NXOpen::UnitCollection 

More...

class — UnitCollection

Provides methods for manipulating the units in a part 

To obtain an instance of this class, refer to NXOpen::BasePart 

More...

class — Update

Provides methods for update and delete. More...

class — Validation

Represents an NX NXOpen::Validation object. More...

class — ValidationCollection

Represents a collection of NXOpen::Validation . More...

class — ValidatorPrintLevel

print level. More...

class — ValidatorType

validator type 

Enumerator — Comment

NoneValidator

AnnotationValidator

BaseArrowValidator

BaseUserSymbolValidator

CadNeutralPmiValidator

CenterLineValidator

CoordinateNoteValidator

CurveValidator

DatumTargetValidator

DatumValidator

DimensionValidator

DraftingImageValidator

DrawingBookletValidator

DrawingRegionValidator

DrawingSheetValidator

DrawingTo3DReportValidator

EdgeConditionSymbolValidator

EnterpriseIdentificationValidator

FCFValidator

FrameBarValidator

GeneralNoteValidator

HatchValidator

HoleTableValidator

IdSymbolValidator

IntersectionSymbolValidator

LabelOnParentValidator

Layout2dComponentStructureValidator

Layout2dComponentValidator

Layout2dDrawingSheetsValidator

Layout2dLinksValidator

Layout2dSketchStructureValidator

LocatorDesignatorValidator

MaterialSpecificationValidator

MemberViewValidator

ModelingViewSearchValidator

ModelingViewsValidator

ModelingViewValidator

NoteValidator

OffsetCenterPointSymbolValidator

PartIdentificationValidator

PartListSectionValidator

PartListValidator

PMIBalloonValidator

PMIPlanarCPSValidator

PMILightweightSectionViewValidator

PMISectionViewValidator

ProcessSpecificationValidator

ProductGridValidator

RegionValidator

SectionLineSegmentValidator

SectionLineValidator

SecurityMarkingValidator

SpecificNoteValidator

SurfaceFinishValidator

TabnotSectionValidator

TabnotValidator

TargetPointSymbolValidator

TDPBaseValidator

TDPBaseRectangleValidator

TDPViewportValidator

TDPViewCarouselValidator

TDPAutomaticTableValidator

TDPFormFieldValidator

TDPRectangleValidator

TDPImageValidator

ThreadCurveValidator

TitleBlockValidator

VDCurveValidator

ViewBreakValidator

ViewingDirectionArrowValidator

ViewingDirectionArrowLabelValidator

ViewLabelValidator

ViewValidator

WeldValidator

CompareViewValidator

More...

class — ValidatorVersion

validator version 

Enumerator — Comment

Zero — version zero.

More...

class — Vector2d

Represents a two-dimensional vector. More...

class — Vector3d

Represents a three-dimensional vector. More...

class — View

Represents a view. More...

class — ViewCollection

Represents a collection of NXOpen::View s. More...

class — ViewDependentDisplayManager

Represents all view dependent display operations 

To obtain an instance of this class, refer to NXOpen::View 

More...

class — ViewSet

Represents a NXOpen::ViewSet . More...

class — ViewSetCollection

Represents a NXOpen::ViewSetCollection 

To obtain an instance of this class, refer to NXOpen::BasePart 

More...

class — ViewUIManager

To obtain an instance of this class, refer to NXOpen::UI 

More...

class — VirtuallabImporter

Represents a VirtuallabImporter to be used when importing the Virtuallab Data This class is created using DexManager . More...

class — VRMLImporter

Used to import a VRML file into the work part. More...

class — WavefrontObjCreator

Represents a NXOpen::WavefrontObjCreator to be used when exporting the OBJ Data This class is created using NXOpen::DexManager . More...

class — WavefrontObjImporter

Represents a NXOpen::WavefrontObjImporter to be used when importing OBJ Data This class is created using NXOpen::DexManager . More...

class — WCS

Represents the World Coordinate System. More...

class — WidthDefinition

Represents a NXOpen::WidthDefinition , which is a representation of an NX width palette. More...

class — WithinCurvesRule

Represents a NXOpen::WithinCurvesRule that collects facets within curve. More...

class — Xform

Represents a smart xform 

To create a new instance of this class, use NXOpen::XformCollection::CreateXform 

More...

class — XformCollection

Represents a collection of NXOpen::Xform objects. More...

class — XYZAxis

Specifies the X, Y, or Z axis 

Enumerator — Comment

XAxis — X axis

YAxis — Y axis

ZAxis — Z axis

More...

## Detailed Description

Classes, Enums and Structs under NXOpen namespace. 

Copyright 2025 Siemens
