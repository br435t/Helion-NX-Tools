# NXOpen.AdjacentSheetBodiesRule Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a03169.html>

Represents a NXOpen::SelectionIntentRule that collects the adjacent bodies connected with the selected seed body. 
More...

Inheritance diagram for NXOpen.AdjacentSheetBodiesRule:

## Public Member Functions

Dispose (self)

Frees the object from memory. 

GetData (self)

Gets the data for the Tangent Sheet Bodies rule: NXOpen::AdjacentSheetBodiesRule . 

Public Member Functions inherited from NXOpen.SelectionIntentRule

Type (self)

Getter for property: (NXOpen.SelectionIntentRule.RuleType) Type Returns the get the type of selection intent rule: NXOpen::SelectionIntentRule . 

## Additional Inherited Members

Public Attributes inherited from NXOpen.SelectionIntentRule

SelectionIntentRuleRuleType = SelectionIntentRule.RuleType

NXOpen.SelectionIntentRuleRuleType is an alias for NXOpen.SelectionIntentRule.RuleType 

## Detailed Description

Represents a NXOpen::SelectionIntentRule that collects the adjacent bodies connected with the selected seed body. 

Created in NX2312.0.0 

## Member Function Documentation

## ◆ Dispose()

NXOpen.AdjacentSheetBodiesRule.Dispose
(
self — )

Frees the object from memory. 

Created in NX2312.0.0 

License requirements: None. 

Reimplemented from NXOpen.SelectionIntentRule.

## ◆ GetData()

NXOpen.AdjacentSheetBodiesRule.GetData
(
self — )

Gets the data for the Tangent Sheet Bodies rule: NXOpen::AdjacentSheetBodiesRule . 

Returns
A tuple consisting of (seedBody, negatedDomainEntities, domainFeatures).
seedBody is: NXOpen.Body. Seed body used to create this rule.

negatedDomainEntities is: List[NXOpen.Body]. Array of bodies to be negated from the output of supplied domain features. .

domainFeatures is: List[NXOpen.NXObject]. Array of domain features to be considered for chaining. .

Created in NX2312.0.0 

License requirements: gateway ("UG GATEWAY") 

Copyright 2025 Siemens
