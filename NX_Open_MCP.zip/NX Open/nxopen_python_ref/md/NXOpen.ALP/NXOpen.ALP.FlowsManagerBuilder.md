# NXOpen.ALP.FlowsManagerBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00013.html>

## Classes

class — Type

TODO: fill in a description for this 

Enumerator — Comment

NotSet

Flow

ScopeFlow

Any

More...

Copyright 2025 Siemens
