# NXOpen.ALP.StationTaktTimeBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00016.html>

## Classes

class — Radio

takt time enum 

Enumerator — Comment

UseLineTaktTime

SetforLoadedStation

More...

Copyright 2025 Siemens
