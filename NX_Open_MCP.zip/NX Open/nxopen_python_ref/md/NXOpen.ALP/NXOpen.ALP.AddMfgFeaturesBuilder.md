# NXOpen.ALP.AddMfgFeaturesBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00011.html>

## Classes

class — Class

the criteria class 

Enumerator — Comment

Discrete

Continuous

More...

class — ConnectedTo

the connectedto values 

Enumerator — Comment

AllStationParts

PartList

More...

class — FeatureAssignmentState

the assignment state values 

Enumerator — Comment

UnassignedFeatures

AssignedFeatures

All

More...

class — Type

the criteria type values 

Enumerator — Comment

All

Weld

Fds

Clinch

Stud

Nut

Bolt

Rivet

More...

Copyright 2025 Siemens
