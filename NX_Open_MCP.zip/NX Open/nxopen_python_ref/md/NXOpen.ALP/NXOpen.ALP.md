# NXOpen.ALP Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00010.html>

Classes, Enums and Structs under NXOpen.ALP namespace. 
More...

## Namespaces

namespace — AddMfgFeaturesBuilder

namespace — CaptureImageBuilder

namespace — FlowsManagerBuilder

namespace — ModifyVariantBuilder

namespace — OperationBuilder

namespace — StationTaktTimeBuilder

namespace — VariantConditionBuilder

## Classes

class — AddExternalResourceBuilder

use for add external resource 

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateAddExternalResourceBuilder 

More...

class — AddMfgFeaturesBuilder

use for cearting Add Mfg Features 

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateAddMfgFeaturesBuilder 

Default values. More...

class — AddWorkareaBuilder

use for creating workarea builder 

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateAddWorkareaBuilder 

More...

class — ALPApplicationBuilder

Represents a class to create enter and exit the ALP application. More...

class — ALPManager

Represents a manager of ALP builders 

Use the static method in this class to obtain an instance. More...

class — AlpPertLayout

Represents sheet layout options 

Enumerator — Comment

Toptobottom

Lefttoright

More...

class — AutoWeldDistributionBuilder

use for creation of Automatic Weld Distribution Builder 

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateAutoWeldDistributionBuilder 

More...

class — CaptureImageBuilder

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateCaptureImageBuilder 

Default values. More...

class — ConfigVariantConditionBuilder

For creating and editing Product Configurator Variant Conditions 

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateConfigVariantConditionBuilder 

More...

class — CriticalResources

Represents assembly line planner journaling methods for Critical Resources related functionalities. More...

class — CycleTimeBuilder

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateCycleTimeBuilder 

Default values. More...

class — FlowsManagerBuilder

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateFlowsManagerBuilder 

More...

class — GlobalSelectionBuilder

Global Selection 

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateGlobalSelectionBuilder 

More...

class — LibraryOperation

Represents assembly line planner journaling methods for Library Operation related functionalities. More...

class — LibraryOperationBuilder

A class for creating operation/operation group from library 

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateLibraryOperationBuilder 

More...

class — MaterialFlowNode

Represents Material Flow information 

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateMaterialFlowNode 

More...

class — ModifyVariantBuilder

For modifying Variant Rule 

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateModifyVariantBuilder 

Default values. More...

class — OperationBuilder

use for cearting operation 

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateOperationBuilder 

Default values. More...

class — OperationGroupBuilder

A class for creating operation group in structure 

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateOperationGroupBuilder 

More...

class — Pert

Represents assembly line planner journaling methods for PERT related functionalities PERT - Program evalution review technique used to understand material flow in manufacturing process planning. More...

class — PositionProductBuilder

use for cearting Position Product 

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreatePositionProductBuilder 

More...

class — ProductVisibility

Represents color/hide assigned products functionalities methods 

Use the static method in this class to obtain an instance. More...

class — StationTaktTimeBuilder

station takt time 

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateStationTaktTimeBuilder 

Default values. More...

class — SuggestPartBuilder

use for suggesting parts to assign to station 

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateSuggestPartBuilder 

More...

class — UINodeUtils

Represents a utils of assembly line planner for journaling uinode methods 

Use the static method in this class to obtain an instance. More...

class — ValidateToolBuilder

use for creation of weld conistency checker builder 

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateValidateToolBuilder 

More...

class — VariantConditionBuilder

For creating and editing Variant Conditions 

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateVariantConditionBuilder 

More...

class — WebGantt

Represents a web gantt of assembly line planner for journaling 

Use the static method in this class to obtain an instance. More...

class — WeldConsistencyCheckerBuilder

use for creation of weld conistency checker builder 

To create a new instance of this class, use NXOpen::ALP::ALPManager::CreateWeldConsistencyCheckerBuilder 

More...

## Detailed Description

Classes, Enums and Structs under NXOpen.ALP namespace. 

Copyright 2025 Siemens
