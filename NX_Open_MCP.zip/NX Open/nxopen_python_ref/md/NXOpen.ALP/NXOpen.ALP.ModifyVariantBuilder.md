# NXOpen.ALP.ModifyVariantBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00014.html>

## Classes

class — VariantRules

This enum is used for defining different rules in dropdown 

Enumerator — Comment

VariantRuleName

More...

Copyright 2025 Siemens
