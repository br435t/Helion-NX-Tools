# NXOpen.ALP.OperationBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00015.html>

## Classes

class — Operation

This enum have collection of all type of operation 

Enumerator — Comment

Undefined

Operator

Tooling

Safety

Conveyance

MHRobot

GeoWeld

Respot

StudNutBolt

RivetFDS

Scribing

Vision

LaserSpotWeld

MigWeld

SealingAdhesive

LaserCut

Hemming

RobotHold

More...

Copyright 2025 Siemens
