# NXOpen.ALP.VariantConditionBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00017.html>

## Classes

class — Condition

This enum is used for defining different contions together 

Enumerator — Comment

And

Or

More...

Copyright 2025 Siemens
