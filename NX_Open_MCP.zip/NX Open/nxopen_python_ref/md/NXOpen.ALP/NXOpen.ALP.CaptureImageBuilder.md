# NXOpen.ALP.CaptureImageBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00012.html>

## Classes

class — CaptureImage

Enumerator — Comment

Trimetric

Isometric

Top

Bottom

Left

Right

Front

Back

More...

Copyright 2025 Siemens
