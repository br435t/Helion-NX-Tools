# NXOpen.AcisImporter Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a03165.html>

Represents a AcisImporter to be used when importing the Acis Data This class is created using DexManager . 
More...

Inheritance diagram for NXOpen.AcisImporter:

## Public Member Functions

FileOpenFlag (self)

Getter for property: (bool) FileOpenFlag Returns the file open flag - set this to false if doing file import. 

FileOpenFlag (self, doingFileOpen)

Setter for property: (bool) FileOpenFlag. 

HealBodies (self)

Getter for property: (bool) HealBodies Returns the heal bodies - if set to true then imported data will be healed. 

HealBodies (self, healBodies)

Setter for property: (bool) HealBodies. 

IncludeWires (self)

Getter for property: (bool) IncludeWires Returns the IncludeWires - if value set to true then wireframes and points will be imported. 

IncludeWires (self, includeWires)

Setter for property: (bool) IncludeWires. 

Optimize (self)

Getter for property: (bool) Optimize Returns the Optimize - if value set to true then redundant geometries will be removed. 

Optimize (self, optimize)

Setter for property: (bool) Optimize. 

SaveSettings (self, filename)

Save the settings - this will save the settings to a file specified. 

SettingsFile (self)

Getter for property: (str) SettingsFile Returns the settings file - definition file for default options. 

SettingsFile (self, filename)

Setter for property: (str) SettingsFile. 

Sew (self)

Getter for property: (bool) Sew Returns the Sew - if value set to true then automatic sewing will be done. 

Sew (self, sew)

Setter for property: (bool) Sew. 

SimplifyGeometry (self)

Getter for property: (bool) SimplifyGeometry Returns the simplify geometry - if value set to true then imported data will be simplified. 

SimplifyGeometry (self, simplifyGeometry)

Setter for property: (bool) SimplifyGeometry. 

Public Member Functions inherited from NXOpen.BaseImporter

GetMode (self)

Get mode - native/managed. 

InputFile (self)

Getter for property: (str) InputFile Returns the input file - name of a file which is being imported. 

InputFile (self, filename)

Setter for property: (str) InputFile. 

OutputFile (self)

Getter for property: (str) OutputFile Returns the output file - name of a output file which is being generated. 

OutputFile (self, filename)

Setter for property: (str) OutputFile. 

SetMode (self, mode)

Set mode - native/managed. 

Public Member Functions inherited from NXOpen.DexBuilder

ProcessHoldFlag (self)

Getter for property: (bool) ProcessHoldFlag Returns the process hold flag - set to true if user wants to wait until transaltion process gets completed. 

ProcessHoldFlag (self, doingFileSave)

Setter for property: (bool) ProcessHoldFlag. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.BaseImporter

BaseImporterMode = BaseImporter.Mode

NXOpen.BaseImporterMode is an alias for NXOpen.BaseImporter.Mode 

## Detailed Description

Represents a AcisImporter to be used when importing the Acis Data This class is created using DexManager . 

NULL object will be returned from Commit() 

To create a new instance of this class, use NXOpen::DexManager::CreateAcisImporter 

Default values. 

Property — Value

HealBodies 

1 

IncludeWires 

0 

Optimize 

0 

Sew 

0 

SimplifyGeometry 

0 

Created in NX11.0.0 

## Member Function Documentation

## ◆ FileOpenFlag() [1/2]

NXOpen.AcisImporter.FileOpenFlag
(
self — )

Getter for property: (bool) FileOpenFlag Returns the file open flag - set this to false if doing file import. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
bool 

## ◆ FileOpenFlag() [2/2]

NXOpen.AcisImporter.FileOpenFlag
(
self,

doingFileOpen )

Setter for property: (bool) FileOpenFlag. 

Sets the file open flag - set this to false if doing file import

Setter License requirements: None.

Created in NX11.0.0 

## ◆ HealBodies() [1/2]

NXOpen.AcisImporter.HealBodies
(
self — )

Getter for property: (bool) HealBodies Returns the heal bodies - if set to true then imported data will be healed. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
bool 

## ◆ HealBodies() [2/2]

NXOpen.AcisImporter.HealBodies
(
self,

healBodies )

Setter for property: (bool) HealBodies. 

Sets the heal bodies - if set to true then imported data will be healed

Setter License requirements: None.

Created in NX11.0.0 

## ◆ IncludeWires() [1/2]

NXOpen.AcisImporter.IncludeWires
(
self — )

Getter for property: (bool) IncludeWires Returns the IncludeWires - if value set to true then wireframes and points will be imported. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
bool 

## ◆ IncludeWires() [2/2]

NXOpen.AcisImporter.IncludeWires
(
self,

includeWires )

Setter for property: (bool) IncludeWires. 

Sets the IncludeWires - if value set to true then wireframes and points will be imported

Setter License requirements: None.

Created in NX11.0.0 

## ◆ Optimize() [1/2]

NXOpen.AcisImporter.Optimize
(
self — )

Getter for property: (bool) Optimize Returns the Optimize - if value set to true then redundant geometries will be removed. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
bool 

## ◆ Optimize() [2/2]

NXOpen.AcisImporter.Optimize
(
self,

optimize )

Setter for property: (bool) Optimize. 

Sets the Optimize - if value set to true then redundant geometries will be removed

Setter License requirements: None.

Created in NX11.0.0 

## ◆ SaveSettings()

NXOpen.AcisImporter.SaveSettings
(
self,

filename )

Save the settings - this will save the settings to a file specified. 

Created in NX11.0.0 

License requirements: None.

Parameters

filename — (str)

## ◆ SettingsFile() [1/2]

NXOpen.AcisImporter.SettingsFile
(
self — )

Getter for property: (str) SettingsFile Returns the settings file - definition file for default options. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
str 

## ◆ SettingsFile() [2/2]

NXOpen.AcisImporter.SettingsFile
(
self,

filename )

Setter for property: (str) SettingsFile. 

Sets the settings file - definition file for default options

Setter License requirements: None.

Created in NX11.0.0 

## ◆ Sew() [1/2]

NXOpen.AcisImporter.Sew
(
self — )

Getter for property: (bool) Sew Returns the Sew - if value set to true then automatic sewing will be done. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
bool 

## ◆ Sew() [2/2]

NXOpen.AcisImporter.Sew
(
self,

sew )

Setter for property: (bool) Sew. 

Sets the Sew - if value set to true then automatic sewing will be done

Setter License requirements: None.

Created in NX11.0.0 

## ◆ SimplifyGeometry() [1/2]

NXOpen.AcisImporter.SimplifyGeometry
(
self — )

Getter for property: (bool) SimplifyGeometry Returns the simplify geometry - if value set to true then imported data will be simplified. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
bool 

## ◆ SimplifyGeometry() [2/2]

NXOpen.AcisImporter.SimplifyGeometry
(
self,

simplifyGeometry )

Setter for property: (bool) SimplifyGeometry. 

Sets the simplify geometry - if value set to true then imported data will be simplified

Setter License requirements: None.

Created in NX11.0.0 

Copyright 2025 Siemens
