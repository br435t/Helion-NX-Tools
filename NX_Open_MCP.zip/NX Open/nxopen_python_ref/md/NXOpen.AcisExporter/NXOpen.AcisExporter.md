# NXOpen.AcisExporter Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00007.html>

## Classes

class — AcisVersionOption

ACIS Version options 

Enumerator — Comment

V2024

V2023

V2022

V2021

V2020

R29

R28

R27

R26

R25

R24

R23

R22

R21

R20

R19

R18

More...

Copyright 2025 Siemens
