# NXOpen.AcisExporter Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a03157.html>

Represents a AcisExporter to be used when importing the Acis Data This class is created using DexManager . 
More...

Inheritance diagram for NXOpen.AcisExporter:

## Public Member Functions

AcisVersion (self)

Getter for property: (NXOpen.AcisExporter.AcisVersionOption) AcisVersion Returns the Acis version - The version of ACIS file to be exported. 

AcisVersion (self, acisVersion)

Setter for property: (NXOpen.AcisExporter.AcisVersionOption) AcisVersion. 

ExportSelectionBlock (self)

Getter for property: (NXOpen.ObjectSelector) ExportSelectionBlock Returns the export selection block - the object selection will be done by this block. 

FileSaveFlag (self)

Getter for property: (bool) FileSaveFlag Returns the file save flag - this should be set to false if doing File Export. 

FileSaveFlag (self, doingFileSave)

Setter for property: (bool) FileSaveFlag. 

SaveSettings (self, filename)

Save the settings - this will save the settings to a file sepcified. 

SettingsFile (self)

Getter for property: (str) SettingsFile Returns the settings file - The definition file to read default options. 

SettingsFile (self, filename)

Setter for property: (str) SettingsFile. 

Public Member Functions inherited from NXOpen.BaseCreator

DatasetName (self)

Getter for property: (str) DatasetName Returns the dataset name - Name of dataset being created. 

DatasetName (self, datasetName)

Setter for property: (str) DatasetName. 

ExportDestination (self)

Getter for property: (NXOpen.BaseCreator.ExportDestinationOption) ExportDestination Returns the export to - determines whether exporting to Teamcenter or Native file system. 

ExportDestination (self, exportFrom)

Setter for property: (NXOpen.BaseCreator.ExportDestinationOption) ExportDestination. 

OutputFile (self)

Getter for property: (str) OutputFile Returns the output file - filepath for output file. 

OutputFile (self, filename)

Setter for property: (str) OutputFile. 

OutputFileExtension (self)

Getter for property: (str) OutputFileExtension Returns the output file extension - Extension of output file being created. 

OutputFileExtension (self, outputFileExtension)

Setter for property: (str) OutputFileExtension. 

Public Member Functions inherited from NXOpen.DexBuilder

ProcessHoldFlag (self)

Getter for property: (bool) ProcessHoldFlag Returns the process hold flag - set to true if user wants to wait until transaltion process gets completed. 

ProcessHoldFlag (self, doingFileSave)

Setter for property: (bool) ProcessHoldFlag. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

AcisExporterAcisVersionOption = AcisExporter.AcisVersionOption

NXOpen.AcisExporterAcisVersionOption is an alias for NXOpen.AcisExporter.AcisVersionOption 

Public Attributes inherited from NXOpen.BaseCreator

BaseCreatorExportDestinationOption = BaseCreator.ExportDestinationOption

NXOpen.BaseCreatorExportDestinationOption is an alias for NXOpen.BaseCreator.ExportDestinationOption 

## Detailed Description

Represents a AcisExporter to be used when importing the Acis Data This class is created using DexManager . 

NULL object will be returned from Commit() 

To create a new instance of this class, use NXOpen::DexManager::CreateAcisExporter 

Default values. 

Property — Value

AcisVersion 

R18 

Created in NX11.0.0 

## Member Function Documentation

## ◆ AcisVersion() [1/2]

NXOpen.AcisExporter.AcisVersion
(
self — )

Getter for property: (NXOpen.AcisExporter.AcisVersionOption) AcisVersion Returns the Acis version - The version of ACIS file to be exported. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
AcisExporter.AcisVersionOption 

## ◆ AcisVersion() [2/2]

NXOpen.AcisExporter.AcisVersion
(
self,

acisVersion )

Setter for property: (NXOpen.AcisExporter.AcisVersionOption) AcisVersion. 

Sets the Acis version - The version of ACIS file to be exported

Setter License requirements: None.

Created in NX11.0.0 

## ◆ ExportSelectionBlock()

NXOpen.AcisExporter.ExportSelectionBlock
(
self — )

Getter for property: (NXOpen.ObjectSelector) ExportSelectionBlock Returns the export selection block - the object selection will be done by this block. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
ObjectSelector 

## ◆ FileSaveFlag() [1/2]

NXOpen.AcisExporter.FileSaveFlag
(
self — )

Getter for property: (bool) FileSaveFlag Returns the file save flag - this should be set to false if doing File Export. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
bool 

## ◆ FileSaveFlag() [2/2]

NXOpen.AcisExporter.FileSaveFlag
(
self,

doingFileSave )

Setter for property: (bool) FileSaveFlag. 

Sets the file save flag - this should be set to false if doing File Export

Setter License requirements: None.

Created in NX11.0.0 

## ◆ SaveSettings()

NXOpen.AcisExporter.SaveSettings
(
self,

filename )

Save the settings - this will save the settings to a file sepcified. 

Created in NX11.0.0 

License requirements: None.

Parameters

filename — (str)

## ◆ SettingsFile() [1/2]

NXOpen.AcisExporter.SettingsFile
(
self — )

Getter for property: (str) SettingsFile Returns the settings file - The definition file to read default options. 

Getter License requirements: None.

Created in NX11.0.0 

Returns
str 

## ◆ SettingsFile() [2/2]

NXOpen.AcisExporter.SettingsFile
(
self,

filename )

Setter for property: (str) SettingsFile. 

Sets the settings file - The definition file to read default options

Setter License requirements: None.

Created in NX11.0.0 

## Member Data Documentation

## ◆ AcisExporterAcisVersionOption

NXOpen.AcisExporter.AcisExporterAcisVersionOption = AcisExporter.AcisVersionOption

NXOpen.AcisExporterAcisVersionOption is an alias for NXOpen.AcisExporter.AcisVersionOption 

Copyright 2025 Siemens
