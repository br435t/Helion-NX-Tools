# NXOpen.AECDesign.PlanElevationViewManager Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00009.html>

## Classes

class — LevelViewType

Represent view types of the level view. More...

Copyright 2025 Siemens
