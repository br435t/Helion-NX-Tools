# NXOpen.AECDesign Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00008.html>

Classes, Enums and Structs under NXOpen.AECDesign namespace. 
More...

## Namespaces

namespace — PlanElevationViewManager

## Classes

class — AECDesignNavigator

Represents the interface for navigator action classes 

Can be create automatically by the data structures 

More...

class — AECDesignNavigatorNode

Represents the interface for navigator node classes 

Use the NXOpen::AECDesign::AECDesignNavigatorView class to create a navigator node 

More...

class — AECDesignNavigatorRoot

Represents the interface for AEC design navigator root classes. More...

class — AECDesignNavigatorView

Represents the interface for navigator view classe 

Use the NXOpen::AECDesign::AECDesignNavigator class to get a navigator view 

More...

class — AECDesignSession

Represents AECDesign session 

To obtain an instance of this class, refer to NXOpen::Session 

More...

class — AecGridCenterSegmentType

Represents the center segment type of grid line. More...

class — AecLineFormatDragPointType

Represents the AEC line drag point type. More...

class — AecLineFormatType

Represents the AEC line format type. More...

class — AecLineType

Represents the AEC Line type. More...

class — AecSymbolType

Represents the AECSymbol type. More...

class — AecTaskEnvType

Represents the AEC task enviroment type. More...

class — LevelSymbolIndex

Represents the index in the level symbol. More...

class — PlanElevationView

Represents AECDesign Plan Elevation View 

This class is sub-object of PlanElevationViewManager, and cannot be directly instantiated. More...

class — PlanElevationViewManager

Represents AECDesign Plan Elevation View Manager 

This class is sub-object of AECDesignSession, and cannot be directly instantiated. More...

## Detailed Description

Classes, Enums and Structs under NXOpen.AECDesign namespace. 

Copyright 2025 Siemens
