# NXOpen.AnimationDesigner.RigidGroupBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10941.html>

Represents a NXOpen::AnimationDesigner::RigidGroupBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.RigidGroupBuilder:

## Public Member Functions

AngularVelocityDirection (self)

Getter for property: (NXOpen.Direction) AngularVelocityDirection Returns the angular velocity direction. 

AngularVelocityDirection (self, dir)

Setter for property: (NXOpen.Direction) AngularVelocityDirection. 

AngularVelocityMagnitude (self)

Getter for property: (NXOpen.Expression) AngularVelocityMagnitude Returns the angular velocity magnitude. 

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

ColorOption (self)

Getter for property: (NXOpen.AnimationDesigner.RigidGroupBuilder.ColorOptions) ColorOption Returns the color option. 

ColorOption (self, colorOption)

Setter for property: (NXOpen.AnimationDesigner.RigidGroupBuilder.ColorOptions) ColorOption. 

CreationType (self)

Getter for property: (NXOpen.AnimationDesigner.RigidGroupBuilder.CreationTypes) CreationType Returns the creation type. 

CreationType (self, creationType)

Setter for property: (NXOpen.AnimationDesigner.RigidGroupBuilder.CreationTypes) CreationType. 

Geometry (self)

Getter for property: (NXOpen.SelectNXObjectList) Geometry Returns the geometries. 

InertiaIxx (self)

Getter for property: (NXOpen.Expression) InertiaIxx Returns the inertia Ixx. 

InertiaIxy (self)

Getter for property: (NXOpen.Expression) InertiaIxy Returns the inertia Ixy. 

InertiaIxz (self)

Getter for property: (NXOpen.Expression) InertiaIxz Returns the inertia Ixz. 

InertiaIyy (self)

Getter for property: (NXOpen.Expression) InertiaIyy Returns the inertia Iyy. 

InertiaIyz (self)

Getter for property: (NXOpen.Expression) InertiaIyz Returns the inertia Iyz. 

InertiaIzz (self)

Getter for property: (NXOpen.Expression) InertiaIzz Returns the inertia Izz. 

LinearVelocityDirection (self)

Getter for property: (NXOpen.Direction) LinearVelocityDirection Returns the linear velocity. 

LinearVelocityDirection (self, dir)

Setter for property: (NXOpen.Direction) LinearVelocityDirection. 

LinearVelocityMagnitude (self)

Getter for property: (NXOpen.Expression) LinearVelocityMagnitude Returns the linear velocity magnitude. 

Mass (self)

Getter for property: (NXOpen.Expression) Mass Returns the mass. 

MassCenterPoint (self)

Getter for property: (NXOpen.Point) MassCenterPoint Returns the mass center point. 

MassCenterPoint (self, center)

Setter for property: (NXOpen.Point) MassCenterPoint. 

MassProperty (self)

Getter for property: (NXOpen.AnimationDesigner.RigidGroupBuilder.MassPropertiesOption) MassProperty Returns the auto-calculate mass property flag which is used to indicate whether all mass properties are calculated by system. 

MassProperty (self, massProperty)

Setter for property: (NXOpen.AnimationDesigner.RigidGroupBuilder.MassPropertiesOption) MassProperty. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

Orientation (self)

Getter for property: (NXOpen.CoordinateSystem) Orientation Returns the orientation. 

Orientation (self, orientation)

Setter for property: (NXOpen.CoordinateSystem) Orientation. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

RigidGroupBuilderColorOptions = RigidGroupBuilder.ColorOptions

NXOpen.AnimationDesigner.RigidGroupBuilderColorOptions is an alias for NXOpen.AnimationDesigner.RigidGroupBuilder.ColorOptions 

RigidGroupBuilderCreationTypes = RigidGroupBuilder.CreationTypes

NXOpen.AnimationDesigner.RigidGroupBuilderCreationTypes is an alias for NXOpen.AnimationDesigner.RigidGroupBuilder.CreationTypes 

RigidGroupBuilderMassPropertiesOption = RigidGroupBuilder.MassPropertiesOption

NXOpen.AnimationDesigner.RigidGroupBuilderMassPropertiesOption is an alias for NXOpen.AnimationDesigner.RigidGroupBuilder.MassPropertiesOption 

## Detailed Description

Represents a NXOpen::AnimationDesigner::RigidGroupBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::RigidGroupCollection::CreateRigidGroupBuilder 

Created in NX12.0.0 

## Member Function Documentation

## ◆ AngularVelocityDirection() [1/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.AngularVelocityDirection
(
self — )

Getter for property: (NXOpen.Direction) AngularVelocityDirection Returns the angular velocity direction. 

It is only used when angular velocity is not zero.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Direction 

## ◆ AngularVelocityDirection() [2/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.AngularVelocityDirection
(
self,

dir )

Setter for property: (NXOpen.Direction) AngularVelocityDirection. 

Sets the angular velocity direction. It is only used when angular velocity is not zero.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ AngularVelocityMagnitude()

NXOpen.AnimationDesigner.RigidGroupBuilder.AngularVelocityMagnitude
(
self — )

Getter for property: (NXOpen.Expression) AngularVelocityMagnitude Returns the angular velocity magnitude. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ Color() [1/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.Color
(
self — )

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.NXColor 

## ◆ Color() [2/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.Color
(
self,

color )

Setter for property: (NXOpen.NXColor) Color. 

Sets the color.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ ColorOption() [1/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.ColorOption
(
self — )

Getter for property: (NXOpen.AnimationDesigner.RigidGroupBuilder.ColorOptions) ColorOption Returns the color option. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
RigidGroupBuilder.ColorOptions 

## ◆ ColorOption() [2/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.ColorOption
(
self,

colorOption )

Setter for property: (NXOpen.AnimationDesigner.RigidGroupBuilder.ColorOptions) ColorOption. 

Sets the color option.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ CreationType() [1/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.CreationType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.RigidGroupBuilder.CreationTypes) CreationType Returns the creation type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
RigidGroupBuilder.CreationTypes 

## ◆ CreationType() [2/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.CreationType
(
self,

creationType )

Setter for property: (NXOpen.AnimationDesigner.RigidGroupBuilder.CreationTypes) CreationType. 

Sets the creation type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ Geometry()

NXOpen.AnimationDesigner.RigidGroupBuilder.Geometry
(
self — )

Getter for property: (NXOpen.SelectNXObjectList) Geometry Returns the geometries. 

This can be NXOpen::Assemblies::ComponentAssembly , NXOpen::Point , NXOpen::Body , NXOpen::Curve , NXOpen::CoordinateSystem , NXOpen::DatumAxis , NXOpen::DatumPlane , NXOpen::Annotations::Pmi , Line Designer Connectors, etc.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.SelectNXObjectList 

## ◆ InertiaIxx()

NXOpen.AnimationDesigner.RigidGroupBuilder.InertiaIxx
(
self — )

Getter for property: (NXOpen.Expression) InertiaIxx Returns the inertia Ixx. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ InertiaIxy()

NXOpen.AnimationDesigner.RigidGroupBuilder.InertiaIxy
(
self — )

Getter for property: (NXOpen.Expression) InertiaIxy Returns the inertia Ixy. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ InertiaIxz()

NXOpen.AnimationDesigner.RigidGroupBuilder.InertiaIxz
(
self — )

Getter for property: (NXOpen.Expression) InertiaIxz Returns the inertia Ixz. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ InertiaIyy()

NXOpen.AnimationDesigner.RigidGroupBuilder.InertiaIyy
(
self — )

Getter for property: (NXOpen.Expression) InertiaIyy Returns the inertia Iyy. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ InertiaIyz()

NXOpen.AnimationDesigner.RigidGroupBuilder.InertiaIyz
(
self — )

Getter for property: (NXOpen.Expression) InertiaIyz Returns the inertia Iyz. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ InertiaIzz()

NXOpen.AnimationDesigner.RigidGroupBuilder.InertiaIzz
(
self — )

Getter for property: (NXOpen.Expression) InertiaIzz Returns the inertia Izz. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ LinearVelocityDirection() [1/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.LinearVelocityDirection
(
self — )

Getter for property: (NXOpen.Direction) LinearVelocityDirection Returns the linear velocity. 

It is only used when linear velocity is not zero.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Direction 

## ◆ LinearVelocityDirection() [2/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.LinearVelocityDirection
(
self,

dir )

Setter for property: (NXOpen.Direction) LinearVelocityDirection. 

Sets the linear velocity. It is only used when linear velocity is not zero.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ LinearVelocityMagnitude()

NXOpen.AnimationDesigner.RigidGroupBuilder.LinearVelocityMagnitude
(
self — )

Getter for property: (NXOpen.Expression) LinearVelocityMagnitude Returns the linear velocity magnitude. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ Mass()

NXOpen.AnimationDesigner.RigidGroupBuilder.Mass
(
self — )

Getter for property: (NXOpen.Expression) Mass Returns the mass. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ MassCenterPoint() [1/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.MassCenterPoint
(
self — )

Getter for property: (NXOpen.Point) MassCenterPoint Returns the mass center point. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Point 

## ◆ MassCenterPoint() [2/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.MassCenterPoint
(
self,

center )

Setter for property: (NXOpen.Point) MassCenterPoint. 

Sets the mass center point.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ MassProperty() [1/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.MassProperty
(
self — )

Getter for property: (NXOpen.AnimationDesigner.RigidGroupBuilder.MassPropertiesOption) MassProperty Returns the auto-calculate mass property flag which is used to indicate whether all mass properties are calculated by system. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
RigidGroupBuilder.MassPropertiesOption 

## ◆ MassProperty() [2/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.MassProperty
(
self,

massProperty )

Setter for property: (NXOpen.AnimationDesigner.RigidGroupBuilder.MassPropertiesOption) MassProperty. 

Sets the auto-calculate mass property flag which is used to indicate whether all mass properties are calculated by system.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ Name() [1/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.Name
(
self — )

Getter for property: (str) Name Returns the name. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
str 

## ◆ Name() [2/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.Name
(
self,

name )

Setter for property: (str) Name. 

Sets the name.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ Orientation() [1/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.Orientation
(
self — )

Getter for property: (NXOpen.CoordinateSystem) Orientation Returns the orientation. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.CoordinateSystem 

## ◆ Orientation() [2/2]

NXOpen.AnimationDesigner.RigidGroupBuilder.Orientation
(
self,

orientation )

Setter for property: (NXOpen.CoordinateSystem) Orientation. 

Sets the orientation.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## Member Data Documentation

## ◆ RigidGroupBuilderColorOptions

NXOpen.AnimationDesigner.RigidGroupBuilder.RigidGroupBuilderColorOptions = RigidGroupBuilder.ColorOptions

NXOpen.AnimationDesigner.RigidGroupBuilderColorOptions is an alias for NXOpen.AnimationDesigner.RigidGroupBuilder.ColorOptions 

## ◆ RigidGroupBuilderCreationTypes

NXOpen.AnimationDesigner.RigidGroupBuilder.RigidGroupBuilderCreationTypes = RigidGroupBuilder.CreationTypes

NXOpen.AnimationDesigner.RigidGroupBuilderCreationTypes is an alias for NXOpen.AnimationDesigner.RigidGroupBuilder.CreationTypes 

## ◆ RigidGroupBuilderMassPropertiesOption

NXOpen.AnimationDesigner.RigidGroupBuilder.RigidGroupBuilderMassPropertiesOption = RigidGroupBuilder.MassPropertiesOption

NXOpen.AnimationDesigner.RigidGroupBuilderMassPropertiesOption is an alias for NXOpen.AnimationDesigner.RigidGroupBuilder.MassPropertiesOption 

Copyright 2025 Siemens
