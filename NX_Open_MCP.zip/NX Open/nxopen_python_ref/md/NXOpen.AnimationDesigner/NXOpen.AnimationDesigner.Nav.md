# NXOpen.AnimationDesigner.Nav Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00116.html>

Classes, Enums and Structs under NXOpen.AnimationDesigner.Nav namespace. 
More...

## Classes

class — Container

Represents a AnimationDesigner Nav Container Class. More...

class — ContainerCollection

Represents a NXOpen::AnimationDesigner::Nav::ContainerCollection . More...

class — Solution

Represents a AnimationDesigner Nav Solution Class. More...

class — SolutionCollection

Represents a NXOpen::AnimationDesigner::Nav::SolutionCollection . More...

class — SubFolder

Represents a AnimationDesigner Nav SubFolder Class. More...

class — SubFolderCollection

Represents a NXOpen::AnimationDesigner::Nav::SubFolderCollection . More...

## Detailed Description

Classes, Enums and Structs under NXOpen.AnimationDesigner.Nav namespace. 

Copyright 2025 Siemens
