# NXOpen.AnimationDesigner.ScrewJointBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10965.html>

Represents a NXOpen::AnimationDesigner::ScrewJointBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.ScrewJointBuilder:

## Public Member Functions

AxisVector (self)

Getter for property: (NXOpen.Direction) AxisVector Returns the axis vector. 

AxisVector (self, axisVector)

Setter for property: (NXOpen.Direction) AxisVector. 

ExpressionRatio (self)

Getter for property: (NXOpen.Expression) ExpressionRatio Returns. 

PointOrigin (self)

Getter for property: (NXOpen.Point) PointOrigin Returns the origin point. 

PointOrigin (self, origin)

Setter for property: (NXOpen.Point) PointOrigin. 

Public Member Functions inherited from NXOpen.AnimationDesigner.PhysicsJointBuilder

AttachmentList (self)

Getter for property: (NXOpen.SelectNXObjectList) AttachmentList Returns the attachment list for a Joint. 

BaseList (self)

Getter for property: (NXOpen.SelectNXObjectList) BaseList Returns the base list for a Joint. 

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

ColorOption (self)

Getter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions) ColorOption Returns the color options. 

ColorOption (self, colorOption)

Setter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions) ColorOption. 

MotionType (self)

Getter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes) MotionType Returns the motion type. 

MotionType (self, motionType)

Setter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes) MotionType. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.AnimationDesigner.PhysicsJointBuilder

PhysicsJointBuilderColorOptions = PhysicsJointBuilder.ColorOptions

NXOpen.AnimationDesigner.PhysicsJointBuilderColorOptions is an alias for NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions 

PhysicsJointBuilderMotionTypes = PhysicsJointBuilder.MotionTypes

NXOpen.AnimationDesigner.PhysicsJointBuilderMotionTypes is an alias for NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes 

## Detailed Description

Represents a NXOpen::AnimationDesigner::ScrewJointBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::ScrewJointCollection::CreateScrewJointBuilder 

Created in NX12.0.2 

## Member Function Documentation

## ◆ AxisVector() [1/2]

NXOpen.AnimationDesigner.ScrewJointBuilder.AxisVector
(
self — )

Getter for property: (NXOpen.Direction) AxisVector Returns the axis vector. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.2 

Returns
NXOpen.Direction 

## ◆ AxisVector() [2/2]

NXOpen.AnimationDesigner.ScrewJointBuilder.AxisVector
(
self,

axisVector )

Setter for property: (NXOpen.Direction) AxisVector. 

Sets the axis vector.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.2 

## ◆ ExpressionRatio()

NXOpen.AnimationDesigner.ScrewJointBuilder.ExpressionRatio
(
self — )

Getter for property: (NXOpen.Expression) ExpressionRatio Returns. 

a value that indicates pitch value for the screw joint.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.2 

Returns
NXOpen.Expression 

## ◆ PointOrigin() [1/2]

NXOpen.AnimationDesigner.ScrewJointBuilder.PointOrigin
(
self — )

Getter for property: (NXOpen.Point) PointOrigin Returns the origin point. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.2 

Returns
NXOpen.Point 

## ◆ PointOrigin() [2/2]

NXOpen.AnimationDesigner.ScrewJointBuilder.PointOrigin
(
self,

origin )

Setter for property: (NXOpen.Point) PointOrigin. 

Sets the origin point.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.2 

Copyright 2025 Siemens
