# NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10833.html>

Represents a NXOpen::AnimationDesigner::PointOnCurveKinematicsChainBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder:

## Public Member Functions

MasterRigidGroup (self)

Getter for property: (NXOpen.SelectNXObject) MasterRigidGroup Returns. 

Name (self)

Getter for property: (str) Name Returns. 

Name (self, name)

Setter for property: (str) Name. 

ProjectionDirection (self)

Getter for property: (NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder.ProjectionDirectionType) ProjectionDirection Returns. 

ProjectionDirection (self, projectionDirection)

Setter for property: (NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder.ProjectionDirectionType) ProjectionDirection. 

ProjectionVector (self)

Getter for property: (NXOpen.Direction) ProjectionVector Returns. 

ProjectionVector (self, projectionVector)

Setter for property: (NXOpen.Direction) ProjectionVector. 

SlaveRigidGroups (self)

Getter for property: (NXOpen.SelectNXObjectList) SlaveRigidGroups Returns. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

PointOnCurveKinematicsChainBuilderProjectionDirectionType = PointOnCurveKinematicsChainBuilder.ProjectionDirectionType

NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilderProjectionDirectionType is an alias for NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder.ProjectionDirectionType 

## Detailed Description

Represents a NXOpen::AnimationDesigner::PointOnCurveKinematicsChainBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::PointOnCurveKinematicsChainCollection::CreatePointOnCurveKinematicsChainBuilder 

Created in NX2306.0.0 

## Member Function Documentation

## ◆ MasterRigidGroup()

NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder.MasterRigidGroup
(
self — )

Getter for property: (NXOpen.SelectNXObject) MasterRigidGroup Returns. 

the master rigid group selection. This should be a NXOpen::AnimationDesigner::RigidGroup .

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ Name() [1/2]

NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder.Name
(
self — )

Getter for property: (str) Name Returns. 

the name

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
str 

## ◆ Name() [2/2]

NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder.Name
(
self,

name )

Setter for property: (str) Name. 

Sets the name

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ ProjectionDirection() [1/2]

NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder.ProjectionDirection
(
self — )

Getter for property: (NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder.ProjectionDirectionType) ProjectionDirection Returns. 

the projection direction type of the slave rigid center point.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
PointOnCurveKinematicsChainBuilder.ProjectionDirectionType 

## ◆ ProjectionDirection() [2/2]

NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder.ProjectionDirection
(
self,

projectionDirection )

Setter for property: (NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder.ProjectionDirectionType) ProjectionDirection. 

Sets the projection direction type of the slave rigid center point.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ ProjectionVector() [1/2]

NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder.ProjectionVector
(
self — )

Getter for property: (NXOpen.Direction) ProjectionVector Returns. 

the projection vector when choosing ProjectionDirectionType_AlongVector.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Direction 

## ◆ ProjectionVector() [2/2]

NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder.ProjectionVector
(
self,

projectionVector )

Setter for property: (NXOpen.Direction) ProjectionVector. 

Sets the projection vector when choosing ProjectionDirectionType_AlongVector.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ SlaveRigidGroups()

NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder.SlaveRigidGroups
(
self — )

Getter for property: (NXOpen.SelectNXObjectList) SlaveRigidGroups Returns. 

the slave rigid groups selection. This should be a NXOpen::AnimationDesigner::RigidGroup .

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.SelectNXObjectList 

## Member Data Documentation

## ◆ PointOnCurveKinematicsChainBuilderProjectionDirectionType

NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder.PointOnCurveKinematicsChainBuilderProjectionDirectionType = PointOnCurveKinematicsChainBuilder.ProjectionDirectionType

NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilderProjectionDirectionType is an alias for NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder.ProjectionDirectionType 

Copyright 2025 Siemens
