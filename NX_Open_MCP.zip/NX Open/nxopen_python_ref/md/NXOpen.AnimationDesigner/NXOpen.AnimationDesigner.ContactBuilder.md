# NXOpen.AnimationDesigner.ContactBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10549.html>

Represents a NXOpen::AnimationDesigner::ContactBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.ContactBuilder:

## Public Member Functions

Geometry (self)

Getter for property: (NXOpen.SelectNXObjectList) Geometry Returns the geometries. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

SetGeometry (self, geometries)

Sets the geometry. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::AnimationDesigner::ContactBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::ContactCollection::CreateContactBuilder 

Created in NX12.0.0 

## Member Function Documentation

## ◆ Geometry()

NXOpen.AnimationDesigner.ContactBuilder.Geometry
(
self — )

Getter for property: (NXOpen.SelectNXObjectList) Geometry Returns the geometries. 

This can be a NXOpen::Assemblies::ComponentAssembly , NXOpen::Point , NXOpen::Face , NXOpen::Edge , bodies and curves.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.SelectNXObjectList 

## ◆ Name() [1/2]

NXOpen.AnimationDesigner.ContactBuilder.Name
(
self — )

Getter for property: (str) Name Returns the name. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
str 

## ◆ Name() [2/2]

NXOpen.AnimationDesigner.ContactBuilder.Name
(
self,

name )

Setter for property: (str) Name. 

Sets the name.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ SetGeometry()

NXOpen.AnimationDesigner.ContactBuilder.SetGeometry
(
self,

geometries )

Sets the geometry. 

Created in NX12.0.2 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

geometries — (List[NXOpen.NXObject]) Input geometries

Copyright 2025 Siemens
