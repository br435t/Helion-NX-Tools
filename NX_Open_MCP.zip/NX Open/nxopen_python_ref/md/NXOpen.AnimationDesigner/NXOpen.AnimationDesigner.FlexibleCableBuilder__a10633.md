# NXOpen.AnimationDesigner.FlexibleCableBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10633.html>

Represents a NXOpen::AnimationDesigner::FlexibleCableBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.FlexibleCableBuilder:

## Public Member Functions

AttachmentList (self)

Getter for property: (NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilderList) AttachmentList Returns. 

AttachmentsReversed (self)

Getter for property: (bool) AttachmentsReversed Returns. 

AttachmentsReversed (self, attachmentsReversed)

Setter for property: (bool) AttachmentsReversed. 

Body (self)

Getter for property: (NXOpen.SelectNXObject) Body Returns. 

Collisions (self)

Getter for property: (NXOpen.SelectNXObjectList) Collisions Returns. 

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

ColorOption (self)

Getter for property: (NXOpen.AnimationDesigner.FlexibleCableBuilder.ColorOptions) ColorOption Returns the color option. 

ColorOption (self, colorOption)

Setter for property: (NXOpen.AnimationDesigner.FlexibleCableBuilder.ColorOptions) ColorOption. 

Curves (self)

Getter for property: (NXOpen.SelectNXObjectList) Curves Returns. 

Diameter (self)

Getter for property: (NXOpen.Expression) Diameter Returns. 

GeometryType (self)

Getter for property: (NXOpen.AnimationDesigner.FlexibleCableBuilder.GeometryTypes) GeometryType Returns. 

GeometryType (self, geometryType)

Setter for property: (NXOpen.AnimationDesigner.FlexibleCableBuilder.GeometryTypes) GeometryType. 

Length (self)

Getter for property: (NXOpen.Expression) Length Returns. 

Material (self)

Getter for property: (NXOpen.AnimationDesigner.FlexibleMaterial) Material Returns. 

Material (self, material)

Setter for property: (NXOpen.AnimationDesigner.FlexibleMaterial) Material. 

Name (self)

Getter for property: (str) Name Returns. 

Name (self, name)

Setter for property: (str) Name. 

SectionType (self)

Getter for property: (NXOpen.AnimationDesigner.FlexibleCableBuilder.SectionTypes) SectionType Returns. 

SectionType (self, sectionType)

Setter for property: (NXOpen.AnimationDesigner.FlexibleCableBuilder.SectionTypes) SectionType. 

Thickness (self)

Getter for property: (NXOpen.Expression) Thickness Returns. 

UpdateAttachmentData (self, curveOrBodyUpdated)

Updates all attachment data if the curves or body are changed. 

UpdatePreviewedCableFacet (self, points, widthDirections, radius, width, thickness)

Updates the previewed cable facet body. 

Width (self)

Getter for property: (NXOpen.Expression) Width Returns. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

FlexibleCableBuilderColorOptions = FlexibleCableBuilder.ColorOptions

NXOpen.AnimationDesigner.FlexibleCableBuilderColorOptions is an alias for NXOpen.AnimationDesigner.FlexibleCableBuilder.ColorOptions 

FlexibleCableBuilderGeometryTypes = FlexibleCableBuilder.GeometryTypes

NXOpen.AnimationDesigner.FlexibleCableBuilderGeometryTypes is an alias for NXOpen.AnimationDesigner.FlexibleCableBuilder.GeometryTypes 

FlexibleCableBuilderSectionTypes = FlexibleCableBuilder.SectionTypes

NXOpen.AnimationDesigner.FlexibleCableBuilderSectionTypes is an alias for NXOpen.AnimationDesigner.FlexibleCableBuilder.SectionTypes 

## Detailed Description

Represents a NXOpen::AnimationDesigner::FlexibleCableBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::FlexibleCableCollection::CreateFlexibleCableBuilder 

Created in NX2306.0.0 

## Member Function Documentation

## ◆ AttachmentList()

NXOpen.AnimationDesigner.FlexibleCableBuilder.AttachmentList
(
self — )

Getter for property: (NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilderList) AttachmentList Returns. 

the list containing the defined attachments.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
FlexibleCableAttachmentBuilderList 

## ◆ AttachmentsReversed() [1/2]

NXOpen.AnimationDesigner.FlexibleCableBuilder.AttachmentsReversed
(
self — )

Getter for property: (bool) AttachmentsReversed Returns. 

the attachments reversed flag.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
bool 

## ◆ AttachmentsReversed() [2/2]

NXOpen.AnimationDesigner.FlexibleCableBuilder.AttachmentsReversed
(
self,

attachmentsReversed )

Setter for property: (bool) AttachmentsReversed. 

Sets the attachments reversed flag.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ Body()

NXOpen.AnimationDesigner.FlexibleCableBuilder.Body
(
self — )

Getter for property: (NXOpen.SelectNXObject) Body Returns. 

the body.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ Collisions()

NXOpen.AnimationDesigner.FlexibleCableBuilder.Collisions
(
self — )

Getter for property: (NXOpen.SelectNXObjectList) Collisions Returns. 

the collision bodies.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.SelectNXObjectList 

## ◆ Color() [1/2]

NXOpen.AnimationDesigner.FlexibleCableBuilder.Color
(
self — )

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.NXColor 

## ◆ Color() [2/2]

NXOpen.AnimationDesigner.FlexibleCableBuilder.Color
(
self,

color )

Setter for property: (NXOpen.NXColor) Color. 

Sets the color.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ ColorOption() [1/2]

NXOpen.AnimationDesigner.FlexibleCableBuilder.ColorOption
(
self — )

Getter for property: (NXOpen.AnimationDesigner.FlexibleCableBuilder.ColorOptions) ColorOption Returns the color option. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
FlexibleCableBuilder.ColorOptions 

## ◆ ColorOption() [2/2]

NXOpen.AnimationDesigner.FlexibleCableBuilder.ColorOption
(
self,

colorOption )

Setter for property: (NXOpen.AnimationDesigner.FlexibleCableBuilder.ColorOptions) ColorOption. 

Sets the color option.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ Curves()

NXOpen.AnimationDesigner.FlexibleCableBuilder.Curves
(
self — )

Getter for property: (NXOpen.SelectNXObjectList) Curves Returns. 

the curves.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.SelectNXObjectList 

## ◆ Diameter()

NXOpen.AnimationDesigner.FlexibleCableBuilder.Diameter
(
self — )

Getter for property: (NXOpen.Expression) Diameter Returns. 

the diameter for circle section type.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ GeometryType() [1/2]

NXOpen.AnimationDesigner.FlexibleCableBuilder.GeometryType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.FlexibleCableBuilder.GeometryTypes) GeometryType Returns. 

the geometry type.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
FlexibleCableBuilder.GeometryTypes 

## ◆ GeometryType() [2/2]

NXOpen.AnimationDesigner.FlexibleCableBuilder.GeometryType
(
self,

geometryType )

Setter for property: (NXOpen.AnimationDesigner.FlexibleCableBuilder.GeometryTypes) GeometryType. 

Sets the geometry type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ Length()

NXOpen.AnimationDesigner.FlexibleCableBuilder.Length
(
self — )

Getter for property: (NXOpen.Expression) Length Returns. 

the length.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ Material() [1/2]

NXOpen.AnimationDesigner.FlexibleCableBuilder.Material
(
self — )

Getter for property: (NXOpen.AnimationDesigner.FlexibleMaterial) Material Returns. 

the material. This can be a NXOpen::AnimationDesigner::FlexibleMaterial .

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
FlexibleMaterial 

## ◆ Material() [2/2]

NXOpen.AnimationDesigner.FlexibleCableBuilder.Material
(
self,

material )

Setter for property: (NXOpen.AnimationDesigner.FlexibleMaterial) Material. 

Sets the material. This can be a NXOpen::AnimationDesigner::FlexibleMaterial .

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ Name() [1/2]

NXOpen.AnimationDesigner.FlexibleCableBuilder.Name
(
self — )

Getter for property: (str) Name Returns. 

the name.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
str 

## ◆ Name() [2/2]

NXOpen.AnimationDesigner.FlexibleCableBuilder.Name
(
self,

name )

Setter for property: (str) Name. 

Sets the name.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ SectionType() [1/2]

NXOpen.AnimationDesigner.FlexibleCableBuilder.SectionType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.FlexibleCableBuilder.SectionTypes) SectionType Returns. 

the section type.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
FlexibleCableBuilder.SectionTypes 

## ◆ SectionType() [2/2]

NXOpen.AnimationDesigner.FlexibleCableBuilder.SectionType
(
self,

sectionType )

Setter for property: (NXOpen.AnimationDesigner.FlexibleCableBuilder.SectionTypes) SectionType. 

Sets the section type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ Thickness()

NXOpen.AnimationDesigner.FlexibleCableBuilder.Thickness
(
self — )

Getter for property: (NXOpen.Expression) Thickness Returns. 

the thickness for rectangle section type.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ UpdateAttachmentData()

NXOpen.AnimationDesigner.FlexibleCableBuilder.UpdateAttachmentData
(
self,

curveOrBodyUpdated )

Updates all attachment data if the curves or body are changed. 

Created in NX2306.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

curveOrBodyUpdated — (bool)

## ◆ UpdatePreviewedCableFacet()

NXOpen.AnimationDesigner.FlexibleCableBuilder.UpdatePreviewedCableFacet
(
self,

points,

widthDirections,

radius,

width,

thickness )

Updates the previewed cable facet body. 

Created in NX2306.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

points — (List[NXOpen.Point3d])

widthDirections — (List[NXOpen.Vector3d])

radius — (float)

width — (float)

thickness — (float)

## ◆ Width()

NXOpen.AnimationDesigner.FlexibleCableBuilder.Width
(
self — )

Getter for property: (NXOpen.Expression) Width Returns. 

the width for rectangle section type.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## Member Data Documentation

## ◆ FlexibleCableBuilderColorOptions

NXOpen.AnimationDesigner.FlexibleCableBuilder.FlexibleCableBuilderColorOptions = FlexibleCableBuilder.ColorOptions

NXOpen.AnimationDesigner.FlexibleCableBuilderColorOptions is an alias for NXOpen.AnimationDesigner.FlexibleCableBuilder.ColorOptions 

## ◆ FlexibleCableBuilderGeometryTypes

NXOpen.AnimationDesigner.FlexibleCableBuilder.FlexibleCableBuilderGeometryTypes = FlexibleCableBuilder.GeometryTypes

NXOpen.AnimationDesigner.FlexibleCableBuilderGeometryTypes is an alias for NXOpen.AnimationDesigner.FlexibleCableBuilder.GeometryTypes 

## ◆ FlexibleCableBuilderSectionTypes

NXOpen.AnimationDesigner.FlexibleCableBuilder.FlexibleCableBuilderSectionTypes = FlexibleCableBuilder.SectionTypes

NXOpen.AnimationDesigner.FlexibleCableBuilderSectionTypes is an alias for NXOpen.AnimationDesigner.FlexibleCableBuilder.SectionTypes 

Copyright 2025 Siemens
