# NXOpen.AnimationDesigner.FixedJointBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10605.html>

Represents a NXOpen::AnimationDesigner::FixedJointBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.FixedJointBuilder:

## Public Member Functions

FeedbackPoint (self)

Getter for property: (NXOpen.Point) FeedbackPoint Returns the position of visual feedback point. 

FeedbackPoint (self, feedback)

Setter for property: (NXOpen.Point) FeedbackPoint. 

Public Member Functions inherited from NXOpen.AnimationDesigner.PhysicsJointBuilder

AttachmentList (self)

Getter for property: (NXOpen.SelectNXObjectList) AttachmentList Returns the attachment list for a Joint. 

BaseList (self)

Getter for property: (NXOpen.SelectNXObjectList) BaseList Returns the base list for a Joint. 

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

ColorOption (self)

Getter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions) ColorOption Returns the color options. 

ColorOption (self, colorOption)

Setter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions) ColorOption. 

MotionType (self)

Getter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes) MotionType Returns the motion type. 

MotionType (self, motionType)

Setter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes) MotionType. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.AnimationDesigner.PhysicsJointBuilder

PhysicsJointBuilderColorOptions = PhysicsJointBuilder.ColorOptions

NXOpen.AnimationDesigner.PhysicsJointBuilderColorOptions is an alias for NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions 

PhysicsJointBuilderMotionTypes = PhysicsJointBuilder.MotionTypes

NXOpen.AnimationDesigner.PhysicsJointBuilderMotionTypes is an alias for NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes 

## Detailed Description

Represents a NXOpen::AnimationDesigner::FixedJointBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::FixedJointCollection::CreateFixedJointBuilder 

Created in NX12.0.0 

## Member Function Documentation

## ◆ FeedbackPoint() [1/2]

NXOpen.AnimationDesigner.FixedJointBuilder.FeedbackPoint
(
self — )

Getter for property: (NXOpen.Point) FeedbackPoint Returns the position of visual feedback point. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Deprecated
Deprecated in NX1899.0.0. Get feedback point mechanism deprecated in 1899. Always get null tag. 

Returns
NXOpen.Point 

## ◆ FeedbackPoint() [2/2]

NXOpen.AnimationDesigner.FixedJointBuilder.FeedbackPoint
(
self,

feedback )

Setter for property: (NXOpen.Point) FeedbackPoint. 

Sets the position of visual feedback point.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Deprecated
Deprecated in NX1899.0.0. Set feedback point mechanism deprecated in 1899. Always sets failed. 

Copyright 2025 Siemens
