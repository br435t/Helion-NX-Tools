# NXOpen.AnimationDesigner.RigidGroupBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00123.html>

## Classes

class — ColorOptions

the color options. More...

class — CreationTypes

the creation types. More...

class — MassPropertiesOption

the mass property options. More...

Copyright 2025 Siemens
