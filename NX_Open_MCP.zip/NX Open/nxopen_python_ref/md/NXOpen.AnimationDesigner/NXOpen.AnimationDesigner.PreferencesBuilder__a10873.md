# NXOpen.AnimationDesigner.PreferencesBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10873.html>

Represents a NXOpen::AnimationDesigner::PreferencesBuilder builder. 
More...

Inheritance diagram for NXOpen.AnimationDesigner.PreferencesBuilder:

## Public Member Functions

ArrangementType (self)

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.ArrangementTypes) ArrangementType Returns the option specifies the arrangement type. 

ArrangementType (self, arrangementType)

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.ArrangementTypes) ArrangementType. 

BulletFlexibleMaterialDensity (self)

Getter for property: (NXOpen.Expression) BulletFlexibleMaterialDensity Returns the bullet flexible material density expression which specifies the density of a flexible body. 

CollisionPrecision (self)

Getter for property: (NXOpen.Expression) CollisionPrecision Returns the collision precision expression. 

ContactColor (self)

Getter for property: (int) ContactColor Returns the color for contact face. 

ContactColor (self, color)

Setter for property: (int) ContactColor. 

ContactHardnessWithCollisionBody (self)

Getter for property: (NXOpen.Expression) ContactHardnessWithCollisionBody Returns the flexible material contact hardness with collision expression which specifies how strict any overlap between a flexible body and collision body is treated. 

ContactHardnessWithFlexibleBody (self)

Getter for property: (NXOpen.Expression) ContactHardnessWithFlexibleBody Returns the flexible material contact hardness with flexible body expression which specifies how strict any overlap between flexible bodies is treated. 

CurveSmoothing (self)

Getter for property: (bool) CurveSmoothing Returns the smooth curve flag. 

CurveSmoothing (self, isSoomth)

Setter for property: (bool) CurveSmoothing. 

DelaySolve (self)

Getter for property: (bool) DelaySolve Returns the delay solve flag. 

DelaySolve (self, delay_solve)

Setter for property: (bool) DelaySolve. 

EnableParallel (self)

Getter for property: (bool) EnableParallel Returns the enable parallel calculation flag. 

EnableParallel (self, enableParallel)

Setter for property: (bool) EnableParallel. 

ErrorReduction (self)

Getter for property: (NXOpen.Expression) ErrorReduction Returns the error reduction. 

FlexibleCollisionSkipStep (self)

Getter for property: (NXOpen.Expression) FlexibleCollisionSkipStep Returns the flexible collision skip step expression which specifies how many steps to skip when a flexible body collides. 

FlexibleEngineTuningEnableMultithreading (self)

Getter for property: (bool) FlexibleEngineTuningEnableMultithreading Returns the option determines whether to use multithreading. 

FlexibleEngineTuningEnableMultithreading (self, flexibleEngineTuningEnableMultithreading)

Setter for property: (bool) FlexibleEngineTuningEnableMultithreading. 

FlexibleEngineTuningMinNumberOfNodesBetweenAttachments (self)

Getter for property: (int) FlexibleEngineTuningMinNumberOfNodesBetweenAttachments Returns the option specifies how many min number of nodes between attachments to create cable. 

FlexibleEngineTuningMinNumberOfNodesBetweenAttachments (self, flexibleEngineTuningMinNumberOfNodesBetweenAttachments)

Setter for property: (int) FlexibleEngineTuningMinNumberOfNodesBetweenAttachments. 

FlexibleEngineTuningNumberOfThreads (self)

Getter for property: (int) FlexibleEngineTuningNumberOfThreads Returns the option specifies the number of threads. 

FlexibleEngineTuningNumberOfThreads (self, flexibleEngineTuningNumberOfThreads)

Setter for property: (int) FlexibleEngineTuningNumberOfThreads. 

FlexibleEngineTuningPrecision (self)

Getter for property: (NXOpen.Expression) FlexibleEngineTuningPrecision Returns the flexible engine tuning precision. 

FlexibleEngineTuningSkipStepsNumber (self)

Getter for property: (int) FlexibleEngineTuningSkipStepsNumber Returns the option specifies how many steps to skip during the simulation. 

FlexibleEngineTuningSkipStepsNumber (self, flexibleEngineTuningSkipStepsNumber)

Setter for property: (int) FlexibleEngineTuningSkipStepsNumber. 

FlexibleFacetBodyAngularPrecision (self)

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.KineoFlexibleFacetBodyPrecision) FlexibleFacetBodyAngularPrecision Returns the flexible facet body angular precision. 

FlexibleFacetBodyAngularPrecision (self, precision)

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.KineoFlexibleFacetBodyPrecision) FlexibleFacetBodyAngularPrecision. 

FlexibleFacetBodyFacetPrecisionOption (self)

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.KineoFlexibleFacetBodyPrecision) FlexibleFacetBodyFacetPrecisionOption Returns the fineness of the facets and the smoothness of a circular cross section in a flexible body. 

FlexibleFacetBodyFacetPrecisionOption (self, precision)

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.KineoFlexibleFacetBodyPrecision) FlexibleFacetBodyFacetPrecisionOption. 

FlexibleFacetBodyLinearPrecision (self)

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.KineoFlexibleFacetBodyPrecision) FlexibleFacetBodyLinearPrecision Returns the flexible facet body linear precision. 

FlexibleFacetBodyLinearPrecision (self, precision)

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.KineoFlexibleFacetBodyPrecision) FlexibleFacetBodyLinearPrecision. 

FlexibleFacetBodyPrecision (self)

Getter for property: (NXOpen.Expression) FlexibleFacetBodyPrecision Returns the flexible facet body precision. 

FlexibleFacetBodySameWithEngineTuningPrecision (self)

Getter for property: (bool) FlexibleFacetBodySameWithEngineTuningPrecision Returns the option determines whether facet bodies should use the same precision as engine tuning. 

FlexibleFacetBodySameWithEngineTuningPrecision (self, flexibleFacetBodySameWithEngineTuningPrecision)

Setter for property: (bool) FlexibleFacetBodySameWithEngineTuningPrecision. 

FlexibleFacetBodyUserDefinedAngularPrecision (self)

Getter for property: (NXOpen.Expression) FlexibleFacetBodyUserDefinedAngularPrecision Returns the flexible facet body user defined angular precision. 

FlexibleFacetBodyUserDefinedLinearPrecision (self)

Getter for property: (NXOpen.Expression) FlexibleFacetBodyUserDefinedLinearPrecision Returns the flexible facet body user defined linear precision. 

FlexibleFacetBodyUserDefinedLinearPrecisionByPercentage (self)

Getter for property: (float) FlexibleFacetBodyUserDefinedLinearPrecisionByPercentage Returns the user defined linear precision percentage of a kineo facet body. 

FlexibleFacetBodyUserDefinedLinearPrecisionByPercentage (self, precision)

Setter for property: (float) FlexibleFacetBodyUserDefinedLinearPrecisionByPercentage. 

FlexibleFacetBodyUserUsingDefinedLinearPrecisionInputType (self)

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyUserDefinedLinearPrecisionInputTypes) FlexibleFacetBodyUserUsingDefinedLinearPrecisionInputType Returns the option determines whether to use a length value instead of a percentage. 

FlexibleFacetBodyUserUsingDefinedLinearPrecisionInputType (self, inputType)

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyUserDefinedLinearPrecisionInputTypes) FlexibleFacetBodyUserUsingDefinedLinearPrecisionInputType. 

FlexibleFacetPrecision (self)

Getter for property: (NXOpen.Expression) FlexibleFacetPrecision Returns the flexible facet precision expression which specifies the fineness of the facets in a flexible body. 

FlexibleMaterialAnchorHardness (self)

Getter for property: (NXOpen.Expression) FlexibleMaterialAnchorHardness Returns the flexible material anchor hardness expression which specifies how strongly a flexible body is expected to stick to another object, e. 

FlexibleMaterialDamping (self)

Getter for property: (NXOpen.Expression) FlexibleMaterialDamping Returns the flexible material damping expression which specifies the coefficient of damping forces acting on flexible bodies to reduce their oscillation over time. 

FlexibleMaterialDensity (self)

Getter for property: (NXOpen.Expression) FlexibleMaterialDensity Returns the flexible material density expression which specifies the density of a flexible body. 

FlexibleMaterialDynamicFriction (self)

Getter for property: (NXOpen.Expression) FlexibleMaterialDynamicFriction Returns the flexible material dynamic friction expression which specifies the coefficient of the dynamic friction acting on a flexible body against a surface. 

FlexibleMaterialEnableMaxContactForce (self)

Getter for property: (bool) FlexibleMaterialEnableMaxContactForce Returns the option determines whether to set the maximum contact force. 

FlexibleMaterialEnableMaxContactForce (self, flexibleMaterialEnableMaxContactForce)

Setter for property: (bool) FlexibleMaterialEnableMaxContactForce. 

FlexibleMaterialEnableMaxTwist (self)

Getter for property: (bool) FlexibleMaterialEnableMaxTwist Returns the option determines whether to set the maximum twist. 

FlexibleMaterialEnableMaxTwist (self, flexibleMaterialEnableMaxTwist)

Setter for property: (bool) FlexibleMaterialEnableMaxTwist. 

FlexibleMaterialEnableMinCurvature (self)

Getter for property: (bool) FlexibleMaterialEnableMinCurvature Returns the option determines whether to set the minimum curvature. 

FlexibleMaterialEnableMinCurvature (self, flexibleMaterialEnableMinCurvature)

Setter for property: (bool) FlexibleMaterialEnableMinCurvature. 

FlexibleMaterialFulcrumLength (self)

Getter for property: (NXOpen.Expression) FlexibleMaterialFulcrumLength Returns the flexible material fulcrum length. 

FlexibleMaterialLinearStiffness (self)

Getter for property: (NXOpen.Expression) FlexibleMaterialLinearStiffness Returns the flexible material linear stiffness expression which specifies the coefficient of conservation of distance between adjacent particles. 

FlexibleMaterialMaxContactForce (self)

Getter for property: (NXOpen.Expression) FlexibleMaterialMaxContactForce Returns the flexible material maximum contact force. 

FlexibleMaterialMaxTension (self)

Getter for property: (NXOpen.Expression) FlexibleMaterialMaxTension Returns the flexible material maximum tension. 

FlexibleMaterialMaxTwist (self)

Getter for property: (NXOpen.Expression) FlexibleMaterialMaxTwist Returns the flexible material maximum twist. 

FlexibleMaterialMinCurvature (self)

Getter for property: (NXOpen.Expression) FlexibleMaterialMinCurvature Returns the flexible material minimum curvature. 

FlexibleMaterialOscillation (self)

Getter for property: (float) FlexibleMaterialOscillation Returns the flexible material oscillation. 

FlexibleMaterialOscillation (self, flexibleMaterialOscillation)

Setter for property: (float) FlexibleMaterialOscillation. 

FlexibleMaterialPrecision (self)

Getter for property: (NXOpen.Expression) FlexibleMaterialPrecision Returns the flexible material precision expression which specifies the fineness of the elements in a flexible body. 

FlexibleMaterialYoungModulus (self)

Getter for property: (NXOpen.Expression) FlexibleMaterialYoungModulus Returns the flexible material Young's modulus. 

FlowLineColor (self)

Getter for property: (int) FlowLineColor Returns the flow line color. 

FlowLineColor (self, flowlinecolor)

Setter for property: (int) FlowLineColor. 

FlowLineFont (self)

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.FlowLineStyleTypes) FlowLineFont Returns the flow line font. 

FlowLineFont (self, flowlinefont)

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.FlowLineStyleTypes) FlowLineFont. 

FlowLineWidth (self)

Getter for property: (int) FlowLineWidth Returns the flow line width. 

FlowLineWidth (self, flowlinewidth)

Setter for property: (int) FlowLineWidth. 

GraphPlotType (self)

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.GraphPlotTypes) GraphPlotType Returns the option specifies the graph plot type. 

GraphPlotType (self, plotType)

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.GraphPlotTypes) GraphPlotType. 

GraphSampleTime (self)

Getter for property: (NXOpen.Expression) GraphSampleTime Returns the graph sample time expression. 

GravityDirection (self)

Getter for property: (int) GravityDirection Returns the gravity direction. 

GravityDirection (self, direction)

Setter for property: (int) GravityDirection. 

HideMeasureRuler (self)

Getter for property: (bool) HideMeasureRuler Returns the hide measure ruler flag. 

HideMeasureRuler (self, hide)

Setter for property: (bool) HideMeasureRuler. 

ImpulseSplitWithCollisionBody (self)

Getter for property: (NXOpen.Expression) ImpulseSplitWithCollisionBody Returns the flexible material impulse split when contact with collision body expression which specifies how to proportion the impulse generated by a collision between a flexible body and collision body. 

ImpulseSplitWithFlexibleBody (self)

Getter for property: (NXOpen.Expression) ImpulseSplitWithFlexibleBody Returns the flexible material impulse split when contact with flexible body expression which specifies how to proportion the impulse generated by a collision between flexible bodies. 

KineoAngularTolerance (self)

Getter for property: (NXOpen.Expression) KineoAngularTolerance Returns the kineo angular tolerance. 

KineoLinearTolerance (self)

Getter for property: (NXOpen.Expression) KineoLinearTolerance Returns the kineo linear tolerance. 

MaxIteration (self)

Getter for property: (NXOpen.Expression) MaxIteration Returns the max iteration. 

NonRigidGroupColor (self)

Getter for property: (int) NonRigidGroupColor Returns the color for non rigid group body. 

NonRigidGroupColor (self, color)

Setter for property: (int) NonRigidGroupColor. 

OnlySimulateActiveDisplayPart (self)

Getter for property: (bool) OnlySimulateActiveDisplayPart Returns the only simulate active display part flag. 

OnlySimulateActiveDisplayPart (self, bOnly)

Setter for property: (bool) OnlySimulateActiveDisplayPart. 

OptimizeRigidGroupProperty (self)

Getter for property: (bool) OptimizeRigidGroupProperty Returns the option indicates whether the optimized properties of rigid group are being used. 

OptimizeRigidGroupProperty (self, optimizeRigidProp)

Setter for property: (bool) OptimizeRigidGroupProperty. 

PhysicsEngine (self)

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.PhysicsEngines) PhysicsEngine Returns the physics engine. 

PhysicsEngine (self, engine)

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.PhysicsEngines) PhysicsEngine. 

PrecisionPresetMode (self)

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.PrecisionPresetModes) PrecisionPresetMode Returns the simulation preset mode. 

PrecisionPresetMode (self, presetMode)

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.PrecisionPresetModes) PrecisionPresetMode. 

RandomizeSolvingOrder (self)

Getter for property: (bool) RandomizeSolvingOrder Returns the option indicates whether to randomize the solving order by the engine. 

RandomizeSolvingOrder (self, randomOrder)

Setter for property: (bool) RandomizeSolvingOrder. 

RichGeomType (self)

Getter for property: (bool) RichGeomType Returns the rich geometry type. 

RichGeomType (self, richGeomType)

Setter for property: (bool) RichGeomType. 

RigidGroupSelectionDisplay (self)

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.RigidGroupSelectionDisplayTypes) RigidGroupSelectionDisplay Returns the option specifies the selection display for rigid groups. 

RigidGroupSelectionDisplay (self, displayType)

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.RigidGroupSelectionDisplayTypes) RigidGroupSelectionDisplay. 

SameWithFlexibleMaterialPrecision (self)

Getter for property: (bool) SameWithFlexibleMaterialPrecision Returns the option determines whether facet bodies should use the same precision as engine tuning. 

SameWithFlexibleMaterialPrecision (self, sameWithFlexibleMaterialPrecision)

Setter for property: (bool) SameWithFlexibleMaterialPrecision. 

ShowFlowLine (self)

Getter for property: (bool) ShowFlowLine Returns the option for enable draw flow line. 

ShowFlowLine (self, showflowline)

Setter for property: (bool) ShowFlowLine. 

SolutionSearchScope (self)

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.SolutionSearchScopeTypes) SolutionSearchScope Returns the option specifies the search scope for the Animation Designer definition. 

SolutionSearchScope (self, scopeType)

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.SolutionSearchScopeTypes) SolutionSearchScope. 

StepIncrementTime (self)

Getter for property: (NXOpen.Expression) StepIncrementTime Returns the step time expression. 

StepTime (self)

Getter for property: (NXOpen.Expression) StepTime Returns the step time. 

TimeScaleFactor (self)

Getter for property: (float) TimeScaleFactor Returns the time scale factor. 

TimeScaleFactor (self, scaleFactor)

Setter for property: (float) TimeScaleFactor. 

Tolerance (self)

Getter for property: (NXOpen.Expression) Tolerance Returns the tolerance. 

UseFacetToMeasure (self)

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.BodyToUseForMeasureTypes) UseFacetToMeasure Returns the option indicates whether to use facet body instead of solid body to measure distance or angle in order to improve performance. 

UseFacetToMeasure (self, bodyType)

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.BodyToUseForMeasureTypes) UseFacetToMeasure. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

PreferencesBuilderArrangementTypes = PreferencesBuilder.ArrangementTypes

NXOpen.AnimationDesigner.PreferencesBuilderArrangementTypes is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.ArrangementTypes 

PreferencesBuilderBodyToUseForMeasureTypes = PreferencesBuilder.BodyToUseForMeasureTypes

NXOpen.AnimationDesigner.PreferencesBuilderBodyToUseForMeasureTypes is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.BodyToUseForMeasureTypes 

PreferencesBuilderFlexibleFacetBodyUserDefinedLinearPrecisionInputTypes = PreferencesBuilder.FlexibleFacetBodyUserDefinedLinearPrecisionInputTypes

NXOpen.AnimationDesigner.PreferencesBuilderFlexibleFacetBodyUserDefinedLinearPrecisionInputTypes is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyUserDefinedLinearPrecisionInputTypes 

PreferencesBuilderFlowLineStyleTypes = PreferencesBuilder.FlowLineStyleTypes

NXOpen.AnimationDesigner.PreferencesBuilderFlowLineStyleTypes is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.FlowLineStyleTypes 

PreferencesBuilderGraphPlotTypes = PreferencesBuilder.GraphPlotTypes

NXOpen.AnimationDesigner.PreferencesBuilderGraphPlotTypes is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.GraphPlotTypes 

PreferencesBuilderKineoFlexibleFacetBodyPrecision = PreferencesBuilder.KineoFlexibleFacetBodyPrecision

NXOpen.AnimationDesigner.PreferencesBuilderKineoFlexibleFacetBodyPrecision is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.KineoFlexibleFacetBodyPrecision 

PreferencesBuilderPhysicsEngines = PreferencesBuilder.PhysicsEngines

NXOpen.AnimationDesigner.PreferencesBuilderPhysicsEngines is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.PhysicsEngines 

PreferencesBuilderPrecisionPresetModes = PreferencesBuilder.PrecisionPresetModes

NXOpen.AnimationDesigner.PreferencesBuilderPrecisionPresetModes is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.PrecisionPresetModes 

PreferencesBuilderRigidGroupSelectionDisplayTypes = PreferencesBuilder.RigidGroupSelectionDisplayTypes

NXOpen.AnimationDesigner.PreferencesBuilderRigidGroupSelectionDisplayTypes is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.RigidGroupSelectionDisplayTypes 

PreferencesBuilderSolutionSearchScopeTypes = PreferencesBuilder.SolutionSearchScopeTypes

NXOpen.AnimationDesigner.PreferencesBuilderSolutionSearchScopeTypes is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.SolutionSearchScopeTypes 

## Detailed Description

Represents a NXOpen::AnimationDesigner::PreferencesBuilder builder. 

Use the static method in NXOpen::AnimationDesigner::AnimationDesignerManager to obtain an instance. 

Created in NX12.0.0 

## Member Function Documentation

## ◆ ArrangementType() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.ArrangementType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.ArrangementTypes) ArrangementType Returns the option specifies the arrangement type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
PreferencesBuilder.ArrangementTypes 

## ◆ ArrangementType() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.ArrangementType
(
self,

arrangementType )

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.ArrangementTypes) ArrangementType. 

Sets the option specifies the arrangement type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

## ◆ BulletFlexibleMaterialDensity()

NXOpen.AnimationDesigner.PreferencesBuilder.BulletFlexibleMaterialDensity
(
self — )

Getter for property: (NXOpen.Expression) BulletFlexibleMaterialDensity Returns the bullet flexible material density expression which specifies the density of a flexible body. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ CollisionPrecision()

NXOpen.AnimationDesigner.PreferencesBuilder.CollisionPrecision
(
self — )

Getter for property: (NXOpen.Expression) CollisionPrecision Returns the collision precision expression. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ ContactColor() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.ContactColor
(
self — )

Getter for property: (int) ContactColor Returns the color for contact face. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
int 

## ◆ ContactColor() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.ContactColor
(
self,

color )

Setter for property: (int) ContactColor. 

Sets the color for contact face.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ ContactHardnessWithCollisionBody()

NXOpen.AnimationDesigner.PreferencesBuilder.ContactHardnessWithCollisionBody
(
self — )

Getter for property: (NXOpen.Expression) ContactHardnessWithCollisionBody Returns the flexible material contact hardness with collision expression which specifies how strict any overlap between a flexible body and collision body is treated. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.Expression 

## ◆ ContactHardnessWithFlexibleBody()

NXOpen.AnimationDesigner.PreferencesBuilder.ContactHardnessWithFlexibleBody
(
self — )

Getter for property: (NXOpen.Expression) ContactHardnessWithFlexibleBody Returns the flexible material contact hardness with flexible body expression which specifies how strict any overlap between flexible bodies is treated. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.Expression 

## ◆ CurveSmoothing() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.CurveSmoothing
(
self — )

Getter for property: (bool) CurveSmoothing Returns the smooth curve flag. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
bool 

## ◆ CurveSmoothing() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.CurveSmoothing
(
self,

isSoomth )

Setter for property: (bool) CurveSmoothing. 

Sets the smooth curve flag.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ DelaySolve() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.DelaySolve
(
self — )

Getter for property: (bool) DelaySolve Returns the delay solve flag. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
bool 

## ◆ DelaySolve() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.DelaySolve
(
self,

delay_solve )

Setter for property: (bool) DelaySolve. 

Sets the delay solve flag.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ EnableParallel() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.EnableParallel
(
self — )

Getter for property: (bool) EnableParallel Returns the enable parallel calculation flag. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1899.0.0 

Returns
bool 

## ◆ EnableParallel() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.EnableParallel
(
self,

enableParallel )

Setter for property: (bool) EnableParallel. 

Sets the enable parallel calculation flag.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1899.0.0 

## ◆ ErrorReduction()

NXOpen.AnimationDesigner.PreferencesBuilder.ErrorReduction
(
self — )

Getter for property: (NXOpen.Expression) ErrorReduction Returns the error reduction. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ FlexibleCollisionSkipStep()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleCollisionSkipStep
(
self — )

Getter for property: (NXOpen.Expression) FlexibleCollisionSkipStep Returns the flexible collision skip step expression which specifies how many steps to skip when a flexible body collides. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.Expression 

## ◆ FlexibleEngineTuningEnableMultithreading() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleEngineTuningEnableMultithreading
(
self — )

Getter for property: (bool) FlexibleEngineTuningEnableMultithreading Returns the option determines whether to use multithreading. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2406.0.0 

Returns
bool 

## ◆ FlexibleEngineTuningEnableMultithreading() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleEngineTuningEnableMultithreading
(
self,

flexibleEngineTuningEnableMultithreading )

Setter for property: (bool) FlexibleEngineTuningEnableMultithreading. 

Sets the option determines whether to use multithreading.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2406.0.0 

## ◆ FlexibleEngineTuningMinNumberOfNodesBetweenAttachments() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleEngineTuningMinNumberOfNodesBetweenAttachments
(
self — )

Getter for property: (int) FlexibleEngineTuningMinNumberOfNodesBetweenAttachments Returns the option specifies how many min number of nodes between attachments to create cable. 

Getter License requirements: nx_mcd_core ("Mechatronics Concept Designer")

Created in NX2312.0.0 

Returns
int 

## ◆ FlexibleEngineTuningMinNumberOfNodesBetweenAttachments() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleEngineTuningMinNumberOfNodesBetweenAttachments
(
self,

flexibleEngineTuningMinNumberOfNodesBetweenAttachments )

Setter for property: (int) FlexibleEngineTuningMinNumberOfNodesBetweenAttachments. 

Sets the option specifies how many min number of nodes between attachments to create cable.

Setter License requirements: nx_mcd_core ("Mechatronics Concept Designer")

Created in NX2312.0.0 

## ◆ FlexibleEngineTuningNumberOfThreads() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleEngineTuningNumberOfThreads
(
self — )

Getter for property: (int) FlexibleEngineTuningNumberOfThreads Returns the option specifies the number of threads. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2406.0.0 

Returns
int 

## ◆ FlexibleEngineTuningNumberOfThreads() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleEngineTuningNumberOfThreads
(
self,

flexibleEngineTuningNumberOfThreads )

Setter for property: (int) FlexibleEngineTuningNumberOfThreads. 

Sets the option specifies the number of threads.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2406.0.0 

## ◆ FlexibleEngineTuningPrecision()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleEngineTuningPrecision
(
self — )

Getter for property: (NXOpen.Expression) FlexibleEngineTuningPrecision Returns the flexible engine tuning precision. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Deprecated
Deprecated in NX2312.0.0. This functionality is no longer supported. 

Returns
NXOpen.Expression 

## ◆ FlexibleEngineTuningSkipStepsNumber() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleEngineTuningSkipStepsNumber
(
self — )

Getter for property: (int) FlexibleEngineTuningSkipStepsNumber Returns the option specifies how many steps to skip during the simulation. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
int 

## ◆ FlexibleEngineTuningSkipStepsNumber() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleEngineTuningSkipStepsNumber
(
self,

flexibleEngineTuningSkipStepsNumber )

Setter for property: (int) FlexibleEngineTuningSkipStepsNumber. 

Sets the option specifies how many steps to skip during the simulation.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ FlexibleFacetBodyAngularPrecision() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyAngularPrecision
(
self — )

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.KineoFlexibleFacetBodyPrecision) FlexibleFacetBodyAngularPrecision Returns the flexible facet body angular precision. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

Deprecated
Deprecated in NX2312.0.0. This functionality is no longer supported. 

Returns
PreferencesBuilder.KineoFlexibleFacetBodyPrecision 

## ◆ FlexibleFacetBodyAngularPrecision() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyAngularPrecision
(
self,

precision )

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.KineoFlexibleFacetBodyPrecision) FlexibleFacetBodyAngularPrecision. 

Sets the flexible facet body angular precision.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

Deprecated
Deprecated in NX2312.0.0. This functionality is no longer supported. 

## ◆ FlexibleFacetBodyFacetPrecisionOption() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyFacetPrecisionOption
(
self — )

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.KineoFlexibleFacetBodyPrecision) FlexibleFacetBodyFacetPrecisionOption Returns the fineness of the facets and the smoothness of a circular cross section in a flexible body. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

Returns
PreferencesBuilder.KineoFlexibleFacetBodyPrecision 

## ◆ FlexibleFacetBodyFacetPrecisionOption() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyFacetPrecisionOption
(
self,

precision )

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.KineoFlexibleFacetBodyPrecision) FlexibleFacetBodyFacetPrecisionOption. 

Sets the fineness of the facets and the smoothness of a circular cross section in a flexible body.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

## ◆ FlexibleFacetBodyLinearPrecision() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyLinearPrecision
(
self — )

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.KineoFlexibleFacetBodyPrecision) FlexibleFacetBodyLinearPrecision Returns the flexible facet body linear precision. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

Deprecated
Deprecated in NX2312.0.0. This functionality is no longer supported. 

Returns
PreferencesBuilder.KineoFlexibleFacetBodyPrecision 

## ◆ FlexibleFacetBodyLinearPrecision() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyLinearPrecision
(
self,

precision )

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.KineoFlexibleFacetBodyPrecision) FlexibleFacetBodyLinearPrecision. 

Sets the flexible facet body linear precision.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

Deprecated
Deprecated in NX2312.0.0. This functionality is no longer supported. 

## ◆ FlexibleFacetBodyPrecision()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyPrecision
(
self — )

Getter for property: (NXOpen.Expression) FlexibleFacetBodyPrecision Returns the flexible facet body precision. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Deprecated
Deprecated in NX2312.0.0. This functionality is no longer supported. 

Returns
NXOpen.Expression 

## ◆ FlexibleFacetBodySameWithEngineTuningPrecision() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodySameWithEngineTuningPrecision
(
self — )

Getter for property: (bool) FlexibleFacetBodySameWithEngineTuningPrecision Returns the option determines whether facet bodies should use the same precision as engine tuning. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Deprecated
Deprecated in NX2312.0.0. This functionality is no longer supported. 

Returns
bool 

## ◆ FlexibleFacetBodySameWithEngineTuningPrecision() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodySameWithEngineTuningPrecision
(
self,

flexibleFacetBodySameWithEngineTuningPrecision )

Setter for property: (bool) FlexibleFacetBodySameWithEngineTuningPrecision. 

Sets the option determines whether facet bodies should use the same precision as engine tuning.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Deprecated
Deprecated in NX2312.0.0. This functionality is no longer supported. 

## ◆ FlexibleFacetBodyUserDefinedAngularPrecision()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyUserDefinedAngularPrecision
(
self — )

Getter for property: (NXOpen.Expression) FlexibleFacetBodyUserDefinedAngularPrecision Returns the flexible facet body user defined angular precision. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

Returns
NXOpen.Expression 

## ◆ FlexibleFacetBodyUserDefinedLinearPrecision()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyUserDefinedLinearPrecision
(
self — )

Getter for property: (NXOpen.Expression) FlexibleFacetBodyUserDefinedLinearPrecision Returns the flexible facet body user defined linear precision. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

Returns
NXOpen.Expression 

## ◆ FlexibleFacetBodyUserDefinedLinearPrecisionByPercentage() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyUserDefinedLinearPrecisionByPercentage
(
self — )

Getter for property: (float) FlexibleFacetBodyUserDefinedLinearPrecisionByPercentage Returns the user defined linear precision percentage of a kineo facet body. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

Returns
float 

## ◆ FlexibleFacetBodyUserDefinedLinearPrecisionByPercentage() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyUserDefinedLinearPrecisionByPercentage
(
self,

precision )

Setter for property: (float) FlexibleFacetBodyUserDefinedLinearPrecisionByPercentage. 

Sets the user defined linear precision percentage of a kineo facet body.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

## ◆ FlexibleFacetBodyUserUsingDefinedLinearPrecisionInputType() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyUserUsingDefinedLinearPrecisionInputType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyUserDefinedLinearPrecisionInputTypes) FlexibleFacetBodyUserUsingDefinedLinearPrecisionInputType Returns the option determines whether to use a length value instead of a percentage. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

Returns
PreferencesBuilder.FlexibleFacetBodyUserDefinedLinearPrecisionInputTypes 

## ◆ FlexibleFacetBodyUserUsingDefinedLinearPrecisionInputType() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyUserUsingDefinedLinearPrecisionInputType
(
self,

inputType )

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyUserDefinedLinearPrecisionInputTypes) FlexibleFacetBodyUserUsingDefinedLinearPrecisionInputType. 

Sets the option determines whether to use a length value instead of a percentage.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

## ◆ FlexibleFacetPrecision()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetPrecision
(
self — )

Getter for property: (NXOpen.Expression) FlexibleFacetPrecision Returns the flexible facet precision expression which specifies the fineness of the facets in a flexible body. 

A larger value means larger facets and relatively better simulation performance.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.Expression 

## ◆ FlexibleMaterialAnchorHardness()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialAnchorHardness
(
self — )

Getter for property: (NXOpen.Expression) FlexibleMaterialAnchorHardness Returns the flexible material anchor hardness expression which specifies how strongly a flexible body is expected to stick to another object, e. 

g. a roller.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.Expression 

## ◆ FlexibleMaterialDamping()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialDamping
(
self — )

Getter for property: (NXOpen.Expression) FlexibleMaterialDamping Returns the flexible material damping expression which specifies the coefficient of damping forces acting on flexible bodies to reduce their oscillation over time. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.Expression 

## ◆ FlexibleMaterialDensity()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialDensity
(
self — )

Getter for property: (NXOpen.Expression) FlexibleMaterialDensity Returns the flexible material density expression which specifies the density of a flexible body. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.Expression 

## ◆ FlexibleMaterialDynamicFriction()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialDynamicFriction
(
self — )

Getter for property: (NXOpen.Expression) FlexibleMaterialDynamicFriction Returns the flexible material dynamic friction expression which specifies the coefficient of the dynamic friction acting on a flexible body against a surface. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.Expression 

## ◆ FlexibleMaterialEnableMaxContactForce() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialEnableMaxContactForce
(
self — )

Getter for property: (bool) FlexibleMaterialEnableMaxContactForce Returns the option determines whether to set the maximum contact force. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
bool 

## ◆ FlexibleMaterialEnableMaxContactForce() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialEnableMaxContactForce
(
self,

flexibleMaterialEnableMaxContactForce )

Setter for property: (bool) FlexibleMaterialEnableMaxContactForce. 

Sets the option determines whether to set the maximum contact force.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ FlexibleMaterialEnableMaxTwist() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialEnableMaxTwist
(
self — )

Getter for property: (bool) FlexibleMaterialEnableMaxTwist Returns the option determines whether to set the maximum twist. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
bool 

## ◆ FlexibleMaterialEnableMaxTwist() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialEnableMaxTwist
(
self,

flexibleMaterialEnableMaxTwist )

Setter for property: (bool) FlexibleMaterialEnableMaxTwist. 

Sets the option determines whether to set the maximum twist.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ FlexibleMaterialEnableMinCurvature() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialEnableMinCurvature
(
self — )

Getter for property: (bool) FlexibleMaterialEnableMinCurvature Returns the option determines whether to set the minimum curvature. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
bool 

## ◆ FlexibleMaterialEnableMinCurvature() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialEnableMinCurvature
(
self,

flexibleMaterialEnableMinCurvature )

Setter for property: (bool) FlexibleMaterialEnableMinCurvature. 

Sets the option determines whether to set the minimum curvature.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ FlexibleMaterialFulcrumLength()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialFulcrumLength
(
self — )

Getter for property: (NXOpen.Expression) FlexibleMaterialFulcrumLength Returns the flexible material fulcrum length. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ FlexibleMaterialLinearStiffness()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialLinearStiffness
(
self — )

Getter for property: (NXOpen.Expression) FlexibleMaterialLinearStiffness Returns the flexible material linear stiffness expression which specifies the coefficient of conservation of distance between adjacent particles. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.Expression 

## ◆ FlexibleMaterialMaxContactForce()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialMaxContactForce
(
self — )

Getter for property: (NXOpen.Expression) FlexibleMaterialMaxContactForce Returns the flexible material maximum contact force. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ FlexibleMaterialMaxTension()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialMaxTension
(
self — )

Getter for property: (NXOpen.Expression) FlexibleMaterialMaxTension Returns the flexible material maximum tension. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ FlexibleMaterialMaxTwist()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialMaxTwist
(
self — )

Getter for property: (NXOpen.Expression) FlexibleMaterialMaxTwist Returns the flexible material maximum twist. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ FlexibleMaterialMinCurvature()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialMinCurvature
(
self — )

Getter for property: (NXOpen.Expression) FlexibleMaterialMinCurvature Returns the flexible material minimum curvature. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ FlexibleMaterialOscillation() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialOscillation
(
self — )

Getter for property: (float) FlexibleMaterialOscillation Returns the flexible material oscillation. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
float 

## ◆ FlexibleMaterialOscillation() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialOscillation
(
self,

flexibleMaterialOscillation )

Setter for property: (float) FlexibleMaterialOscillation. 

Sets the flexible material oscillation.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ FlexibleMaterialPrecision()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialPrecision
(
self — )

Getter for property: (NXOpen.Expression) FlexibleMaterialPrecision Returns the flexible material precision expression which specifies the fineness of the elements in a flexible body. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.Expression 

## ◆ FlexibleMaterialYoungModulus()

NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleMaterialYoungModulus
(
self — )

Getter for property: (NXOpen.Expression) FlexibleMaterialYoungModulus Returns the flexible material Young's modulus. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ FlowLineColor() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlowLineColor
(
self — )

Getter for property: (int) FlowLineColor Returns the flow line color. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

Returns
int 

## ◆ FlowLineColor() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlowLineColor
(
self,

flowlinecolor )

Setter for property: (int) FlowLineColor. 

Sets the flow line color.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

## ◆ FlowLineFont() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlowLineFont
(
self — )

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.FlowLineStyleTypes) FlowLineFont Returns the flow line font. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

Returns
PreferencesBuilder.FlowLineStyleTypes 

## ◆ FlowLineFont() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlowLineFont
(
self,

flowlinefont )

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.FlowLineStyleTypes) FlowLineFont. 

Sets the flow line font.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

## ◆ FlowLineWidth() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlowLineWidth
(
self — )

Getter for property: (int) FlowLineWidth Returns the flow line width. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

Returns
int 

## ◆ FlowLineWidth() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.FlowLineWidth
(
self,

flowlinewidth )

Setter for property: (int) FlowLineWidth. 

Sets the flow line width.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

## ◆ GraphPlotType() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.GraphPlotType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.GraphPlotTypes) GraphPlotType Returns the option specifies the graph plot type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

Returns
PreferencesBuilder.GraphPlotTypes 

## ◆ GraphPlotType() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.GraphPlotType
(
self,

plotType )

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.GraphPlotTypes) GraphPlotType. 

Sets the option specifies the graph plot type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

## ◆ GraphSampleTime()

NXOpen.AnimationDesigner.PreferencesBuilder.GraphSampleTime
(
self — )

Getter for property: (NXOpen.Expression) GraphSampleTime Returns the graph sample time expression. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1872.0.0 

Returns
NXOpen.Expression 

## ◆ GravityDirection() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.GravityDirection
(
self — )

Getter for property: (int) GravityDirection Returns the gravity direction. 

0 - Gx, 1 - Gy, 2 - Gz, 3 - None.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
int 

## ◆ GravityDirection() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.GravityDirection
(
self,

direction )

Setter for property: (int) GravityDirection. 

Sets the gravity direction. 0 - Gx, 1 - Gy, 2 - Gz, 3 - None.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ HideMeasureRuler() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.HideMeasureRuler
(
self — )

Getter for property: (bool) HideMeasureRuler Returns the hide measure ruler flag. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
bool 

## ◆ HideMeasureRuler() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.HideMeasureRuler
(
self,

hide )

Setter for property: (bool) HideMeasureRuler. 

Sets the hide measure ruler flag.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ ImpulseSplitWithCollisionBody()

NXOpen.AnimationDesigner.PreferencesBuilder.ImpulseSplitWithCollisionBody
(
self — )

Getter for property: (NXOpen.Expression) ImpulseSplitWithCollisionBody Returns the flexible material impulse split when contact with collision body expression which specifies how to proportion the impulse generated by a collision between a flexible body and collision body. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.Expression 

## ◆ ImpulseSplitWithFlexibleBody()

NXOpen.AnimationDesigner.PreferencesBuilder.ImpulseSplitWithFlexibleBody
(
self — )

Getter for property: (NXOpen.Expression) ImpulseSplitWithFlexibleBody Returns the flexible material impulse split when contact with flexible body expression which specifies how to proportion the impulse generated by a collision between flexible bodies. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.Expression 

## ◆ KineoAngularTolerance()

NXOpen.AnimationDesigner.PreferencesBuilder.KineoAngularTolerance
(
self — )

Getter for property: (NXOpen.Expression) KineoAngularTolerance Returns the kineo angular tolerance. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2406.0.0 

Returns
NXOpen.Expression 

## ◆ KineoLinearTolerance()

NXOpen.AnimationDesigner.PreferencesBuilder.KineoLinearTolerance
(
self — )

Getter for property: (NXOpen.Expression) KineoLinearTolerance Returns the kineo linear tolerance. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2406.0.0 

Returns
NXOpen.Expression 

## ◆ MaxIteration()

NXOpen.AnimationDesigner.PreferencesBuilder.MaxIteration
(
self — )

Getter for property: (NXOpen.Expression) MaxIteration Returns the max iteration. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ NonRigidGroupColor() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.NonRigidGroupColor
(
self — )

Getter for property: (int) NonRigidGroupColor Returns the color for non rigid group body. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
int 

## ◆ NonRigidGroupColor() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.NonRigidGroupColor
(
self,

color )

Setter for property: (int) NonRigidGroupColor. 

Sets the color for non rigid group body.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ OnlySimulateActiveDisplayPart() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.OnlySimulateActiveDisplayPart
(
self — )

Getter for property: (bool) OnlySimulateActiveDisplayPart Returns the only simulate active display part flag. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
bool 

## ◆ OnlySimulateActiveDisplayPart() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.OnlySimulateActiveDisplayPart
(
self,

bOnly )

Setter for property: (bool) OnlySimulateActiveDisplayPart. 

Sets the only simulate active display part flag.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ OptimizeRigidGroupProperty() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.OptimizeRigidGroupProperty
(
self — )

Getter for property: (bool) OptimizeRigidGroupProperty Returns the option indicates whether the optimized properties of rigid group are being used. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
bool 

## ◆ OptimizeRigidGroupProperty() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.OptimizeRigidGroupProperty
(
self,

optimizeRigidProp )

Setter for property: (bool) OptimizeRigidGroupProperty. 

Sets the option indicates whether the optimized properties of rigid group are being used.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

## ◆ PhysicsEngine() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.PhysicsEngine
(
self — )

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.PhysicsEngines) PhysicsEngine Returns the physics engine. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

Returns
PreferencesBuilder.PhysicsEngines 

## ◆ PhysicsEngine() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.PhysicsEngine
(
self,

engine )

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.PhysicsEngines) PhysicsEngine. 

Sets the physics engine.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

## ◆ PrecisionPresetMode() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.PrecisionPresetMode
(
self — )

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.PrecisionPresetModes) PrecisionPresetMode Returns the simulation preset mode. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
PreferencesBuilder.PrecisionPresetModes 

## ◆ PrecisionPresetMode() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.PrecisionPresetMode
(
self,

presetMode )

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.PrecisionPresetModes) PrecisionPresetMode. 

Sets the simulation preset mode

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ RandomizeSolvingOrder() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.RandomizeSolvingOrder
(
self — )

Getter for property: (bool) RandomizeSolvingOrder Returns the option indicates whether to randomize the solving order by the engine. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1926.0.0 

Returns
bool 

## ◆ RandomizeSolvingOrder() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.RandomizeSolvingOrder
(
self,

randomOrder )

Setter for property: (bool) RandomizeSolvingOrder. 

Sets the option indicates whether to randomize the solving order by the engine.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1926.0.0 

## ◆ RichGeomType() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.RichGeomType
(
self — )

Getter for property: (bool) RichGeomType Returns the rich geometry type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1980.0.0 

Returns
bool 

## ◆ RichGeomType() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.RichGeomType
(
self,

richGeomType )

Setter for property: (bool) RichGeomType. 

Sets the rich geometry type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1980.0.0 

## ◆ RigidGroupSelectionDisplay() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.RigidGroupSelectionDisplay
(
self — )

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.RigidGroupSelectionDisplayTypes) RigidGroupSelectionDisplay Returns the option specifies the selection display for rigid groups. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1980.0.0 

Returns
PreferencesBuilder.RigidGroupSelectionDisplayTypes 

## ◆ RigidGroupSelectionDisplay() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.RigidGroupSelectionDisplay
(
self,

displayType )

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.RigidGroupSelectionDisplayTypes) RigidGroupSelectionDisplay. 

Sets the option specifies the selection display for rigid groups.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1980.0.0 

## ◆ SameWithFlexibleMaterialPrecision() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.SameWithFlexibleMaterialPrecision
(
self — )

Getter for property: (bool) SameWithFlexibleMaterialPrecision Returns the option determines whether facet bodies should use the same precision as engine tuning. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
bool 

## ◆ SameWithFlexibleMaterialPrecision() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.SameWithFlexibleMaterialPrecision
(
self,

sameWithFlexibleMaterialPrecision )

Setter for property: (bool) SameWithFlexibleMaterialPrecision. 

Sets the option determines whether facet bodies should use the same precision as engine tuning.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

## ◆ ShowFlowLine() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.ShowFlowLine
(
self — )

Getter for property: (bool) ShowFlowLine Returns the option for enable draw flow line. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

Returns
bool 

## ◆ ShowFlowLine() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.ShowFlowLine
(
self,

showflowline )

Setter for property: (bool) ShowFlowLine. 

Sets the option for enable draw flow line.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

## ◆ SolutionSearchScope() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.SolutionSearchScope
(
self — )

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.SolutionSearchScopeTypes) SolutionSearchScope Returns the option specifies the search scope for the Animation Designer definition. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1980.0.0 

Returns
PreferencesBuilder.SolutionSearchScopeTypes 

## ◆ SolutionSearchScope() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.SolutionSearchScope
(
self,

scopeType )

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.SolutionSearchScopeTypes) SolutionSearchScope. 

Sets the option specifies the search scope for the Animation Designer definition.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1980.0.0 

## ◆ StepIncrementTime()

NXOpen.AnimationDesigner.PreferencesBuilder.StepIncrementTime
(
self — )

Getter for property: (NXOpen.Expression) StepIncrementTime Returns the step time expression. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ StepTime()

NXOpen.AnimationDesigner.PreferencesBuilder.StepTime
(
self — )

Getter for property: (NXOpen.Expression) StepTime Returns the step time. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ TimeScaleFactor() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.TimeScaleFactor
(
self — )

Getter for property: (float) TimeScaleFactor Returns the time scale factor. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
float 

## ◆ TimeScaleFactor() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.TimeScaleFactor
(
self,

scaleFactor )

Setter for property: (float) TimeScaleFactor. 

Sets the time scale factor

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ Tolerance()

NXOpen.AnimationDesigner.PreferencesBuilder.Tolerance
(
self — )

Getter for property: (NXOpen.Expression) Tolerance Returns the tolerance. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ UseFacetToMeasure() [1/2]

NXOpen.AnimationDesigner.PreferencesBuilder.UseFacetToMeasure
(
self — )

Getter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.BodyToUseForMeasureTypes) UseFacetToMeasure Returns the option indicates whether to use facet body instead of solid body to measure distance or angle in order to improve performance. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1980.0.0 

Returns
PreferencesBuilder.BodyToUseForMeasureTypes 

## ◆ UseFacetToMeasure() [2/2]

NXOpen.AnimationDesigner.PreferencesBuilder.UseFacetToMeasure
(
self,

bodyType )

Setter for property: (NXOpen.AnimationDesigner.PreferencesBuilder.BodyToUseForMeasureTypes) UseFacetToMeasure. 

Sets the option indicates whether to use facet body instead of solid body to measure distance or angle in order to improve performance.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1980.0.0 

## Member Data Documentation

## ◆ PreferencesBuilderArrangementTypes

NXOpen.AnimationDesigner.PreferencesBuilder.PreferencesBuilderArrangementTypes = PreferencesBuilder.ArrangementTypes

NXOpen.AnimationDesigner.PreferencesBuilderArrangementTypes is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.ArrangementTypes 

## ◆ PreferencesBuilderBodyToUseForMeasureTypes

NXOpen.AnimationDesigner.PreferencesBuilder.PreferencesBuilderBodyToUseForMeasureTypes = PreferencesBuilder.BodyToUseForMeasureTypes

NXOpen.AnimationDesigner.PreferencesBuilderBodyToUseForMeasureTypes is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.BodyToUseForMeasureTypes 

## ◆ PreferencesBuilderFlexibleFacetBodyUserDefinedLinearPrecisionInputTypes

NXOpen.AnimationDesigner.PreferencesBuilder.PreferencesBuilderFlexibleFacetBodyUserDefinedLinearPrecisionInputTypes = PreferencesBuilder.FlexibleFacetBodyUserDefinedLinearPrecisionInputTypes

NXOpen.AnimationDesigner.PreferencesBuilderFlexibleFacetBodyUserDefinedLinearPrecisionInputTypes is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.FlexibleFacetBodyUserDefinedLinearPrecisionInputTypes 

## ◆ PreferencesBuilderFlowLineStyleTypes

NXOpen.AnimationDesigner.PreferencesBuilder.PreferencesBuilderFlowLineStyleTypes = PreferencesBuilder.FlowLineStyleTypes

NXOpen.AnimationDesigner.PreferencesBuilderFlowLineStyleTypes is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.FlowLineStyleTypes 

## ◆ PreferencesBuilderGraphPlotTypes

NXOpen.AnimationDesigner.PreferencesBuilder.PreferencesBuilderGraphPlotTypes = PreferencesBuilder.GraphPlotTypes

NXOpen.AnimationDesigner.PreferencesBuilderGraphPlotTypes is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.GraphPlotTypes 

## ◆ PreferencesBuilderKineoFlexibleFacetBodyPrecision

NXOpen.AnimationDesigner.PreferencesBuilder.PreferencesBuilderKineoFlexibleFacetBodyPrecision = PreferencesBuilder.KineoFlexibleFacetBodyPrecision

NXOpen.AnimationDesigner.PreferencesBuilderKineoFlexibleFacetBodyPrecision is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.KineoFlexibleFacetBodyPrecision 

## ◆ PreferencesBuilderPhysicsEngines

NXOpen.AnimationDesigner.PreferencesBuilder.PreferencesBuilderPhysicsEngines = PreferencesBuilder.PhysicsEngines

NXOpen.AnimationDesigner.PreferencesBuilderPhysicsEngines is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.PhysicsEngines 

## ◆ PreferencesBuilderPrecisionPresetModes

NXOpen.AnimationDesigner.PreferencesBuilder.PreferencesBuilderPrecisionPresetModes = PreferencesBuilder.PrecisionPresetModes

NXOpen.AnimationDesigner.PreferencesBuilderPrecisionPresetModes is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.PrecisionPresetModes 

## ◆ PreferencesBuilderRigidGroupSelectionDisplayTypes

NXOpen.AnimationDesigner.PreferencesBuilder.PreferencesBuilderRigidGroupSelectionDisplayTypes = PreferencesBuilder.RigidGroupSelectionDisplayTypes

NXOpen.AnimationDesigner.PreferencesBuilderRigidGroupSelectionDisplayTypes is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.RigidGroupSelectionDisplayTypes 

## ◆ PreferencesBuilderSolutionSearchScopeTypes

NXOpen.AnimationDesigner.PreferencesBuilder.PreferencesBuilderSolutionSearchScopeTypes = PreferencesBuilder.SolutionSearchScopeTypes

NXOpen.AnimationDesigner.PreferencesBuilderSolutionSearchScopeTypes is an alias for NXOpen.AnimationDesigner.PreferencesBuilder.SolutionSearchScopeTypes 

Copyright 2025 Siemens
