# NXOpen.AnimationDesigner.RackPinionBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10917.html>

Represents a NXOpen::AnimationDesigner::RackPinionBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.RackPinionBuilder:

## Public Member Functions

ContactPoint (self)

Getter for property: (NXOpen.Point) ContactPoint Returns the contact point. 

ContactPoint (self, contactPoint)

Setter for property: (NXOpen.Point) ContactPoint. 

Radius (self)

Getter for property: (NXOpen.Expression) Radius Returns the radius expression. 

Public Member Functions inherited from NXOpen.AnimationDesigner.CouplerBuilder

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

ColorOption (self)

Getter for property: (NXOpen.AnimationDesigner.CouplerBuilder.ColorOptions) ColorOption Returns the color options. 

ColorOption (self, colorOption)

Setter for property: (NXOpen.AnimationDesigner.CouplerBuilder.ColorOptions) ColorOption. 

MasterAxisJoint (self)

Getter for property: (NXOpen.SelectNXObject) MasterAxisJoint Returns the master axis joint. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

SlaveAxisJoint (self)

Getter for property: (NXOpen.SelectNXObject) SlaveAxisJoint Returns the slave axis joint. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.AnimationDesigner.CouplerBuilder

CouplerBuilderColorOptions = CouplerBuilder.ColorOptions

NXOpen.AnimationDesigner.CouplerBuilderColorOptions is an alias for NXOpen.AnimationDesigner.CouplerBuilder.ColorOptions 

## Detailed Description

Represents a NXOpen::AnimationDesigner::RackPinionBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::RackPinionCollection::CreateRackPinionBuilder 

Created in NX12.0.0 

## Member Function Documentation

## ◆ ContactPoint() [1/2]

NXOpen.AnimationDesigner.RackPinionBuilder.ContactPoint
(
self — )

Getter for property: (NXOpen.Point) ContactPoint Returns the contact point. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Point 

## ◆ ContactPoint() [2/2]

NXOpen.AnimationDesigner.RackPinionBuilder.ContactPoint
(
self,

contactPoint )

Setter for property: (NXOpen.Point) ContactPoint. 

Sets the contact point.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ Radius()

NXOpen.AnimationDesigner.RackPinionBuilder.Radius
(
self — )

Getter for property: (NXOpen.Expression) Radius Returns the radius expression. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

Copyright 2025 Siemens
