# NXOpen.AnimationDesigner.PathConstraintJointBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00118.html>

## Classes

class — PathTypes

the path types 

Enumerator — Comment

FromCoordinateSystems — from coordinate systems

FromCurves — from curves

More...

Copyright 2025 Siemens
