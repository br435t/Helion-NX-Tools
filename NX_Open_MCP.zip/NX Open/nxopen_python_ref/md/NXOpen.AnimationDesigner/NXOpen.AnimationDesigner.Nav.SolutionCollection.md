# NXOpen.AnimationDesigner.Nav.SolutionCollection Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11041.html>

Represents a NXOpen::AnimationDesigner::Nav::SolutionCollection . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.Nav.SolutionCollection:

## Public Member Functions

FindObject (part, name)

Finds the NXOpen::AnimationDesigner::Nav::Solution object with the given name. 

## Detailed Description

Represents a NXOpen::AnimationDesigner::Nav::SolutionCollection . 

To obtain an instance of this class, refer to NXOpen::AnimationDesigner::AnimationDesignerManager 

Created in NX12.0.0 

## Member Function Documentation

## ◆ FindObject()

NXOpen.AnimationDesigner.Nav.SolutionCollection.FindObject
(
part,

name )

Finds the NXOpen::AnimationDesigner::Nav::Solution object with the given name. 

Returns
study (NXOpen.AnimationDesigner.Nav.Solution): NXOpen::AnimationDesigner::Nav::Solution object with this name. .

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer") 
Parameters

part — (NXOpen.Part)

name — (str) The name of the NXOpen::AnimationDesigner::Nav::Solution .

Copyright 2025 Siemens
