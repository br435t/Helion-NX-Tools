# NXOpen.AnimationDesigner.ActivityOperatorBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10373.html>

Represents a NXOpen::AnimationDesigner::ActivityOperatorBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.ActivityOperatorBuilder:

## Public Member Functions

ActionObject (self)

Getter for property: (NXOpen.SelectNXObject) ActionObject Returns the base list for a Joint. 

CreateBar (self, index)

Creates a new bar. 

DeleteBars (self, bars)

Deletes the bars. 

GetTime (self, index)

Gets the bar start time. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

SetBarActionType (self, index, actionType)

Sets the bar action type. 

SetBarName (self, index, name)

Sets the bar name. 

SetTime (self, index, start_time)

Sets the bar start time. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

ActivityOperatorBuilderActionTypes = ActivityOperatorBuilder.ActionTypes

NXOpen.AnimationDesigner.ActivityOperatorBuilderActionTypes is an alias for NXOpen.AnimationDesigner.ActivityOperatorBuilder.ActionTypes 

## Detailed Description

Represents a NXOpen::AnimationDesigner::ActivityOperatorBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::ActivityOperatorCollection::CreateActivityOperatorBuilder 

Created in NX2406.0.0 

## Member Function Documentation

## ◆ ActionObject()

NXOpen.AnimationDesigner.ActivityOperatorBuilder.ActionObject
(
self — )

Getter for property: (NXOpen.SelectNXObject) ActionObject Returns the base list for a Joint. 

The list can consist of NXOpen::AnimationDesigner::RevoluteJoint objects or other objects which can active and deactive.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2406.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ CreateBar()

NXOpen.AnimationDesigner.ActivityOperatorBuilder.CreateBar
(
self,

index )

Creates a new bar. 

Created in NX2406.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

## ◆ DeleteBars()

NXOpen.AnimationDesigner.ActivityOperatorBuilder.DeleteBars
(
self,

bars )

Deletes the bars. 

Created in NX2406.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

bars — (List[int])

## ◆ GetTime()

NXOpen.AnimationDesigner.ActivityOperatorBuilder.GetTime
(
self,

index )

Gets the bar start time. 

Returns
start_time (float): .

Created in NX2406.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

## ◆ Name() [1/2]

NXOpen.AnimationDesigner.ActivityOperatorBuilder.Name
(
self — )

Getter for property: (str) Name Returns the name. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2406.0.0 

Returns
str 

## ◆ Name() [2/2]

NXOpen.AnimationDesigner.ActivityOperatorBuilder.Name
(
self,

name )

Setter for property: (str) Name. 

Sets the name.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2406.0.0 

## ◆ SetBarActionType()

NXOpen.AnimationDesigner.ActivityOperatorBuilder.SetBarActionType
(
self,

index,

actionType )

Sets the bar action type. 

Created in NX2406.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

actionType — (NXOpen.AnimationDesigner.ActivityOperatorBuilder.ActionTypes)

## ◆ SetBarName()

NXOpen.AnimationDesigner.ActivityOperatorBuilder.SetBarName
(
self,

index,

name )

Sets the bar name. 

Created in NX2406.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

name — (str)

## ◆ SetTime()

NXOpen.AnimationDesigner.ActivityOperatorBuilder.SetTime
(
self,

index,

start_time )

Sets the bar start time. 

Created in NX2406.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

start_time — (float)

## Member Data Documentation

## ◆ ActivityOperatorBuilderActionTypes

NXOpen.AnimationDesigner.ActivityOperatorBuilder.ActivityOperatorBuilderActionTypes = ActivityOperatorBuilder.ActionTypes

NXOpen.AnimationDesigner.ActivityOperatorBuilderActionTypes is an alias for NXOpen.AnimationDesigner.ActivityOperatorBuilder.ActionTypes 

Copyright 2025 Siemens
