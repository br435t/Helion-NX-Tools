# NXOpen.AnimationDesigner.PositionMotorBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00121.html>

## Classes

class — AutoCalculate

the auto calculate types. More...

class — Axis

the axis types. More...

class — ColorOptions

the color options. More...

Copyright 2025 Siemens
