# NXOpen.AnimationDesigner.FlexibleMaterialBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10657.html>

Represents a NXOpen::AnimationDesigner::FlexibleMaterialBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.FlexibleMaterialBuilder:

## Public Member Functions

Density (self)

Getter for property: (NXOpen.Expression) Density Returns. 

EnableMaxContactForce (self)

Getter for property: (bool) EnableMaxContactForce Returns. 

EnableMaxContactForce (self, enableMaxContactForce)

Setter for property: (bool) EnableMaxContactForce. 

EnableMaxTwist (self)

Getter for property: (bool) EnableMaxTwist Returns. 

EnableMaxTwist (self, enableMaxTwist)

Setter for property: (bool) EnableMaxTwist. 

EnableMinCurvature (self)

Getter for property: (bool) EnableMinCurvature Returns. 

EnableMinCurvature (self, enableMinCurvature)

Setter for property: (bool) EnableMinCurvature. 

FulcrumLength (self)

Getter for property: (NXOpen.Expression) FulcrumLength Returns. 

MaxContactForce (self)

Getter for property: (NXOpen.Expression) MaxContactForce Returns. 

MaxTension (self)

Getter for property: (NXOpen.Expression) MaxTension Returns. 

MaxTwist (self)

Getter for property: (NXOpen.Expression) MaxTwist Returns. 

MinCurvature (self)

Getter for property: (NXOpen.Expression) MinCurvature Returns. 

Name (self)

Getter for property: (str) Name Returns. 

Name (self, name)

Setter for property: (str) Name. 

Oscillation (self)

Getter for property: (float) Oscillation Returns. 

Oscillation (self, oscillation)

Setter for property: (float) Oscillation. 

YoungModulus (self)

Getter for property: (NXOpen.Expression) YoungModulus Returns. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::AnimationDesigner::FlexibleMaterialBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::FlexibleMaterialCollection::CreateFlexibleMaterialBuilder 

Created in NX2306.0.0 

## Member Function Documentation

## ◆ Density()

NXOpen.AnimationDesigner.FlexibleMaterialBuilder.Density
(
self — )

Getter for property: (NXOpen.Expression) Density Returns. 

the density.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ EnableMaxContactForce() [1/2]

NXOpen.AnimationDesigner.FlexibleMaterialBuilder.EnableMaxContactForce
(
self — )

Getter for property: (bool) EnableMaxContactForce Returns. 

the option determines whether to set the maximum contact force.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
bool 

## ◆ EnableMaxContactForce() [2/2]

NXOpen.AnimationDesigner.FlexibleMaterialBuilder.EnableMaxContactForce
(
self,

enableMaxContactForce )

Setter for property: (bool) EnableMaxContactForce. 

Sets the option determines whether to set the maximum contact force.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ EnableMaxTwist() [1/2]

NXOpen.AnimationDesigner.FlexibleMaterialBuilder.EnableMaxTwist
(
self — )

Getter for property: (bool) EnableMaxTwist Returns. 

the option determines whether to set the maximum twist.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
bool 

## ◆ EnableMaxTwist() [2/2]

NXOpen.AnimationDesigner.FlexibleMaterialBuilder.EnableMaxTwist
(
self,

enableMaxTwist )

Setter for property: (bool) EnableMaxTwist. 

Sets the option determines whether to set the maximum twist.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ EnableMinCurvature() [1/2]

NXOpen.AnimationDesigner.FlexibleMaterialBuilder.EnableMinCurvature
(
self — )

Getter for property: (bool) EnableMinCurvature Returns. 

the option determines whether to set the minimum curvature.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
bool 

## ◆ EnableMinCurvature() [2/2]

NXOpen.AnimationDesigner.FlexibleMaterialBuilder.EnableMinCurvature
(
self,

enableMinCurvature )

Setter for property: (bool) EnableMinCurvature. 

Sets the option determines whether to set the minimum curvature.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ FulcrumLength()

NXOpen.AnimationDesigner.FlexibleMaterialBuilder.FulcrumLength
(
self — )

Getter for property: (NXOpen.Expression) FulcrumLength Returns. 

the fulcrum length.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ MaxContactForce()

NXOpen.AnimationDesigner.FlexibleMaterialBuilder.MaxContactForce
(
self — )

Getter for property: (NXOpen.Expression) MaxContactForce Returns. 

the maximum contact force.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ MaxTension()

NXOpen.AnimationDesigner.FlexibleMaterialBuilder.MaxTension
(
self — )

Getter for property: (NXOpen.Expression) MaxTension Returns. 

the maximum tension.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ MaxTwist()

NXOpen.AnimationDesigner.FlexibleMaterialBuilder.MaxTwist
(
self — )

Getter for property: (NXOpen.Expression) MaxTwist Returns. 

the maximum twist.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ MinCurvature()

NXOpen.AnimationDesigner.FlexibleMaterialBuilder.MinCurvature
(
self — )

Getter for property: (NXOpen.Expression) MinCurvature Returns. 

the minimum curvature.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ Name() [1/2]

NXOpen.AnimationDesigner.FlexibleMaterialBuilder.Name
(
self — )

Getter for property: (str) Name Returns. 

the name.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
str 

## ◆ Name() [2/2]

NXOpen.AnimationDesigner.FlexibleMaterialBuilder.Name
(
self,

name )

Setter for property: (str) Name. 

Sets the name.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ Oscillation() [1/2]

NXOpen.AnimationDesigner.FlexibleMaterialBuilder.Oscillation
(
self — )

Getter for property: (float) Oscillation Returns. 

the oscillation.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
float 

## ◆ Oscillation() [2/2]

NXOpen.AnimationDesigner.FlexibleMaterialBuilder.Oscillation
(
self,

oscillation )

Setter for property: (float) Oscillation. 

Sets the oscillation.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ YoungModulus()

NXOpen.AnimationDesigner.FlexibleMaterialBuilder.YoungModulus
(
self — )

Getter for property: (NXOpen.Expression) YoungModulus Returns. 

the Young's modulus.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

Copyright 2025 Siemens
