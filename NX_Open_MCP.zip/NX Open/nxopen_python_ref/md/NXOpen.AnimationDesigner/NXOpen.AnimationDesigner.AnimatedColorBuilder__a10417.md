# NXOpen.AnimationDesigner.AnimatedColorBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10417.html>

Represents a NXOpen::AnimationDesigner::AnimatedColorBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.AnimatedColorBuilder:

## Public Member Functions

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

CreateBar (self, index)

Creates a new bar. 

CreationType (self)

Getter for property: (NXOpen.AnimationDesigner.AnimatedColorBuilder.CreationTypes) CreationType Returns the creation type. 

CreationType (self, creationType)

Setter for property: (NXOpen.AnimationDesigner.AnimatedColorBuilder.CreationTypes) CreationType. 

DeleteBars (self, bars)

Deletes the bars. 

EnableRepeatTime (self)

Getter for property: (bool) EnableRepeatTime Returns the option determines whether to set the repeat time. 

EnableRepeatTime (self, enableRepeatTime)

Setter for property: (bool) EnableRepeatTime. 

MirrorBars (self, bars, mirror_time)

Mirrors the bars. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

RepeatTime (self)

Getter for property: (int) RepeatTime Returns the repeat time. 

RepeatTime (self, repeatTime)

Setter for property: (int) RepeatTime. 

SelectObject (self)

Getter for property: (NXOpen.SelectNXObjectList) SelectObject Returns the select object. 

SetBarEndColor (self, index, color)

Sets the bar end color. 

SetBarEndTime (self, index, end_time)

Sets the bar end time. 

SetBarName (self, index, name)

Sets the bar name. 

SetBarStartColor (self, index, color)

Sets the bar start . 

SetBarStartTime (self, index, start_time)

Sets the bar start time. 

SplitBar (self, index, split_time)

Splits the bar with the split time. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

AnimatedColorBuilderCreationTypes = AnimatedColorBuilder.CreationTypes

NXOpen.AnimationDesigner.AnimatedColorBuilderCreationTypes is an alias for NXOpen.AnimationDesigner.AnimatedColorBuilder.CreationTypes 

## Detailed Description

Represents a NXOpen::AnimationDesigner::AnimatedColorBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::AnimatedColorCollection::CreateAnimatedColorBuilder 

Default values. 

Property — Value

CreationType 

CreateaSingleAnimatedColorEffect 

Created in NX1953.0.0 

## Member Function Documentation

## ◆ Color() [1/2]

NXOpen.AnimationDesigner.AnimatedColorBuilder.Color
(
self — )

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1953.0.0 

Returns
NXOpen.NXColor 

## ◆ Color() [2/2]

NXOpen.AnimationDesigner.AnimatedColorBuilder.Color
(
self,

color )

Setter for property: (NXOpen.NXColor) Color. 

Sets the color.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1953.0.0 

## ◆ CreateBar()

NXOpen.AnimationDesigner.AnimatedColorBuilder.CreateBar
(
self,

index )

Creates a new bar. 

Created in NX1953.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

## ◆ CreationType() [1/2]

NXOpen.AnimationDesigner.AnimatedColorBuilder.CreationType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.AnimatedColorBuilder.CreationTypes) CreationType Returns the creation type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1953.0.0 

Returns
AnimatedColorBuilder.CreationTypes 

## ◆ CreationType() [2/2]

NXOpen.AnimationDesigner.AnimatedColorBuilder.CreationType
(
self,

creationType )

Setter for property: (NXOpen.AnimationDesigner.AnimatedColorBuilder.CreationTypes) CreationType. 

Sets the creation type

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1953.0.0 

## ◆ DeleteBars()

NXOpen.AnimationDesigner.AnimatedColorBuilder.DeleteBars
(
self,

bars )

Deletes the bars. 

Created in NX1953.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

bars — (List[int])

## ◆ EnableRepeatTime() [1/2]

NXOpen.AnimationDesigner.AnimatedColorBuilder.EnableRepeatTime
(
self — )

Getter for property: (bool) EnableRepeatTime Returns the option determines whether to set the repeat time. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

Returns
bool 

## ◆ EnableRepeatTime() [2/2]

NXOpen.AnimationDesigner.AnimatedColorBuilder.EnableRepeatTime
(
self,

enableRepeatTime )

Setter for property: (bool) EnableRepeatTime. 

Sets the option determines whether to set the repeat time.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

## ◆ MirrorBars()

NXOpen.AnimationDesigner.AnimatedColorBuilder.MirrorBars
(
self,

bars,

mirror_time )

Mirrors the bars. 

Created in NX1953.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

bars — (List[int])

mirror_time — (float)

## ◆ Name() [1/2]

NXOpen.AnimationDesigner.AnimatedColorBuilder.Name
(
self — )

Getter for property: (str) Name Returns the name. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1953.0.0 

Returns
str 

## ◆ Name() [2/2]

NXOpen.AnimationDesigner.AnimatedColorBuilder.Name
(
self,

name )

Setter for property: (str) Name. 

Sets the name.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1953.0.0 

## ◆ RepeatTime() [1/2]

NXOpen.AnimationDesigner.AnimatedColorBuilder.RepeatTime
(
self — )

Getter for property: (int) RepeatTime Returns the repeat time. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

Returns
int 

## ◆ RepeatTime() [2/2]

NXOpen.AnimationDesigner.AnimatedColorBuilder.RepeatTime
(
self,

repeatTime )

Setter for property: (int) RepeatTime. 

Sets the repeat time.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

## ◆ SelectObject()

NXOpen.AnimationDesigner.AnimatedColorBuilder.SelectObject
(
self — )

Getter for property: (NXOpen.SelectNXObjectList) SelectObject Returns the select object. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1953.0.0 

Returns
NXOpen.SelectNXObjectList 

## ◆ SetBarEndColor()

NXOpen.AnimationDesigner.AnimatedColorBuilder.SetBarEndColor
(
self,

index,

color )

Sets the bar end color. 

Created in NX1953.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

color — (NXOpen.NXColor)

## ◆ SetBarEndTime()

NXOpen.AnimationDesigner.AnimatedColorBuilder.SetBarEndTime
(
self,

index,

end_time )

Sets the bar end time. 

Created in NX1953.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

end_time — (float)

## ◆ SetBarName()

NXOpen.AnimationDesigner.AnimatedColorBuilder.SetBarName
(
self,

index,

name )

Sets the bar name. 

Created in NX1953.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

name — (str)

## ◆ SetBarStartColor()

NXOpen.AnimationDesigner.AnimatedColorBuilder.SetBarStartColor
(
self,

index,

color )

Sets the bar start . 

Created in NX1953.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

color — (NXOpen.NXColor)

## ◆ SetBarStartTime()

NXOpen.AnimationDesigner.AnimatedColorBuilder.SetBarStartTime
(
self,

index,

start_time )

Sets the bar start time. 

Created in NX1953.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

start_time — (float)

## ◆ SplitBar()

NXOpen.AnimationDesigner.AnimatedColorBuilder.SplitBar
(
self,

index,

split_time )

Splits the bar with the split time. 

Created in NX1953.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

split_time — (float)

## Member Data Documentation

## ◆ AnimatedColorBuilderCreationTypes

NXOpen.AnimationDesigner.AnimatedColorBuilder.AnimatedColorBuilderCreationTypes = AnimatedColorBuilder.CreationTypes

NXOpen.AnimationDesigner.AnimatedColorBuilderCreationTypes is an alias for NXOpen.AnimationDesigner.AnimatedColorBuilder.CreationTypes 

Copyright 2025 Siemens
