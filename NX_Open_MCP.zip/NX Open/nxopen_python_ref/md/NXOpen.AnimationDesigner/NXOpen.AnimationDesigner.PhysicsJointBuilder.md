# NXOpen.AnimationDesigner.PhysicsJointBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00119.html>

## Classes

class — ColorOptions

the color options. More...

class — MotionTypes

the motion types. More...

Copyright 2025 Siemens
