# NXOpen.AnimationDesigner.AnimatedVisibilityBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00105.html>

## Classes

class — ColorOptions

the color options. More...

class — CreationTypes

the creation types. More...

Copyright 2025 Siemens
