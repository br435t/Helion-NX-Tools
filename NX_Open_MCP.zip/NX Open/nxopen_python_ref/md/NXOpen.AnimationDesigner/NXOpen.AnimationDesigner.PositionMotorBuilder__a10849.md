# NXOpen.AnimationDesigner.PositionMotorBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10849.html>

Represents a NXOpen::AnimationDesigner::PositionMotorBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.PositionMotorBuilder:

## Public Member Functions

AxisType (self)

Getter for property: (NXOpen.AnimationDesigner.PositionMotorBuilder.Axis) AxisType Returns the axis type. 

AxisType (self, axisType)

Setter for property: (NXOpen.AnimationDesigner.PositionMotorBuilder.Axis) AxisType. 

BarCalculate (self, index)

Calculates the bar. 

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

ColorOption (self)

Getter for property: (NXOpen.AnimationDesigner.PositionMotorBuilder.ColorOptions) ColorOption Returns the color option. 

ColorOption (self, colorOption)

Setter for property: (NXOpen.AnimationDesigner.PositionMotorBuilder.ColorOptions) ColorOption. 

CreateBar (self, index)

Creates a new bar. 

DeleteBars (self, bars)

Deletes the bars. 

MirrorBars (self, bars, mirror_time)

Mirrors the bars. 

PasteBars (self, bars, shift_time, isCut)

Pastes the bars. 

SetBarAcceleration (self, index, acceleration)

Sets the bar acceleration. 

SetBarCalcType (self, index, calc_type)

Sets the bar calculation type. 

SetBarDeceleration (self, index, deceleration)

Sets the bar deceleration. 

SetBarEndTime (self, index, end_time)

Sets the bar end time. 

SetBarIncrement (self, index, increment)

Sets the bar increment. 

SetBarLimitAcceleration (self, index, limit_acceleration)

Sets the bar limit acceleration. 

SetBarName (self, index, name)

Sets the bar name. 

SetBarSpeed (self, index, speed)

Sets the bar speed. 

SetBarStartTime (self, index, start_time)

Sets the bar start time. 

SetBarTime (self, bars, deltaStart, deltaDuration)

Sets the bar time. 

SplitBar (self, index, split_time)

Splits the bars with the start time exp tag. 

UpdateDestination (self)

Updates the motor destination. 

Public Member Functions inherited from NXOpen.AnimationDesigner.MotorBuilder

AxisJoint (self)

Getter for property: (NXOpen.SelectNXObject) AxisJoint Returns the joint select. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

PositionMotorBuilderAutoCalculate = PositionMotorBuilder.AutoCalculate

NXOpen.AnimationDesigner.PositionMotorBuilderAutoCalculate is an alias for NXOpen.AnimationDesigner.PositionMotorBuilder.AutoCalculate 

PositionMotorBuilderAxis = PositionMotorBuilder.Axis

NXOpen.AnimationDesigner.PositionMotorBuilderAxis is an alias for NXOpen.AnimationDesigner.PositionMotorBuilder.Axis 

PositionMotorBuilderColorOptions = PositionMotorBuilder.ColorOptions

NXOpen.AnimationDesigner.PositionMotorBuilderColorOptions is an alias for NXOpen.AnimationDesigner.PositionMotorBuilder.ColorOptions 

## Detailed Description

Represents a NXOpen::AnimationDesigner::PositionMotorBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::PositionMotorCollection::CreatePositionMotorBuilder 

Created in NX12.0.0 

## Member Function Documentation

## ◆ AxisType() [1/2]

NXOpen.AnimationDesigner.PositionMotorBuilder.AxisType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.PositionMotorBuilder.Axis) AxisType Returns the axis type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
PositionMotorBuilder.Axis 

## ◆ AxisType() [2/2]

NXOpen.AnimationDesigner.PositionMotorBuilder.AxisType
(
self,

axisType )

Setter for property: (NXOpen.AnimationDesigner.PositionMotorBuilder.Axis) AxisType. 

Sets the axis type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ BarCalculate()

NXOpen.AnimationDesigner.PositionMotorBuilder.BarCalculate
(
self,

index )

Calculates the bar. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

## ◆ Color() [1/2]

NXOpen.AnimationDesigner.PositionMotorBuilder.Color
(
self — )

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
NXOpen.NXColor 

## ◆ Color() [2/2]

NXOpen.AnimationDesigner.PositionMotorBuilder.Color
(
self,

color )

Setter for property: (NXOpen.NXColor) Color. 

Sets the color.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

## ◆ ColorOption() [1/2]

NXOpen.AnimationDesigner.PositionMotorBuilder.ColorOption
(
self — )

Getter for property: (NXOpen.AnimationDesigner.PositionMotorBuilder.ColorOptions) ColorOption Returns the color option. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
PositionMotorBuilder.ColorOptions 

## ◆ ColorOption() [2/2]

NXOpen.AnimationDesigner.PositionMotorBuilder.ColorOption
(
self,

colorOption )

Setter for property: (NXOpen.AnimationDesigner.PositionMotorBuilder.ColorOptions) ColorOption. 

Sets the color option.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

## ◆ CreateBar()

NXOpen.AnimationDesigner.PositionMotorBuilder.CreateBar
(
self,

index )

Creates a new bar. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

## ◆ DeleteBars()

NXOpen.AnimationDesigner.PositionMotorBuilder.DeleteBars
(
self,

bars )

Deletes the bars. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

bars — (List[int])

## ◆ MirrorBars()

NXOpen.AnimationDesigner.PositionMotorBuilder.MirrorBars
(
self,

bars,

mirror_time )

Mirrors the bars. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

bars — (List[int])

mirror_time — (float)

## ◆ PasteBars()

NXOpen.AnimationDesigner.PositionMotorBuilder.PasteBars
(
self,

bars,

shift_time,

isCut )

Pastes the bars. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

bars — (List[int])

shift_time — (float)

isCut — (bool)

## ◆ SetBarAcceleration()

NXOpen.AnimationDesigner.PositionMotorBuilder.SetBarAcceleration
(
self,

index,

acceleration )

Sets the bar acceleration. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

acceleration — (float)

## ◆ SetBarCalcType()

NXOpen.AnimationDesigner.PositionMotorBuilder.SetBarCalcType
(
self,

index,

calc_type )

Sets the bar calculation type. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

calc_type — (int)

## ◆ SetBarDeceleration()

NXOpen.AnimationDesigner.PositionMotorBuilder.SetBarDeceleration
(
self,

index,

deceleration )

Sets the bar deceleration. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

deceleration — (float)

## ◆ SetBarEndTime()

NXOpen.AnimationDesigner.PositionMotorBuilder.SetBarEndTime
(
self,

index,

end_time )

Sets the bar end time. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

end_time — (float)

## ◆ SetBarIncrement()

NXOpen.AnimationDesigner.PositionMotorBuilder.SetBarIncrement
(
self,

index,

increment )

Sets the bar increment. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

increment — (float)

## ◆ SetBarLimitAcceleration()

NXOpen.AnimationDesigner.PositionMotorBuilder.SetBarLimitAcceleration
(
self,

index,

limit_acceleration )

Sets the bar limit acceleration. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

limit_acceleration — (bool)

## ◆ SetBarName()

NXOpen.AnimationDesigner.PositionMotorBuilder.SetBarName
(
self,

index,

name )

Sets the bar name. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

name — (str)

## ◆ SetBarSpeed()

NXOpen.AnimationDesigner.PositionMotorBuilder.SetBarSpeed
(
self,

index,

speed )

Sets the bar speed. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

speed — (float)

## ◆ SetBarStartTime()

NXOpen.AnimationDesigner.PositionMotorBuilder.SetBarStartTime
(
self,

index,

start_time )

Sets the bar start time. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

start_time — (float)

## ◆ SetBarTime()

NXOpen.AnimationDesigner.PositionMotorBuilder.SetBarTime
(
self,

bars,

deltaStart,

deltaDuration )

Sets the bar time. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

bars — (List[int])

deltaStart — (float)

deltaDuration — (float)

## ◆ SplitBar()

NXOpen.AnimationDesigner.PositionMotorBuilder.SplitBar
(
self,

index,

split_time )

Splits the bars with the start time exp tag. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

split_time — (float)

## ◆ UpdateDestination()

NXOpen.AnimationDesigner.PositionMotorBuilder.UpdateDestination
(
self — )

Updates the motor destination. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer") 

## Member Data Documentation

## ◆ PositionMotorBuilderAutoCalculate

NXOpen.AnimationDesigner.PositionMotorBuilder.PositionMotorBuilderAutoCalculate = PositionMotorBuilder.AutoCalculate

NXOpen.AnimationDesigner.PositionMotorBuilderAutoCalculate is an alias for NXOpen.AnimationDesigner.PositionMotorBuilder.AutoCalculate 

## ◆ PositionMotorBuilderAxis

NXOpen.AnimationDesigner.PositionMotorBuilder.PositionMotorBuilderAxis = PositionMotorBuilder.Axis

NXOpen.AnimationDesigner.PositionMotorBuilderAxis is an alias for NXOpen.AnimationDesigner.PositionMotorBuilder.Axis 

## ◆ PositionMotorBuilderColorOptions

NXOpen.AnimationDesigner.PositionMotorBuilder.PositionMotorBuilderColorOptions = PositionMotorBuilder.ColorOptions

NXOpen.AnimationDesigner.PositionMotorBuilderColorOptions is an alias for NXOpen.AnimationDesigner.PositionMotorBuilder.ColorOptions 

Copyright 2025 Siemens
