# NXOpen.AnimationDesigner.BulletCableBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10513.html>

Represents a NXOpen::AnimationDesigner::BulletCableBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.BulletCableBuilder:

## Public Member Functions

AttachmentList (self)

Getter for property: (NXOpen.AnimationDesigner.BulletCableAttachmentBuilderList) AttachmentList Returns. 

CableBody (self)

Getter for property: (NXOpen.SelectNXObject) CableBody Returns. 

Diameter (self)

Getter for property: (NXOpen.Expression) Diameter Returns. 

GeometryType (self)

Getter for property: (NXOpen.AnimationDesigner.BulletCableBuilder.DerivationType) GeometryType Returns. 

GeometryType (self, geometryType)

Setter for property: (NXOpen.AnimationDesigner.BulletCableBuilder.DerivationType) GeometryType. 

GuideCurves (self)

Getter for property: (NXOpen.SelectNXObjectList) GuideCurves Returns. 

Material (self)

Getter for property: (NXOpen.AnimationDesigner.BulletFlexibleMaterial) Material Returns. 

Material (self, material)

Setter for property: (NXOpen.AnimationDesigner.BulletFlexibleMaterial) Material. 

Name (self)

Getter for property: (str) Name Returns. 

Name (self, name)

Setter for property: (str) Name. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

BulletCableBuilderDerivationType = BulletCableBuilder.DerivationType

NXOpen.AnimationDesigner.BulletCableBuilderDerivationType is an alias for NXOpen.AnimationDesigner.BulletCableBuilder.DerivationType 

## Detailed Description

Represents a NXOpen::AnimationDesigner::BulletCableBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::BulletCableCollection::CreateBulletCableBuilder 

Created in NX2306.0.0 

## Member Function Documentation

## ◆ AttachmentList()

NXOpen.AnimationDesigner.BulletCableBuilder.AttachmentList
(
self — )

Getter for property: (NXOpen.AnimationDesigner.BulletCableAttachmentBuilderList) AttachmentList Returns. 

the list containing the defined attachments.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
BulletCableAttachmentBuilderList 

## ◆ CableBody()

NXOpen.AnimationDesigner.BulletCableBuilder.CableBody
(
self — )

Getter for property: (NXOpen.SelectNXObject) CableBody Returns. 

the cable body.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ Diameter()

NXOpen.AnimationDesigner.BulletCableBuilder.Diameter
(
self — )

Getter for property: (NXOpen.Expression) Diameter Returns. 

the diameter.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ GeometryType() [1/2]

NXOpen.AnimationDesigner.BulletCableBuilder.GeometryType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.BulletCableBuilder.DerivationType) GeometryType Returns. 

the geometry type used to derive the bullet cable.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
BulletCableBuilder.DerivationType 

## ◆ GeometryType() [2/2]

NXOpen.AnimationDesigner.BulletCableBuilder.GeometryType
(
self,

geometryType )

Setter for property: (NXOpen.AnimationDesigner.BulletCableBuilder.DerivationType) GeometryType. 

Sets the geometry type used to derive the bullet cable.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ GuideCurves()

NXOpen.AnimationDesigner.BulletCableBuilder.GuideCurves
(
self — )

Getter for property: (NXOpen.SelectNXObjectList) GuideCurves Returns. 

the guide curves.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.SelectNXObjectList 

## ◆ Material() [1/2]

NXOpen.AnimationDesigner.BulletCableBuilder.Material
(
self — )

Getter for property: (NXOpen.AnimationDesigner.BulletFlexibleMaterial) Material Returns. 

the material. This can be a NXOpen::AnimationDesigner::BulletFlexibleMaterial .

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
BulletFlexibleMaterial 

## ◆ Material() [2/2]

NXOpen.AnimationDesigner.BulletCableBuilder.Material
(
self,

material )

Setter for property: (NXOpen.AnimationDesigner.BulletFlexibleMaterial) Material. 

Sets the material. This can be a NXOpen::AnimationDesigner::BulletFlexibleMaterial .

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ Name() [1/2]

NXOpen.AnimationDesigner.BulletCableBuilder.Name
(
self — )

Getter for property: (str) Name Returns. 

the name.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
str 

## ◆ Name() [2/2]

NXOpen.AnimationDesigner.BulletCableBuilder.Name
(
self,

name )

Setter for property: (str) Name. 

Sets the name.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## Member Data Documentation

## ◆ BulletCableBuilderDerivationType

NXOpen.AnimationDesigner.BulletCableBuilder.BulletCableBuilderDerivationType = BulletCableBuilder.DerivationType

NXOpen.AnimationDesigner.BulletCableBuilderDerivationType is an alias for NXOpen.AnimationDesigner.BulletCableBuilder.DerivationType 

Copyright 2025 Siemens
