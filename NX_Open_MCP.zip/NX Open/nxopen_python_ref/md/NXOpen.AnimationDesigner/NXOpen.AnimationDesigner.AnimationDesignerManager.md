# NXOpen.AnimationDesigner.AnimationDesignerManager Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00106.html>

## Classes

class — JaAnimationDesignerDisplayColorOption

Represents display color option. More...

class — JaAnimationDesignerEnvelopeAccuracyMode

Represents envelope accuracy mode. More...

class — JaAnimationDesignerEnvelopeMode

Represents create envelope mode. More...

class — JaAnimationDesignerInterferenceType

Represents create interference type. More...

Copyright 2025 Siemens
