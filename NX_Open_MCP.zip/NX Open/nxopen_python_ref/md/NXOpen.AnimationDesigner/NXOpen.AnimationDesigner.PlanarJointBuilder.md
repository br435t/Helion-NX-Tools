# NXOpen.AnimationDesigner.PlanarJointBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10809.html>

Represents a NXOpen::AnimationDesigner::PlanarJointBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.PlanarJointBuilder:

## Public Member Functions

AxisVector (self)

Getter for property: (NXOpen.Direction) AxisVector Returns. 

AxisVector (self, axisVector)

Setter for property: (NXOpen.Direction) AxisVector. 

PointOrigin (self)

Getter for property: (NXOpen.Point) PointOrigin Returns. 

PointOrigin (self, origin)

Setter for property: (NXOpen.Point) PointOrigin. 

Public Member Functions inherited from NXOpen.AnimationDesigner.PhysicsJointBuilder

AttachmentList (self)

Getter for property: (NXOpen.SelectNXObjectList) AttachmentList Returns the attachment list for a Joint. 

BaseList (self)

Getter for property: (NXOpen.SelectNXObjectList) BaseList Returns the base list for a Joint. 

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

ColorOption (self)

Getter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions) ColorOption Returns the color options. 

ColorOption (self, colorOption)

Setter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions) ColorOption. 

MotionType (self)

Getter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes) MotionType Returns the motion type. 

MotionType (self, motionType)

Setter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes) MotionType. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.AnimationDesigner.PhysicsJointBuilder

PhysicsJointBuilderColorOptions = PhysicsJointBuilder.ColorOptions

NXOpen.AnimationDesigner.PhysicsJointBuilderColorOptions is an alias for NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions 

PhysicsJointBuilderMotionTypes = PhysicsJointBuilder.MotionTypes

NXOpen.AnimationDesigner.PhysicsJointBuilderMotionTypes is an alias for NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes 

## Detailed Description

Represents a NXOpen::AnimationDesigner::PlanarJointBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::PlanarJointCollection::CreatePlanarJointBuilder 

Created in NX12.0.2 

## Member Function Documentation

## ◆ AxisVector() [1/2]

NXOpen.AnimationDesigner.PlanarJointBuilder.AxisVector
(
self — )

Getter for property: (NXOpen.Direction) AxisVector Returns. 

a value that specifies axis vector.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.2 

Returns
NXOpen.Direction 

## ◆ AxisVector() [2/2]

NXOpen.AnimationDesigner.PlanarJointBuilder.AxisVector
(
self,

axisVector )

Setter for property: (NXOpen.Direction) AxisVector. 

Sets a value that specifies axis vector.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.2 

## ◆ PointOrigin() [1/2]

NXOpen.AnimationDesigner.PlanarJointBuilder.PointOrigin
(
self — )

Getter for property: (NXOpen.Point) PointOrigin Returns. 

a value that indicates the origin point.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.2 

Returns
NXOpen.Point 

## ◆ PointOrigin() [2/2]

NXOpen.AnimationDesigner.PlanarJointBuilder.PointOrigin
(
self,

origin )

Setter for property: (NXOpen.Point) PointOrigin. 

Sets a value that indicates the origin point.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.2 

Copyright 2025 Siemens
