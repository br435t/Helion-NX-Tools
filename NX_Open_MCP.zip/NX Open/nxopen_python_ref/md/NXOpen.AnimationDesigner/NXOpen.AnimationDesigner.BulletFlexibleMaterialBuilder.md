# NXOpen.AnimationDesigner.BulletFlexibleMaterialBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10529.html>

Represents a NXOpen::AnimationDesigner::BulletFlexibleMaterialBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.BulletFlexibleMaterialBuilder:

## Public Member Functions

DampingValue (self)

Getter for property: (NXOpen.Expression) DampingValue Returns. 

DensityValue (self)

Getter for property: (NXOpen.Expression) DensityValue Returns. 

DynamicFrictionValue (self)

Getter for property: (NXOpen.Expression) DynamicFrictionValue Returns. 

LinearStiffnessValue (self)

Getter for property: (NXOpen.Expression) LinearStiffnessValue Returns. 

Name (self)

Getter for property: (str) Name Returns. 

Name (self, name)

Setter for property: (str) Name. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::AnimationDesigner::BulletFlexibleMaterialBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::BulletFlexibleMaterialCollection::CreateBulletFlexibleMaterialBuilder 

Created in NX2306.0.0 

## Member Function Documentation

## ◆ DampingValue()

NXOpen.AnimationDesigner.BulletFlexibleMaterialBuilder.DampingValue
(
self — )

Getter for property: (NXOpen.Expression) DampingValue Returns. 

the damping value

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ DensityValue()

NXOpen.AnimationDesigner.BulletFlexibleMaterialBuilder.DensityValue
(
self — )

Getter for property: (NXOpen.Expression) DensityValue Returns. 

the density value

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ DynamicFrictionValue()

NXOpen.AnimationDesigner.BulletFlexibleMaterialBuilder.DynamicFrictionValue
(
self — )

Getter for property: (NXOpen.Expression) DynamicFrictionValue Returns. 

the dynamic friction value

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ LinearStiffnessValue()

NXOpen.AnimationDesigner.BulletFlexibleMaterialBuilder.LinearStiffnessValue
(
self — )

Getter for property: (NXOpen.Expression) LinearStiffnessValue Returns. 

the linear stiffness value

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ Name() [1/2]

NXOpen.AnimationDesigner.BulletFlexibleMaterialBuilder.Name
(
self — )

Getter for property: (str) Name Returns. 

the name.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
str 

## ◆ Name() [2/2]

NXOpen.AnimationDesigner.BulletFlexibleMaterialBuilder.Name
(
self,

name )

Setter for property: (str) Name. 

Sets the name.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Copyright 2025 Siemens
