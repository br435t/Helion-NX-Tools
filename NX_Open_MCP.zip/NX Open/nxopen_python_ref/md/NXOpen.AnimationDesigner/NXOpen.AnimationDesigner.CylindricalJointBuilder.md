# NXOpen.AnimationDesigner.CylindricalJointBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10589.html>

Represents a NXOpen::AnimationDesigner::CylindricalJointBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.CylindricalJointBuilder:

## Public Member Functions

AnchorPoint (self)

Getter for property: (NXOpen.Point) AnchorPoint Returns the anchor point. 

AnchorPoint (self, anchorPoint)

Setter for property: (NXOpen.Point) AnchorPoint. 

AngularLowerLimit (self)

Getter for property: (NXOpen.Expression) AngularLowerLimit Returns the angular lower limit. 

AngularUpperLimit (self)

Getter for property: (NXOpen.Expression) AngularUpperLimit Returns the angular upper limit. 

AxisVector (self)

Getter for property: (NXOpen.Direction) AxisVector Returns the axis vector. 

AxisVector (self, axisVector)

Setter for property: (NXOpen.Direction) AxisVector. 

EnableAngularLowerLimit (self)

Getter for property: (bool) EnableAngularLowerLimit Returns the angular lower limit option. 

EnableAngularLowerLimit (self, enable)

Setter for property: (bool) EnableAngularLowerLimit. 

EnableAngularUpperLimit (self)

Getter for property: (bool) EnableAngularUpperLimit Returns the angular upper limit option. 

EnableAngularUpperLimit (self, enable)

Setter for property: (bool) EnableAngularUpperLimit. 

EnableLinearLowerLimit (self)

Getter for property: (bool) EnableLinearLowerLimit Returns the linear lower limit option. 

EnableLinearLowerLimit (self, enable)

Setter for property: (bool) EnableLinearLowerLimit. 

EnableLinearUpperLimit (self)

Getter for property: (bool) EnableLinearUpperLimit Returns the linear upper limit option. 

EnableLinearUpperLimit (self, enable)

Setter for property: (bool) EnableLinearUpperLimit. 

LinearLowerLimit (self)

Getter for property: (NXOpen.Expression) LinearLowerLimit Returns the linear lower limit. 

LinearUpperLimit (self)

Getter for property: (NXOpen.Expression) LinearUpperLimit Returns the linear upper limit. 

Offset (self)

Getter for property: (NXOpen.Expression) Offset Returns the offset value. 

StartAngle (self)

Getter for property: (NXOpen.Expression) StartAngle Returns the start angle. 

Public Member Functions inherited from NXOpen.AnimationDesigner.PhysicsJointBuilder

AttachmentList (self)

Getter for property: (NXOpen.SelectNXObjectList) AttachmentList Returns the attachment list for a Joint. 

BaseList (self)

Getter for property: (NXOpen.SelectNXObjectList) BaseList Returns the base list for a Joint. 

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

ColorOption (self)

Getter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions) ColorOption Returns the color options. 

ColorOption (self, colorOption)

Setter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions) ColorOption. 

MotionType (self)

Getter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes) MotionType Returns the motion type. 

MotionType (self, motionType)

Setter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes) MotionType. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.AnimationDesigner.PhysicsJointBuilder

PhysicsJointBuilderColorOptions = PhysicsJointBuilder.ColorOptions

NXOpen.AnimationDesigner.PhysicsJointBuilderColorOptions is an alias for NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions 

PhysicsJointBuilderMotionTypes = PhysicsJointBuilder.MotionTypes

NXOpen.AnimationDesigner.PhysicsJointBuilderMotionTypes is an alias for NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes 

## Detailed Description

Represents a NXOpen::AnimationDesigner::CylindricalJointBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::CylindricalJointCollection::CreateCylindricalJointBuilder 

Created in NX12.0.0 

## Member Function Documentation

## ◆ AnchorPoint() [1/2]

NXOpen.AnimationDesigner.CylindricalJointBuilder.AnchorPoint
(
self — )

Getter for property: (NXOpen.Point) AnchorPoint Returns the anchor point. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Point 

## ◆ AnchorPoint() [2/2]

NXOpen.AnimationDesigner.CylindricalJointBuilder.AnchorPoint
(
self,

anchorPoint )

Setter for property: (NXOpen.Point) AnchorPoint. 

Sets the anchor point.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ AngularLowerLimit()

NXOpen.AnimationDesigner.CylindricalJointBuilder.AngularLowerLimit
(
self — )

Getter for property: (NXOpen.Expression) AngularLowerLimit Returns the angular lower limit. 

The lower limit setup for joint angular movement.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ AngularUpperLimit()

NXOpen.AnimationDesigner.CylindricalJointBuilder.AngularUpperLimit
(
self — )

Getter for property: (NXOpen.Expression) AngularUpperLimit Returns the angular upper limit. 

The upper limit setup for joint angular movement.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ AxisVector() [1/2]

NXOpen.AnimationDesigner.CylindricalJointBuilder.AxisVector
(
self — )

Getter for property: (NXOpen.Direction) AxisVector Returns the axis vector. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Direction 

## ◆ AxisVector() [2/2]

NXOpen.AnimationDesigner.CylindricalJointBuilder.AxisVector
(
self,

axisVector )

Setter for property: (NXOpen.Direction) AxisVector. 

Sets the axis vector.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ EnableAngularLowerLimit() [1/2]

NXOpen.AnimationDesigner.CylindricalJointBuilder.EnableAngularLowerLimit
(
self — )

Getter for property: (bool) EnableAngularLowerLimit Returns the angular lower limit option. 

If the enable is true, then this joint will be applied the lower limit in angular direction.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
bool 

## ◆ EnableAngularLowerLimit() [2/2]

NXOpen.AnimationDesigner.CylindricalJointBuilder.EnableAngularLowerLimit
(
self,

enable )

Setter for property: (bool) EnableAngularLowerLimit. 

Sets the angular lower limit option. If the enable is true, then this joint will be applied the lower limit in angular direction.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ EnableAngularUpperLimit() [1/2]

NXOpen.AnimationDesigner.CylindricalJointBuilder.EnableAngularUpperLimit
(
self — )

Getter for property: (bool) EnableAngularUpperLimit Returns the angular upper limit option. 

If the enable is true, then this joint will be applied the upper limit in angular direction.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
bool 

## ◆ EnableAngularUpperLimit() [2/2]

NXOpen.AnimationDesigner.CylindricalJointBuilder.EnableAngularUpperLimit
(
self,

enable )

Setter for property: (bool) EnableAngularUpperLimit. 

Sets the angular upper limit option. If the enable is true, then this joint will be applied the upper limit in angular direction.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ EnableLinearLowerLimit() [1/2]

NXOpen.AnimationDesigner.CylindricalJointBuilder.EnableLinearLowerLimit
(
self — )

Getter for property: (bool) EnableLinearLowerLimit Returns the linear lower limit option. 

If the enable is true, then this joint will be applied the lower limit in linear direction.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
bool 

## ◆ EnableLinearLowerLimit() [2/2]

NXOpen.AnimationDesigner.CylindricalJointBuilder.EnableLinearLowerLimit
(
self,

enable )

Setter for property: (bool) EnableLinearLowerLimit. 

Sets the linear lower limit option. If the enable is true, then this joint will be applied the lower limit in linear direction.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ EnableLinearUpperLimit() [1/2]

NXOpen.AnimationDesigner.CylindricalJointBuilder.EnableLinearUpperLimit
(
self — )

Getter for property: (bool) EnableLinearUpperLimit Returns the linear upper limit option. 

If the enable is true, then this joint will be applied the upper limit in linear direction.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
bool 

## ◆ EnableLinearUpperLimit() [2/2]

NXOpen.AnimationDesigner.CylindricalJointBuilder.EnableLinearUpperLimit
(
self,

enable )

Setter for property: (bool) EnableLinearUpperLimit. 

Sets the linear upper limit option. If the enable is true, then this joint will be applied the upper limit in linear direction.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ LinearLowerLimit()

NXOpen.AnimationDesigner.CylindricalJointBuilder.LinearLowerLimit
(
self — )

Getter for property: (NXOpen.Expression) LinearLowerLimit Returns the linear lower limit. 

The lower limit setup for joint linear movement.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ LinearUpperLimit()

NXOpen.AnimationDesigner.CylindricalJointBuilder.LinearUpperLimit
(
self — )

Getter for property: (NXOpen.Expression) LinearUpperLimit Returns the linear upper limit. 

The upper limit setup for joint linear movement.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ Offset()

NXOpen.AnimationDesigner.CylindricalJointBuilder.Offset
(
self — )

Getter for property: (NXOpen.Expression) Offset Returns the offset value. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.2 

Returns
NXOpen.Expression 

## ◆ StartAngle()

NXOpen.AnimationDesigner.CylindricalJointBuilder.StartAngle
(
self — )

Getter for property: (NXOpen.Expression) StartAngle Returns the start angle. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.2 

Returns
NXOpen.Expression 

Copyright 2025 Siemens
