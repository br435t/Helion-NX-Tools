# NXOpen.AnimationDesigner.SpeedMotorBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10989.html>

Represents a NXOpen::AnimationDesigner::SpeedMotorBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.SpeedMotorBuilder:

## Public Member Functions

AxisType (self)

Getter for property: (NXOpen.AnimationDesigner.SpeedMotorBuilder.Axis) AxisType Returns the axis type. 

AxisType (self, axisType)

Setter for property: (NXOpen.AnimationDesigner.SpeedMotorBuilder.Axis) AxisType. 

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

ColorOption (self)

Getter for property: (NXOpen.AnimationDesigner.SpeedMotorBuilder.ColorOptions) ColorOption Returns the color option. 

ColorOption (self, colorOption)

Setter for property: (NXOpen.AnimationDesigner.SpeedMotorBuilder.ColorOptions) ColorOption. 

EditStartTime (self, deltaStart)

Sets the start time value. 

MaxAcceleration (self)

Getter for property: (NXOpen.Expression) MaxAcceleration Returns the max acceleration. 

Speed (self)

Getter for property: (NXOpen.Expression) Speed Returns the speed. 

StartTime (self)

Getter for property: (NXOpen.Expression) StartTime Returns the start time. 

UseAcceleration (self)

Getter for property: (bool) UseAcceleration Returns the limit acceleration. 

UseAcceleration (self, useAcceleration)

Setter for property: (bool) UseAcceleration. 

Public Member Functions inherited from NXOpen.AnimationDesigner.MotorBuilder

AxisJoint (self)

Getter for property: (NXOpen.SelectNXObject) AxisJoint Returns the joint select. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

SpeedMotorBuilderAxis = SpeedMotorBuilder.Axis

NXOpen.AnimationDesigner.SpeedMotorBuilderAxis is an alias for NXOpen.AnimationDesigner.SpeedMotorBuilder.Axis 

SpeedMotorBuilderColorOptions = SpeedMotorBuilder.ColorOptions

NXOpen.AnimationDesigner.SpeedMotorBuilderColorOptions is an alias for NXOpen.AnimationDesigner.SpeedMotorBuilder.ColorOptions 

## Detailed Description

Represents a NXOpen::AnimationDesigner::SpeedMotorBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::SpeedMotorCollection::CreateSpeedMotorBuilder 

Created in NX12.0.0 

## Member Function Documentation

## ◆ AxisType() [1/2]

NXOpen.AnimationDesigner.SpeedMotorBuilder.AxisType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.SpeedMotorBuilder.Axis) AxisType Returns the axis type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
SpeedMotorBuilder.Axis 

## ◆ AxisType() [2/2]

NXOpen.AnimationDesigner.SpeedMotorBuilder.AxisType
(
self,

axisType )

Setter for property: (NXOpen.AnimationDesigner.SpeedMotorBuilder.Axis) AxisType. 

Sets the axis type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ Color() [1/2]

NXOpen.AnimationDesigner.SpeedMotorBuilder.Color
(
self — )

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
NXOpen.NXColor 

## ◆ Color() [2/2]

NXOpen.AnimationDesigner.SpeedMotorBuilder.Color
(
self,

color )

Setter for property: (NXOpen.NXColor) Color. 

Sets the color.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

## ◆ ColorOption() [1/2]

NXOpen.AnimationDesigner.SpeedMotorBuilder.ColorOption
(
self — )

Getter for property: (NXOpen.AnimationDesigner.SpeedMotorBuilder.ColorOptions) ColorOption Returns the color option. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
SpeedMotorBuilder.ColorOptions 

## ◆ ColorOption() [2/2]

NXOpen.AnimationDesigner.SpeedMotorBuilder.ColorOption
(
self,

colorOption )

Setter for property: (NXOpen.AnimationDesigner.SpeedMotorBuilder.ColorOptions) ColorOption. 

Sets the color option.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

## ◆ EditStartTime()

NXOpen.AnimationDesigner.SpeedMotorBuilder.EditStartTime
(
self,

deltaStart )

Sets the start time value. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

deltaStart — (float)

## ◆ MaxAcceleration()

NXOpen.AnimationDesigner.SpeedMotorBuilder.MaxAcceleration
(
self — )

Getter for property: (NXOpen.Expression) MaxAcceleration Returns the max acceleration. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ Speed()

NXOpen.AnimationDesigner.SpeedMotorBuilder.Speed
(
self — )

Getter for property: (NXOpen.Expression) Speed Returns the speed. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ StartTime()

NXOpen.AnimationDesigner.SpeedMotorBuilder.StartTime
(
self — )

Getter for property: (NXOpen.Expression) StartTime Returns the start time. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ UseAcceleration() [1/2]

NXOpen.AnimationDesigner.SpeedMotorBuilder.UseAcceleration
(
self — )

Getter for property: (bool) UseAcceleration Returns the limit acceleration. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
bool 

## ◆ UseAcceleration() [2/2]

NXOpen.AnimationDesigner.SpeedMotorBuilder.UseAcceleration
(
self,

useAcceleration )

Setter for property: (bool) UseAcceleration. 

Sets the limit acceleration.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## Member Data Documentation

## ◆ SpeedMotorBuilderAxis

NXOpen.AnimationDesigner.SpeedMotorBuilder.SpeedMotorBuilderAxis = SpeedMotorBuilder.Axis

NXOpen.AnimationDesigner.SpeedMotorBuilderAxis is an alias for NXOpen.AnimationDesigner.SpeedMotorBuilder.Axis 

## ◆ SpeedMotorBuilderColorOptions

NXOpen.AnimationDesigner.SpeedMotorBuilder.SpeedMotorBuilderColorOptions = SpeedMotorBuilder.ColorOptions

NXOpen.AnimationDesigner.SpeedMotorBuilderColorOptions is an alias for NXOpen.AnimationDesigner.SpeedMotorBuilder.ColorOptions 

Copyright 2025 Siemens
