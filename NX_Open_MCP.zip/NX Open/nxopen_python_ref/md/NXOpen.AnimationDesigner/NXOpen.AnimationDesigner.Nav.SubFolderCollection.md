# NXOpen.AnimationDesigner.Nav.SubFolderCollection Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11049.html>

Represents a NXOpen::AnimationDesigner::Nav::SubFolderCollection . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.Nav.SubFolderCollection:

## Public Member Functions

FindObject (part, name)

Finds the NXOpen::AnimationDesigner::Nav::SubFolder object with the given name. 

## Detailed Description

Represents a NXOpen::AnimationDesigner::Nav::SubFolderCollection . 

To obtain an instance of this class, refer to NXOpen::AnimationDesigner::AnimationDesignerManager 

Created in NX2007.0.0 

## Member Function Documentation

## ◆ FindObject()

NXOpen.AnimationDesigner.Nav.SubFolderCollection.FindObject
(
part,

name )

Finds the NXOpen::AnimationDesigner::Nav::SubFolder object with the given name. 

Returns
folder (NXOpen.AnimationDesigner.Nav.SubFolder): NXOpen::AnimationDesigner::Nav::SubFolder object with this name. .

Created in NX1980.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer") 
Parameters

part — (NXOpen.Part)

name — (str) The name of the NXOpen::AnimationDesigner::Nav::SubFolder .

Copyright 2025 Siemens
