# NXOpen.AnimationDesigner.AnimatedCameraBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10389.html>

Represents a NXOpen::AnimationDesigner::AnimatedCameraBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.AnimatedCameraBuilder:

## Public Member Functions

AnimationCamera (self)

Getter for property: (NXOpen.NXObject) AnimationCamera Returns the associated animation camera. 

AnimationCamera (self, animation_camera)

Setter for property: (NXOpen.NXObject) AnimationCamera. 

AssociateObjects (self)

Getter for property: (NXOpen.SelectNXObjectList) AssociateObjects Returns the associate object selection. 

AvoidViewRoll (self)

Getter for property: (bool) AvoidViewRoll Returns the 'Associated to Object' mode avoid view roll option. 

AvoidViewRoll (self, bAvoidRoll)

Setter for property: (bool) AvoidViewRoll. 

CameraAngle (self)

Getter for property: (NXOpen.Expression) CameraAngle Returns the camera angle. 

CameraAxisType (self)

Getter for property: (NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraAxisTypes) CameraAxisType Returns. 

CameraAxisType (self, axisType)

Setter for property: (NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraAxisTypes) CameraAxisType. 

CameraModeType (self)

Getter for property: (NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraModeTypes) CameraModeType Returns. 

CameraModeType (self, modeType)

Setter for property: (NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraModeTypes) CameraModeType. 

CameraOrientation (self)

Getter for property: (NXOpen.NXObject) CameraOrientation Returns the 'Associated to Object' mode camera init orientation. 

CameraOrientation (self, camera_orientation)

Setter for property: (NXOpen.NXObject) CameraOrientation. 

CreatePOV (self, currentTime)

Creates a new pov. 

DeletePOVs (self, povs)

Deletes the povs. 

DirectionType (self)

Getter for property: (NXOpen.AnimationDesigner.AnimatedCameraBuilder.LookAtDirectionTypes) DirectionType Returns. 

DirectionType (self, lookAtDirType)

Setter for property: (NXOpen.AnimationDesigner.AnimatedCameraBuilder.LookAtDirectionTypes) DirectionType. 

EndPathPoint (self)

Getter for property: (NXOpen.Point) EndPathPoint Returns the 'Associated to Object' mode associated curve end point. 

EndPathPoint (self, endPoint)

Setter for property: (NXOpen.Point) EndPathPoint. 

EndTime (self)

Getter for property: (NXOpen.Expression) EndTime Returns the 'Associated to Object' mode end time. 

EvaluatePath (self, curves)

Evaluate the composited path from associated curves. 

LookAtObject (self)

Getter for property: (NXOpen.SelectNXObject) LookAtObject Returns the 'Associated to Object' mode look at object selection. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

PlayKeyFrameAtTime (self, time)

Play key frame at time. 

PointOnLookAtRigid (self)

Getter for property: (NXOpen.Point) PointOnLookAtRigid Returns the 'Associated to Object' mode look at point on look at object. 

PointOnLookAtRigid (self, lookAtPoint)

Setter for property: (NXOpen.Point) PointOnLookAtRigid. 

RotationSpeed (self)

Getter for property: (NXOpen.Expression) RotationSpeed Returns the rotational speed. 

SetPOVName (self, pos, name)

Sets the pov name. 

SetPOVStartTime (self, pos, start_time)

Sets the pov start time. 

SetPOVStepNumber (self, pos, step_num)

Sets the pov step count. 

SetViewScale (self, fViewScale)

Sets the view scale value. 

SpecifyTime (self)

Getter for property: (bool) SpecifyTime Returns the 'Associated to Object' mode specify time option. 

SpecifyTime (self, specifyTime)

Setter for property: (bool) SpecifyTime. 

StartPathPoint (self)

Getter for property: (NXOpen.Point) StartPathPoint Returns the 'Associated to Object' mode associated curve start point. 

StartPathPoint (self, startPoint)

Setter for property: (NXOpen.Point) StartPathPoint. 

StartTime (self)

Getter for property: (NXOpen.Expression) StartTime Returns the 'Associated to Object' mode start time. 

TransitionModeType (self)

Getter for property: (NXOpen.AnimationDesigner.AnimatedCameraBuilder.TransitionModeTypes) TransitionModeType Returns. 

TransitionModeType (self, transitionModeType)

Setter for property: (NXOpen.AnimationDesigner.AnimatedCameraBuilder.TransitionModeTypes) TransitionModeType. 

UpdateCurrentView (self, rotation, translation, scale)

Updates current view. 

UpdatePOV (self, pos)

Updates a pov. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

AnimatedCameraBuilderCameraAxisTypes = AnimatedCameraBuilder.CameraAxisTypes

NXOpen.AnimationDesigner.AnimatedCameraBuilderCameraAxisTypes is an alias for NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraAxisTypes 

AnimatedCameraBuilderCameraModeTypes = AnimatedCameraBuilder.CameraModeTypes

NXOpen.AnimationDesigner.AnimatedCameraBuilderCameraModeTypes is an alias for NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraModeTypes 

AnimatedCameraBuilderLookAtDirectionTypes = AnimatedCameraBuilder.LookAtDirectionTypes

NXOpen.AnimationDesigner.AnimatedCameraBuilderLookAtDirectionTypes is an alias for NXOpen.AnimationDesigner.AnimatedCameraBuilder.LookAtDirectionTypes 

AnimatedCameraBuilderTransitionModeTypes = AnimatedCameraBuilder.TransitionModeTypes

NXOpen.AnimationDesigner.AnimatedCameraBuilderTransitionModeTypes is an alias for NXOpen.AnimationDesigner.AnimatedCameraBuilder.TransitionModeTypes 

## Detailed Description

Represents a NXOpen::AnimationDesigner::AnimatedCameraBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::AnimatedCameraCollection::CreateAnimatedCameraBuilder 

Created in NX1847.0.0 

## Member Function Documentation

## ◆ AnimationCamera() [1/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.AnimationCamera
(
self — )

Getter for property: (NXOpen.NXObject) AnimationCamera Returns the associated animation camera. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1953.0.0 

Returns
NXOpen.NXObject 

## ◆ AnimationCamera() [2/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.AnimationCamera
(
self,

animation_camera )

Setter for property: (NXOpen.NXObject) AnimationCamera. 

Sets the associated animation camera.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1953.0.0 

## ◆ AssociateObjects()

NXOpen.AnimationDesigner.AnimatedCameraBuilder.AssociateObjects
(
self — )

Getter for property: (NXOpen.SelectNXObjectList) AssociateObjects Returns the associate object selection. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.SelectNXObjectList 

## ◆ AvoidViewRoll() [1/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.AvoidViewRoll
(
self — )

Getter for property: (bool) AvoidViewRoll Returns the 'Associated to Object' mode avoid view roll option. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
bool 

## ◆ AvoidViewRoll() [2/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.AvoidViewRoll
(
self,

bAvoidRoll )

Setter for property: (bool) AvoidViewRoll. 

Sets the 'Associated to Object' mode avoid view roll option.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

## ◆ CameraAngle()

NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraAngle
(
self — )

Getter for property: (NXOpen.Expression) CameraAngle Returns the camera angle. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1926.0.0 

Returns
NXOpen.Expression 

## ◆ CameraAxisType() [1/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraAxisType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraAxisTypes) CameraAxisType Returns. 

the axis type.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1926.0.0 

Returns
AnimatedCameraBuilder.CameraAxisTypes 

## ◆ CameraAxisType() [2/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraAxisType
(
self,

axisType )

Setter for property: (NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraAxisTypes) CameraAxisType. 

Sets the axis type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1926.0.0 

## ◆ CameraModeType() [1/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraModeType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraModeTypes) CameraModeType Returns. 

the mode type.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1926.0.0 

Returns
AnimatedCameraBuilder.CameraModeTypes 

## ◆ CameraModeType() [2/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraModeType
(
self,

modeType )

Setter for property: (NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraModeTypes) CameraModeType. 

Sets the mode type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1926.0.0 

## ◆ CameraOrientation() [1/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraOrientation
(
self — )

Getter for property: (NXOpen.NXObject) CameraOrientation Returns the 'Associated to Object' mode camera init orientation. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.NXObject 

## ◆ CameraOrientation() [2/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraOrientation
(
self,

camera_orientation )

Setter for property: (NXOpen.NXObject) CameraOrientation. 

Sets the 'Associated to Object' mode camera init orientation.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

## ◆ CreatePOV()

NXOpen.AnimationDesigner.AnimatedCameraBuilder.CreatePOV
(
self,

currentTime )

Creates a new pov. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

currentTime — (float)

## ◆ DeletePOVs()

NXOpen.AnimationDesigner.AnimatedCameraBuilder.DeletePOVs
(
self,

povs )

Deletes the povs. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

povs — (List[int])

## ◆ DirectionType() [1/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.DirectionType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.AnimatedCameraBuilder.LookAtDirectionTypes) DirectionType Returns. 

the 'Associated to Object' mode look at direction type.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
AnimatedCameraBuilder.LookAtDirectionTypes 

## ◆ DirectionType() [2/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.DirectionType
(
self,

lookAtDirType )

Setter for property: (NXOpen.AnimationDesigner.AnimatedCameraBuilder.LookAtDirectionTypes) DirectionType. 

Sets the 'Associated to Object' mode look at direction type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

## ◆ EndPathPoint() [1/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.EndPathPoint
(
self — )

Getter for property: (NXOpen.Point) EndPathPoint Returns the 'Associated to Object' mode associated curve end point. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.Point 

## ◆ EndPathPoint() [2/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.EndPathPoint
(
self,

endPoint )

Setter for property: (NXOpen.Point) EndPathPoint. 

Sets the 'Associated to Object' mode associated curve end point.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

## ◆ EndTime()

NXOpen.AnimationDesigner.AnimatedCameraBuilder.EndTime
(
self — )

Getter for property: (NXOpen.Expression) EndTime Returns the 'Associated to Object' mode end time. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.Expression 

## ◆ EvaluatePath()

NXOpen.AnimationDesigner.AnimatedCameraBuilder.EvaluatePath
(
self,

curves )

Evaluate the composited path from associated curves. 

Created in NX2206.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

curves — (List[NXOpen.NXObject]) curve or edge

## ◆ LookAtObject()

NXOpen.AnimationDesigner.AnimatedCameraBuilder.LookAtObject
(
self — )

Getter for property: (NXOpen.SelectNXObject) LookAtObject Returns the 'Associated to Object' mode look at object selection. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ Name() [1/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.Name
(
self — )

Getter for property: (str) Name Returns the name. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
str 

## ◆ Name() [2/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.Name
(
self,

name )

Setter for property: (str) Name. 

Sets the name.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

## ◆ PlayKeyFrameAtTime()

NXOpen.AnimationDesigner.AnimatedCameraBuilder.PlayKeyFrameAtTime
(
self,

time )

Play key frame at time. 

Created in NX2312.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

time — (float)

## ◆ PointOnLookAtRigid() [1/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.PointOnLookAtRigid
(
self — )

Getter for property: (NXOpen.Point) PointOnLookAtRigid Returns the 'Associated to Object' mode look at point on look at object. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.Point 

## ◆ PointOnLookAtRigid() [2/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.PointOnLookAtRigid
(
self,

lookAtPoint )

Setter for property: (NXOpen.Point) PointOnLookAtRigid. 

Sets the 'Associated to Object' mode look at point on look at object.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

## ◆ RotationSpeed()

NXOpen.AnimationDesigner.AnimatedCameraBuilder.RotationSpeed
(
self — )

Getter for property: (NXOpen.Expression) RotationSpeed Returns the rotational speed. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1926.0.0 

Returns
NXOpen.Expression 

## ◆ SetPOVName()

NXOpen.AnimationDesigner.AnimatedCameraBuilder.SetPOVName
(
self,

pos,

name )

Sets the pov name. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

pos — (int)

name — (str)

## ◆ SetPOVStartTime()

NXOpen.AnimationDesigner.AnimatedCameraBuilder.SetPOVStartTime
(
self,

pos,

start_time )

Sets the pov start time. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

pos — (int)

start_time — (float)

## ◆ SetPOVStepNumber()

NXOpen.AnimationDesigner.AnimatedCameraBuilder.SetPOVStepNumber
(
self,

pos,

step_num )

Sets the pov step count. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

pos — (int)

step_num — (int)

## ◆ SetViewScale()

NXOpen.AnimationDesigner.AnimatedCameraBuilder.SetViewScale
(
self,

fViewScale )

Sets the view scale value. 

Created in NX2206.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

fViewScale — (float)

## ◆ SpecifyTime() [1/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.SpecifyTime
(
self — )

Getter for property: (bool) SpecifyTime Returns the 'Associated to Object' mode specify time option. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
bool 

## ◆ SpecifyTime() [2/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.SpecifyTime
(
self,

specifyTime )

Setter for property: (bool) SpecifyTime. 

Sets the 'Associated to Object' mode specify time option.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

## ◆ StartPathPoint() [1/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.StartPathPoint
(
self — )

Getter for property: (NXOpen.Point) StartPathPoint Returns the 'Associated to Object' mode associated curve start point. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.Point 

## ◆ StartPathPoint() [2/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.StartPathPoint
(
self,

startPoint )

Setter for property: (NXOpen.Point) StartPathPoint. 

Sets the 'Associated to Object' mode associated curve start point.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

## ◆ StartTime()

NXOpen.AnimationDesigner.AnimatedCameraBuilder.StartTime
(
self — )

Getter for property: (NXOpen.Expression) StartTime Returns the 'Associated to Object' mode start time. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2206.0.0 

Returns
NXOpen.Expression 

## ◆ TransitionModeType() [1/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.TransitionModeType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.AnimatedCameraBuilder.TransitionModeTypes) TransitionModeType Returns. 

the transition mode type.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1953.0.0 

Returns
AnimatedCameraBuilder.TransitionModeTypes 

## ◆ TransitionModeType() [2/2]

NXOpen.AnimationDesigner.AnimatedCameraBuilder.TransitionModeType
(
self,

transitionModeType )

Setter for property: (NXOpen.AnimationDesigner.AnimatedCameraBuilder.TransitionModeTypes) TransitionModeType. 

Sets the transition mode type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1953.0.0 

## ◆ UpdateCurrentView()

NXOpen.AnimationDesigner.AnimatedCameraBuilder.UpdateCurrentView
(
self,

rotation,

translation,

scale )

Updates current view. 

Created in NX2312.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

rotation — (NXOpen.Matrix3x3)

translation — (NXOpen.Point3d)

scale — (float)

## ◆ UpdatePOV()

NXOpen.AnimationDesigner.AnimatedCameraBuilder.UpdatePOV
(
self,

pos )

Updates a pov. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

pos — (int)

## Member Data Documentation

## ◆ AnimatedCameraBuilderCameraAxisTypes

NXOpen.AnimationDesigner.AnimatedCameraBuilder.AnimatedCameraBuilderCameraAxisTypes = AnimatedCameraBuilder.CameraAxisTypes

NXOpen.AnimationDesigner.AnimatedCameraBuilderCameraAxisTypes is an alias for NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraAxisTypes 

## ◆ AnimatedCameraBuilderCameraModeTypes

NXOpen.AnimationDesigner.AnimatedCameraBuilder.AnimatedCameraBuilderCameraModeTypes = AnimatedCameraBuilder.CameraModeTypes

NXOpen.AnimationDesigner.AnimatedCameraBuilderCameraModeTypes is an alias for NXOpen.AnimationDesigner.AnimatedCameraBuilder.CameraModeTypes 

## ◆ AnimatedCameraBuilderLookAtDirectionTypes

NXOpen.AnimationDesigner.AnimatedCameraBuilder.AnimatedCameraBuilderLookAtDirectionTypes = AnimatedCameraBuilder.LookAtDirectionTypes

NXOpen.AnimationDesigner.AnimatedCameraBuilderLookAtDirectionTypes is an alias for NXOpen.AnimationDesigner.AnimatedCameraBuilder.LookAtDirectionTypes 

## ◆ AnimatedCameraBuilderTransitionModeTypes

NXOpen.AnimationDesigner.AnimatedCameraBuilder.AnimatedCameraBuilderTransitionModeTypes = AnimatedCameraBuilder.TransitionModeTypes

NXOpen.AnimationDesigner.AnimatedCameraBuilderTransitionModeTypes is an alias for NXOpen.AnimationDesigner.AnimatedCameraBuilder.TransitionModeTypes 

Copyright 2025 Siemens
