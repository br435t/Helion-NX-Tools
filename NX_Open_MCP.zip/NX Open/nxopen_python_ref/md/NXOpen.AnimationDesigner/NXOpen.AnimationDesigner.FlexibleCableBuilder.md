# NXOpen.AnimationDesigner.FlexibleCableBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00111.html>

## Classes

class — ColorOptions

the color options. More...

class — GeometryTypes

the geometry types for flexible cable creation. More...

class — SectionTypes

the section types for flexible cable creation. More...

Copyright 2025 Siemens
