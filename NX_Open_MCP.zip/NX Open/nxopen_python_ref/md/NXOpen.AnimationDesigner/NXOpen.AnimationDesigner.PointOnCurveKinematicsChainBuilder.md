# NXOpen.AnimationDesigner.PointOnCurveKinematicsChainBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00120.html>

## Classes

class — ProjectionDirectionType

the projection direction types. More...

Copyright 2025 Siemens
