# NXOpen.AnimationDesigner.AnimatedColorBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00103.html>

## Classes

class — CreationTypes

the enumeration types. More...

Copyright 2025 Siemens
