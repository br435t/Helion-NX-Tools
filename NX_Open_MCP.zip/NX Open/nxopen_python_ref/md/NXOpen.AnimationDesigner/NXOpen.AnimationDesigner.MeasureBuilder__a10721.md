# NXOpen.AnimationDesigner.MeasureBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10721.html>

Represents a NXOpen::AnimationDesigner::MeasureBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.MeasureBuilder:

## Public Member Functions

Direction1 (self)

Getter for property: (NXOpen.Direction) Direction1 Returns the first direction used to measure the angle with the second direction. 

Direction1 (self, direction1)

Setter for property: (NXOpen.Direction) Direction1. 

Direction2 (self)

Getter for property: (NXOpen.Direction) Direction2 Returns the second direction used to measure the angle with the first direction. 

Direction2 (self, direction2)

Setter for property: (NXOpen.Direction) Direction2. 

List1 (self)

Getter for property: (NXOpen.SelectNXObjectList) List1 Returns the first object list used to be measured with the second object list. 

List2 (self)

Getter for property: (NXOpen.SelectNXObjectList) List2 Returns the second object list used to be measured with the first object list. 

MeasureType (self)

Getter for property: (NXOpen.AnimationDesigner.MeasureBuilder.MeasureTypes) MeasureType Returns the measure type. 

MeasureType (self, measureType)

Setter for property: (NXOpen.AnimationDesigner.MeasureBuilder.MeasureTypes) MeasureType. 

Motor (self)

Getter for property: (NXOpen.SelectNXObject) Motor Returns the motor. 

MotorParameterType (self)

Getter for property: (NXOpen.AnimationDesigner.MeasureBuilder.MotorParameterTypes) MotorParameterType Returns the motor parameter type. 

MotorParameterType (self, motorParameterType)

Setter for property: (NXOpen.AnimationDesigner.MeasureBuilder.MotorParameterTypes) MotorParameterType. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

UseVector (self)

Getter for property: (bool) UseVector Returns the use vector flag. 

UseVector (self, useVector)

Setter for property: (bool) UseVector. 

Vector (self)

Getter for property: (NXOpen.Direction) Vector Returns the vector. 

Vector (self, vector)

Setter for property: (NXOpen.Direction) Vector. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

MeasureBuilderMeasureTypes = MeasureBuilder.MeasureTypes

NXOpen.AnimationDesigner.MeasureBuilderMeasureTypes is an alias for NXOpen.AnimationDesigner.MeasureBuilder.MeasureTypes 

MeasureBuilderMotorParameterTypes = MeasureBuilder.MotorParameterTypes

NXOpen.AnimationDesigner.MeasureBuilderMotorParameterTypes is an alias for NXOpen.AnimationDesigner.MeasureBuilder.MotorParameterTypes 

## Detailed Description

Represents a NXOpen::AnimationDesigner::MeasureBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::MeasureCollection::CreateMeasureBuilder 

Created in NX12.0.0 

## Member Function Documentation

## ◆ Direction1() [1/2]

NXOpen.AnimationDesigner.MeasureBuilder.Direction1
(
self — )

Getter for property: (NXOpen.Direction) Direction1 Returns the first direction used to measure the angle with the second direction. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Direction 

## ◆ Direction1() [2/2]

NXOpen.AnimationDesigner.MeasureBuilder.Direction1
(
self,

direction1 )

Setter for property: (NXOpen.Direction) Direction1. 

Sets the first direction used to measure the angle with the second direction.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ Direction2() [1/2]

NXOpen.AnimationDesigner.MeasureBuilder.Direction2
(
self — )

Getter for property: (NXOpen.Direction) Direction2 Returns the second direction used to measure the angle with the first direction. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Direction 

## ◆ Direction2() [2/2]

NXOpen.AnimationDesigner.MeasureBuilder.Direction2
(
self,

direction2 )

Setter for property: (NXOpen.Direction) Direction2. 

Sets the second direction used to measure the angle with the first direction.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ List1()

NXOpen.AnimationDesigner.MeasureBuilder.List1
(
self — )

Getter for property: (NXOpen.SelectNXObjectList) List1 Returns the first object list used to be measured with the second object list. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.SelectNXObjectList 

## ◆ List2()

NXOpen.AnimationDesigner.MeasureBuilder.List2
(
self — )

Getter for property: (NXOpen.SelectNXObjectList) List2 Returns the second object list used to be measured with the first object list. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.SelectNXObjectList 

## ◆ MeasureType() [1/2]

NXOpen.AnimationDesigner.MeasureBuilder.MeasureType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.MeasureBuilder.MeasureTypes) MeasureType Returns the measure type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
MeasureBuilder.MeasureTypes 

## ◆ MeasureType() [2/2]

NXOpen.AnimationDesigner.MeasureBuilder.MeasureType
(
self,

measureType )

Setter for property: (NXOpen.AnimationDesigner.MeasureBuilder.MeasureTypes) MeasureType. 

Sets the measure type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ Motor()

NXOpen.AnimationDesigner.MeasureBuilder.Motor
(
self — )

Getter for property: (NXOpen.SelectNXObject) Motor Returns the motor. 

This can be a NXOpen::AnimationDesigner::SpeedMotor or NXOpen::AnimationDesigner::PositionMotor .

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ MotorParameterType() [1/2]

NXOpen.AnimationDesigner.MeasureBuilder.MotorParameterType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.MeasureBuilder.MotorParameterTypes) MotorParameterType Returns the motor parameter type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
MeasureBuilder.MotorParameterTypes 

## ◆ MotorParameterType() [2/2]

NXOpen.AnimationDesigner.MeasureBuilder.MotorParameterType
(
self,

motorParameterType )

Setter for property: (NXOpen.AnimationDesigner.MeasureBuilder.MotorParameterTypes) MotorParameterType. 

Sets the motor parameter type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ Name() [1/2]

NXOpen.AnimationDesigner.MeasureBuilder.Name
(
self — )

Getter for property: (str) Name Returns the name. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
str 

## ◆ Name() [2/2]

NXOpen.AnimationDesigner.MeasureBuilder.Name
(
self,

name )

Setter for property: (str) Name. 

Sets the name.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ UseVector() [1/2]

NXOpen.AnimationDesigner.MeasureBuilder.UseVector
(
self — )

Getter for property: (bool) UseVector Returns the use vector flag. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1980.0.0 

Returns
bool 

## ◆ UseVector() [2/2]

NXOpen.AnimationDesigner.MeasureBuilder.UseVector
(
self,

useVector )

Setter for property: (bool) UseVector. 

Sets the use vector flag.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1980.0.0 

## ◆ Vector() [1/2]

NXOpen.AnimationDesigner.MeasureBuilder.Vector
(
self — )

Getter for property: (NXOpen.Direction) Vector Returns the vector. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1980.0.0 

Returns
NXOpen.Direction 

## ◆ Vector() [2/2]

NXOpen.AnimationDesigner.MeasureBuilder.Vector
(
self,

vector )

Setter for property: (NXOpen.Direction) Vector. 

Sets the vector.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1980.0.0 

## Member Data Documentation

## ◆ MeasureBuilderMeasureTypes

NXOpen.AnimationDesigner.MeasureBuilder.MeasureBuilderMeasureTypes = MeasureBuilder.MeasureTypes

NXOpen.AnimationDesigner.MeasureBuilderMeasureTypes is an alias for NXOpen.AnimationDesigner.MeasureBuilder.MeasureTypes 

## ◆ MeasureBuilderMotorParameterTypes

NXOpen.AnimationDesigner.MeasureBuilder.MeasureBuilderMotorParameterTypes = MeasureBuilder.MotorParameterTypes

NXOpen.AnimationDesigner.MeasureBuilderMotorParameterTypes is an alias for NXOpen.AnimationDesigner.MeasureBuilder.MotorParameterTypes 

Copyright 2025 Siemens
