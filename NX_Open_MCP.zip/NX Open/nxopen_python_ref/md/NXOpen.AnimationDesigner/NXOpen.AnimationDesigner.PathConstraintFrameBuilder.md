# NXOpen.AnimationDesigner.PathConstraintFrameBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00117.html>

## Classes

class — CurveTypes

the curve types 

Enumerator — Comment

Line — line

Spline — spline

More...

Copyright 2025 Siemens
