# NXOpen.AnimationDesigner.JointJoggerBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10709.html>

Represents a NXOpen::AnimationDesigner::JointJoggerBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.JointJoggerBuilder:

## Public Member Functions

AddJointData (self, joint)

Adds the joint data. 

CaptureArrangement (self)

Getter for property: (bool) CaptureArrangement Returns the capture arrangement option. 

CaptureArrangement (self, captureArrangement)

Setter for property: (bool) CaptureArrangement. 

EditJointAngle (self, joint, angleValue)

Edits the joint angle. 

EditJointDistance (self, joint, distanceValue)

Edits the joint distance. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

RemoveJointData (self, joint)

Removes the joint data. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::AnimationDesigner::JointJoggerBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::JointJoggerCollection::CreateJointJoggerBuilder 

Created in NX1872.0.0 

## Member Function Documentation

## ◆ AddJointData()

NXOpen.AnimationDesigner.JointJoggerBuilder.AddJointData
(
self,

joint )

Adds the joint data. 

Created in NX1872.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

joint — (NXOpen.NXObject) RevoluteJoint or SliderJoint or CylindricalJoint or ScrewJoint

## ◆ CaptureArrangement() [1/2]

NXOpen.AnimationDesigner.JointJoggerBuilder.CaptureArrangement
(
self — )

Getter for property: (bool) CaptureArrangement Returns the capture arrangement option. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1953.0.0 

Returns
bool 

## ◆ CaptureArrangement() [2/2]

NXOpen.AnimationDesigner.JointJoggerBuilder.CaptureArrangement
(
self,

captureArrangement )

Setter for property: (bool) CaptureArrangement. 

Sets the capture arrangement option.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1953.0.0 

## ◆ EditJointAngle()

NXOpen.AnimationDesigner.JointJoggerBuilder.EditJointAngle
(
self,

joint,

angleValue )

Edits the joint angle. 

Created in NX1872.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

joint — (NXOpen.NXObject) RevoluteJoint or CylindricalJoint

angleValue — (float)

## ◆ EditJointDistance()

NXOpen.AnimationDesigner.JointJoggerBuilder.EditJointDistance
(
self,

joint,

distanceValue )

Edits the joint distance. 

Created in NX1872.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

joint — (NXOpen.NXObject) SliderJoint or CylindricalJoint or ScrewJoint

distanceValue — (float)

## ◆ Name() [1/2]

NXOpen.AnimationDesigner.JointJoggerBuilder.Name
(
self — )

Getter for property: (str) Name Returns the name. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1872.0.0 

Returns
str 

## ◆ Name() [2/2]

NXOpen.AnimationDesigner.JointJoggerBuilder.Name
(
self,

name )

Setter for property: (str) Name. 

Sets the name.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1872.0.0 

## ◆ RemoveJointData()

NXOpen.AnimationDesigner.JointJoggerBuilder.RemoveJointData
(
self,

joint )

Removes the joint data. 

Created in NX1872.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

joint — (NXOpen.NXObject) RevoluteJoint or SliderJoint or CylindricalJoint or ScrewJoint

Copyright 2025 Siemens
