# NXOpen.AnimationDesigner.InverseKinematicsBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00113.html>

## Classes

class — AlignTypes

the inverse kinematics vector alignment types. More...

class — BodyTypes

the inverse kinematics body types. More...

class — Result

Specifies the result of the inverse kinematics solver. More...

Copyright 2025 Siemens
