# NXOpen.AnimationDesigner.MechanicalCamBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10741.html>

Represents a NXOpen::AnimationDesigner::MechanicalCamBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.MechanicalCamBuilder:

## Public Member Functions

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

ColorOption (self)

Getter for property: (NXOpen.AnimationDesigner.MechanicalCamBuilder.ColorOptions) ColorOption Returns the color option. 

ColorOption (self, colorOption)

Setter for property: (NXOpen.AnimationDesigner.MechanicalCamBuilder.ColorOptions) ColorOption. 

FollowerAxis (self)

Getter for property: (NXOpen.SelectNXObject) FollowerAxis Returns the follower axis joint. 

FollowerFaces (self)

Getter for property: (NXOpen.SelectNXObjectList) FollowerFaces Returns the follower faces. 

MasterAxis (self)

Getter for property: (NXOpen.SelectNXObject) MasterAxis Returns the master axis joint. 

MasterFaces (self)

Getter for property: (NXOpen.SelectNXObjectList) MasterFaces Returns the master faces. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

MechanicalCamBuilderColorOptions = MechanicalCamBuilder.ColorOptions

NXOpen.AnimationDesigner.MechanicalCamBuilderColorOptions is an alias for NXOpen.AnimationDesigner.MechanicalCamBuilder.ColorOptions 

## Detailed Description

Represents a NXOpen::AnimationDesigner::MechanicalCamBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::MechanicalCamCollection::CreateMechanicalCamBuilder 

Created in NX12.0.0 

## Member Function Documentation

## ◆ Color() [1/2]

NXOpen.AnimationDesigner.MechanicalCamBuilder.Color
(
self — )

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

Returns
NXOpen.NXColor 

## ◆ Color() [2/2]

NXOpen.AnimationDesigner.MechanicalCamBuilder.Color
(
self,

color )

Setter for property: (NXOpen.NXColor) Color. 

Sets the color.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

## ◆ ColorOption() [1/2]

NXOpen.AnimationDesigner.MechanicalCamBuilder.ColorOption
(
self — )

Getter for property: (NXOpen.AnimationDesigner.MechanicalCamBuilder.ColorOptions) ColorOption Returns the color option. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

Returns
MechanicalCamBuilder.ColorOptions 

## ◆ ColorOption() [2/2]

NXOpen.AnimationDesigner.MechanicalCamBuilder.ColorOption
(
self,

colorOption )

Setter for property: (NXOpen.AnimationDesigner.MechanicalCamBuilder.ColorOptions) ColorOption. 

Sets the color option.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2312.0.0 

## ◆ FollowerAxis()

NXOpen.AnimationDesigner.MechanicalCamBuilder.FollowerAxis
(
self — )

Getter for property: (NXOpen.SelectNXObject) FollowerAxis Returns the follower axis joint. 

This can be a NXOpen::AnimationDesigner::RevoluteJoint or NXOpen::AnimationDesigner::SliderJoint

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ FollowerFaces()

NXOpen.AnimationDesigner.MechanicalCamBuilder.FollowerFaces
(
self — )

Getter for property: (NXOpen.SelectNXObjectList) FollowerFaces Returns the follower faces. 

This can be a NXOpen::Face .

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.SelectNXObjectList 

## ◆ MasterAxis()

NXOpen.AnimationDesigner.MechanicalCamBuilder.MasterAxis
(
self — )

Getter for property: (NXOpen.SelectNXObject) MasterAxis Returns the master axis joint. 

This can be a NXOpen::AnimationDesigner::RevoluteJoint or NXOpen::AnimationDesigner::SliderJoint

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ MasterFaces()

NXOpen.AnimationDesigner.MechanicalCamBuilder.MasterFaces
(
self — )

Getter for property: (NXOpen.SelectNXObjectList) MasterFaces Returns the master faces. 

This can be a NXOpen::Face .

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.SelectNXObjectList 

## ◆ Name() [1/2]

NXOpen.AnimationDesigner.MechanicalCamBuilder.Name
(
self — )

Getter for property: (str) Name Returns the name. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
str 

## ◆ Name() [2/2]

NXOpen.AnimationDesigner.MechanicalCamBuilder.Name
(
self,

name )

Setter for property: (str) Name. 

Sets the name.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## Member Data Documentation

## ◆ MechanicalCamBuilderColorOptions

NXOpen.AnimationDesigner.MechanicalCamBuilder.MechanicalCamBuilderColorOptions = MechanicalCamBuilder.ColorOptions

NXOpen.AnimationDesigner.MechanicalCamBuilderColorOptions is an alias for NXOpen.AnimationDesigner.MechanicalCamBuilder.ColorOptions 

Copyright 2025 Siemens
