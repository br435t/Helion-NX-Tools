# NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10621.html>

Represents a NXOpen::AnimationDesigner::FlexibleCableAttachmentBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder:

## Public Member Functions

Attachment (self)

Getter for property: (NXOpen.SelectNXObject) Attachment Returns. 

AttachmentFrame (self)

Getter for property: (NXOpen.CoordinateSystem) AttachmentFrame Returns. 

AttachmentFrame (self, attachmentFrame)

Setter for property: (NXOpen.CoordinateSystem) AttachmentFrame. 

AttachmentType (self)

Getter for property: (NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.AttachmentTypes) AttachmentType Returns. 

AttachmentType (self, attachmentType)

Setter for property: (NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.AttachmentTypes) AttachmentType. 

DistanceFromStart (self)

Getter for property: (NXOpen.Expression) DistanceFromStart Returns. 

MaxRetractedLength (self)

Getter for property: (NXOpen.Expression) MaxRetractedLength Returns. 

MinRetractedLength (self)

Getter for property: (NXOpen.Expression) MinRetractedLength Returns. 

RotationAxis (self)

Getter for property: (NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.RotationAxes) RotationAxis Returns. 

RotationAxis (self, rotationAxis)

Setter for property: (NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.RotationAxes) RotationAxis. 

SecondaryAttachmentFrame (self)

Getter for property: (NXOpen.CoordinateSystem) SecondaryAttachmentFrame Returns. 

SecondaryAttachmentFrame (self, secondaryAttachmentFrame)

Setter for property: (NXOpen.CoordinateSystem) SecondaryAttachmentFrame. 

SecondaryDistanceFromStart (self)

Getter for property: (NXOpen.Expression) SecondaryDistanceFromStart Returns. 

SpringConstant (self)

Getter for property: (NXOpen.Expression) SpringConstant Returns. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

FlexibleCableAttachmentBuilderAttachmentTypes = FlexibleCableAttachmentBuilder.AttachmentTypes

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilderAttachmentTypes is an alias for NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.AttachmentTypes 

FlexibleCableAttachmentBuilderRotationAxes = FlexibleCableAttachmentBuilder.RotationAxes

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilderRotationAxes is an alias for NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.RotationAxes 

## Detailed Description

Represents a NXOpen::AnimationDesigner::FlexibleCableAttachmentBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::FlexibleCableCollection::CreateFlexibleCableAttachmentBuilder 

Created in NX2306.0.0 

## Member Function Documentation

## ◆ Attachment()

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.Attachment
(
self — )

Getter for property: (NXOpen.SelectNXObject) Attachment Returns. 

the atttachment.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ AttachmentFrame() [1/2]

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.AttachmentFrame
(
self — )

Getter for property: (NXOpen.CoordinateSystem) AttachmentFrame Returns. 

the attachment frame.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.CoordinateSystem 

## ◆ AttachmentFrame() [2/2]

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.AttachmentFrame
(
self,

attachmentFrame )

Setter for property: (NXOpen.CoordinateSystem) AttachmentFrame. 

Sets the attachment frame.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ AttachmentType() [1/2]

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.AttachmentType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.AttachmentTypes) AttachmentType Returns. 

the attachment type.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
FlexibleCableAttachmentBuilder.AttachmentTypes 

## ◆ AttachmentType() [2/2]

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.AttachmentType
(
self,

attachmentType )

Setter for property: (NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.AttachmentTypes) AttachmentType. 

Sets the attachment type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ DistanceFromStart()

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.DistanceFromStart
(
self — )

Getter for property: (NXOpen.Expression) DistanceFromStart Returns. 

the distance along cable between the attachment point and the cable start point.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ MaxRetractedLength()

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.MaxRetractedLength
(
self — )

Getter for property: (NXOpen.Expression) MaxRetractedLength Returns. 

the maximum length of cable that can be retracted.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ MinRetractedLength()

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.MinRetractedLength
(
self — )

Getter for property: (NXOpen.Expression) MinRetractedLength Returns. 

the minimum length of cable that can be retracted.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ RotationAxis() [1/2]

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.RotationAxis
(
self — )

Getter for property: (NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.RotationAxes) RotationAxis Returns. 

the attachment rotation axis.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
FlexibleCableAttachmentBuilder.RotationAxes 

## ◆ RotationAxis() [2/2]

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.RotationAxis
(
self,

rotationAxis )

Setter for property: (NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.RotationAxes) RotationAxis. 

Sets the attachment rotation axis.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ SecondaryAttachmentFrame() [1/2]

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.SecondaryAttachmentFrame
(
self — )

Getter for property: (NXOpen.CoordinateSystem) SecondaryAttachmentFrame Returns. 

the secondary attachment frame.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.CoordinateSystem 

## ◆ SecondaryAttachmentFrame() [2/2]

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.SecondaryAttachmentFrame
(
self,

secondaryAttachmentFrame )

Setter for property: (NXOpen.CoordinateSystem) SecondaryAttachmentFrame. 

Sets the secondary attachment frame.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ SecondaryDistanceFromStart()

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.SecondaryDistanceFromStart
(
self — )

Getter for property: (NXOpen.Expression) SecondaryDistanceFromStart Returns. 

the distance along cable between the secondary attachment point and the cable start point.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ SpringConstant()

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.SpringConstant
(
self — )

Getter for property: (NXOpen.Expression) SpringConstant Returns. 

the physical constant that determines how hard or easy it is to move the attachment when retracting or extending the cable.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## Member Data Documentation

## ◆ FlexibleCableAttachmentBuilderAttachmentTypes

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.FlexibleCableAttachmentBuilderAttachmentTypes = FlexibleCableAttachmentBuilder.AttachmentTypes

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilderAttachmentTypes is an alias for NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.AttachmentTypes 

## ◆ FlexibleCableAttachmentBuilderRotationAxes

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.FlexibleCableAttachmentBuilderRotationAxes = FlexibleCableAttachmentBuilder.RotationAxes

NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilderRotationAxes is an alias for NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder.RotationAxes 

Copyright 2025 Siemens
