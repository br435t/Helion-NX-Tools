# NXOpen.AnimationDesigner.AnimatedExplodeBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10433.html>

Represents a NXOpen::AnimationDesigner::AnimatedExplodeBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.AnimatedExplodeBuilder:

## Public Member Functions

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

ColorOption (self)

Getter for property: (NXOpen.AnimationDesigner.AnimatedExplodeBuilder.ColorOptions) ColorOption Returns the color option. 

ColorOption (self, colorOption)

Setter for property: (NXOpen.AnimationDesigner.AnimatedExplodeBuilder.ColorOptions) ColorOption. 

ColorPickerFlowLineColor (self)

Getter for property: (NXOpen.NXColor) ColorPickerFlowLineColor Returns the flow line color. 

ColorPickerFlowLineColor (self, color)

Setter for property: (NXOpen.NXColor) ColorPickerFlowLineColor. 

CreationType (self)

Getter for property: (NXOpen.AnimationDesigner.AnimatedExplodeBuilder.CreationTypes) CreationType Returns the creation type. 

CreationType (self, creationType)

Setter for property: (NXOpen.AnimationDesigner.AnimatedExplodeBuilder.CreationTypes) CreationType. 

DefineFlowLineStyle (self)

Getter for property: (bool) DefineFlowLineStyle Returns the define flow line style. 

DefineFlowLineStyle (self, defineflowlinestyle)

Setter for property: (bool) DefineFlowLineStyle. 

DeleteStep (self, pos)

Deletes the step. 

DrawFlowLinePerObject (self)

Getter for property: (bool) DrawFlowLinePerObject Returns the option for enable draw flow line per object. 

DrawFlowLinePerObject (self, drawflowlineperobject)

Setter for property: (bool) DrawFlowLinePerObject. 

GetStepCount (self)

Gets the step count. 

InsertStep (self, pos, startTime, duration, distance, spin, angle, dir)

Inserts a step. 

LineFontFlowLineFont (self)

Getter for property: (int) LineFontFlowLineFont Returns the flow line font. 

LineFontFlowLineFont (self, font)

Setter for property: (int) LineFontFlowLineFont. 

LineWidthFlowLineWidth (self)

Getter for property: (int) LineWidthFlowLineWidth Returns the flow line width. 

LineWidthFlowLineWidth (self, width)

Setter for property: (int) LineWidthFlowLineWidth. 

MirrorSteps (self, steps, mirror_time)

Mirrors the steps. 

MotionObject (self)

Getter for property: (NXOpen.SelectNXObjectList) MotionObject Returns the object to animated explode. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

SetStepAngle (self, pos, angle)

Sets the step angle. 

SetStepDirection (self, pos, dir)

Sets the step direction. 

SetStepDistance (self, pos, distance)

Sets the step distance. 

SetStepDuration (self, pos, duration)

Sets the step duration. 

SetStepName (self, pos, name)

Sets the step name. 

SetStepSpin (self, pos, spin)

Sets the step spin. 

SetStepStartTime (self, pos, start_time)

Sets the step start time. 

SetStepTargetPosition (self, pos, rotation)

Sets the step rotation. 

SetStepUseOrigin (self, pos, useOrigin)

Sets the step flag use origin. 

ShowFlowLineInSimulation (self)

Getter for property: (bool) ShowFlowLineInSimulation Returns the use specified flow line. 

ShowFlowLineInSimulation (self, showflowlineinsimulation)

Setter for property: (bool) ShowFlowLineInSimulation. 

SplitStep (self, pos, split_time)

Splits the step with the split time. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

AnimatedExplodeBuilderColorOptions = AnimatedExplodeBuilder.ColorOptions

NXOpen.AnimationDesigner.AnimatedExplodeBuilderColorOptions is an alias for NXOpen.AnimationDesigner.AnimatedExplodeBuilder.ColorOptions 

AnimatedExplodeBuilderCreationTypes = AnimatedExplodeBuilder.CreationTypes

NXOpen.AnimationDesigner.AnimatedExplodeBuilderCreationTypes is an alias for NXOpen.AnimationDesigner.AnimatedExplodeBuilder.CreationTypes 

## Detailed Description

Represents a NXOpen::AnimationDesigner::AnimatedExplodeBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::AnimatedExplodeCollection::CreateAnimatedExplodeBuilder 

Created in NX1847.0.0 

## Member Function Documentation

## ◆ Color() [1/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.Color
(
self — )

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
NXOpen.NXColor 

## ◆ Color() [2/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.Color
(
self,

color )

Setter for property: (NXOpen.NXColor) Color. 

Sets the color.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

## ◆ ColorOption() [1/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.ColorOption
(
self — )

Getter for property: (NXOpen.AnimationDesigner.AnimatedExplodeBuilder.ColorOptions) ColorOption Returns the color option. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
AnimatedExplodeBuilder.ColorOptions 

## ◆ ColorOption() [2/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.ColorOption
(
self,

colorOption )

Setter for property: (NXOpen.AnimationDesigner.AnimatedExplodeBuilder.ColorOptions) ColorOption. 

Sets the color option.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

## ◆ ColorPickerFlowLineColor() [1/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.ColorPickerFlowLineColor
(
self — )

Getter for property: (NXOpen.NXColor) ColorPickerFlowLineColor Returns the flow line color. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

Returns
NXOpen.NXColor 

## ◆ ColorPickerFlowLineColor() [2/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.ColorPickerFlowLineColor
(
self,

color )

Setter for property: (NXOpen.NXColor) ColorPickerFlowLineColor. 

Sets the flow line color.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

## ◆ CreationType() [1/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.CreationType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.AnimatedExplodeBuilder.CreationTypes) CreationType Returns the creation type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
AnimatedExplodeBuilder.CreationTypes 

## ◆ CreationType() [2/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.CreationType
(
self,

creationType )

Setter for property: (NXOpen.AnimationDesigner.AnimatedExplodeBuilder.CreationTypes) CreationType. 

Sets the creation type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

## ◆ DefineFlowLineStyle() [1/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.DefineFlowLineStyle
(
self — )

Getter for property: (bool) DefineFlowLineStyle Returns the define flow line style. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

Returns
bool 

## ◆ DefineFlowLineStyle() [2/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.DefineFlowLineStyle
(
self,

defineflowlinestyle )

Setter for property: (bool) DefineFlowLineStyle. 

Sets the define flow line style.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

## ◆ DeleteStep()

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.DeleteStep
(
self,

pos )

Deletes the step. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

pos — (int)

## ◆ DrawFlowLinePerObject() [1/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.DrawFlowLinePerObject
(
self — )

Getter for property: (bool) DrawFlowLinePerObject Returns the option for enable draw flow line per object. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2406.0.0 

Returns
bool 

## ◆ DrawFlowLinePerObject() [2/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.DrawFlowLinePerObject
(
self,

drawflowlineperobject )

Setter for property: (bool) DrawFlowLinePerObject. 

Sets the option for enable draw flow line per object.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2406.0.0 

## ◆ GetStepCount()

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.GetStepCount
(
self — )

Gets the step count. 

Returns
count (int): .

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer") 

## ◆ InsertStep()

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.InsertStep
(
self,

pos,

startTime,

duration,

distance,

spin,

angle,

dir )

Inserts a step. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

pos — (int)

startTime — (float)

duration — (float)

distance — (float)

spin — (float)

angle — (float)

dir — (NXOpen.Direction)

## ◆ LineFontFlowLineFont() [1/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.LineFontFlowLineFont
(
self — )

Getter for property: (int) LineFontFlowLineFont Returns the flow line font. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

Returns
int 

## ◆ LineFontFlowLineFont() [2/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.LineFontFlowLineFont
(
self,

font )

Setter for property: (int) LineFontFlowLineFont. 

Sets the flow line font.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

## ◆ LineWidthFlowLineWidth() [1/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.LineWidthFlowLineWidth
(
self — )

Getter for property: (int) LineWidthFlowLineWidth Returns the flow line width. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

Returns
int 

## ◆ LineWidthFlowLineWidth() [2/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.LineWidthFlowLineWidth
(
self,

width )

Setter for property: (int) LineWidthFlowLineWidth. 

Sets the flow line width.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

## ◆ MirrorSteps()

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.MirrorSteps
(
self,

steps,

mirror_time )

Mirrors the steps. 

Returns
newSteps (List[int]): .

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

steps — (List[int])

mirror_time — (float)

## ◆ MotionObject()

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.MotionObject
(
self — )

Getter for property: (NXOpen.SelectNXObjectList) MotionObject Returns the object to animated explode. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
NXOpen.SelectNXObjectList 

## ◆ Name() [1/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.Name
(
self — )

Getter for property: (str) Name Returns the name. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
str 

## ◆ Name() [2/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.Name
(
self,

name )

Setter for property: (str) Name. 

Sets the name.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

## ◆ SetStepAngle()

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.SetStepAngle
(
self,

pos,

angle )

Sets the step angle. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

pos — (int)

angle — (float)

## ◆ SetStepDirection()

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.SetStepDirection
(
self,

pos,

dir )

Sets the step direction. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

pos — (int)

dir — (NXOpen.Direction)

## ◆ SetStepDistance()

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.SetStepDistance
(
self,

pos,

distance )

Sets the step distance. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

pos — (int)

distance — (float)

## ◆ SetStepDuration()

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.SetStepDuration
(
self,

pos,

duration )

Sets the step duration. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

pos — (int)

duration — (float)

## ◆ SetStepName()

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.SetStepName
(
self,

pos,

name )

Sets the step name. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

pos — (int)

name — (str)

## ◆ SetStepSpin()

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.SetStepSpin
(
self,

pos,

spin )

Sets the step spin. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

pos — (int)

spin — (float)

## ◆ SetStepStartTime()

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.SetStepStartTime
(
self,

pos,

start_time )

Sets the step start time. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

pos — (int)

start_time — (float)

## ◆ SetStepTargetPosition()

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.SetStepTargetPosition
(
self,

pos,

rotation )

Sets the step rotation. 

Created in NX2206.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

pos — (int)

rotation — (NXOpen.Matrix4x4)

## ◆ SetStepUseOrigin()

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.SetStepUseOrigin
(
self,

pos,

useOrigin )

Sets the step flag use origin. 

Created in NX1980.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

pos — (int)

useOrigin — (bool)

## ◆ ShowFlowLineInSimulation() [1/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.ShowFlowLineInSimulation
(
self — )

Getter for property: (bool) ShowFlowLineInSimulation Returns the use specified flow line. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

Returns
bool 

## ◆ ShowFlowLineInSimulation() [2/2]

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.ShowFlowLineInSimulation
(
self,

showflowlineinsimulation )

Setter for property: (bool) ShowFlowLineInSimulation. 

Sets the use specified flow line.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2212.0.0 

## ◆ SplitStep()

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.SplitStep
(
self,

pos,

split_time )

Splits the step with the split time. 

Returns
splited (bool): .

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

pos — (int)

split_time — (float)

## Member Data Documentation

## ◆ AnimatedExplodeBuilderColorOptions

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.AnimatedExplodeBuilderColorOptions = AnimatedExplodeBuilder.ColorOptions

NXOpen.AnimationDesigner.AnimatedExplodeBuilderColorOptions is an alias for NXOpen.AnimationDesigner.AnimatedExplodeBuilder.ColorOptions 

## ◆ AnimatedExplodeBuilderCreationTypes

NXOpen.AnimationDesigner.AnimatedExplodeBuilder.AnimatedExplodeBuilderCreationTypes = AnimatedExplodeBuilder.CreationTypes

NXOpen.AnimationDesigner.AnimatedExplodeBuilderCreationTypes is an alias for NXOpen.AnimationDesigner.AnimatedExplodeBuilder.CreationTypes 

Copyright 2025 Siemens
