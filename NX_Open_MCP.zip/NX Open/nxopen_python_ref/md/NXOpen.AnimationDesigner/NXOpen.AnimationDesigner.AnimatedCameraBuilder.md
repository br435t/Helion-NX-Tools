# NXOpen.AnimationDesigner.AnimatedCameraBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00102.html>

## Classes

class — CameraAxisTypes

the camera axis types. More...

class — CameraModeTypes

the camera mode types. More...

class — LookAtDirectionTypes

the look at direction types. More...

class — TransitionModeTypes

the transition mode types. More...

Copyright 2025 Siemens
