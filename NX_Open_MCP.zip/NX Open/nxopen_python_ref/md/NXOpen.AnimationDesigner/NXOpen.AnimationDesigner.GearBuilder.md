# NXOpen.AnimationDesigner.GearBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00112.html>

## Classes

class — GearType

Definitions of gear type 

Enumerator — Comment

General — general gear

Chainbelt — chain belt

Cable — cable

More...

Copyright 2025 Siemens
