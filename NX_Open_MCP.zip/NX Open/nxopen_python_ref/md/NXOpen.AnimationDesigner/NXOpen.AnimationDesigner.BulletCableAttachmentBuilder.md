# NXOpen.AnimationDesigner.BulletCableAttachmentBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10509.html>

Represents a NXOpen::AnimationDesigner::BulletCableAttachmentBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.BulletCableAttachmentBuilder:

## Public Member Functions

Anchor (self)

Getter for property: (NXOpen.Point) Anchor Returns. 

Anchor (self, anchor)

Setter for property: (NXOpen.Point) Anchor. 

Attachment (self)

Getter for property: (NXOpen.SelectNXObject) Attachment Returns. 

Direction (self)

Getter for property: (NXOpen.Direction) Direction Returns. 

Direction (self, direction)

Setter for property: (NXOpen.Direction) Direction. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Detailed Description

Represents a NXOpen::AnimationDesigner::BulletCableAttachmentBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::BulletCableCollection::CreateBulletCableAttachmentBuilder 

Created in NX2306.0.0 

## Member Function Documentation

## ◆ Anchor() [1/2]

NXOpen.AnimationDesigner.BulletCableAttachmentBuilder.Anchor
(
self — )

Getter for property: (NXOpen.Point) Anchor Returns. 

the anchor point.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Point 

## ◆ Anchor() [2/2]

NXOpen.AnimationDesigner.BulletCableAttachmentBuilder.Anchor
(
self,

anchor )

Setter for property: (NXOpen.Point) Anchor. 

Sets the anchor point.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ Attachment()

NXOpen.AnimationDesigner.BulletCableAttachmentBuilder.Attachment
(
self — )

Getter for property: (NXOpen.SelectNXObject) Attachment Returns. 

the atttachment.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ Direction() [1/2]

NXOpen.AnimationDesigner.BulletCableAttachmentBuilder.Direction
(
self — )

Getter for property: (NXOpen.Direction) Direction Returns. 

the direction vector.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Direction 

## ◆ Direction() [2/2]

NXOpen.AnimationDesigner.BulletCableAttachmentBuilder.Direction
(
self,

direction )

Setter for property: (NXOpen.Direction) Direction. 

Sets the direction vector.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Copyright 2025 Siemens
