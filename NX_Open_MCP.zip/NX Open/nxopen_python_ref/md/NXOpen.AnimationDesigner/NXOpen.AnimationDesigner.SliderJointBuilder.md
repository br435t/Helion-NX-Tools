# NXOpen.AnimationDesigner.SliderJointBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10977.html>

Represents a NXOpen::AnimationDesigner::SliderJointBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.SliderJointBuilder:

## Public Member Functions

EnableLowerLimit (self)

Getter for property: (bool) EnableLowerLimit Returns the lower limit option. 

EnableLowerLimit (self, enable)

Setter for property: (bool) EnableLowerLimit. 

EnableUpperLimit (self)

Getter for property: (bool) EnableUpperLimit Returns the upper limit option. 

EnableUpperLimit (self, enable)

Setter for property: (bool) EnableUpperLimit. 

LowerLimit (self)

Getter for property: (NXOpen.Expression) LowerLimit Returns the lower limit. 

Offset (self)

Getter for property: (NXOpen.Expression) Offset Returns the offset value. 

UpperLimit (self)

Getter for property: (NXOpen.Expression) UpperLimit Returns the upper limit. 

Vector (self)

Getter for property: (NXOpen.Direction) Vector Returns the vector. 

Vector (self, specifyVector)

Setter for property: (NXOpen.Direction) Vector. 

Public Member Functions inherited from NXOpen.AnimationDesigner.PhysicsJointBuilder

AttachmentList (self)

Getter for property: (NXOpen.SelectNXObjectList) AttachmentList Returns the attachment list for a Joint. 

BaseList (self)

Getter for property: (NXOpen.SelectNXObjectList) BaseList Returns the base list for a Joint. 

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

ColorOption (self)

Getter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions) ColorOption Returns the color options. 

ColorOption (self, colorOption)

Setter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions) ColorOption. 

MotionType (self)

Getter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes) MotionType Returns the motion type. 

MotionType (self, motionType)

Setter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes) MotionType. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.AnimationDesigner.PhysicsJointBuilder

PhysicsJointBuilderColorOptions = PhysicsJointBuilder.ColorOptions

NXOpen.AnimationDesigner.PhysicsJointBuilderColorOptions is an alias for NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions 

PhysicsJointBuilderMotionTypes = PhysicsJointBuilder.MotionTypes

NXOpen.AnimationDesigner.PhysicsJointBuilderMotionTypes is an alias for NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes 

## Detailed Description

Represents a NXOpen::AnimationDesigner::SliderJointBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::SliderJointCollection::CreateSliderJointBuilder 

Created in NX12.0.0 

## Member Function Documentation

## ◆ EnableLowerLimit() [1/2]

NXOpen.AnimationDesigner.SliderJointBuilder.EnableLowerLimit
(
self — )

Getter for property: (bool) EnableLowerLimit Returns the lower limit option. 

If the enable is true, then the joint will be applied a lower limit in movement.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
bool 

## ◆ EnableLowerLimit() [2/2]

NXOpen.AnimationDesigner.SliderJointBuilder.EnableLowerLimit
(
self,

enable )

Setter for property: (bool) EnableLowerLimit. 

Sets the lower limit option. If the enable is true, then the joint will be applied a lower limit in movement.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ EnableUpperLimit() [1/2]

NXOpen.AnimationDesigner.SliderJointBuilder.EnableUpperLimit
(
self — )

Getter for property: (bool) EnableUpperLimit Returns the upper limit option. 

If the enable is true, then the joint will be applied an upper limit in movement.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
bool 

## ◆ EnableUpperLimit() [2/2]

NXOpen.AnimationDesigner.SliderJointBuilder.EnableUpperLimit
(
self,

enable )

Setter for property: (bool) EnableUpperLimit. 

Sets the upper limit option. If the enable is true, then the joint will be applied an upper limit in movement.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ LowerLimit()

NXOpen.AnimationDesigner.SliderJointBuilder.LowerLimit
(
self — )

Getter for property: (NXOpen.Expression) LowerLimit Returns the lower limit. 

The lower limit setup for joint movement.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ Offset()

NXOpen.AnimationDesigner.SliderJointBuilder.Offset
(
self — )

Getter for property: (NXOpen.Expression) Offset Returns the offset value. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.2 

Returns
NXOpen.Expression 

## ◆ UpperLimit()

NXOpen.AnimationDesigner.SliderJointBuilder.UpperLimit
(
self — )

Getter for property: (NXOpen.Expression) UpperLimit Returns the upper limit. 

The upper limit setup for joint movement.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ Vector() [1/2]

NXOpen.AnimationDesigner.SliderJointBuilder.Vector
(
self — )

Getter for property: (NXOpen.Direction) Vector Returns the vector. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Direction 

## ◆ Vector() [2/2]

NXOpen.AnimationDesigner.SliderJointBuilder.Vector
(
self,

specifyVector )

Setter for property: (NXOpen.Direction) Vector. 

Sets the vector.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Copyright 2025 Siemens
