# NXOpen.AnimationDesigner.MeasureBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00114.html>

## Classes

class — MeasureTypes

the measure types. More...

class — MotorParameterTypes

the motor parameter types. More...

Copyright 2025 Siemens
