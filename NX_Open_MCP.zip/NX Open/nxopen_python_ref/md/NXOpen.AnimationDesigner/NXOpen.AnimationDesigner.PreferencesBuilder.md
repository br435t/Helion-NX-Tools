# NXOpen.AnimationDesigner.PreferencesBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00122.html>

## Classes

class — ArrangementTypes

the arrangement types. More...

class — BodyToUseForMeasureTypes

the body types to use for measure. More...

class — FlexibleFacetBodyUserDefinedLinearPrecisionInputTypes

the input type for using a length value or a percentage for kineo flexible facet body user defined linear precision. More...

class — FlowLineStyleTypes

the flow line style types. More...

class — GraphPlotTypes

the graph plot types. More...

class — KineoFlexibleFacetBodyPrecision

the kineo flexible facet body precision. More...

class — PhysicsEngines

the physics engine. More...

class — PrecisionPresetModes

the Precision Preset Mode. More...

class — RigidGroupSelectionDisplayTypes

the rigid group selection display types. More...

class — SolutionSearchScopeTypes

the solution search scope types. More...

Copyright 2025 Siemens
