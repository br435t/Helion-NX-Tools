# NXOpen.AnimationDesigner.InverseKinematicsBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10685.html>

Represents a AnimationDesigner::InverseKinematicsBuilder 

To create a new instance of this class, use NXOpen::AnimationDesigner::InverseKinematicsCollection::CreateInverseKinematicsBuilder 

More...

Inheritance diagram for NXOpen.AnimationDesigner.InverseKinematicsBuilder:

## Public Member Functions

AlignType (self)

Getter for property: (NXOpen.AnimationDesigner.InverseKinematicsBuilder.AlignTypes) AlignType Returns the option of align type for two bodies type. 

AlignType (self, alignType)

Setter for property: (NXOpen.AnimationDesigner.InverseKinematicsBuilder.AlignTypes) AlignType. 

AvoidCollision (self)

Getter for property: (bool) AvoidCollision Returns the option of avoiding collision. 

AvoidCollision (self, avoidCollision)

Setter for property: (bool) AvoidCollision. 

BodyType (self)

Getter for property: (NXOpen.AnimationDesigner.InverseKinematicsBuilder.BodyTypes) BodyType Returns the type. 

BodyType (self, type)

Setter for property: (NXOpen.AnimationDesigner.InverseKinematicsBuilder.BodyTypes) BodyType. 

EulerAngleConvention (self)

Getter for property: (NXOpen.Mechatronics.Convention) EulerAngleConvention Returns the Euler angle convention. 

EulerAngleConvention (self, type)

Setter for property: (NXOpen.Mechatronics.Convention) EulerAngleConvention. 

FirstPoint (self)

Getter for property: (NXOpen.Point) FirstPoint Returns the first point for two bodies type. 

FirstPoint (self, firstPoint)

Setter for property: (NXOpen.Point) FirstPoint. 

FirstRigidGroup (self)

Getter for property: (NXOpen.SelectNXObject) FirstRigidGroup Returns the first rigid group for two bodies type. 

FrameList (self)

Getter for property: (NXOpen.Mechatronics.FrameBuilderList) FrameList Returns the list containing the defined frames. 

GenerateTracer (self)

Getter for property: (bool) GenerateTracer Returns the option of generating tracer object. 

GenerateTracer (self, bTracer)

Setter for property: (bool) GenerateTracer. 

GetErrorPose (self)

Returns the pose that encounters error. 

GetFirstPointOrientation (self)

Gets the first point orientations for two bodies type. 

GetOrientation (self)

Gets the orientations. 

GetResult (self)

Returns the solver result. 

GetSecondPointOrientation (self)

Gets the second point orientations for two bodies type. 

GetStartPointOrientation (self)

Gets the start point orientations. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

PointTolerance (self)

Getter for property: (NXOpen.Expression) PointTolerance Returns the tolerance of point alignment for two bodies type. 

RigidGroup (self)

Getter for property: (NXOpen.SelectNXObject) RigidGroup Returns the rigid group. 

SecondPoint (self)

Getter for property: (NXOpen.Point) SecondPoint Returns the second point for two bodies type. 

SecondPoint (self, secondPoint)

Setter for property: (NXOpen.Point) SecondPoint. 

SecondRigidGroup (self)

Getter for property: (NXOpen.SelectNXObject) SecondRigidGroup Returns the second rigid group for two bodies type. 

SetFirstPointOrientation (self, startOrit)

Sets the first point orientations for two bodies type. 

SetOrientation (self, startOrit, targetOrit)

Sets the orientations. 

SetSecondPointOrientation (self, startOrit)

Sets the second point orientations for two bodies type. 

SetStartPointOrientation (self, startOrit)

Sets the start point orientations. 

StartPoint (self)

Getter for property: (NXOpen.Point) StartPoint Returns the start point. 

StartPoint (self, startPoint)

Setter for property: (NXOpen.Point) StartPoint. 

TargetPoint (self)

Getter for property: (NXOpen.Point) TargetPoint Returns the target point. 

TargetPoint (self, targetPoint)

Setter for property: (NXOpen.Point) TargetPoint. 

UpdateIk (self)

Update IK object. 

UpdateIkStatus (self)

Update IK status to out of date. 

VectorTolerance (self)

Getter for property: (NXOpen.Expression) VectorTolerance Returns the tolerance of vector alignment for two bodies type. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

InverseKinematicsBuilderAlignTypes = InverseKinematicsBuilder.AlignTypes

NXOpen.AnimationDesigner.InverseKinematicsBuilderAlignTypes is an alias for NXOpen.AnimationDesigner.InverseKinematicsBuilder.AlignTypes 

InverseKinematicsBuilderBodyTypes = InverseKinematicsBuilder.BodyTypes

NXOpen.AnimationDesigner.InverseKinematicsBuilderBodyTypes is an alias for NXOpen.AnimationDesigner.InverseKinematicsBuilder.BodyTypes 

InverseKinematicsBuilderResult = InverseKinematicsBuilder.Result

NXOpen.AnimationDesigner.InverseKinematicsBuilderResult is an alias for NXOpen.AnimationDesigner.InverseKinematicsBuilder.Result 

## Detailed Description

Represents a AnimationDesigner::InverseKinematicsBuilder 

To create a new instance of this class, use NXOpen::AnimationDesigner::InverseKinematicsCollection::CreateInverseKinematicsBuilder 

Created in NX1847.0.0 

## Member Function Documentation

## ◆ AlignType() [1/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.AlignType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.InverseKinematicsBuilder.AlignTypes) AlignType Returns the option of align type for two bodies type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
InverseKinematicsBuilder.AlignTypes 

## ◆ AlignType() [2/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.AlignType
(
self,

alignType )

Setter for property: (NXOpen.AnimationDesigner.InverseKinematicsBuilder.AlignTypes) AlignType. 

Sets the option of align type for two bodies type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ AvoidCollision() [1/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.AvoidCollision
(
self — )

Getter for property: (bool) AvoidCollision Returns the option of avoiding collision. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
bool 

## ◆ AvoidCollision() [2/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.AvoidCollision
(
self,

avoidCollision )

Setter for property: (bool) AvoidCollision. 

Sets the option of avoiding collision.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

## ◆ BodyType() [1/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.BodyType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.InverseKinematicsBuilder.BodyTypes) BodyType Returns the type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
InverseKinematicsBuilder.BodyTypes 

## ◆ BodyType() [2/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.BodyType
(
self,

type )

Setter for property: (NXOpen.AnimationDesigner.InverseKinematicsBuilder.BodyTypes) BodyType. 

Sets the type

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ EulerAngleConvention() [1/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.EulerAngleConvention
(
self — )

Getter for property: (NXOpen.Mechatronics.Convention) EulerAngleConvention Returns the Euler angle convention. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1926.0.0 

Returns
NXOpen.Mechatronics.Convention 

## ◆ EulerAngleConvention() [2/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.EulerAngleConvention
(
self,

type )

Setter for property: (NXOpen.Mechatronics.Convention) EulerAngleConvention. 

Sets the Euler angle convention.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1926.0.0 

## ◆ FirstPoint() [1/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.FirstPoint
(
self — )

Getter for property: (NXOpen.Point) FirstPoint Returns the first point for two bodies type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Point 

## ◆ FirstPoint() [2/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.FirstPoint
(
self,

firstPoint )

Setter for property: (NXOpen.Point) FirstPoint. 

Sets the first point for two bodies type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ FirstRigidGroup()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.FirstRigidGroup
(
self — )

Getter for property: (NXOpen.SelectNXObject) FirstRigidGroup Returns the first rigid group for two bodies type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ FrameList()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.FrameList
(
self — )

Getter for property: (NXOpen.Mechatronics.FrameBuilderList) FrameList Returns the list containing the defined frames. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1926.0.0 

Returns
NXOpen.Mechatronics.FrameBuilderList 

## ◆ GenerateTracer() [1/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.GenerateTracer
(
self — )

Getter for property: (bool) GenerateTracer Returns the option of generating tracer object. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1980.0.0 

Returns
bool 

## ◆ GenerateTracer() [2/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.GenerateTracer
(
self,

bTracer )

Setter for property: (bool) GenerateTracer. 

Sets the option of generating tracer object.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1980.0.0 

## ◆ GetErrorPose()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.GetErrorPose
(
self — )

Returns the pose that encounters error. 

Returns
pose (NXOpen.CoordinateSystem): .

Created in NX1926.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer") 

## ◆ GetFirstPointOrientation()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.GetFirstPointOrientation
(
self — )

Gets the first point orientations for two bodies type. 

Returns
startOrit (NXOpen.Matrix3x3): The first orientation matrix. .

Created in NX2306.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer") 

## ◆ GetOrientation()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.GetOrientation
(
self — )

Gets the orientations. 

Returns
A tuple consisting of (startOrit, targetOrit).
startOrit is: NXOpen.Matrix3x3. The start orientation matrix. .

targetOrit is: NXOpen.Matrix3x3. The target orientation matrix. .

Created in NX1847.0.0 

Deprecated
Deprecated in NX1926.0.0. Please use NXOpen::AnimationDesigner::InverseKinematicsBuilder::GetStartPointOrientation instead 

License requirements: nx_animationdesigner (" NX Animation Designer") 

## ◆ GetResult()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.GetResult
(
self — )

Returns the solver result. 

Returns
result (NXOpen.AnimationDesigner.InverseKinematicsBuilder.Result): The result of the inverse kinematics solver .

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer") 

## ◆ GetSecondPointOrientation()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.GetSecondPointOrientation
(
self — )

Gets the second point orientations for two bodies type. 

Returns
startOrit (NXOpen.Matrix3x3): The second orientation matrix. .

Created in NX2306.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer") 

## ◆ GetStartPointOrientation()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.GetStartPointOrientation
(
self — )

Gets the start point orientations. 

Returns
startOrit (NXOpen.Matrix3x3): The start orientation matrix. .

Created in NX1926.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer") 

## ◆ Name() [1/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.Name
(
self — )

Getter for property: (str) Name Returns the name. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1899.0.0 

Returns
str 

## ◆ Name() [2/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.Name
(
self,

name )

Setter for property: (str) Name. 

Sets the name.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1899.0.0 

## ◆ PointTolerance()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.PointTolerance
(
self — )

Getter for property: (NXOpen.Expression) PointTolerance Returns the tolerance of point alignment for two bodies type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## ◆ RigidGroup()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.RigidGroup
(
self — )

Getter for property: (NXOpen.SelectNXObject) RigidGroup Returns the rigid group. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ SecondPoint() [1/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.SecondPoint
(
self — )

Getter for property: (NXOpen.Point) SecondPoint Returns the second point for two bodies type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Point 

## ◆ SecondPoint() [2/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.SecondPoint
(
self,

secondPoint )

Setter for property: (NXOpen.Point) SecondPoint. 

Sets the second point for two bodies type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

## ◆ SecondRigidGroup()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.SecondRigidGroup
(
self — )

Getter for property: (NXOpen.SelectNXObject) SecondRigidGroup Returns the second rigid group for two bodies type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.SelectNXObject 

## ◆ SetFirstPointOrientation()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.SetFirstPointOrientation
(
self,

startOrit )

Sets the first point orientations for two bodies type. 

Created in NX2306.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

startOrit — (NXOpen.Matrix3x3) The first orientation matrix.

## ◆ SetOrientation()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.SetOrientation
(
self,

startOrit,

targetOrit )

Sets the orientations. 

Created in NX1847.0.0 

Deprecated
Deprecated in NX1926.0.0. Please use NXOpen::AnimationDesigner::InverseKinematicsBuilder::SetStartPointOrientation instead 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

startOrit — (NXOpen.Matrix3x3) The start orientation matrix.

targetOrit — (NXOpen.Matrix3x3) The target orientation matrix.

## ◆ SetSecondPointOrientation()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.SetSecondPointOrientation
(
self,

startOrit )

Sets the second point orientations for two bodies type. 

Created in NX2306.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

startOrit — (NXOpen.Matrix3x3) The second orientation matrix.

## ◆ SetStartPointOrientation()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.SetStartPointOrientation
(
self,

startOrit )

Sets the start point orientations. 

Created in NX1926.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

startOrit — (NXOpen.Matrix3x3) The start orientation matrix.

## ◆ StartPoint() [1/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.StartPoint
(
self — )

Getter for property: (NXOpen.Point) StartPoint Returns the start point. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
NXOpen.Point 

## ◆ StartPoint() [2/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.StartPoint
(
self,

startPoint )

Setter for property: (NXOpen.Point) StartPoint. 

Sets the start point.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

## ◆ TargetPoint() [1/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.TargetPoint
(
self — )

Getter for property: (NXOpen.Point) TargetPoint Returns the target point. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Deprecated
Deprecated in NX1926.0.0. Please use NXOpen::AnimationDesigner::InverseKinematicsBuilder::FrameList instead. 

Returns
NXOpen.Point 

## ◆ TargetPoint() [2/2]

NXOpen.AnimationDesigner.InverseKinematicsBuilder.TargetPoint
(
self,

targetPoint )

Setter for property: (NXOpen.Point) TargetPoint. 

Sets the target point.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Deprecated
Deprecated in NX1926.0.0. Please use NXOpen::AnimationDesigner::InverseKinematicsBuilder::FrameList instead. 

## ◆ UpdateIk()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.UpdateIk
(
self — )

Update IK object. 

Created in NX2212.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer") 

## ◆ UpdateIkStatus()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.UpdateIkStatus
(
self — )

Update IK status to out of date. 

Created in NX2212.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer") 

## ◆ VectorTolerance()

NXOpen.AnimationDesigner.InverseKinematicsBuilder.VectorTolerance
(
self — )

Getter for property: (NXOpen.Expression) VectorTolerance Returns the tolerance of vector alignment for two bodies type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX2306.0.0 

Returns
NXOpen.Expression 

## Member Data Documentation

## ◆ InverseKinematicsBuilderAlignTypes

NXOpen.AnimationDesigner.InverseKinematicsBuilder.InverseKinematicsBuilderAlignTypes = InverseKinematicsBuilder.AlignTypes

NXOpen.AnimationDesigner.InverseKinematicsBuilderAlignTypes is an alias for NXOpen.AnimationDesigner.InverseKinematicsBuilder.AlignTypes 

## ◆ InverseKinematicsBuilderBodyTypes

NXOpen.AnimationDesigner.InverseKinematicsBuilder.InverseKinematicsBuilderBodyTypes = InverseKinematicsBuilder.BodyTypes

NXOpen.AnimationDesigner.InverseKinematicsBuilderBodyTypes is an alias for NXOpen.AnimationDesigner.InverseKinematicsBuilder.BodyTypes 

## ◆ InverseKinematicsBuilderResult

NXOpen.AnimationDesigner.InverseKinematicsBuilder.InverseKinematicsBuilderResult = InverseKinematicsBuilder.Result

NXOpen.AnimationDesigner.InverseKinematicsBuilderResult is an alias for NXOpen.AnimationDesigner.InverseKinematicsBuilder.Result 

Copyright 2025 Siemens
