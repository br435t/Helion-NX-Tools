# NXOpen.AnimationDesigner.FlexibleCableAttachmentBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00110.html>

## Classes

class — AttachmentTypes

the attachment types. More...

class — RotationAxes

the attachment rotation axes. More...

Copyright 2025 Siemens
