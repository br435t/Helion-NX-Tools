# NXOpen.AnimationDesigner.ActivityOperatorBuilder Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00101.html>

## Classes

class — ActionTypes

the active action types. More...

Copyright 2025 Siemens
