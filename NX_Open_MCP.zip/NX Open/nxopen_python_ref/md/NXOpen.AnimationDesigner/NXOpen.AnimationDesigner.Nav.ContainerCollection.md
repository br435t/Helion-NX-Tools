# NXOpen.AnimationDesigner.Nav.ContainerCollection Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a11033.html>

Represents a NXOpen::AnimationDesigner::Nav::ContainerCollection . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.Nav.ContainerCollection:

## Public Member Functions

FindObject (part, name)

Finds the NXOpen::AnimationDesigner::Nav::Container object with the given name. 

## Detailed Description

Represents a NXOpen::AnimationDesigner::Nav::ContainerCollection . 

To obtain an instance of this class, refer to NXOpen::AnimationDesigner::AnimationDesignerManager 

Created in NX2007.0.0 

## Member Function Documentation

## ◆ FindObject()

NXOpen.AnimationDesigner.Nav.ContainerCollection.FindObject
(
part,

name )

Finds the NXOpen::AnimationDesigner::Nav::Container object with the given name. 

Returns
folder (NXOpen.AnimationDesigner.Nav.Container): NXOpen::AnimationDesigner::Nav::Container object with this name. .

Created in NX2007.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer") 
Parameters

part — (NXOpen.Part)

name — (str) The name of the NXOpen::AnimationDesigner::Nav::Container .

Copyright 2025 Siemens
