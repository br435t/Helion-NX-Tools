# NXOpen.AnimationDesigner.ConstraintConversionBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10541.html>

Represents a AnimationDesigner::ConstraintConversionBuilder builder 

To create a new instance of this class, use NXOpen::AnimationDesigner::AnimationDesignerManager::CreateConstraintConversionBuilder 

More...

Inheritance diagram for NXOpen.AnimationDesigner.ConstraintConversionBuilder:

## Public Member Functions

EnableObjectsConversion (self, physics, enable)

Enables the conversion of objects. 

GetTentativeAssemblyNames (self)

Returns the tentatively converting assembly names. 

GetTentativePhysics (self)

Returns the tentatively converting physics objects. 

SetAssemblyObjectType (self, type)

Sets the assembly object type to convert. 

TentativelyConvert (self)

Tentatively converts assembly constraints. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

ConstraintConversionBuilderAssemblyObjectTypes = ConstraintConversionBuilder.AssemblyObjectTypes

NXOpen.AnimationDesigner.ConstraintConversionBuilderAssemblyObjectTypes is an alias for NXOpen.AnimationDesigner.ConstraintConversionBuilder.AssemblyObjectTypes 

## Detailed Description

Represents a AnimationDesigner::ConstraintConversionBuilder builder 

To create a new instance of this class, use NXOpen::AnimationDesigner::AnimationDesignerManager::CreateConstraintConversionBuilder 

Created in NX12.0.0 

## Member Function Documentation

## ◆ EnableObjectsConversion()

NXOpen.AnimationDesigner.ConstraintConversionBuilder.EnableObjectsConversion
(
self,

physics,

enable )

Enables the conversion of objects. 

If it is impossible, the objects will keep unable status.

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

physics — (List[NXOpen.NXObject])

enable — (bool)

## ◆ GetTentativeAssemblyNames()

NXOpen.AnimationDesigner.ConstraintConversionBuilder.GetTentativeAssemblyNames
(
self — )

Returns the tentatively converting assembly names. 

Returns
assNames (List[str]): .

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer") 

## ◆ GetTentativePhysics()

NXOpen.AnimationDesigner.ConstraintConversionBuilder.GetTentativePhysics
(
self — )

Returns the tentatively converting physics objects. 

Returns
physics (List[NXOpen.NXObject]): .

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer") 

## ◆ SetAssemblyObjectType()

NXOpen.AnimationDesigner.ConstraintConversionBuilder.SetAssemblyObjectType
(
self,

type )

Sets the assembly object type to convert. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

type — (NXOpen.AnimationDesigner.ConstraintConversionBuilder.AssemblyObjectTypes)

## ◆ TentativelyConvert()

NXOpen.AnimationDesigner.ConstraintConversionBuilder.TentativelyConvert
(
self — )

Tentatively converts assembly constraints. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer") 

## Member Data Documentation

## ◆ ConstraintConversionBuilderAssemblyObjectTypes

NXOpen.AnimationDesigner.ConstraintConversionBuilder.ConstraintConversionBuilderAssemblyObjectTypes = ConstraintConversionBuilder.AssemblyObjectTypes

NXOpen.AnimationDesigner.ConstraintConversionBuilderAssemblyObjectTypes is an alias for NXOpen.AnimationDesigner.ConstraintConversionBuilder.AssemblyObjectTypes 

Copyright 2025 Siemens
