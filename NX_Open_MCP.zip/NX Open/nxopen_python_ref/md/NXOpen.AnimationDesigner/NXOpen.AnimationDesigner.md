# NXOpen.AnimationDesigner Namespace Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a00100.html>

Classes, Enums and Structs under NXOpen.AnimationDesigner namespace. 
More...

## Namespaces

namespace — ActivityOperatorBuilder

namespace — AnimatedCameraBuilder

namespace — AnimatedColorBuilder

namespace — AnimatedExplodeBuilder

namespace — AnimatedVisibilityBuilder

namespace — AnimationDesignerManager

namespace — BulletCableBuilder

namespace — ConstraintConversionBuilder

namespace — CouplerBuilder

namespace — FlexibleCableAttachmentBuilder

namespace — FlexibleCableBuilder

namespace — GearBuilder

namespace — InverseKinematicsBuilder

namespace — MeasureBuilder

namespace — MechanicalCamBuilder

namespace — Nav

Classes, Enums and Structs under NXOpen.AnimationDesigner.Nav namespace. 

namespace — PathConstraintFrameBuilder

namespace — PathConstraintJointBuilder

namespace — PhysicsJointBuilder

namespace — PointOnCurveKinematicsChainBuilder

namespace — PositionMotorBuilder

namespace — PreferencesBuilder

namespace — RigidGroupBuilder

namespace — SpeedMotorBuilder

## Classes

class — ActivityOperator

Represents a Activity Operator feature. More...

class — ActivityOperatorBuilder

Represents a NXOpen::AnimationDesigner::ActivityOperatorBuilder . More...

class — ActivityOperatorCollection

Represents a collection of Activity Operator objects. More...

class — AnimatedCamera

Represents an Animated Camera feature. More...

class — AnimatedCameraBuilder

Represents a NXOpen::AnimationDesigner::AnimatedCameraBuilder . More...

class — AnimatedCameraCollection

Represents a collection of Animated Camera objects. More...

class — AnimatedColor

Represents an Animated Color feature. More...

class — AnimatedColorBuilder

Represents a NXOpen::AnimationDesigner::AnimatedColorBuilder . More...

class — AnimatedColorCollection

Represents a collection of Animated Color objects. More...

class — AnimatedExplode

Represents an animated explode feature. More...

class — AnimatedExplodeBuilder

Represents a NXOpen::AnimationDesigner::AnimatedExplodeBuilder . More...

class — AnimatedExplodeCollection

Represents a collection of Animated Explode objects. More...

class — AnimatedVisibility

Represents an Animated Visibility feature. More...

class — AnimatedVisibilityBuilder

Represents a NXOpen::AnimationDesigner::AnimatedVisibilityBuilder . More...

class — AnimatedVisibilityCollection

Represents a collection of Animated Visibility objects. More...

class — AnimationDesignerManager

Represents an object to manage Animation Designer application objects. More...

class — BondJoint

Represents a Bond Joint feature. More...

class — BondJointBuilder

Represents a NXOpen::AnimationDesigner::BondJointBuilder . More...

class — BondJointCollection

Represents a collection of Bond Joint objects. More...

class — BulletCable

Represents a Bullet Cable feature. More...

class — BulletCableAttachmentBuilder

Represents a NXOpen::AnimationDesigner::BulletCableAttachmentBuilder . More...

class — BulletCableAttachmentBuilderList

Represents a list of objects. More...

class — BulletCableBuilder

Represents a NXOpen::AnimationDesigner::BulletCableBuilder . More...

class — BulletCableCollection

Represents a collection of Bullet Cable object. More...

class — BulletFlexibleMaterial

Represents a Bullet Flexible Material feature. More...

class — BulletFlexibleMaterialBuilder

Represents a NXOpen::AnimationDesigner::BulletFlexibleMaterialBuilder . More...

class — BulletFlexibleMaterialCollection

Represents a collection of Bullet Flexible Material object. More...

class — ConstraintConversionBuilder

Represents a AnimationDesigner::ConstraintConversionBuilder builder 

To create a new instance of this class, use NXOpen::AnimationDesigner::AnimationDesignerManager::CreateConstraintConversionBuilder 

More...

class — Contact

Represents a Contact feature. More...

class — ContactBuilder

Represents a NXOpen::AnimationDesigner::ContactBuilder . More...

class — ContactCollection

Represents a collection of Contact objects. More...

class — Convention

Specifies convention of Euler angle 

Enumerator — Comment

Xyz

Xzy

Yxz

Yzx

Zxy

Zyx

Xyx

Xzx

Yxy

Yzy

Zxz

Zyz

More...

class — Coupler

Represents the Animation Designer coupler class. More...

class — CouplerBuilder

Represents a base builder for Couplers. More...

class — CurveOnCurveJoint

Represents a Curve On Curve Joint feature. More...

class — CurveOnCurveJointBuilder

Represents a NXOpen::AnimationDesigner::CurveOnCurveJointBuilder . More...

class — CurveOnCurveJointCollection

Represents a collection of Curve On Curve Joint objects. More...

class — CylindricalJoint

Represents a Cylindrical Joint feature. More...

class — CylindricalJointBuilder

Represents a NXOpen::AnimationDesigner::CylindricalJointBuilder . More...

class — CylindricalJointCollection

Represents a collection of Cylindrical Joint objects. More...

class — ExportTraceBuilder

Represents a builder to export a trace from NXOpen::AnimationDesigner::Tracer . More...

class — FixedJoint

Represents a Fixed Joint feature. More...

class — FixedJointBuilder

Represents a NXOpen::AnimationDesigner::FixedJointBuilder . More...

class — FixedJointCollection

Represents a collection of Fixed Joint objects. More...

class — FlexibleCable

Represents a Flexible Cable feature. More...

class — FlexibleCableAttachmentBuilder

Represents a NXOpen::AnimationDesigner::FlexibleCableAttachmentBuilder . More...

class — FlexibleCableAttachmentBuilderList

Represents a list of objects. More...

class — FlexibleCableBuilder

Represents a NXOpen::AnimationDesigner::FlexibleCableBuilder . More...

class — FlexibleCableCollection

Represents a collection of Flexible Cable object. More...

class — FlexibleMaterial

Represents a Flexible Material feature. More...

class — FlexibleMaterialBuilder

Represents a NXOpen::AnimationDesigner::FlexibleMaterialBuilder . More...

class — FlexibleMaterialCollection

Represents a collection of Flexible Material object. More...

class — Gear

Represents a Gear feature. More...

class — GearBuilder

Represents a NXOpen::AnimationDesigner::GearBuilder . More...

class — GearCollection

Represents a collection of Gear objects. More...

class — InverseKinematics

Represents the Inverse Kinematics class. More...

class — InverseKinematicsBuilder

Represents a AnimationDesigner::InverseKinematicsBuilder 

To create a new instance of this class, use NXOpen::AnimationDesigner::InverseKinematicsCollection::CreateInverseKinematicsBuilder 

More...

class — InverseKinematicsCollection

Represents a collection of Inverse Kinematics. More...

class — JointJogger

Represents a Joint Jogger feature. More...

class — JointJoggerBuilder

Represents a NXOpen::AnimationDesigner::JointJoggerBuilder . More...

class — JointJoggerCollection

Represents a collection of Joint Jogger objects. More...

class — Measure

Represents a Measure feature. More...

class — MeasureBuilder

Represents a NXOpen::AnimationDesigner::MeasureBuilder . More...

class — MeasureCollection

Represents a collection of Measure objects. More...

class — MechanicalCam

Represents a Mechanical Cam feature. More...

class — MechanicalCamBuilder

Represents a NXOpen::AnimationDesigner::MechanicalCamBuilder . More...

class — MechanicalCamCollection

Represents a collection of Mechanical Cam objects. More...

class — Motor

Represents the Animation Designer motor class. More...

class — MotorBuilder

Represents a base builder for Motor. More...

class — PathConstraintFrameBuilder

Represents a frame that constrains the orientation along the path curve. More...

class — PathConstraintFrameBuilderList

Represents a list of objects. More...

class — PathConstraintJoint

Represents a Path Constraint Joint feature. More...

class — PathConstraintJointBuilder

Represents a NXOpen::AnimationDesigner::PathConstraintJoint builder. More...

class — PathConstraintJointCollection

Represents a collection of Path Constraint Joint objects. More...

class — PhysicsJoint

Represents the Animation Designer joint class. More...

class — PhysicsJointBuilder

Represents a base builder for Physics Joints. More...

class — PlanarJoint

Represents a Planar Joint feature. More...

class — PlanarJointBuilder

Represents a NXOpen::AnimationDesigner::PlanarJointBuilder . More...

class — PlanarJointCollection

Represents a collection of Planar Joint objects. More...

class — PointOnCurveJoint

Represents a Point On Curve Joint feature. More...

class — PointOnCurveJointBuilder

Represents a NXOpen::AnimationDesigner::PointOnCurveJoint builder. More...

class — PointOnCurveJointCollection

Represents a collection of Point On Curve Joint objects. More...

class — PointOnCurveKinematicsChain

Represents a Point On Curve Kinematics Chain feature. More...

class — PointOnCurveKinematicsChainBuilder

Represents a NXOpen::AnimationDesigner::PointOnCurveKinematicsChainBuilder . More...

class — PointOnCurveKinematicsChainCollection

Represents a collection of Point On Curve Kinematics Chain objects. More...

class — PositionMotor

Represents a Position Motor feature. More...

class — PositionMotorBuilder

Represents a NXOpen::AnimationDesigner::PositionMotorBuilder . More...

class — PositionMotorCollection

Represents a collection of Position Motor objects. More...

class — PreferencesBuilder

Represents a NXOpen::AnimationDesigner::PreferencesBuilder builder. More...

class — RackPinion

Represents a Rack Pinion feature. More...

class — RackPinionBuilder

Represents a NXOpen::AnimationDesigner::RackPinionBuilder . More...

class — RackPinionCollection

Represents a collection of Rack Pinion objects. More...

class — RevoluteJoint

Represents a Revolute Joint feature. More...

class — RevoluteJointBuilder

Represents a NXOpen::AnimationDesigner::RevoluteJointBuilder . More...

class — RevoluteJointCollection

Represents a collection of Revolute Joint objects. More...

class — RigidGroup

Represents a Rigid Group feature. More...

class — RigidGroupBuilder

Represents a NXOpen::AnimationDesigner::RigidGroupBuilder . More...

class — RigidGroupCollection

Represents a collection of Rigid Group objects. More...

class — ScrewJoint

Represents a Screw Joint feature. More...

class — ScrewJointBuilder

Represents a NXOpen::AnimationDesigner::ScrewJointBuilder . More...

class — ScrewJointCollection

Represents a collection of Screw Joint objects. More...

class — SliderJoint

Represents a Slider Joint feature. More...

class — SliderJointBuilder

Represents a NXOpen::AnimationDesigner::SliderJointBuilder . More...

class — SliderJointCollection

Represents a collection of Slider Joint objects. More...

class — SpeedMotor

Represents a Speed Motor feature. More...

class — SpeedMotorBuilder

Represents a NXOpen::AnimationDesigner::SpeedMotorBuilder . More...

class — SpeedMotorCollection

Represents a collection of Speed Motor objects. More...

class — SphericalJoint

Represents a Spherical Joint feature. More...

class — SphericalJointBuilder

Represents a AnimationDesigner::SphericalJointBuilder builder 

To create a new instance of this class, use NXOpen::AnimationDesigner::SphericalJointCollection::CreateSphericalJointBuilder 

More...

class — SphericalJointCollection

Represents a collection of Spherical Joint objects. More...

class — Tracer

Represents the Tracer class. More...

class — TracerBuilder

Represents a AnimationDesigner::Tracer builder 

To create a new instance of this class, use NXOpen::AnimationDesigner::TracerCollection::CreateTracerBuilder 

More...

class — TracerCollection

Represents a collection of Tracer. More...

## Detailed Description

Classes, Enums and Structs under NXOpen.AnimationDesigner namespace. 

Copyright 2025 Siemens
