# NXOpen.AnimationDesigner.CurveOnCurveJointBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10577.html>

Represents a NXOpen::AnimationDesigner::CurveOnCurveJointBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.CurveOnCurveJointBuilder:

## Public Member Functions

AxisVector (self)

Getter for property: (NXOpen.Direction) AxisVector Returns the axis vector which is tangent to the connected curve at the selected point. 

AxisVector (self, axisVector)

Setter for property: (NXOpen.Direction) AxisVector. 

EvaluatePath (self, curves)

Evaluates the path. 

GetConnectedCurve (self)

Gets the connected curve which the attachment will move along. 

GetSectionCurve (self)

Gets the section curve which belong to the attachment. 

Offset (self)

Getter for property: (NXOpen.Expression) Offset Returns the offset specifies the "Zero Point" on the curve whose distance to the point along the curve is the offset value. 

PointOnCurve (self)

Getter for property: (NXOpen.Point) PointOnCurve Returns the selected point on curve. 

PointOnCurve (self, pointOnCurve)

Setter for property: (NXOpen.Point) PointOnCurve. 

SetConnectedCurve (self, curves)

Sets the connected curve which the attachment will move along. 

SetSectionCurve (self, curves)

Sets the section curve which belong to the attachment. 

Sliding (self)

Getter for property: (bool) Sliding Returns the sliding flag. 

Sliding (self, sliding)

Setter for property: (bool) Sliding. 

Public Member Functions inherited from NXOpen.AnimationDesigner.PhysicsJointBuilder

AttachmentList (self)

Getter for property: (NXOpen.SelectNXObjectList) AttachmentList Returns the attachment list for a Joint. 

BaseList (self)

Getter for property: (NXOpen.SelectNXObjectList) BaseList Returns the base list for a Joint. 

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

ColorOption (self)

Getter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions) ColorOption Returns the color options. 

ColorOption (self, colorOption)

Setter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions) ColorOption. 

MotionType (self)

Getter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes) MotionType Returns the motion type. 

MotionType (self, motionType)

Setter for property: (NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes) MotionType. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Additional Inherited Members

Public Attributes inherited from NXOpen.AnimationDesigner.PhysicsJointBuilder

PhysicsJointBuilderColorOptions = PhysicsJointBuilder.ColorOptions

NXOpen.AnimationDesigner.PhysicsJointBuilderColorOptions is an alias for NXOpen.AnimationDesigner.PhysicsJointBuilder.ColorOptions 

PhysicsJointBuilderMotionTypes = PhysicsJointBuilder.MotionTypes

NXOpen.AnimationDesigner.PhysicsJointBuilderMotionTypes is an alias for NXOpen.AnimationDesigner.PhysicsJointBuilder.MotionTypes 

## Detailed Description

Represents a NXOpen::AnimationDesigner::CurveOnCurveJointBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::CurveOnCurveJointCollection::CreateCurveOnCurveJointBuilder 

Created in NX12.0.0 

## Member Function Documentation

## ◆ AxisVector() [1/2]

NXOpen.AnimationDesigner.CurveOnCurveJointBuilder.AxisVector
(
self — )

Getter for property: (NXOpen.Direction) AxisVector Returns the axis vector which is tangent to the connected curve at the selected point. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Direction 

## ◆ AxisVector() [2/2]

NXOpen.AnimationDesigner.CurveOnCurveJointBuilder.AxisVector
(
self,

axisVector )

Setter for property: (NXOpen.Direction) AxisVector. 

Sets the axis vector which is tangent to the connected curve at the selected point.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ EvaluatePath()

NXOpen.AnimationDesigner.CurveOnCurveJointBuilder.EvaluatePath
(
self,

curves )

Evaluates the path. 

If there is no path, create it, otherwise evaluate it.

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

curves — (List[NXOpen.NXObject]) curve or edge

## ◆ GetConnectedCurve()

NXOpen.AnimationDesigner.CurveOnCurveJointBuilder.GetConnectedCurve
(
self — )

Gets the connected curve which the attachment will move along. 

Returns
curves (List[NXOpen.NXObject]): curve or edge .

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer") 

## ◆ GetSectionCurve()

NXOpen.AnimationDesigner.CurveOnCurveJointBuilder.GetSectionCurve
(
self — )

Gets the section curve which belong to the attachment. 

Returns
curves (List[NXOpen.NXObject]): curve or edge .

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer") 

## ◆ Offset()

NXOpen.AnimationDesigner.CurveOnCurveJointBuilder.Offset
(
self — )

Getter for property: (NXOpen.Expression) Offset Returns the offset specifies the "Zero Point" on the curve whose distance to the point along the curve is the offset value. 

Zero Point is on the opposite direction of the axis with respect to the point on the curve.

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ PointOnCurve() [1/2]

NXOpen.AnimationDesigner.CurveOnCurveJointBuilder.PointOnCurve
(
self — )

Getter for property: (NXOpen.Point) PointOnCurve Returns the selected point on curve. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Point 

## ◆ PointOnCurve() [2/2]

NXOpen.AnimationDesigner.CurveOnCurveJointBuilder.PointOnCurve
(
self,

pointOnCurve )

Setter for property: (NXOpen.Point) PointOnCurve. 

Sets the selected point on curve.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ SetConnectedCurve()

NXOpen.AnimationDesigner.CurveOnCurveJointBuilder.SetConnectedCurve
(
self,

curves )

Sets the connected curve which the attachment will move along. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

curves — (List[NXOpen.NXObject]) curve or edge

## ◆ SetSectionCurve()

NXOpen.AnimationDesigner.CurveOnCurveJointBuilder.SetSectionCurve
(
self,

curves )

Sets the section curve which belong to the attachment. 

Created in NX12.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

curves — (List[NXOpen.NXObject]) curve or edge

## ◆ Sliding() [1/2]

NXOpen.AnimationDesigner.CurveOnCurveJointBuilder.Sliding
(
self — )

Getter for property: (bool) Sliding Returns the sliding flag. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
bool 

## ◆ Sliding() [2/2]

NXOpen.AnimationDesigner.CurveOnCurveJointBuilder.Sliding
(
self,

sliding )

Setter for property: (bool) Sliding. 

Sets the sliding flag.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Copyright 2025 Siemens
