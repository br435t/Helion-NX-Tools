# NXOpen.AnimationDesigner.AnimatedVisibilityBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10453.html>

Represents a NXOpen::AnimationDesigner::AnimatedVisibilityBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.AnimatedVisibilityBuilder:

## Public Member Functions

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

ColorOption (self)

Getter for property: (NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.ColorOptions) ColorOption Returns the color option. 

ColorOption (self, colorOption)

Setter for property: (NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.ColorOptions) ColorOption. 

CreateBar (self, index)

Creates a new bar. 

CreationType (self)

Getter for property: (NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.CreationTypes) CreationType Returns the creation type. 

CreationType (self, creationType)

Setter for property: (NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.CreationTypes) CreationType. 

DeleteBars (self, bars)

Deletes the bars. 

MirrorBars (self, bars, mirror_time)

Mirrors the bars. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

RigidGroup (self)

Getter for property: (NXOpen.SelectNXObjectList) RigidGroup Returns the rigid group to display translucency. 

SetBarEndTime (self, index, end_time)

Sets the bar end time. 

SetBarEndTranslucency (self, index, translucency)

Sets the bar end translucency. 

SetBarName (self, index, name)

Sets the bar name. 

SetBarStartTime (self, index, start_time)

Sets the bar start time. 

SetBarStartTranslucency (self, index, translucency)

Sets the bar start translucency. 

SplitBar (self, index, split_time)

Splits the bar with the split time. 

Translucency (self)

Getter for property: (int) Translucency Returns the translucency. 

Translucency (self, translucency)

Setter for property: (int) Translucency. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

AnimatedVisibilityBuilderColorOptions = AnimatedVisibilityBuilder.ColorOptions

NXOpen.AnimationDesigner.AnimatedVisibilityBuilderColorOptions is an alias for NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.ColorOptions 

AnimatedVisibilityBuilderCreationTypes = AnimatedVisibilityBuilder.CreationTypes

NXOpen.AnimationDesigner.AnimatedVisibilityBuilderCreationTypes is an alias for NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.CreationTypes 

## Detailed Description

Represents a NXOpen::AnimationDesigner::AnimatedVisibilityBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::AnimatedVisibilityCollection::CreateAnimatedVisibilityBuilder 

Created in NX1847.0.0 

## Member Function Documentation

## ◆ Color() [1/2]

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.Color
(
self — )

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
NXOpen.NXColor 

## ◆ Color() [2/2]

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.Color
(
self,

color )

Setter for property: (NXOpen.NXColor) Color. 

Sets the color.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

## ◆ ColorOption() [1/2]

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.ColorOption
(
self — )

Getter for property: (NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.ColorOptions) ColorOption Returns the color option. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
AnimatedVisibilityBuilder.ColorOptions 

## ◆ ColorOption() [2/2]

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.ColorOption
(
self,

colorOption )

Setter for property: (NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.ColorOptions) ColorOption. 

Sets the color option.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

## ◆ CreateBar()

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.CreateBar
(
self,

index )

Creates a new bar. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

## ◆ CreationType() [1/2]

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.CreationType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.CreationTypes) CreationType Returns the creation type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
AnimatedVisibilityBuilder.CreationTypes 

## ◆ CreationType() [2/2]

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.CreationType
(
self,

creationType )

Setter for property: (NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.CreationTypes) CreationType. 

Sets the creation type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

## ◆ DeleteBars()

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.DeleteBars
(
self,

bars )

Deletes the bars. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

bars — (List[int])

## ◆ MirrorBars()

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.MirrorBars
(
self,

bars,

mirror_time )

Mirrors the bars. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

bars — (List[int])

mirror_time — (float)

## ◆ Name() [1/2]

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.Name
(
self — )

Getter for property: (str) Name Returns the name. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
str 

## ◆ Name() [2/2]

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.Name
(
self,

name )

Setter for property: (str) Name. 

Sets the name.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

## ◆ RigidGroup()

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.RigidGroup
(
self — )

Getter for property: (NXOpen.SelectNXObjectList) RigidGroup Returns the rigid group to display translucency. 

This can be a NXOpen::AnimationDesigner::RigidGroup .

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
NXOpen.SelectNXObjectList 

## ◆ SetBarEndTime()

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.SetBarEndTime
(
self,

index,

end_time )

Sets the bar end time. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

end_time — (float)

## ◆ SetBarEndTranslucency()

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.SetBarEndTranslucency
(
self,

index,

translucency )

Sets the bar end translucency. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

translucency — (int)

## ◆ SetBarName()

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.SetBarName
(
self,

index,

name )

Sets the bar name. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

name — (str)

## ◆ SetBarStartTime()

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.SetBarStartTime
(
self,

index,

start_time )

Sets the bar start time. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

start_time — (float)

## ◆ SetBarStartTranslucency()

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.SetBarStartTranslucency
(
self,

index,

translucency )

Sets the bar start translucency. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

translucency — (int)

## ◆ SplitBar()

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.SplitBar
(
self,

index,

split_time )

Splits the bar with the split time. 

Created in NX1847.0.0 

License requirements: nx_animationdesigner (" NX Animation Designer")

Parameters

index — (int)

split_time — (float)

## ◆ Translucency() [1/2]

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.Translucency
(
self — )

Getter for property: (int) Translucency Returns the translucency. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

Returns
int 

## ◆ Translucency() [2/2]

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.Translucency
(
self,

translucency )

Setter for property: (int) Translucency. 

Sets the translucency.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX1847.0.0 

## Member Data Documentation

## ◆ AnimatedVisibilityBuilderColorOptions

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.AnimatedVisibilityBuilderColorOptions = AnimatedVisibilityBuilder.ColorOptions

NXOpen.AnimationDesigner.AnimatedVisibilityBuilderColorOptions is an alias for NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.ColorOptions 

## ◆ AnimatedVisibilityBuilderCreationTypes

NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.AnimatedVisibilityBuilderCreationTypes = AnimatedVisibilityBuilder.CreationTypes

NXOpen.AnimationDesigner.AnimatedVisibilityBuilderCreationTypes is an alias for NXOpen.AnimationDesigner.AnimatedVisibilityBuilder.CreationTypes 

Copyright 2025 Siemens
