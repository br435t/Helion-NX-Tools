# NXOpen.AnimationDesigner.GearBuilder Class Reference

<https://docs.sw.siemens.com/documentation/external/PL20241101461013487/en-US/custom_api/nxopen_python_ref/a10669.html>

Represents a NXOpen::AnimationDesigner::GearBuilder . 
More...

Inheritance diagram for NXOpen.AnimationDesigner.GearBuilder:

## Public Member Functions

ChangeDirection (self)

Getter for property: (bool) ChangeDirection Returns the inner gear option. 

ChangeDirection (self, change)

Setter for property: (bool) ChangeDirection. 

ExpressionRatio (self)

Getter for property: (NXOpen.Expression) ExpressionRatio Returns the ratio expression. 

UseType (self)

Getter for property: (NXOpen.AnimationDesigner.GearBuilder.GearType) UseType Returns the gear type. 

UseType (self, useType)

Setter for property: (NXOpen.AnimationDesigner.GearBuilder.GearType) UseType. 

Public Member Functions inherited from NXOpen.AnimationDesigner.CouplerBuilder

Color (self)

Getter for property: (NXOpen.NXColor) Color Returns the color. 

Color (self, color)

Setter for property: (NXOpen.NXColor) Color. 

ColorOption (self)

Getter for property: (NXOpen.AnimationDesigner.CouplerBuilder.ColorOptions) ColorOption Returns the color options. 

ColorOption (self, colorOption)

Setter for property: (NXOpen.AnimationDesigner.CouplerBuilder.ColorOptions) ColorOption. 

MasterAxisJoint (self)

Getter for property: (NXOpen.SelectNXObject) MasterAxisJoint Returns the master axis joint. 

Name (self)

Getter for property: (str) Name Returns the name. 

Name (self, name)

Setter for property: (str) Name. 

SlaveAxisJoint (self)

Getter for property: (NXOpen.SelectNXObject) SlaveAxisJoint Returns the slave axis joint. 

Public Member Functions inherited from NXOpen.Builder

Commit (self)

Commits any edits that have been applied to the builder. 

Destroy (self)

Deletes the builder, and cleans up any objects created by the builder. 

GetCommittedObjects (self)

For builders that create more than one object, this method returns the objects that are created by commit. 

GetObject (self)

Returns the object currently being edited by this builder. 

PreviewBuilder (self)

Getter for property: (NXOpen.PreviewBuilder) PreviewBuilder Returns the preview builder subobject. 

ShowResults (self)

Updates the model to reflect the result of an edit to the model for all builders that support showing results. 

Public Member Functions inherited from NXOpen.TaggedObject

Tag (self)

Returns the Tag for this object. 

## Public Attributes

GearBuilderGearType = GearBuilder.GearType

NXOpen.AnimationDesigner.GearBuilderGearType is an alias for NXOpen.AnimationDesigner.GearBuilder.GearType 

Public Attributes inherited from NXOpen.AnimationDesigner.CouplerBuilder

CouplerBuilderColorOptions = CouplerBuilder.ColorOptions

NXOpen.AnimationDesigner.CouplerBuilderColorOptions is an alias for NXOpen.AnimationDesigner.CouplerBuilder.ColorOptions 

## Detailed Description

Represents a NXOpen::AnimationDesigner::GearBuilder . 

To create a new instance of this class, use NXOpen::AnimationDesigner::GearCollection::CreateGearBuilder 

Created in NX12.0.0 

## Member Function Documentation

## ◆ ChangeDirection() [1/2]

NXOpen.AnimationDesigner.GearBuilder.ChangeDirection
(
self — )

Getter for property: (bool) ChangeDirection Returns the inner gear option. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
bool 

## ◆ ChangeDirection() [2/2]

NXOpen.AnimationDesigner.GearBuilder.ChangeDirection
(
self,

change )

Setter for property: (bool) ChangeDirection. 

Sets the inner gear option.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## ◆ ExpressionRatio()

NXOpen.AnimationDesigner.GearBuilder.ExpressionRatio
(
self — )

Getter for property: (NXOpen.Expression) ExpressionRatio Returns the ratio expression. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
NXOpen.Expression 

## ◆ UseType() [1/2]

NXOpen.AnimationDesigner.GearBuilder.UseType
(
self — )

Getter for property: (NXOpen.AnimationDesigner.GearBuilder.GearType) UseType Returns the gear type. 

Getter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

Returns
GearBuilder.GearType 

## ◆ UseType() [2/2]

NXOpen.AnimationDesigner.GearBuilder.UseType
(
self,

useType )

Setter for property: (NXOpen.AnimationDesigner.GearBuilder.GearType) UseType. 

Sets the gear type.

Setter License requirements: nx_animationdesigner (" NX Animation Designer")

Created in NX12.0.0 

## Member Data Documentation

## ◆ GearBuilderGearType

NXOpen.AnimationDesigner.GearBuilder.GearBuilderGearType = GearBuilder.GearType

NXOpen.AnimationDesigner.GearBuilderGearType is an alias for NXOpen.AnimationDesigner.GearBuilder.GearType 

Copyright 2025 Siemens
