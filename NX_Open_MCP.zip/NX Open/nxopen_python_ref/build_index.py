#!/usr/bin/env python3
"""Build a local BM25 keyword index over chunks.jsonl — pure stdlib, no
downloads, no API key. Ideal for API-reference lookup where exact class and
method names dominate. Persists to bm25_index.pkl.

Usage:  py build_index.py
"""
import json, os, sys, math, pickle, collections

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from nxopen_rag import tokenize   # single source of truth for tokenization

CHUNKS = os.path.join(HERE, "chunks.jsonl")
INDEX  = os.path.join(HERE, "bm25_index.pkl")

def main():
    # Index the Doxygen corpus plus, if present, the parsed .pyi stubs.
    sources = [CHUNKS]
    stubs = os.path.join(HERE, "stub_chunks.jsonl")
    if os.path.exists(stubs):
        sources.append(stubs)

    docs, meta = [], []
    for src in sources:
        for line in open(src, encoding="utf-8"):
            r = json.loads(line)
            docs.append(tokenize(r["text"]))
            meta.append({"id": r["id"], "text": r["text"], "name": r["name"],
                         "module": r["module"], "kind": r["kind"], "url": r["url"],
                         "section": r["section"], "source": r.get("source", "doxygen")})
    print("indexing sources: " + ", ".join(os.path.basename(s) for s in sources))
    N = len(docs)
    df = collections.Counter()
    for d in docs:
        for t in set(d):
            df[t] += 1
    idf = {t: math.log(1 + (N - n + 0.5) / (n + 0.5)) for t, n in df.items()}
    doc_len = [len(d) for d in docs]
    avgdl = sum(doc_len) / N
    # postings: term -> list of (doc_idx, term_freq)
    postings = collections.defaultdict(list)
    for i, d in enumerate(docs):
        for t, tf in collections.Counter(d).items():
            postings[t].append((i, tf))

    with open(INDEX, "wb") as f:
        pickle.dump({"idf": idf, "postings": dict(postings), "doc_len": doc_len,
                     "avgdl": avgdl, "N": N, "meta": meta}, f,
                    protocol=pickle.HIGHEST_PROTOCOL)
    size_mb = os.path.getsize(INDEX) / 1e6
    print(f"indexed {N} chunks, {len(idf)} unique terms -> bm25_index.pkl ({size_mb:.0f} MB)")

if __name__ == "__main__":
    main()
