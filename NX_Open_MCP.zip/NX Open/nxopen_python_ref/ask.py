#!/usr/bin/env python3
"""Ask NXOpen API questions with BM25 retrieval + Claude (one-shot CLI).

Thin wrapper over nxopen_rag.NXOpenRAG — see that module to call from code.

Usage:
    py ask.py "How do I create a block feature?"
    py ask.py -k 12 --show-sources "What methods does NXOpen.Session expose?"
    py ask.py --retrieve-only "block feature builder"   # offline, no LLM/key

Auth: set ANTHROPIC_API_KEY, or `ant auth login`. Behind a TLS-inspecting proxy,
set SSL_CERT_FILE to your corporate root CA.
"""
import os, sys, argparse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from nxopen_rag import NXOpenRAG

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("question", nargs="+")
    ap.add_argument("-k", type=int, default=8, help="chunks to retrieve")
    ap.add_argument("--show-sources", action="store_true")
    ap.add_argument("--retrieve-only", action="store_true", help="skip the LLM call")
    ap.add_argument("--text", action="store_true",
                    help="with --retrieve-only, print full chunk text (signatures + docstrings)")
    args = ap.parse_args()
    question = " ".join(args.question)

    rag = NXOpenRAG()

    if args.retrieve_only:
        for h in rag.search(question, args.k):
            src = "stub" if h.get("source") == "stub" else "doc"
            if args.text:
                print(f"### [{src}] {h['name']}  ({h['score']:.1f})  {h['url']}\n{h['text']}\n")
            else:
                print(f"{h['score']:6.2f}  {src:4s} {h['name']:42s} {h['section'][:34]:34s} {h['url']}")
        return

    result = rag.ask(question, k=args.k)
    print(result["answer"])
    if args.show_sources:
        print("\n─── retrieved sources ───")
        for s in result["sources"]:
            print(f"  {s['score']:6.2f}  {s['name']}  {s['url']}")

if __name__ == "__main__":
    main()
