#!/usr/bin/env python3
"""Chunk corpus.jsonl into retrieval-sized pieces for RAG.

Strategy:
  - Doxygen class pages have a "## ◆ Method()" section per member — each becomes one chunk.
  - The text before the member documentation becomes an "overview" chunk.
  - Namespace pages and pages without member sections are windowed by size.
Each chunk carries metadata (name, module, kind, url) and is prefixed with a
context header so the embedding captures which class/namespace it belongs to.
"""
import re, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
IN  = os.path.join(HERE, "corpus.jsonl")
OUT = os.path.join(HERE, "chunks.jsonl")

MAX_CHARS = 1800   # window size for prose without member sections
OVERLAP   = 200

def windows(text, size=MAX_CHARS, overlap=OVERLAP):
    text = text.strip()
    if len(text) <= size:
        return [text] if text else []
    out, i = [], 0
    while i < len(text):
        out.append(text[i:i+size])
        i += size - overlap
    return out

def split_members(text):
    """Return (overview_text, [(method_title, method_body), ...])."""
    # Member docs begin at "## Member Function Documentation"; individual
    # members are "## ◆ Name()" subsections.
    parts = re.split(r'\n## ◆ ', text)
    overview = parts[0]
    members = []
    for p in parts[1:]:
        line, _, body = p.partition('\n')
        members.append((line.strip(), body.strip()))
    # Trim the "## Member Function Documentation" tail off the overview
    overview = re.split(r'\n## Member Function Documentation', overview)[0].strip()
    return overview, members

def main():
    n_in = n_chunks = 0
    with open(IN, encoding="utf-8") as f, open(OUT, "w", encoding="utf-8") as out:
        for line in f:
            rec = json.loads(line)
            n_in += 1
            name, module, kind, url = rec["name"], rec["module"], rec["kind"], rec["url"]
            text = rec["text"]
            chunks = []  # (section_title, body)

            overview, members = split_members(text)
            if members:
                if overview:
                    for w in windows(overview):
                        chunks.append(("overview", w))
                for title, body in members:
                    # Keep whole method unless very large
                    if len(body) <= MAX_CHARS * 2:
                        chunks.append((title, body))
                    else:
                        for w in windows(body):
                            chunks.append((title, w))
            else:
                for w in windows(text):
                    chunks.append(("overview", w))

            for i, (title, body) in enumerate(chunks):
                header = f"{name} ({kind})"
                if title != "overview":
                    header += f" — {title}"
                chunk_text = f"{header}\n{body}".strip()
                out.write(json.dumps({
                    "id": f"{rec['file']}#{i}",
                    "text": chunk_text,
                    "name": name, "module": module, "kind": kind,
                    "url": url, "section": title,
                }, ensure_ascii=False) + "\n")
                n_chunks += 1
    print(f"pages={n_in}  chunks={n_chunks}  avg={n_chunks/n_in:.1f} chunks/page")

if __name__ == "__main__":
    main()
