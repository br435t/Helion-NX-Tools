# Using the NXOpen knowledge base as an MCP server for Claude

This exposes the local NXOpen Python API knowledge base (Siemens NX 2506) to Claude
as a **Model Context Protocol (MCP)** tool. Claude calls `search_nxopen(...)` and
gets back exact Python signatures (from the `.pyi` stubs) and prose docs (from the
Doxygen reference), each tagged with its source.

The server runs locally over **stdio** and is **retrieval-only — no API key, no
network**. It sidesteps the corporate TLS proxy entirely (that only affects `pip`
and the optional Claude-calling scripts, not this tool).

- Server: `nxopen_python_ref/nxopen_mcp.py`
- Tool: `search_nxopen`

---

## 1. Prerequisites

- The prebuilt index `nxopen_python_ref/bm25_index.pkl` exists (it does).
- Python launcher `py` is on PATH (Windows default).
- The MCP SDK is installed in that Python:

```sh
py -m pip install mcp
# behind the Helion TLS-inspecting proxy:
py -m pip install --trusted-host pypi.org --trusted-host files.pythonhosted.org mcp
```

Sanity check (starts the server; it waits silently on stdio — press Ctrl-C):

```sh
py "C:\Code\NX Open\nxopen_python_ref\nxopen_mcp.py"
```

---

## 2a. Register with Claude Code

Add the server (default scope is the current project, which writes a `.mcp.json`):

```sh
claude mcp add nxopen -- py "C:\Code\NX Open\nxopen_python_ref\nxopen_mcp.py"
```

Flags: `-s user` makes it available in every project; `-s project` (default) shares
it with the repo via `.mcp.json`. Check and remove with:

```sh
claude mcp list
claude mcp remove nxopen
```

Or hand-write `.mcp.json` in the project root:

```json
{
  "mcpServers": {
    "nxopen": {
      "command": "py",
      "args": ["C:\\Code\\NX Open\\nxopen_python_ref\\nxopen_mcp.py"]
    }
  }
}
```

Restart the Claude Code session (or `/mcp` to reconnect) so the tool loads.

---

## 2b. Register with Claude Desktop

Edit `%APPDATA%\Claude\claude_desktop_config.json` (create it if missing):

```json
{
  "mcpServers": {
    "nxopen": {
      "command": "py",
      "args": ["C:\\Code\\NX Open\\nxopen_python_ref\\nxopen_mcp.py"]
    }
  }
}
```

Fully quit and reopen Claude Desktop. The `nxopen` server appears under the
tools/plug icon; expand it to confirm `search_nxopen` is listed.

---

## 3. Use it

Just ask Claude NXOpen questions — it decides to call `search_nxopen` and answers
from the retrieved signatures. Examples:

- "How do I create a block feature in NXOpen? Show the exact builder call."
- "What methods does NXOpen.Session expose for the work part?"
- "Write an NX journal that extrudes a selected sketch."

### Tool reference — `search_nxopen`

| Arg | Type | Default | Meaning |
|-----|------|---------|---------|
| `query` | string | — | Class/method names or concepts. camelCase is split, so natural language matches (`"CreateExtrudeBuilder"`, `"extrude sketch section"`). |
| `k` | int | 8 | Number of results (1–40). Raise for broad coverage or many overloads. |
| `module` | string | "" | Optional dotted-prefix filter, e.g. `"NXOpen.CAM"` or `"NXOpen.Features"`. |

Each result is tagged `[stub signature]` (exact types) or `[reference]` (prose +
"Created in NX…", license requirements) with its source path/URL.

---

## 4. Troubleshooting

- **Tool doesn't appear:** MCP config only loads on a **new** session — restart
  Claude Code/Desktop after registering.
- **Server fails to start / "No module named mcp":** the `mcp` package isn't in the
  Python that `py` runs — re-run the install in step 1.
- **"No module named nxopen_rag" / index errors:** run the server by its full path
  (it resolves siblings relative to itself); confirm `bm25_index.pkl` is present.
- **Wrong Python picked up:** replace `py` in the config with the full interpreter
  path, e.g. `C:\\Users\\br435t\\AppData\\Local\\Programs\\Python\\Python312\\python.exe`.
- **Don't add `ANTHROPIC_API_KEY` or proxy certs** for this — retrieval needs
  neither. Those only matter for `ask.py`/`chat.py` when *you* run them standalone.

---

## Why retrieval-only (no "answer" tool)

In MCP, Claude is already the model. A tool that made its own Claude call would be a
wasteful nested LLM and would drag in the API key + corporate-TLS requirements. So
the server just returns the real API surface and lets the calling Claude reason and
cite. If you later need this shared across machines/teammates, ask for an HTTP/SSE
variant instead of stdio.
